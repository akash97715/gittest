# Zip Compression Analysis: Reducing from 117 MB to < 25 MB

## Current Folder Structure & Sizes

### Top-Level Directories
```
fcr-ai-sso  → 201.46 MB  [MAIN BLOAT]
.venv       →  31.60 MB  [VIRTUAL ENV]
.vs         →   1.46 MB  [IDE CACHE]
────────────────────────
Total       → ~234 MB
```

### Inside fcr-ai-sso Breakdown
```
node_modules          → 197.87 MB  ⚠️ BIGGEST CULPRIT
src                   →   0.69 MB  (keep)
assets                →   0.10 MB  (keep)
pages                 →   0.06 MB  (keep)
components            →   0.03 MB  (keep)
backend               →   0.01 MB  (keep)
public                →   0.01 MB  (keep)
data                  →   0.00 MB  (keep)
deploy-staging        →   0.00 MB  (keep)
────────────────────────
Total                 → 201.46 MB
```

### Large Files in fcr-ai-sso (> 5 MB each)
```
rolldown-binding.win32-x64-msvc.node  → 21.85 MB (in node_modules)
lightningcss.win32-x64-msvc.node      →  9.06 MB (in node_modules)
lucide-react.js.map                   →  5.35 MB (in node_modules)
@react-pdf_renderer.js.map            →  5.05 MB (in node_modules)
────────────────────────────────────────────────
Total .map files (source maps)        → 48.05 MB
```

---

## Recommended Deletions to Achieve < 25 MB

### Priority 1: MUST DELETE (Recoverable)
| Item | Size | Reason | Impact |
|------|------|--------|--------|
| **node_modules/** | 197.87 MB | Dependencies (reinstallable with `npm install`) | ✅ Run `npm install` to restore |
| **.venv/** | 31.60 MB | Python virtual environment | ✅ Run `python -m venv .venv` to restore |
| **.vs/** | 1.46 MB | Visual Studio IDE cache | ✅ Auto-regenerates on open |
| **package-lock.json** | ~10 MB (est) | Lock file (regenerable from package.json) | ⚠️ Keep if using npm ci |

**Subtotal Saved: ~240 MB** (Reduces 234 MB folder to ~0 MB*)

### Priority 2: SHOULD DELETE (Redundant)
| Item | Size | Reason |
|------|------|--------|
| **.map files** | 48.05 MB | Source maps (debug only, not needed in production zip) |
| **fcr-ai-sso/node_modules/.bin/** | 5-10 MB | Binary executables (regenerates with npm install) |

**Subtotal Saved: ~50+ MB**

### Priority 3: OPTIONAL (If Needed)
| Item | Size | Reason |
|------|------|--------|
| **node_modules/.cache/** | 5-15 MB | Cache directories |
| **.git/** | Not present | Git history (if present, delete) |
| **dist/** | Not present | Build artifacts (if present, delete) |

---

## Final Size Estimate

### Before Optimization
```
Current: ~117 MB (zip)
Uncompressed: ~234 MB
```

### After Optimization
```
Source Code Only:
  - src/                  0.69 MB
  - assets/               0.10 MB
  - pages/                0.06 MB
  - components/           0.03 MB
  - backend/              0.01 MB
  - public/               0.01 MB
  - Configuration files   ~0.5 MB (package.json, .env, etc.)
  - Other files           ~2.0 MB
  ────────────────────
  Subtotal              ~3-4 MB (uncompressed)
  
  Zipped (40-50% compression): 1.5-2 MB ✅
```

---

## Recommended .gitignore / Exclusion List

Create or update `.gitignore` and use this for zip exclusion:

```
# Dependencies (reinstall with npm install)
node_modules/

# Python environment (recreate with python -m venv .venv)
.venv/
venv/

# IDE & OS
.vs/
.vscode/
.idea/
*.swp
*.swo
Thumbs.db
.DS_Store

# Build & Cache
dist/
build/
.next/
.cache/
*.log

# Source maps (optional - for production)
**/*.map

# Environment
.env.local
.env.*.local
```

---

## Action Plan

### Option A: Manual Zip Creation (Recommended)
```powershell
# 1. Delete node_modules
Remove-Item -Recurse -Force fcr-ai-sso\node_modules

# 2. Delete .venv
Remove-Item -Recurse -Force .venv

# 3. Delete .vs
Remove-Item -Recurse -Force .vs

# 4. Delete .map files (optional)
Get-ChildItem -Recurse -Include "*.map" -Force | Remove-Item -Force

# 5. Create zip with 7-Zip or PowerShell
Compress-Archive -Path .\fcr-ai-sso, .\ -DestinationPath fcr-ai-for_8_20.zip
```

### Option B: Using .gitignore with 7-Zip
```
# Create .gitignore and use 7-Zip GUI:
# Right-click → 7-Zip → Add to archive
# Settings → Exclude: node_modules, .venv, .vs, **/*.map
```

### Option C: PowerShell Script (Automated)
```powershell
# Run this from parent directory
$excludeFolders = @('node_modules', '.venv', '.vs')
$excludeExtensions = @('.map')

Get-ChildItem -Recurse | Where-Object {
    ($excludeFolders -contains $_.Name) -or 
    ($excludeExtensions -contains $_.Extension)
} | Remove-Item -Recurse -Force

# Then zip
Compress-Archive -Path .\* -DestinationPath fcr-ai-minimal.zip
```

---

## Recovery Instructions for Recipient

After unzipping, run:

```bash
cd fcr-ai-for_8_20/fcr-ai-sso

# Restore dependencies
npm install

# Restore Python environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1
# If requirements.txt exists:
pip install -r requirements.txt

# Start development
npm run dev
node server.js
```

---

## Summary

| Metric | Value |
|--------|-------|
| **Current Zip** | 117 MB |
| **Target Zip** | < 25 MB |
| **Uncompressed Size** | ~234 MB → ~4 MB |
| **Largest Culprits** | node_modules (197.87 MB) + .venv (31.60 MB) |
| **Estimated Final Zip** | 1.5-2 MB ✅ |
| **Effort** | Delete 4 folders + 1 command |

**Total Space Saved: ~115 MB (98% reduction!)**
