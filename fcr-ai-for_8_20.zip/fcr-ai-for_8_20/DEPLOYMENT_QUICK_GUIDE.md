# 🚀 DEPLOYMENT QUICK GUIDE FOR GIRIDHAR

**Status:** ✅ READY TO DEPLOY  
**Effort:** ~30 minutes for 3 instances  
**Risk:** ⚠️ LOW (telemetry is isolated, never blocks user requests)  

---

## Pre-Deployment Checklist (5 min)

```bash
# 1. Verify all files are committed
git status
# Should show: all telemetry files tracked

# 2. Verify environment variables
cat .env | grep TELEMETRY_
# Should show:
# TELEMETRY_ENABLED=true
# TELEMETRY_TRANSPORT=direct
# TELEMETRY_BATCH_SIZE=10
# TELEMETRY_FLUSH_INTERVAL_MS=30000
# VITE_TELEMETRY_ENABLED=true
# etc.

# 3. Test build locally
npm install
npm run build  # or npm run dev for dev mode

# 4. Verify no errors
npm start &    # Start backend
npm run dev &  # Start frontend
# Check browser console (F12) — should be clean
# Check server logs — should show telemetry initialized
```

---

## Deployment Steps

### Step 1: Deploy to Instance 1 (15 min)

```bash
# SSH into Instance 1
ssh -i your-key.pem ubuntu@instance-1.aws.amazon.com

# Pull latest code
cd /app/fcr-ai-sso
git pull origin main

# Install dependencies (if needed)
npm install

# Restart application
pm2 restart fcr-ai-sso
# OR: systemctl restart fcr-ai-sso
# OR: docker-compose restart

# Verify startup
sleep 10
curl http://localhost:3000/api/ping
# Expected: {"status": "ok"}

# Verify telemetry route exists
curl -X POST http://localhost:3000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{"events": []}'
# Expected: {"received": 0}

# Check logs
pm2 logs fcr-ai-sso | grep -i telemetry
# Should show: "Telemetry initialized" or similar
```

### Step 2: Deploy to Instance 2 (10 min)

```bash
# Repeat Step 1 with Instance 2
ssh -i your-key.pem ubuntu@instance-2.aws.amazon.com
cd /app/fcr-ai-sso
git pull origin main
pm2 restart fcr-ai-sso
sleep 10
curl http://localhost:3000/api/ping
```

### Step 3: Deploy to Instance 3 (10 min)

```bash
# Repeat Step 1 with Instance 3
ssh -i your-key.pem ubuntu@instance-3.aws.amazon.com
cd /app/fcr-ai-sso
git pull origin main
pm2 restart fcr-ai-sso
sleep 10
curl http://localhost:3000/api/ping
```

---

## Post-Deployment Verification (10 min)

### Verify Telemetry Route on All Instances

```bash
# Test valid event
for instance in 1 2 3; do
  echo "=== Instance $instance ==="
  curl -X POST http://instance-$instance.aws.amazon.com:3000/api/telemetry \
    -H "Content-Type: application/json" \
    -d '{"events": [{"event_type": "test_event", "user_id": "test@example.com", "session_id": "test123"}]}'
done

# Expected: {"received": 1} for each
```

### Verify Database Connection

```bash
# From any instance or local machine with Azure access:

# Test PostgreSQL connection
psql -h aiaypd03.postgres.database.azure.com \
     -U sa-its-aiaypd03-fcrai-dev \
     -d fcrai_org \
     -c "SELECT COUNT(*) as event_count FROM telemetry.user_events;"

# Expected output:
#  event_count
# ─────────────
#  N (some number > 0 if events were sent)
```

### Verify Events Are Flowing

```sql
-- Connect to Azure PostgreSQL and run:

-- Count all events
SELECT COUNT(*) FROM telemetry.user_events;

-- Last 10 events
SELECT event_timestamp, user_id, event_type 
FROM telemetry.user_events 
ORDER BY event_timestamp DESC 
LIMIT 10;

-- Events per instance (check if mixed)
SELECT COUNT(*) as count FROM telemetry.user_events 
WHERE event_timestamp > NOW() - INTERVAL '1 hour';

-- Check for duplicates
SELECT COUNT(*) FROM telemetry.kafka_event_tracking;
-- Should be approximately same as user_events (no large difference)
```

---

## Monitoring During Week 4

### Daily Check (2 min)

```bash
# Every morning, run:
psql -h aiaypd03.postgres.database.azure.com \
     -U sa-its-aiaypd03-fcrai-dev \
     -d fcrai_org \
     -c "SELECT COUNT(*) as new_events FROM telemetry.user_events WHERE event_timestamp > NOW() - INTERVAL '24 hours';"

# Expected: > 100 events per day (adjust based on usage)
```

### Weekly Metrics (10 min)

```sql
-- Feature adoption (which features used most)
SELECT event_type, COUNT(*) as usage_count
FROM telemetry.user_events
WHERE event_timestamp > NOW() - INTERVAL '7 days'
GROUP BY event_type
ORDER BY usage_count DESC;

-- Error rate
SELECT COUNT(*) as errors
FROM telemetry.user_events
WHERE event_type = 'error' AND event_timestamp > NOW() - INTERVAL '7 days';

-- Active users
SELECT COUNT(DISTINCT user_id) as active_users
FROM telemetry.user_events
WHERE event_timestamp > NOW() - INTERVAL '7 days';
```

---

## Rollback Procedure (If Needed)

### If telemetry is causing issues:

```bash
# Option 1: Disable telemetry (fastest)
# On each instance, edit .env:
TELEMETRY_ENABLED=false
pm2 restart fcr-ai-sso

# Application continues to work, just no event collection

# Option 2: Rollback code (if urgent)
git revert <commit-hash>
git push
pm2 restart fcr-ai-sso
```

---

## Troubleshooting

### No Events in Database

**Check list:**
1. ✅ TELEMETRY_ENABLED=true in .env
2. ✅ Database credentials correct (test connection manually)
3. ✅ Application started successfully (check logs)
4. ✅ Events being sent (check browser Network tab, F12)

**Fix:**
```bash
# 1. Check app logs
pm2 logs fcr-ai-sso | tail -50

# 2. Check telemetry service initialization
# Look for: "Telemetry service initialized" or similar

# 3. Manually test API endpoint
curl -X POST http://localhost:3000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{"events": [{"event_type": "user_login", "user_id": "test@example.com", "session_id": "test123"}]}'

# Should return 200 with {"received": 1}
```

### Database Connection Error

```bash
# Test connectivity
telnet aiaypd03.postgres.database.azure.com 5432
# Should say "Connected"

# Test credentials
psql -h aiaypd03.postgres.database.azure.com \
     -U sa-its-aiaypd03-fcrai-dev \
     -d fcrai_org \
     -c "SELECT 1"
# Should return "1"

# Check .env credentials match
grep TELEMETRY_DB .env
```

### Performance Issues

**Telemetry should never slow down the app because:**
- Fire-and-forget design (async, no await)
- Batch processing (not writing row-by-row)
- Separate database pool (doesn't compete with Redshift)

If you see slowdowns:
1. Check connection pool size: `TELEMETRY_BATCH_SIZE` should be 10
2. Check flush interval: `TELEMETRY_FLUSH_INTERVAL_MS` should be 30000
3. Verify database isn't overloaded: `SELECT COUNT(*) FROM telemetry.user_events;`

---

## Commands Cheat Sheet

```bash
# Start app (all instances same)
cd /app/fcr-ai-sso
npm install
npm start              # Backend
npm run dev            # Frontend (separate window)

# Check logs
pm2 logs fcr-ai-sso
pm2 logs fcr-ai-sso | grep telemetry

# Restart all
pm2 restart all

# Check status
pm2 status

# Database query from local machine
psql -h aiaypd03.postgres.database.azure.com \
     -U sa-its-aiaypd03-fcrai-dev \
     -d fcrai_org \
     -c "SELECT COUNT(*) FROM telemetry.user_events;"

# Test telemetry endpoint
curl -X POST http://localhost:3000/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{"events": []}'

# Monitor in real-time
watch -n 5 "psql -h aiaypd03.postgres.database.azure.com -U sa-its-aiaypd03-fcrai-dev -d fcrai_org -c 'SELECT COUNT(*) FROM telemetry.user_events;'"
```

---

## Timeline & Expectations

| Time | Action | Expected Result |
|------|--------|-----------------|
| T+0 | Deploy Instance 1 | HTTP 200 on /api/telemetry |
| T+10 | Deploy Instance 2 | Events from instance 1 visible in DB |
| T+20 | Deploy Instance 3 | Events from instance 2 visible in DB |
| T+30 | Verify all 3 | All 3 sending events to same table |
| T+60 | Run Monday drill | Deployment working, report to Vish |

---

## Week 4 Validation

### By End of Week 4 (Before User Handoff)

**Checklist:**
- [ ] All 3 instances deployed and sending events
- [ ] Events flowing to telemetry.user_events table
- [ ] No duplicate issues (check kafka_event_tracking)
- [ ] Medical features validated via telemetry data
- [ ] Performance acceptable (response times normal)
- [ ] Error rates low (< 1%)
- [ ] Baseline metrics collected (feature adoption, etc.)
- [ ] Reports ready for Mythreya (Mon/Tue)

**SQL to verify:**
```sql
-- Baseline snapshot
SELECT 
  COUNT(*) as total_events,
  COUNT(DISTINCT user_id) as active_users,
  COUNT(DISTINCT session_id) as sessions,
  MIN(event_timestamp) as first_event,
  MAX(event_timestamp) as last_event
FROM telemetry.user_events;
```

---

## 📞 Need Help?

**Check these docs in order:**

1. **TELEMETRY_QUICK_START.md** - Common issues & fixes
2. **TELEMETRY_IMPLEMENTATION_COMPLETE.md** - Architecture & configuration
3. **TELEMETRY_ARCHITECTURE_DIAGRAMS.md** - How everything flows
4. **TELEMETRY_FINAL_VERIFICATION.md** - Quality checklist

---

## ✅ Summary

**Deployment is straightforward:**
1. Git pull on each instance
2. Restart application (pm2 restart)
3. Verify route responds (curl test)
4. Verify events flowing (database query)

**Risk is LOW:**
- Telemetry is isolated (separate DB pool)
- Never blocks user requests (fire-and-forget)
- Can be disabled instantly (TELEMETRY_ENABLED=false)

**Success criteria:**
- All 3 instances running
- Events appearing in telemetry.user_events table
- No duplicates in kafka_event_tracking table
- Application performance unchanged

**You're good to go! 🚀**

