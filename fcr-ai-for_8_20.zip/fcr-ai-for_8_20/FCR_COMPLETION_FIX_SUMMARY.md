# FCR Completion vs Required - Logic Fix

## Problem Statement

The "FCR Completion vs Required Pace" calculation was using incorrect logic that resulted in understating the required FCR count.

### Issue from Meeting Transcript
- **Total MSLs in organization:** 165
- **Required FCRs shown:** 107 (WRONG - showed as monthly average)
- **Should be:** 165 (one FCR per active MSL per quarter)
- **Reason for discrepancy:** The old logic was calculating monthly averages instead of using the total active MSL roster count

### Meeting Context
From the conversation between manager Visweshar and colleague Mythreya:
- **Correct formula:** Required = COUNT(DISTINCT active_msl_in_roster)
- **Completed:** Sum of all FCRs written in the quarter
- **Source of required:** Roster data (not derived from FCR count)
- **Key insight:** "The required should also be higher because the MSL count wouldn't have reduced"

---

## Solution Implemented

### 1. Backend Changes (server.js)

#### Change 1: Added `required_fcrs` field to KPI query
```sql
-- BEFORE: No required_fcrs field
SELECT
  COUNT(DISTINCT survey_target_id) AS total_fcrs,
  COUNT(DISTINCT rep_wwid) AS total_reps,
  ...

-- AFTER: Now includes required_fcrs
SELECT
  COUNT(DISTINCT survey_target_id) AS total_fcrs,
  COUNT(DISTINCT rep_wwid) AS total_reps,
  COUNT(DISTINCT rep_wwid) AS required_fcrs,  -- ← Added this line
  ...
```

**Logic:** 
- `required_fcrs` = COUNT(DISTINCT rep_wwid) = total unique MSLs active in the period
- Represents minimum FCRs that SHOULD be written (1 per MSL per quarter)

#### Change 2: Enhanced trend query with required pace
```sql
-- BEFORE: Only returned completed FCRs per month
SELECT
  TO_CHAR(DATE_TRUNC('month', acty_dt), 'Mon YY') AS month,
  COUNT(DISTINCT survey_target_id) AS fcrs

-- AFTER: Now calculates required pace per month
WITH monthly_fcrs AS (
  SELECT
    TO_CHAR(DATE_TRUNC('month', acty_dt), 'Mon YY') AS month,
    DATE_TRUNC('month', acty_dt) AS month_dt,
    COUNT(DISTINCT survey_target_id) AS fcrs,
    COUNT(DISTINCT rep_wwid) AS active_reps
  ...
),
total_unique_reps AS (
  SELECT COUNT(DISTINCT rep_wwid) as total_reps
  ...
)
SELECT
  m.month,
  m.month_dt,
  m.fcrs AS completed,
  m.active_reps,
  t.total_reps,
  ROUND(1.0 * t.total_reps / COUNT(*) OVER(), 1) AS required_pace_per_month
```

**Returns:**
- `completed`: Actual FCRs written that month
- `active_reps`: MSLs who wrote FCRs that month
- `total_reps`: Total unique MSLs in entire period
- `required_pace_per_month`: Required pace = total_reps / number_of_months

---

### 2. Frontend Changes (DashboardPage.jsx)

#### Change 1: Dynamic required calculation
```javascript
// BEFORE
const fcrsTrend = summary?.trend?.map(r => ({ 
  month: r.month, 
  completed: Number(r.fcrs) 
})) || completionTrend;

// AFTER
const requiredFcrs = kpi?.required_fcrs ? Number(kpi.required_fcrs) : 0;
const completedFcrs = kpi?.total_fcrs ? Number(kpi.total_fcrs) : 0;
const fcrsDiff = completedFcrs - requiredFcrs;
const fcrsTrend = summary?.trend?.map(r => ({ 
  month: r.month, 
  completed: Number(r.completed),
  required: r.required_pace_per_month ? Number(r.required_pace_per_month) : null
})) || completionTrend;
```

#### Change 2: Updated chart legend
```javascript
// BEFORE
<span className="legend-item" style={{ color: '#9CA3AF' }}>
  <span style={{ width: 10, borderTop: '2px dashed #9CA3AF', display: 'inline-block' }} />
  Required (≈100/mo)
</span>
...
<span className="positive-pill">+74 vs required</span>

// AFTER
<span className="legend-item" style={{ color: '#9CA3AF' }}>
  <span style={{ width: 10, borderTop: '2px dashed #9CA3AF', display: 'inline-block' }} />
  Required ({fmt(requiredFcrs)} MSLs)
</span>
...
<span className={`positive-pill${fcrsDiff < 0 ? ' negative' : ''}`}>
  {fcrsDiff >= 0 ? '+' : ''}{fmt(fcrsDiff)} vs required
</span>
```

#### Change 3: Updated reference line on chart
```javascript
// BEFORE
<ReferenceLine y={100} stroke="#9CA3AF" strokeDasharray="5 5" />

// AFTER
{requiredFcrs > 0 && (
  <ReferenceLine 
    y={requiredFcrs} 
    stroke="#9CA3AF" 
    strokeDasharray="5 5" 
    label={{ 
      value: `Required: ${requiredFcrs}`, 
      position: 'right', 
      fill: '#9CA3AF', 
      fontSize: 11 
    }} 
  />
)}
```

---

### 3. CSS Changes (index.css)

Added styling for negative comparison (when below required):
```css
.positive-pill.negative {
  color: #DC2626;
  background: #FEF2F2; 
  border: 1px solid #FECACA;
}
```

---

## Impact & Results

| Aspect | Before | After |
|--------|--------|-------|
| **Required Calculation** | Monthly average (~100/mo) | Total active MSLs |
| **Required Value** | Hardcoded | Dynamic from API |
| **Comparison** | Hardcoded (+74) | Calculated dynamically |
| **Chart Reference Line** | Fixed at 100 | Actual required pace |
| **Below-Required Styling** | Not differentiated | Red alert styling |
| **Data Accuracy** | ❌ Incorrect | ✅ Correct |

### Example
- **Scenario:** 165 total MSLs, 120 FCRs written
- **Before:** Showed Required=107, Completed=120, Diff=+13 (confusing/incorrect)
- **After:** Shows Required=165, Completed=120, Diff=-45 (accurate alert that coaching is below target)

---

## Testing Recommendations

1. **Verify API response** includes new `required_fcrs` field:
   ```bash
   curl http://localhost:8080/api/summary?timeframe=90
   ```
   Should return: `"required_fcrs": 165`

2. **Check trend data** includes required pace:
   - Each trend record should have `required_pace_per_month` 

3. **Validate dashboard display:**
   - Required value matches active MSL count
   - Reference line on chart shows at correct position
   - Comparison value updates correctly
   - Negative styling appears when below required

4. **Edge cases:**
   - When no MSLs have written FCRs (required should still show roster count)
   - When FCRs exceed required (positive pill shows green)
   - When FCRs below required (positive pill shows red)

---

## Files Modified

1. **server.js** - Backend API logic
   - Added `required_fcrs` to KPI query
   - Enhanced trend query with required pace calculation

2. **src/pages/DashboardPage.jsx** - Frontend display
   - Dynamic required calculation
   - Updated legend and comparison value
   - Added required reference line to chart

3. **src/index.css** - Styling
   - Added `.positive-pill.negative` for alert styling

---

## References

- **Meeting Transcript:** Visweshar + Mythreya discussion on FCR completion formula
- **Key Quote:** "The required should also be higher. Meaning if we have 200 MSL, the required should be 200 FCRs"
- **Formula:** Required FCRs = COUNT(DISTINCT active_msl_in_roster) for the quarter
- **Principle:** 1 FCR per MSL per quarter is the standard
