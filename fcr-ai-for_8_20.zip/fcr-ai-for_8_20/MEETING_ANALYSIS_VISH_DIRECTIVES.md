# Meeting Analysis - Core Directives & TODOs from Vish
**Meeting Date:** Friday (Recent)  
**Manager:** Nagarajan, Visveshwar [JJCUS] (Vish)  
**Your Role:** Reddy, Giridhar [JJCUS Non-J&J] (Giri)

---

## 🎯 CORE SUGGESTIONS FROM VISH (MANAGER)

### 1. **Instance Architecture Strategy**
- **Primary Directive:** Create **3 instances TOTAL** (already have 1, need 2 more)
- **Naming Convention (IMPORTANT):**
  - ✅ DO: Name them as "instance 1", "instance 2", "instance 3" initially
  - ❌ DON'T: Use labels like "QA" or "prod" (these trigger approval processes and delays)
- **Rationale:** Avoid bureaucratic approval workflows; focus on speed of delivery
- **Domain Names:** Vish will provide actual domain names later (to be finalized separately and DNS will be updated accordingly)

### 2. **Service Enablement & Deployment**
- **All services need to be enabled across all 3 instances**
- Vish will provide services/configurations that were developed (his part)
- Giri (you) should take that code and deploy it across all 3 instances

### 3. **Release & Validation Strategy**
- **End of Week 4 Target:** Have something solid from medical perspective
- **User Handoff:** Once solid, give it back to users at end of week 4
- **Pressure Relief:** After week 4, the team will "step off the accelerator" to reduce pressure
- **This allows:** More breathing room for enhancements vs. chaotic development pace

### 4. **Post-MVP Feature Planning**
- After initial solid release → Focus on **skill gaps calculations** (Monday evening or Tuesday morning discussion)
- Then → Incremental small feature enhancements (over next few weeks)
- Finally → Commercial features and other "good stuff" (deferred for later)

### 5. **Overall Philosophy**
> *"We are kind of scrambling to develop everything and putting it in, but we will kind of step the foot off the accelerator a bit"*
- Focus on quality over speed after MVP
- Structured rollout prevents burnout and improves code quality

---

## ✅ ALL TODOs & MODIFICATIONS FOR YOUR DESIGN

### **CRITICAL PATH - INSTANCE SETUP & DEPLOYMENT**

| # | Task | Owner | Status | Notes |
|---|------|-------|--------|-------|
| 1 | **Create 2 new instances** | Vamsi (Krishna) with your coordination | BLOCKER | To make 3 total (instance 1, 2, 3) |
| 2 | **Enable all services in new instances** | Vamsi + Giri | Dependent on #1 | Services provided by Vish |
| 3 | **Deploy Giri's code to all 3 instances** | Giri | Dependent on #1 & #2 | "Take this code and deploy it in those two instances as well" |
| 4 | **Wait for domain names from Vish** | N/A | TBD | Will be used for final DNS configuration |
| 5 | **Configure DNS for final domain names** | (TBD - likely Vamsi/DevOps) | Blocked until #4 | After domain names finalized |

### **VALIDATION & RELEASE PHASE**

| # | Task | Owner | Timeline | Notes |
|---|------|-------|----------|-------|
| 6 | **Complete deployment drill** | Team | Monday (specific date TBD) | Let Vish know when done |
| 7 | **Validate all 3 instances with medical features** | Giri + Team | Before End of Week 4 | Must be solid before user handoff |
| 8 | **Provide to users** | Team Lead (Vish) | End of Week 4 | This is the MVP release milestone |

### **POST-MVP ENHANCEMENTS**

| # | Task | Owner | Timeline | Notes |
|---|------|-------|----------|-------|
| 9 | **Skill gaps calculations work** | Mythreya + Vish | Monday evening or Tuesday morning | Discussion session to be scheduled |
| 10 | **Small feature enhancements** | Team | Weeks 5+ | Incremental improvements after MVP |
| 11 | **Commercial features** | Team | Later (TBD) | Deferred until later phase |

---

## 🔴 CRITICAL POINTS - DON'T MISS

1. **Instance Naming is Non-Negotiable for This Phase:**
   - Use "instance 1, 2, 3" NOT "dev/qa/prod"
   - This is deliberate to bypass approval delays
   - ⚠️ Names can be changed later after delivery

2. **Coordination Dependency:**
   - Vamsi (Krishna) needs to coordinate instance creation
   - You need to work WITH him (not just wait for him)
   - Both creation AND service enablement must happen before you can deploy

3. **Code Deployment is Your (Giri's) Responsibility:**
   - Vish will provide the base services/code
   - YOUR job is to take it and deploy across all 3 instances
   - This is explicitly your deliverable

4. **Week 4 is the Hard Deadline for MVP:**
   - Everything must be "solid" by end of week 4
   - This is when users get it
   - No room for delays after that

5. **Workload Management:**
   - Vish is explicitly saying: Don't work on weekends
   - After MVP, pace will slow down (this is intentional)
   - This suggests current sprint is high-intensity but temporary

---

## 📋 ACTION ITEMS FOR YOU (GIRI) - Prioritized

### **IMMEDIATE (This Week)**
- [ ] Confirm with Vamsi about creating 2 new instances
- [ ] Prepare your deployment code/scripts for the 3 instances
- [ ] Understand what services Vish is providing for deployment
- [ ] Setup deployment pipeline/process for all 3 instances

### **SHORT TERM (Next 1-2 Weeks)**
- [ ] Complete deployment of code to all 3 instances once they're ready
- [ ] Run deployment drill on Monday and report completion to Vish
- [ ] Validate medical features are working correctly on all instances

### **END OF WEEK 4**
- [ ] Ensure everything is solid and ready for user handoff
- [ ] Coordinate with Vish for user delivery

### **POST-MVP**
- [ ] Schedule/attend skill gaps calculations discussion (Mon/Tue)
- [ ] Plan incremental feature enhancements

---

## 💡 KEY QUOTES FROM VISH

> "So just create the instances and we can figure out the naming convention and all the other stuff later."

> "We are kind of scrambling into develop everything and putting it in, but we will kind of, like, you know, step the foot off the accelerator a bit"

> "Once we have something really solid from the medical perspective, maybe at the end of week 4, we can give it back to the users"

> "Please don't work in the weekend. We will connect back this on Monday."

---

## 🗓️ Timeline Summary

```
THIS WEEK (Week 3)
├─ Create 2 new instances (with Vamsi)
├─ Enable services
└─ Deploy your code

MONDAY (Start of Week 4)
├─ Deployment drill completion
└─ Report to Vish

WEEK 4
├─ Validation of medical features
└─ Ensure everything is "solid"

END OF WEEK 4 ← **HARD DEADLINE**
├─ User handoff/delivery
└─ MVP Released

WEEK 5+
├─ Skill gaps calculations
├─ Small feature enhancements
└─ Later: Commercial features
```

---

## ⚡ What's NOT Needed Right Now
- Prod/QA naming
- DNS configuration (waiting for domain names)
- Commercial features
- Weekend work
- Excessive documentation (focus on delivery)

---

**Summary:** Your focus should be on coordinating with Vamsi to get 3 instances ready, deploying your code to all of them, validating the medical features work, and getting it ready for user handoff at end of week 4. Everything else comes after.
