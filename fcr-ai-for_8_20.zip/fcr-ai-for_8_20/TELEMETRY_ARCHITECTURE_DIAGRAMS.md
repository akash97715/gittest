# Telemetry System - Architecture Diagram

## Complete Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                             FRONTEND (React + Vite)                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                   │
│  User Actions                     TelemetryService (src/services/)              │
│  ──────────────                   ───────────────────────────────               │
│  • Click Button      ────────→    • trackButtonClick()                          │
│  • Navigate Page     ────────→    • trackPageView() / trackPageExit()           │
│  • Search           ────────→    • trackSearch()                                │
│  • Export Data      ────────→    • trackDataExport()                            │
│  • Error Occurs     ────────→    • trackError()                                 │
│  • API Call         ────────→    • trackApiCall()                               │
│                                   │                                              │
│                                   ▼                                              │
│                          Event Queue (in-memory)                                │
│                          • Batch by size: 10 events                             │
│                          • Batch by time: 30 seconds                            │
│                                   │                                              │
│                                   ▼                                              │
│                    sessionStorage: telemetrySessionId                           │
│                    (persists across page reloads)                               │
│                                   │                                              │
│                                   ▼                                              │
│                          Flush: POST /api/telemetry                             │
│                          ↓                      ↓                               │
│                     Success?               Failure?                             │
│                          ▼                      ▼                               │
│                      Done              localStorage Queue                       │
│                                        (up to 1000 events)                      │
│                                        Retry on next load                       │
│                                                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
                 ┌─────────────────────────────────────────────┐
                 │    NETWORK / HTTP / JSON                     │
                 │  POST /api/telemetry                        │
                 │  Content-Type: application/json             │
                 │  {events: [{...}, {...}]}                  │
                 └─────────────────────────────────────────────┘
                                           │
                                           ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         BACKEND (Node.js + Express)                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                   │
│  POST /api/telemetry (server.js)                                                │
│  │                                                                               │
│  ├─→ Validate event types (CHECK against VALID_EVENT_TYPES)                    │
│  │   ├─ Invalid? → Return 400 error                                             │
│  │   └─ Valid? ↓                                                                │
│  │                                                                               │
│  ├─→ Call publisher.publish(events) [ASYNC, NO AWAIT]                          │
│  │   │                                                                           │
│  │   └─→ Publisher (backend/telemetry/publisher.js)                            │
│  │       │                                                                       │
│  │       ├─ Check TELEMETRY_TRANSPORT env var                                   │
│  │       │  │                                                                    │
│  │       │  ├─ "direct" → Call eventWriter.writeEvents()                      │
│  │       │  └─ "kafka"  → (Future) Send to Kafka producer                     │
│  │       │                                                                       │
│  │       └─ Never throw errors (logged only)                                   │
│  │                                                                               │
│  └─→ Return 200 immediately [FIRE AND FORGET]                                  │
│      User request never blocked!                                                │
│                                                                                   │
│                                                                                   │
│  Event Writer (backend/telemetry/eventWriter.js)                               │
│  ────────────────────────────────────────────────                              │
│  Process incoming events:                                                       │
│                                                                                   │
│  1. Generate Dedup IDs                                                          │
│     SHA256(userId|sessionId|timestamp|eventType)                               │
│     │                                                                            │
│     ▼                                                                            │
│                                                                                   │
│  2. Dedup Check                                                                 │
│     Query kafka_event_tracking: WHERE dedup_id IN (...)                        │
│     │                                                                            │
│     ├─ Already exists? → Skip (COUNT as skipped)                               │
│     └─ New? ↓                                                                   │
│                                                                                   │
│  3. Batch Insert into kafka_event_tracking                                     │
│     INSERT ... ON CONFLICT (dedup_id) DO NOTHING                               │
│     (Reserves dedup_id for future Kafka consumer)                              │
│     │                                                                            │
│     ▼                                                                            │
│                                                                                   │
│  4. Batch Insert into user_events                                              │
│     INSERT (session_id, user_id, event_type, event_data, ...)                 │
│     VALUES (...), (...), (...)                                                │
│     (All at once, not row-by-row)                                              │
│     │                                                                            │
│     ▼                                                                            │
│                                                                                   │
│  5. Write to event_processing_status                                           │
│     Tracks lifecycle: received → validated → stored → aggregated               │
│     │                                                                            │
│     ▼                                                                            │
│                                                                                   │
│  6. Return Results                                                              │
│     {inserted: 9, skipped: 1, errors: []}                                      │
│                                                                                   │
│  Connection Pool (telemetryDb.js)                                              │
│  ────────────────────────────────                                              │
│  • Separate from Redshift pool                                                  │
│  • Azure PostgreSQL (aiaypd03.postgres.database.azure.com)                    │
│  • SSL enabled for security                                                     │
│  • Max 10 connections, min 2 (warm pool)                                       │
│                                                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
                                           │
                                           ▼
                 ┌─────────────────────────────────────────────┐
                 │   Azure PostgreSQL Connection                │
                 │   Port: 5432                                 │
                 │   SSL: Enabled                               │
                 │   Timeout: 30s idle, 10s connection         │
                 └─────────────────────────────────────────────┘
                                           │
                                           ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     DATABASE: telemetry (PostgreSQL)                            │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                   │
│  user_events (Primary)                                                          │
│  ──────────────────────                                                         │
│  event_id          BIGSERIAL PK                                                 │
│  session_id        UUID (from sessionStorage)                                   │
│  user_id           VARCHAR (user email or ID)                                   │
│  user_name         VARCHAR                                                      │
│  user_email        VARCHAR                                                      │
│  event_type        VARCHAR (CHECK: must be in valid types)                      │
│  event_data        JSONB (flexible payload)                                     │
│  page              VARCHAR (optional)                                           │
│  event_timestamp   TIMESTAMPTZ (indexed)                                        │
│  kafka_*           NULLABLE (for future Kafka fields)                           │
│                                                                                   │
│  ┌──────────────────────────────────────────────────────────────┐              │
│  │ Sample Row:                                                  │              │
│  │ {                                                            │              │
│  │   "event_id": 12345,                                        │              │
│  │   "session_id": "1692874645123-abc123",                    │              │
│  │   "user_id": "user@example.com",                           │              │
│  │   "event_type": "button_click",                            │              │
│  │   "event_data": {                                          │              │
│  │     "button_name": "export_pdf",                           │              │
│  │     "page_name": "activity"                                │              │
│  │   },                                                        │              │
│  │   "event_timestamp": "2026-08-24T10:30:45.123Z"           │              │
│  │ }                                                           │              │
│  └──────────────────────────────────────────────────────────────┘              │
│                                                                                   │
│  kafka_event_tracking (Deduplication)                                          │
│  ─────────────────────────────────────                                         │
│  dedup_id          VARCHAR PK (SHA256 hash)                                     │
│  kafka_topic       VARCHAR (NULL for now, ready for Kafka)                      │
│  kafka_partition   INT (NULL for now)                                           │
│  kafka_offset      BIGINT (NULL for now)                                        │
│  event_id          BIGINT FK → user_events.event_id                            │
│  session_id        UUID                                                        │
│  user_id           VARCHAR                                                      │
│  processing_status VARCHAR (received, validated, stored, etc)                   │
│  created_at        TIMESTAMPTZ                                                  │
│                                                                                   │
│  Purpose: Prevents duplicate events even without Kafka                          │
│  Query: INSERT ... ON CONFLICT (dedup_id) DO NOTHING                           │
│                                                                                   │
│  event_processing_status (Lifecycle Tracking)                                  │
│  ──────────────────────────────────────────────                                │
│  event_tracking_id BIGSERIAL PK                                                 │
│  event_id          BIGINT FK                                                    │
│  dedup_id          VARCHAR FK                                                   │
│  stage             VARCHAR (received, validated, stored, aggregated)            │
│  stage_status      VARCHAR (success, pending, error)                            │
│  timestamp_*       TIMESTAMPTZ (timestamps for each stage)                      │
│  processing_duration_ms INT                                                      │
│                                                                                   │
│  Purpose: Track event lifecycle and performance                                 │
│                                                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## Transport Switch (Kafka Migration Ready)

```
CURRENT (Direct Mode)                  FUTURE (Kafka Mode)
─────────────────────────────────────────────────────────────

POST /api/telemetry                    POST /api/telemetry
    │                                      │
    └─→ publisher.publish()    ────→   publisher.publish()
        │                                   │
        ├─ Check env var                   ├─ Check env var
        │  TRANSPORT=direct                │  TRANSPORT=kafka
        │  │                               │  │
        │  └─→ eventWriter                 └─→ Kafka Producer
        │      writeEvents()                   │
        │      │                               ├─ Send to Kafka topic
        │      ├─ Generate dedup_id          │
        │      ├─ Check dedup table          ┌─────────────────────┐
        │      ├─ Batch insert               │  Kafka Broker       │
        │      └─ Return 200                 │  (Distributed)      │
        │                                    └─────────────────────┘
        │                                        │
        └─────────────────────────────────────────┘
                                            │
                                            └─→ Kafka Consumer
                                                │
                                                ├─ Deserialize
                                                ├─ Call eventWriter
                                                │  .writeEvents()
                                                │  (SAME function!)
                                                └─→ PostgreSQL

KEY: Same eventWriter.writeEvents() is called in both modes!
     Zero code changes needed, just set TELEMETRY_TRANSPORT=kafka
```

---

## Session ID Lifecycle

```
Session 1: Browser Opened
─────────────────────────

Page Load
  │
  └─→ TelemetryService constructor
      │
      └─→ _getOrCreateSessionId()
          │
          ├─ Check sessionStorage.getItem('telemetrySessionId')
          │  │
          │  └─ Doesn't exist? Generate new:
          │     "1692874645123-abc123"
          │     └─→ Save to sessionStorage
          │
          └─→ sessionId = "1692874645123-abc123"

User clicks button
  │
  └─→ trackButtonClick()
      │
      └─→ Event added to queue:
          {
            session_id: "1692874645123-abc123",  ← Same ID!
            event_type: "button_click",
            ...
          }

User navigates
  │
  └─→ trackPageView()
      │
      └─→ Event added to queue:
          {
            session_id: "1692874645123-abc123",  ← Same ID!
            event_type: "page_view",
            ...
          }

Page reload (user presses F5)
  │
  └─→ sessionStorage persists!
      │
      └─→ TelemetryService constructor
          │
          └─→ _getOrCreateSessionId()
              │
              ├─ Check sessionStorage.getItem('telemetrySessionId')
              │  │
              │  └─ EXISTS! Return existing:
              │     "1692874645123-abc123"
              │
              └─→ sessionId = "1692874645123-abc123"  ← Same as before!

Browser close
  │
  └─→ sessionStorage cleared (browser destroys it)

Browser reopened
  │
  └─→ TelemetryService constructor
      │
      └─→ _getOrCreateSessionId()
          │
          ├─ Check sessionStorage.getItem('telemetrySessionId')
          │  │
          │  └─ Doesn't exist (cleared on close)
          │
          └─→ Generate NEW session ID
             "1692874960000-xyz789"  ← Different session!
```

---

## Event Type Validation

```
Valid Event Types (12 total):
───────────────────────────

✓ user_login       — User authenticated (called in App.jsx)
✓ user_logout      — User logged out
✓ session_start    — Session started (called automatically)
✓ session_end      — Session ended (called on logout)
✓ page_view        — User viewed a page (called in App.jsx)
✓ page_exit        — User left a page (called in App.jsx)
✓ button_click     — User clicked a button (manual tracking)
✓ search           — User performed search (manual tracking)
✓ data_export      — User exported data (manual tracking)
✓ api_call         — API call made (manual tracking)
✓ error            — Error occurred (manual tracking)
✓ custom           — Custom event (for flexibility)

Validation Flow:
───────────────

Frontend: telemetryService.trackEvent(eventType)
    │
    └─→ Event created with eventType
        │
        └─→ Event sent to backend

Backend: POST /api/telemetry
    │
    └─→ const invalid = events.filter(e => !VALID_EVENT_TYPES.includes(e.event_type))
        │
        ├─ Found invalid? 
        │  │
        │  └─→ Return 400 "Invalid event types"
        │
        └─ All valid?
           │
           └─→ Proceed with publishing
```

---

## Error Handling & Resilience

```
Scenario 1: Network Failure
──────────────────────────

Event queued in memory
    │
    └─→ Flush trigger (size or time)
        │
        └─→ fetch('/api/telemetry') ← Network error!
            │
            ├─ Error caught
            │
            └─→ _saveToOfflineQueue(batch)
                │
                └─→ localStorage.setItem('telemetry_offline_queue', [...])
                    │
                    └─→ Events persisted locally (up to 1000)

Network restored
    │
    └─→ User navigates
        │
        └─→ App reloads / browser regains connection
            │
            └─→ _flushOfflineQueue() called automatically
                │
                └─→ POST /api/telemetry with saved events
                    │
                    ├─ Success? → localStorage.removeItem()
                    └─ Failure? → Keep in localStorage, try again later


Scenario 2: Database Down
─────────────────────────

POST /api/telemetry received
    │
    └─→ publisher.publish() async (fire-and-forget)
        │
        └─→ eventWriter.writeEvents()
            │
            └─→ telemetryPool.connect() ← Database unavailable!
                │
                ├─ Error: "Connection timeout"
                │
                └─→ Caught in try/catch
                    │
                    └─→ console.error("Telemetry DB error...")
                        │
                        └─→ No propagation to frontend!

Frontend: Still got 200 OK
    │
    └─→ User continues unaffected!
        │
        └─→ Backend logs error for ops team to handle


Scenario 3: Duplicate Events (Kafka Protection)
──────────────────────────────────────────────

Event 1: dedup_id = SHA256(user123|session-abc|2026-08-24T10:30:45Z|button_click)
                  = "abc123def456..."

Sent to backend
    │
    └─→ eventWriter checks kafka_event_tracking
        │
        ├─ Not found → INSERT new row
        │
        └─→ Event inserted to user_events

Sent to backend AGAIN (retry, network glitch)
    │
    └─→ eventWriter checks kafka_event_tracking
        │
        ├─ Found "abc123def456..." in table!
        │
        └─→ INSERT ... ON CONFLICT DO NOTHING
            │
            ├─ Row already exists (same dedup_id)
            │
            └─→ SKIP (no duplicate in user_events!)
                │
                └─→ Return: {inserted: 0, skipped: 1}

Result: Event appears in user_events ONCE despite multiple submissions
```

---

## Summary

✅ **Completely isolated from main application** (separate DB pool)  
✅ **Never blocks user requests** (fire-and-forget)  
✅ **Resilient to failures** (localStorage queue, error logging)  
✅ **Prevents duplicates** (dedup_id with ON CONFLICT)  
✅ **Kafka-ready** (transport switch, same write logic)  
✅ **Production-ready** (batching, pooling, monitoring hooks)  

