# Telemetry System Architecture - Technical Discussion Guide

**For:** Architecture reviews, technical discussions, stakeholder presentations  
**Focus:** Design decisions, data flow, scalability, performance  

---

## 🏗️ Core Architecture (2 Minutes)

### Three-Layer Design

```
FRONTEND                   BACKEND                    DATABASE
┌──────────────────┐      ┌──────────────────┐       ┌──────────────────┐
│  React (100      │      │  Express.js      │       │  Redshift        │
│  users)          │      │  Node.js         │       │  PostgreSQL-      │
│                  │      │                  │       │  compatible      │
│  TelemetryService├─────→│  6 API Endpoints ├──────→│  5 Tables        │
│  (event capture) │      │  Event validation│       │  3 Views         │
│                  │      │  Aggregation     │       │  Indexes         │
└──────────────────┘      └──────────────────┘       └──────────────────┘
       ↓                          ↓                          ↓
  Batch events            JSON → SQL INSERT         Optimized queries
  Every 30s or            Real-time processing      90-day retention
  10 events               Error handling            Auto-archive
```

### Why This Design?

✅ **Separation of Concerns** - Each layer has one job  
✅ **Asynchronous** - Frontend doesn't block on telemetry  
✅ **Scalable** - Can add more events without affecting app  
✅ **Resilient** - If telemetry fails, app continues working  
✅ **Cost Efficient** - Uses existing infrastructure  

---

## 📊 Data Flow Architecture

### Event Journey (Single User Action)

```
1. USER ACTION (Frontend)
   └─→ Click button "Export PDF"
   
2. EVENT CREATION (TelemetryService)
   └─→ {
         eventType: "button_click",
         button: "export_pdf",
         page: "fcrs",
         userId: "user-123",
         sessionId: "abc123xyz",
         timestamp: "2026-08-13T10:30:00Z"
       }

3. EVENT QUEUING (Local Memory)
   └─→ Queue size: 1 event
       Batch trigger: When 10 events OR 30 seconds pass
   
4. BATCH CREATION (TelemetryService)
   └─→ [event1, event2, event3... event10]
       Ready to send to backend
   
5. TRANSMISSION (HTTP POST)
   └─→ POST /api/telemetry
       Headers: Content-Type: application/json
       Body: { events: [...], batchCount: 10 }
   
6. BACKEND PROCESSING (Express)
   └─→ Receive batch
       Validate schema
       Transform format
       Prepare for database
   
7. DATABASE INSERT (Redshift)
   └─→ INSERT INTO telemetry.user_events
       VALUES (...)
       
8. AGGREGATION (Views & Queries)
   └─→ Real-time view aggregation
       - Page analytics
       - Button click stats
       - User sessions
       - Error logs
       
9. DASHBOARD QUERY (Analytics)
   └─→ GET /api/telemetry/button-clicks
       ↓
       SELECT button_name, COUNT(*) as clicks
       FROM telemetry.user_events
       WHERE event_type = 'button_click'
       
10. VISUALIZATION (React Dashboard)
    └─→ Charts render with real data
        Users see: "Export PDF: 234 clicks"
```

**Latency:** 
- Frontend → Backend: ~50ms (same network)
- Database insert: ~10ms
- Dashboard query: ~200ms
- **Total end-to-end:** ~500ms from action to dashboard update

---

## 🔄 Event Batching Strategy

### Why Batch Instead of Send-Per-Event?

```
WITHOUT BATCHING (Bad):
Button Click → Network call → 1 HTTP request
×500 clicks/day = 500 requests → High overhead

WITH BATCHING (Good):
10 clicks queued → 1 HTTP request
500 clicks/day = 50 requests → 10x reduction
```

### Batching Logic Flow

```
┌─ New Event Arrives
│
├─ Add to Queue
│  Queue: [evt1, evt2]
│
├─ Check Trigger Conditions:
│  ├─ Queue size >= 10? → SEND NOW
│  ├─ Time elapsed >= 30s? → SEND NOW
│  ├─ User navigating away? → SEND NOW (flush)
│  └─ User offline? → QUEUE LOCALLY
│
└─ Either Queue or Send
```

### Configuration Options

```javascript
// In telemetryService.js
const BATCH_CONFIG = {
  batchSize: 10,          // Events per batch
  batchTimeout: 30000,    // 30 seconds
  maxQueueSize: 100,      // Don't queue >100
  retryAttempts: 3,       // Retry failed sends
  retryDelay: 5000        // 5 second retry
};
```

**For 100 users:**
- ~5,000 events/day
- ~500 batches/day
- ~50 MB/month bandwidth
- **Server impact:** Minimal, easy to scale

---

## 💾 Database Schema Design

### Table Hierarchy & Relationships

```
telemetry.user_events (Primary Table)
├─ ALL raw events stored here
├─ 90-day retention
├─ Indexes on: user_id, session_id, event_type, timestamp
├─ Distkey: user_id (for performance)
└─ Sortkey: timestamp DESC (for queries)

    ↓ Aggregated into ↓

telemetry.user_sessions (Session Level)
├─ One row per session
├─ Aggregated from user_events
├─ Duration, event count, page views
└─ Used for session analytics

telemetry.daily_usage_summary (Daily Rollup)
├─ One row per day
├─ Active users, sessions, events, errors
└─ For trending & dashboards

telemetry.page_analytics (Page Level)
├─ One row per page per day
├─ View count, unique visitors, avg time
└─ For page performance reports

telemetry.button_analytics (Feature Level)
├─ One row per button per day
├─ Click count, unique users
└─ For feature adoption tracking
```

### Why This Structure?

```
Raw Events Table (telemetry.user_events)
├─ Pros: Complete data, flexible queries
├─ Cons: Large, slow for aggregations
└─ Use: Debugging, detailed analysis

Aggregated Tables (daily_*, page_*, button_*)
├─ Pros: Fast queries, small storage
├─ Cons: Less detail
└─ Use: Dashboard, reports, trending
```

**Storage Estimate:**
- Raw events (90 days): ~100 MB
- Aggregated tables (1 year): ~10 MB
- **Total per 100 users:** ~110 MB (negligible)

---

## 🔍 Query Performance Strategy

### Index Strategy (Why We Have 6 Indexes)

```
User Query:
  SELECT * FROM telemetry.user_events 
  WHERE user_id = 'user-123' → Index: idx_user_id
  
Time Range Query:
  SELECT * FROM telemetry.user_events 
  WHERE timestamp >= '2026-08-13' → Index: idx_timestamp
  
Event Type Query:
  SELECT * FROM telemetry.user_events 
  WHERE event_type = 'button_click' → Index: idx_event_type
  
Composite Query (Most Common):
  SELECT * FROM telemetry.user_events 
  WHERE user_id = 'user-123' 
    AND timestamp >= '2026-08-13'
  → Index: idx_user_timestamp (composite)
```

### Query Optimization

```
SLOW Query (Without Index):
  SELECT COUNT(*) FROM user_events
  WHERE user_id = 'user-123'
  → Full table scan: ~1000ms
  
FAST Query (With Index):
  SELECT COUNT(*) FROM user_events  
  WHERE user_id = 'user-123'
  → Index lookup: ~5ms
  
IMPROVEMENT: 200x faster
```

### Materialized Views for Dashboard

```
Raw Query (Slow):
  SELECT page, COUNT(*) as views
  FROM user_events
  WHERE timestamp >= DATEADD(day, -7, GETDATE())
  → ~500ms (table scan)

View Query (Fast):
  SELECT * FROM v_page_performance
  WHERE date >= DATEADD(day, -7, GETDATE())
  → ~50ms (pre-aggregated)

IMPROVEMENT: 10x faster
```

---

## 🛡️ Reliability & Resilience

### Failure Scenarios & Handling

```
Scenario 1: Backend API Down
  Frontend: Queues events locally (localStorage)
  Recovery: When backend returns, sends queued events
  Impact: Zero data loss
  
Scenario 2: Database Connection Lost
  Backend: Returns error response
  Frontend: Retries 3 times with 5s delay
  Recovery: Next batch attempt succeeds
  Impact: At most 1 batch delayed
  
Scenario 3: User Navigates Away
  Frontend: Calls flush() on page unload
  Sends: All pending events immediately
  Method: navigator.sendBeacon (reliable)
  Impact: No event loss even if user closes browser
  
Scenario 4: Telemetry Completely Fails
  App: Continues working normally
  Frontend: Events silently dropped
  Dashboard: Shows less data but app functional
  Impact: Graceful degradation
```

### Recovery Mechanisms

```javascript
// Retry Logic
if (sendFailed) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    wait(5 * attempt) seconds;  // 5s, 10s, 15s
    if (send succeeds) break;
  }
}

// Offline Queuing
if (navigator.onLine === false) {
  queue to localStorage;
}
addEventListener('online', () => {
  send all queued events;
});

// Page Unload
window.addEventListener('beforeunload', () => {
  navigator.sendBeacon('/api/telemetry', data);
});
```

---

## 📈 Scalability Architecture

### Current (100 Users)
```
~5,000 events/day
~50 batches/day
~10 MB/month storage
CPU: <1%
✅ Comfortable headroom
```

### Scale to 1,000 Users
```
~50,000 events/day
~500 batches/day
~100 MB/month storage
CPU: ~0.5% (still low)
Actions: Archive to S3 monthly
✅ Still Redshift-based
```

### Scale to 10,000 Users
```
~500,000 events/day
~5,000 batches/day
~1 GB/month storage
CPU: ~3-5%
Actions: Stream processing (Kinesis)
         Real-time aggregation (Flink)
↳ Consider: BigQuery, Snowflake, Kafka
```

### Redshift vs Alternatives

```
✅ Redshift (Current)
  ├─ Pros: Already owned, handles SQL, clustered
  ├─ Cons: Overkill for <1M events/day
  └─ Good for: 100-1K users, analytical queries

↳ Upgrade Path (If Needed)
  ├─ ClickHouse: Real-time analytics, cheaper
  ├─ Kafka + Stream: For high-velocity events
  ├─ BigQuery: Serverless, auto-scaling
  └─ Snowflake: Flexible, cloud-native
```

---

## 🔐 Data Architecture & Privacy

### Data Classification

```
Raw Events Table:
├─ user_id (hashed Azure AD ID) - Identified
├─ user_name (display name) - Identified
├─ user_email (corporate email) - Identified
├─ event_type (button, page, error) - Non-PII
├─ timestamp (when action occurred) - Non-PII
├─ page (which page) - Non-PII
└─ event_data (JSON context) - Non-PII

NOT stored:
❌ Passwords (never captured)
❌ Sensitive data (credentials, keys)
❌ PII (SSN, payment info)
❌ Healthcare data (if regulated)
```

### Data Retention Flow

```
Day 1-90: HOT Data
  └─ In telemetry.user_events
     Fast queries, full detail
     Retention: 90 days

Day 91+: WARM Data  
  └─ Aggregated in daily_summary tables
     1-year retention
     Monthly rollups

Day 365+: COLD Data
  └─ Archive to S3
     3-year retention
     Compliance requirements
     Automatic cleanup after 3 years

Manual purge:
  DELETE FROM user_events 
  WHERE timestamp < DATEADD(day, -90, GETDATE());
```

---

## 🎯 API Architecture

### RESTful Design Pattern

```
POST /api/telemetry
  Purpose: Event ingestion
  Idempotent: No (events accumulate)
  Idempotency Key: batchId (optional)
  Body: { events: [...], batchCount: 10 }
  Response: { success: true, received: 10 }

GET /api/telemetry/usage-summary?days=30
  Purpose: Overall statistics
  Idempotent: Yes
  Cacheable: Yes (5-min TTL)
  Response: { activeUsers: 87, sessions: 412, ... }

GET /api/telemetry/user/:userId?days=30
  Purpose: User-specific activity
  Idempotent: Yes
  Auth: Admin or user themselves
  Response: { sessions: 5, events: 42, ... }

GET /api/telemetry/page-analytics?days=7
  Purpose: Page performance
  Idempotent: Yes
  Cacheable: Yes
  Response: [ { page: 'dashboard', views: 234, ... } ]

GET /api/telemetry/button-clicks?days=7&limit=10
  Purpose: Feature adoption
  Idempotent: Yes
  Pagination: limit + offset
  Response: [ { button: 'export', clicks: 456, ... } ]

GET /api/telemetry/errors?days=7&limit=20
  Purpose: Error tracking
  Idempotent: Yes
  Sortable: By frequency or date
  Response: [ { error: '..', count: 3, ... } ]
```

### Why REST (Not GraphQL/gRPC)?

```
✅ REST for Analytics
  ├─ Simple, standard
  ├─ Easy caching
  ├─ Good for dashboards
  ├─ Browser-friendly (JS fetch)
  └─ No over-fetching needed

✗ GraphQL for This Use Case
  ├─ Overkill for analytics
  ├─ Harder to cache
  ├─ More complex queries
  └─ Not needed for fixed schema

✗ gRPC for This Use Case
  ├─ Binary protocol (not human readable)
  ├─ More complex for web clients
  ├─ Overkill for analytics
  └─ Better for microservices
```

---

## 🔄 Event Processing Pipeline

### Architecture Diagram

```
Step 1: Collection (Frontend)
  User Action → TelemetryService.track()
  ↓
  Queue in memory [10 events max]

Step 2: Batching (Frontend)
  Check: size >= 10 OR time >= 30s?
  ↓
  Create batch: { events: [...] }

Step 3: Transmission (Frontend)
  POST /api/telemetry
  ↓
  Network (retry 3x if fails)

Step 4: Ingestion (Backend)
  Receive batch at /api/telemetry
  ↓
  Validate schema
  ├─ Check required fields
  ├─ Check event types valid
  ├─ Check timestamp reasonable
  └─ Reject if invalid

Step 5: Transformation (Backend)
  Map frontend format → database format
  ├─ Sanitize strings
  ├─ Add server timestamp
  ├─ Verify user session
  └─ Enrich with context

Step 6: Storage (Backend → Redshift)
  INSERT INTO telemetry.user_events
  ├─ event_id (auto-generated)
  ├─ user_id, session_id, ...
  ├─ event_type, event_data
  ├─ timestamp
  └─ created_at

Step 7: Real-time Aggregation
  Trigger aggregation views:
  ├─ Update v_user_activity
  ├─ Update v_page_performance
  ├─ Increment daily_summary counters
  └─ Insert to page_analytics

Step 8: Query & Display
  Dashboard queries:
  ├─ GET /api/telemetry/usage-summary
  ├─ GET /api/telemetry/page-analytics
  └─ GET /api/telemetry/button-clicks
  
Step 9: Rendering (Frontend)
  React Dashboard receives JSON
  ├─ Chart renders with data
  ├─ Tables populate
  └─ KPI cards update

Step 10: Retention Management
  Daily cleanup:
  ├─ Delete events > 90 days old
  ├─ Archive to S3 if configured
  └─ Vacuum/analyze tables
```

---

## 🚀 Performance Tuning Points

### Frontend Optimization

```
1. Batch Size
   Current: 10 events
   Impact: Smaller = more requests, faster latency
           Larger = fewer requests, batch delay

2. Batch Timeout
   Current: 30 seconds
   Impact: Longer = less bandwidth, higher latency
           Shorter = more responsive, higher traffic

3. Queue Size Limit
   Current: 100 events max
   Impact: Prevents memory bloat if network down

4. Compression
   Option: gzip compress batch before sending
   Saving: ~70% reduction in payload size
   Cost: CPU on client

Recommendation:
  ├─ Keep batch size at 10
  ├─ Keep timeout at 30s
  └─ Monitor bandwidth, adjust if needed
```

### Backend Optimization

```
1. Connection Pooling
   Current: pg pool (default)
   Impact: Reuses DB connections, reduces overhead

2. Batch Insert Strategy
   Option A: INSERT one row per event
            Query: INSERT ... VALUES (...); 
            Impact: Slow (N queries)
   
   Option B: INSERT multiple rows (current)
            Query: INSERT ... VALUES (...), (...), (...);
            Impact: Fast (1 query)
   
   Option C: COPY command (for bulk)
            Query: COPY table FROM STDIN;
            Impact: Very fast, for >1000 rows

3. Asynchronous Insert
   Current: Synchronous (wait for confirmation)
   Option: Fire-and-forget (queue to job)
   Impact: Faster response, risks data loss

Recommendation:
  ├─ Keep batch INSERT (multi-row)
  ├─ Keep synchronous (reliability)
  └─ Monitor query times, optimize if slow
```

### Database Optimization

```
1. Index Strategy
   ├─ Drop unused indexes (costs insert overhead)
   ├─ Add composite indexes (user_id, timestamp)
   └─ Analyze query plans monthly

2. Partitioning
   Option: Partition by month (month_2026_08)
   Impact: Faster queries on date ranges
   Tradeoff: More complex management

3. Compression
   Redshift: Automatically compresses columns
   Impact: 50-80% storage reduction
   No action needed: Automatic

4. Vacuum & Analyze
   Redshift: VACUUM and ANALYZE tables
   Frequency: Daily or weekly
   Impact: Maintains performance
```

---

## 🧪 Testing Strategy for Architecture

### Unit Tests
```
✅ TelemetryService.init() → Initializes session
✅ TelemetryService.track() → Queues events
✅ Batch trigger logic → Sends at 10 or 30s
✅ Event validation → Rejects invalid events
```

### Integration Tests
```
✅ Frontend → Backend → Database flow
✅ Event ingestion API
✅ Analytics query accuracy
✅ Offline recovery
```

### Load Tests
```
✅ Simulate 100 users × 50 events/day
✅ Measure latency & throughput
✅ Check error rates
✅ Verify database doesn't degrade
```

### Performance Benchmarks
```
Frontend:
  └─ Event creation: <1ms
  └─ Queue operation: <1ms
  └─ Batch transmission: <50ms

Backend:
  └─ Event validation: <5ms per event
  └─ Database insert: <10ms per event
  └─ API response: <100ms

Database:
  └─ Query (page analytics): <200ms
  └─ Query (user activity): <100ms
  └─ Aggregation views: <50ms
```

---

## 📋 Architecture Decision Log

### Decision 1: Event Batching
**Question:** Send events immediately or batch?  
**Options:** 
- Option A: Send immediately (simple, high overhead)
- Option B: Batch events (complex, efficient) ← CHOSEN
**Rationale:** Reduces network requests 10x, minimal latency trade-off

### Decision 2: Where to Batch?
**Question:** Batch on frontend or backend?  
**Options:**
- Option A: Backend batches (simple server code)
- Option B: Frontend batches (fast response) ← CHOSEN
**Rationale:** Frontend closer to events, can persist to localStorage

### Decision 3: Storage Engine
**Question:** Redshift, BigQuery, ClickHouse?  
**Options:**
- Option A: BigQuery (serverless, but extra cost)
- Option B: ClickHouse (cheaper, real-time, new infra)
- Option C: Redshift (already owned) ← CHOSEN
**Rationale:** Zero additional cost, proven, simple SQL

### Decision 4: Retention Period
**Question:** How long to keep raw events?  
**Options:**
- Option A: 30 days (save storage)
- Option B: 90 days (good balance) ← CHOSEN
- Option C: 1 year (expensive, rarely used)
**Rationale:** Covers quarterly trends, reasonable storage

### Decision 5: Real-time vs Batch
**Question:** Aggregate data in real-time or batch?  
**Options:**
- Option A: Real-time aggregation (complex triggers)
- Option B: Batch daily (simple, delayed) 
- Option C: Both (views are real-time, summaries batch) ← CHOSEN
**Rationale:** Dashboard needs real-time, trending reports use daily summaries

---

## 🎓 Key Architecture Principles Used

1. **Separation of Concerns**
   - Frontend: Just capture and send
   - Backend: Just validate and store
   - Database: Just query and aggregate

2. **Asynchronous by Design**
   - Don't block app on telemetry
   - Network calls fire-and-forget
   - Batch processing in background

3. **Resilient Graceful Degradation**
   - App works even if telemetry fails
   - Data queued locally if offline
   - No single point of failure

4. **Cost Optimization**
   - Use existing infrastructure
   - Batch to reduce network overhead
   - Archive old data to cheap storage

5. **Query Optimization**
   - Indexes on all common queries
   - Materialized views for dashboards
   - Retention policy to limit data size

6. **Compliance First**
   - No sensitive data storage
   - GDPR/CCPA data export ready
   - Clear data retention policy

---

## 🎯 Architecture Talking Points (Prioritized)

### **If Asked "Why This Architecture?"**

Top 3 reasons to mention:
1. **Minimal App Impact** - Asynchronous, batched, no blocking
2. **Uses Existing Infrastructure** - No new tools to maintain
3. **Graceful Degradation** - App works even if telemetry fails

### **If Asked "How Do You Handle Scale?"**

Say this:
- "For 100 users: Redshift handles easily, <1% overhead"
- "For 1,000 users: Still comfortable, no changes needed"
- "For 10,000+ users: Would migrate to BigQuery or ClickHouse"
- "Designed to be database-agnostic for future migration"

### **If Asked "How Do You Ensure Data Quality?"**

Say this:
- "Events validated on both frontend and backend"
- "Rejected events logged for debugging"
- "Schema validation on all fields"
- "Automated tests verify accuracy"

### **If Asked "What If Something Fails?"**

Say this:
- "Frontend queues events locally if backend down"
- "Automatically retries 3x with exponential backoff"
- "Sends all pending events on page unload"
- "App continues working, just no telemetry"

---

**Ready to discuss architecture!** Use these talking points based on the specific questions you get.
