import { useState } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from 'recharts';
import {
  AlertCircle, ChevronDown, Download, Sparkles,
  RefreshCw, Calendar, Filter, Info
} from 'lucide-react';
import {
  kpiData, pipelineData, submissionsDaily, submissionsMonthly,
  coverageData, recentFCRs
} from '../data/mockData';

const SERIES = [
  { key: 'Oncology',              color: '#e05470' },
  { key: 'Immunology',           color: '#6eb5ff' },
  { key: 'Neuroscience',         color: '#b39ddb' },
  { key: 'Cardiovascular',       color: '#80cbc4' },
  { key: 'Other',                color: '#ffcc80' },
];

const TABS = ['Adoption Snapshot', 'Submissions Trend', 'Coverage by Org', 'Alerts (10)'];

const statusClass = {
  Completed: 'badge-completed',
  Submitted: 'badge-submitted',
  Draft:     'badge-draft',
  Overdue:   'badge-overdue',
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, padding: '8px 12px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)', fontFamily: 'inherit', fontSize: 11 }}>
      <div style={{ fontWeight: 700, marginBottom: 5, color: '#111' }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 2 }}>
          <span style={{ width: 7, height: 7, borderRadius: 2, background: p.color, display: 'inline-block' }} />
          <span style={{ color: '#6b7280' }}>{p.name}:</span>
          <span style={{ fontWeight: 600, color: '#111' }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function ActivityPage() {
  const [activeTab, setActiveTab] = useState('Adoption Snapshot');
  const [chartMode, setChartMode] = useState('Daily');
  const [search, setSearch] = useState('');

  const chartData = chartMode === 'Daily' ? submissionsDaily : submissionsMonthly;
  const xKey = chartMode === 'Daily' ? 'date' : 'date';

  const filtered = recentFCRs.filter(r =>
    !search ||
    r.id.toLowerCase().includes(search.toLowerCase()) ||
    r.manager.toLowerCase().includes(search.toLowerCase()) ||
    r.msl.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      {/* Page Header */}
      <div className="page-header-row">
        <h1 className="page-title">Activity</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div className="sync-info">
            <RefreshCw size={11} color="#16a34a" />
            Synced from iConnect · 4h ago
          </div>
          <button id="btn-export" className="ask-ai-btn" style={{ border: '1px solid #e5e7eb', color: '#374151' }}>
            <Download size={12} /> Export <ChevronDown size={11} />
          </button>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="tab-bar">
        {TABS.map(t => (
          <div
            key={t}
            id={`tab-${t.replace(/\s+/g, '-').toLowerCase()}`}
            className={`tab-item ${activeTab === t ? 'active' : ''}`}
            onClick={() => setActiveTab(t)}
          >
            {t}
          </div>
        ))}
      </div>

      {/* Alerts Row */}
      <div className="alerts-row">
        <AlertCircle size={15} className="alerts-icon" />
        <span className="alerts-text">
          <strong>10 open alerts</strong> <span>· 3 high severity</span>
        </span>
        <span style={{ fontSize: 11, color: '#6b7280' }}>
          Rule based signals across adoption, capability, and coaching quality. Click to expand.
        </span>
        <div className="alerts-spacer" />
        <div className="alerts-chips-right">
          <span id="chip-high"   className="chip chip-high">3 high</span>
          <span id="chip-medium" className="chip chip-medium">4 medium</span>
          <span id="chip-low"    className="chip chip-low">3 low</span>
        </div>
        <ChevronDown size={14} className="alerts-expand" />
      </div>

      {/* Coaching Adoption Card */}
      <div className="coaching-card">
        <div className="coaching-card-label"><span>LIVE · ADOPTION</span></div>
        <div className="coaching-card-title">
          Coaching Adoption
          <div className="icon-btns">
            {[Calendar, Filter, RefreshCw].map((Icon, i) => (
              <button key={i} className="icon-btn-sm"><Icon size={11} /></button>
            ))}
          </div>
        </div>

        {/* KPI Row */}
        <div className="kpi-row">
          {[
            { label: 'FCRs in View',                value: kpiData.fcrsInView,           sub: kpiData.fcrsInViewSub },
            { label: 'Coaches w/ ≥1 FCR',           value: kpiData.coachesWithFCR,       sub: kpiData.coachesWithFCRSub },
            { label: 'Pre-Launch Training Complete', value: kpiData.prelaunchComplete,    sub: kpiData.prelaunchSub },
            { label: 'Avg FCRs Per Coach',           value: kpiData.avgFCRsPerCoach,      sub: kpiData.avgFCRsPerCoachSub },
            { label: 'Avg Days Between Obs',         value: kpiData.avgDaysBetweenObs,   sub: kpiData.avgDaysSub },
          ].map((k, i) => (
            <div key={i} className="kpi-box">
              <div className="kpi-box-label">{k.label}</div>
              <div className="kpi-box-value">{k.value}</div>
              <div className="kpi-box-sub">{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Pipeline Row */}
        <div className="pipeline-section-label">
          <span>FCR Pipeline</span>
          <span className="pipeline-total-count">38 total in view</span>
        </div>
        <div className="pipeline-row">
          {pipelineData.map((p, i) => (
            <div key={i} className="pipeline-box">
              <div className="pipeline-icon" style={{ borderColor: p.color }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, display: 'block' }} />
              </div>
              <div>
                <div className="pipeline-count">{p.count}</div>
                <div className="pipeline-label">{p.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submissions Over Time */}
      <div className="section-card">
        <div className="section-card-hdr">
          <div>
            <div className="section-card-title">
              Submissions Over Time
              <Info size={12} style={{ color: '#9ca3af' }} />
            </div>
            <div className="section-card-sub">
              FCR submissions over time. Switch to{' '}
              <span
                style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline' }}
                onClick={() => setChartMode(m => m === 'Daily' ? 'Monthly' : 'Daily')}
              >
                {chartMode === 'Daily' ? 'Monthly' : 'Daily'}
              </span>{' '}
              to see {chartMode === 'Daily' ? 'month-over-month' : 'day-over-day'} change.
            </div>
          </div>
          <div className="card-actions">
            <div className="toggle-group">
              <button id="toggle-daily"   className={`toggle-btn ${chartMode === 'Daily'   ? 'active' : ''}`} onClick={() => setChartMode('Daily')}>Daily</button>
              <button id="toggle-monthly" className={`toggle-btn ${chartMode === 'Monthly' ? 'active' : ''}`} onClick={() => setChartMode('Monthly')}>Monthly</button>
            </div>
            <button id="btn-chart-ask-ai" className="ask-ai-btn"><Sparkles size={11} /> Ask AI</button>
          </div>
        </div>
        <div className="chart-wrap">
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <defs>
                {SERIES.map(s => (
                  <linearGradient key={s.key} id={`g-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%"  stopColor={s.color} stopOpacity={0.5} />
                    <stop offset="100%" stopColor={s.color} stopOpacity={0.15} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis
                dataKey={xKey}
                tick={{ fontSize: 10, fill: '#9ca3af' }}
                axisLine={false} tickLine={false}
                interval={chartMode === 'Daily' ? 3 : 0}
              />
              <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              {SERIES.map(s => (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  stackId="1"
                  stroke={s.color}
                  strokeWidth={1.5}
                  fill={`url(#g-${s.key})`}
                  dot={false}
                  activeDot={{ r: 3 }}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
          {/* Legend */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 18, flexWrap: 'wrap', marginTop: 10, paddingBottom: 4 }}>
            {SERIES.map(s => (
              <div key={s.key} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#6b7280' }}>
                <span style={{ fontSize: 12, color: s.color }}>→</span>
                {s.key}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Coverage by Supervisory Org */}
      <div className="section-card">
        <div className="section-card-hdr">
          <div>
            <div className="section-card-title">
              Coverage by Supervisory Org
              <Info size={12} style={{ color: '#9ca3af' }} />
            </div>
            <div className="section-card-sub">
              % of Coaches in each org actively submitting FCRs, total FCRs, and average cadence between observations.
            </div>
          </div>
          <div className="card-actions">
            <button id="btn-coverage-ask-ai" className="ask-ai-btn"><Sparkles size={11} /> Ask AI</button>
          </div>
        </div>
        <div>
          <table className="data-table" aria-label="Coverage by supervisory org" style={{ tableLayout: 'auto' }}>
            <colgroup>
              <col style={{ width: '30%' }} />
              <col style={{ width: '12%' }} />
              <col style={{ width: '38%' }} />
              <col style={{ width: '10%' }} />
              <col style={{ width: '10%' }} />
            </colgroup>
            <thead>
              <tr>
                <th>Supervisory Org</th>
                <th>Active Coaches</th>
                <th>% Active</th>
                <th>FCRs</th>
                <th>Avg cadence</th>
              </tr>
            </thead>
            <tbody>
              {coverageData.map((row, i) => (
                <tr key={i} id={`coverage-${i}`}>
                  <td><a href="#" className="link-blue">{row.org}</a></td>
                  <td>{row.active} / {row.target}</td>
                  <td>
                    <div className="pct-bar-wrap" style={{ gap: 10 }}>
                      <div className="pct-bar-track" style={{ flex: 1 }}>
                        <div
                          className="pct-bar-fill"
                          style={{
                            width: `${row.pct}%`,
                            background: row.pct === 100 ? '#16a34a' : row.pct >= 50 ? '#d97706' : '#dc2626',
                          }}
                        />
                      </div>
                      <span className="pct-text" style={{ color: row.pct === 100 ? '#16a34a' : row.pct >= 50 ? '#d97706' : '#dc2626' }}>
                        {row.pct}%
                      </span>
                    </div>
                  </td>
                  <td>
                    <span style={{ color: row.fcrs === 0 ? '#d97706' : '#2563eb', fontWeight: 600 }}>
                      {row.fcrs}
                    </span>
                  </td>
                  <td style={{ 
                    color: parseInt(row.cadence) > 30 ? '#d97706' : '#374151',
                    fontWeight: parseInt(row.cadence) > 30 ? 600 : 400
                  }}>{row.cadence}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent FCRs */}
      <div className="section-card">
        <div className="section-card-hdr">
          <div>
            <div className="section-card-title">
              Recent FCRs
              <Info size={12} style={{ color: '#9ca3af' }} />
            </div>
            <div className="section-card-sub">Click any row for the full ACR-style report</div>
          </div>
          <div className="card-actions">
            <div className="search-input-wrap">
              <svg className="si" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
              <input
                id="search-fcrs"
                type="text"
                placeholder="Search FCR ID, MSL, Coach..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                aria-label="Search FCRs"
              />
            </div>
          </div>
        </div>
        <div>
          <table className="data-table" aria-label="Recent FCRs">
            <thead>
              <tr>
                <th>FCR ID</th>
                <th>Manager</th>
                <th>MSL</th>
                <th>TA</th>
                <th>Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => (
                <tr key={r.id} id={`fcr-row-${i}`}>
                  <td><a href="#" className="link-blue" style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.id}</a></td>
                  <td><a href="#" className="link-blue">{r.manager}</a></td>
                  <td><a href="#" className="link-blue">{r.msl}</a></td>
                  <td style={{ color: '#374151' }}>{r.ta}</td>
                  <td style={{ color: '#6b7280' }}>{r.date}</td>
                  <td><span className={`badge ${statusClass[r.status] || ''}`}>{r.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="table-footer">Showing {filtered.length} of {recentFCRs.length} FCRs</div>
      </div>
    </>
  );
}
