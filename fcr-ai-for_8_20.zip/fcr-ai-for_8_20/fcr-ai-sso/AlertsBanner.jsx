import { AlertTriangle, AlertCircle, Info, ChevronRight } from 'lucide-react';

const alertsData = { critical: 3, warning: 5, info: 10 };


export default function AlertsBanner() {
  return (
    <div className="alerts-banner" role="alert" aria-label="System alerts">
      <span className="alerts-banner-title">Active Alerts</span>

      <div
        id="alert-critical"
        className="alert-chip critical"
        title="View critical alerts"
      >
        <AlertTriangle size={12} />
        {alertsData.critical} Critical
      </div>

      <div
        id="alert-warning"
        className="alert-chip warning"
        title="View warning alerts"
      >
        <AlertCircle size={12} />
        {alertsData.warning} Warnings
      </div>

      <div
        id="alert-info"
        className="alert-chip info"
        title="View informational alerts"
      >
        <Info size={12} />
        {alertsData.info} Informational
      </div>

      <div className="alerts-banner-cta">
        View All Alerts <ChevronRight size={12} style={{ display: 'inline', verticalAlign: 'middle' }} />
      </div>
    </div>
  );
}
