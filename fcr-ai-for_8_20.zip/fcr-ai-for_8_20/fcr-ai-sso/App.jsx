import { useState, useEffect } from 'react';
import { useIsAuthenticated, useAccount } from '@azure/msal-react';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import ActivityPage from './pages/ActivityPage';
import CapabilityPage from './pages/CapabilityPage';
import AskAIPage from './pages/AskAIPage';
import ReferencePage from './pages/ReferencePage';
import LoginPage from './pages/LoginPage';
import ConsentPage from './pages/ConsentPage';
import { telemetryService } from './services/telemetryService';
import './index.css';

function PlaceholderPage({ title }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, color: '#9ca3af', padding: 48 }}>
      <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.25 }}>📋</div>
      <div style={{ fontSize: 17, fontWeight: 700, color: '#374151' }}>{title}</div>
      <div style={{ fontSize: 12, marginTop: 6 }}>Coming soon — will be connected to the live backend.</div>
    </div>
  );
}

export default function App() {
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount();
  const [hasConsented, setHasConsented] = useState(false);
  const [active, setActive] = useState('activity');
  const [pageEntryTime, setPageEntryTime] = useState(Date.now());

  // Initialize telemetry with user info on authentication
  useEffect(() => {
    if (isAuthenticated && account) {
      telemetryService.init(
        account.localAccountId || account.homeAccountId,
        account.name,
        account.username
      );
    }
  }, [isAuthenticated, account]);

  // Track page views and exits
  useEffect(() => {
    setPageEntryTime(Date.now());
    telemetryService.trackPageView(active, window.location.pathname);

    return () => {
      // Calculate time spent on page
      const timeOnPage = Date.now() - pageEntryTime;
      telemetryService.trackPageExit(active, timeOnPage);
    };
  }, [active]);

  // Step 1: Login via Microsoft SSO
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // Step 2: Consent / Warning
  if (!hasConsented) {
    return <ConsentPage onAccept={() => setHasConsented(true)} />;
  }

  const renderPage = () => {
    switch (active) {
      case 'activity':   return <ActivityPage />;
      case 'capability': return <CapabilityPage />;
      case 'askai':      return <AskAIPage />;
      case 'reference':  return <ReferencePage />;
      default:           return <PlaceholderPage title="Coming Soon" />;
    }
  };

  return (
    <div className="app-shell">
      <Sidebar active={active} onNavigate={setActive} />
      <div className="main-area">
        <Topbar />
        <main className="page-content" id="main-content" role="main">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
