import { useState } from 'react';
import { Sparkles, Send, RefreshCw, Download, Users, Briefcase, User, BookOpen, LayoutGrid } from 'lucide-react';

const SUGGESTIONS = ['Biggest capability gap right now', 'Coaches with 0 FCRs', 'Promotion-ready MSLs'];

const ROLES = [
  { id: 'all',       label: 'All',            icon: LayoutGrid },
  { id: 'hr',        label: 'HR / Talent',    icon: Users },
  { id: 'director',  label: 'Field Director', icon: Briefcase },
  { id: 'msl',       label: 'MSL Leader',     icon: User },
  { id: 'ld',        label: 'L&D',            icon: BookOpen },
];

const QUESTIONS = [
  // Quality
  { role: 'all',      category: 'QUALITY',     color: '#c41230', icon: '🎯', q: "What's the biggest capability gap across the field right now?" },
  { role: 'all',      category: 'CAPABILITY',  color: '#7c3aed', icon: '📉', q: 'Which MSLs are below required proficiency for their level?' },
  { role: 'all',      category: 'ADOPTION',    color: '#2563eb', icon: '🚀', q: 'Are we on pace to have every MSL coached at least once before launch?' },
  { role: 'hr',       category: 'TALENT',      color: '#059669', icon: '⭐', q: 'Which MSLs are promotion-ready based on coaching scores?' },
  { role: 'hr',       category: 'RISK',        color: '#dc2626', icon: '⚠️', q: 'Who has had no FCR submitted in the last 60 days?' },
  { role: 'hr',       category: 'QUALITY',     color: '#c41230', icon: '📊', q: 'What is the average quality score by therapeutic area?' },
  { role: 'director', category: 'ADOPTION',    color: '#2563eb', icon: '📅', q: 'Which teams have the longest average cadence between observations?' },
  { role: 'director', category: 'CAPABILITY',  color: '#7c3aed', icon: '🔍', q: 'Where are the biggest skill gaps in my region?' },
  { role: 'director', category: 'PIPELINE',    color: '#d97706', icon: '📋', q: 'How many FCRs are overdue across my supervisory orgs?' },
  { role: 'msl',      category: 'COACHING',    color: '#059669', icon: '💬', q: 'What coaching themes appear most in my recent FCRs?' },
  { role: 'msl',      category: 'QUALITY',     color: '#c41230', icon: '📈', q: 'How has my proficiency score changed over the last quarter?' },
  { role: 'msl',      category: 'CAPABILITY',  color: '#7c3aed', icon: '🎓', q: 'What skills am I being coached on most frequently?' },
  { role: 'ld',       category: 'TRAINING',    color: '#d97706', icon: '🏫', q: 'Which TAs have the lowest pre-launch training completion rates?' },
  { role: 'ld',       category: 'CAPABILITY',  color: '#7c3aed', icon: '📚', q: 'What are the most common capability gaps across all MSLs?' },
  { role: 'ld',       category: 'ADOPTION',    color: '#2563eb', icon: '✅', q: 'What percentage of MSLs have completed the required competency modules?' },
];

export default function AskAIPage() {
  const [activeRole, setActiveRole] = useState('all');
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const visibleQuestions = QUESTIONS.filter(q => activeRole === 'all' || q.role === activeRole || q.role === 'all');

  const handleAsk = (q = query) => {
    if (!q.trim()) return;
    setQuery(q);
    setLoading(true);
    setResponse(null);
    setTimeout(() => {
      setLoading(false);
      setResponse(`Based on your FCR data, here's what I found for: "${q}"\n\nThis is a demo response. Once connected to the live backend, the AI will provide detailed, data-driven answers including charts, tables, and recommended next steps.`);
    }, 1400);
  };

  return (
    <>
      {/* Page Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: '#111827' }}>Ask AI</h1>
          <p style={{ fontSize: 13, color: '#6b7280', marginTop: 2 }}>
            Natural-language exploration across FCRs, skills, adoption and coaching themes
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#6b7280' }}>
            <RefreshCw size={11} color="#16a34a" />
            Synced from iConnect · 4h ago
          </div>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 12px', border: '1px solid #e5e7eb', borderRadius: 6, background: '#fff', fontSize: 12, fontWeight: 600, color: '#374151', cursor: 'pointer', fontFamily: 'inherit' }}>
            <Download size={12} /> Export <span style={{ fontSize: 10 }}>▾</span>
          </button>
        </div>
      </div>

      {/* Hero Search Card */}
      <div style={{
        background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12,
        padding: '40px 48px', textAlign: 'center',
        boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
      }}>
        {/* Badge */}
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: '#fff0f2', border: '1px solid #fecaca', borderRadius: 20, padding: '4px 12px', marginBottom: 18 }}>
          <Sparkles size={12} color="#c41230" />
          <span style={{ fontSize: 11, fontWeight: 700, color: '#c41230' }}>AI-Powered FCR Intelligence</span>
        </div>

        {/* Heading */}
        <h2 style={{ fontSize: 28, fontWeight: 800, color: '#111827', lineHeight: 1.2, marginBottom: 10 }}>
          Ask anything about your field coaching data
        </h2>
        <p style={{ fontSize: 13, color: '#6b7280', maxWidth: 560, margin: '0 auto 28px', lineHeight: 1.6 }}>
          Get grounded answers with stats, tables, trends and recommended next steps, across adoption, quality, talent risk and coaching themes.
        </p>

        {/* Search Input */}
        <div style={{ display: 'flex', gap: 0, maxWidth: 660, margin: '0 auto 12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)', borderRadius: 8, overflow: 'hidden', border: '1px solid #e5e7eb' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Sparkles size={14} style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }} />
            <input
              id="ask-ai-hero-input"
              type="text"
              placeholder="Ask about adoption, quality, talent risk, coaching themes, cadence..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAsk()}
              style={{
                width: '100%', height: 48, paddingLeft: 38, paddingRight: 14,
                border: 'none', outline: 'none', fontSize: 13, fontFamily: 'inherit',
                color: '#111827', background: '#fff',
              }}
            />
          </div>
          <button
            id="btn-ask-ai-hero"
            onClick={() => handleAsk()}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '0 22px', background: '#c41230', border: 'none',
              color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer',
              fontFamily: 'inherit', whiteSpace: 'nowrap',
            }}
          >
            <Send size={13} /> Ask AI
          </button>
        </div>

        {/* Try suggestions */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: '#9ca3af', fontWeight: 500 }}>Try:</span>
          {SUGGESTIONS.map((s, i) => (
            <button
              key={i}
              id={`suggestion-${i}`}
              onClick={() => handleAsk(s)}
              style={{
                padding: '3px 10px', border: '1px solid #e5e7eb', borderRadius: 20,
                background: '#f9fafb', color: '#374151', fontSize: 12, fontWeight: 500,
                cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s',
              }}
              onMouseOver={e => { e.target.style.borderColor = '#c41230'; e.target.style.color = '#c41230'; }}
              onMouseOut={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.color = '#374151'; }}
            >
              {s}
            </button>
          ))}
        </div>

        {/* AI Response */}
        {loading && (
          <div style={{ marginTop: 20, padding: '14px 18px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb', textAlign: 'left', maxWidth: 660, margin: '20px auto 0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#6b7280' }}>
              <Sparkles size={13} color="#c41230" />
              <span>AI is analyzing your FCR data...</span>
            </div>
          </div>
        )}
        {response && !loading && (
          <div style={{ marginTop: 20, padding: '16px 18px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb', textAlign: 'left', maxWidth: 660, margin: '20px auto 0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <Sparkles size={13} color="#c41230" />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#111827' }}>AI Response</span>
            </div>
            <p style={{ fontSize: 12, color: '#374151', lineHeight: 1.7, whiteSpace: 'pre-line' }}>{response}</p>
          </div>
        )}
      </div>

      {/* Role Tabs */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
        {ROLES.map(r => (
          <button
            key={r.id}
            id={`role-tab-${r.id}`}
            onClick={() => setActiveRole(r.id)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '6px 14px', borderRadius: 20,
              border: activeRole === r.id ? '1.5px solid #c41230' : '1px solid #e5e7eb',
              background: activeRole === r.id ? '#c41230' : '#fff',
              color: activeRole === r.id ? '#fff' : '#374151',
              fontSize: 12, fontWeight: 600, cursor: 'pointer',
              fontFamily: 'inherit', transition: 'all 0.15s',
            }}
          >
            <r.icon size={12} />
            {r.label}
          </button>
        ))}
        <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 4 }}>Most-asked questions across roles</span>
      </div>

      {/* Question Cards Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 14,
      }}>
        {visibleQuestions.slice(0, 9).map((item, i) => (
          <div
            key={i}
            id={`question-card-${i}`}
            onClick={() => handleAsk(item.q)}
            style={{
              background: '#fff', border: '1px solid #e5e7eb', borderRadius: 10,
              padding: '16px 18px', cursor: 'pointer',
              transition: 'all 0.15s',
              display: 'flex', flexDirection: 'column', gap: 8,
              boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
            }}
            onMouseOver={e => {
              e.currentTarget.style.borderColor = '#c41230';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(196,18,48,0.08)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.borderColor = '#e5e7eb';
              e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.04)';
            }}
          >
            {/* Top row: icon + category */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              <span style={{
                fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em',
                color: item.color, background: `${item.color}12`, padding: '2px 7px', borderRadius: 4,
              }}>
                {item.category}
              </span>
            </div>
            {/* Question text */}
            <p style={{ fontSize: 13, fontWeight: 600, color: '#111827', lineHeight: 1.5, margin: 0 }}>
              {item.q}
            </p>
          </div>
        ))}
      </div>
    </>
  );
}
