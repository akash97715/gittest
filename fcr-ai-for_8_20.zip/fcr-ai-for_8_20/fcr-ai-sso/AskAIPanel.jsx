import { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';

const aiInsights = [
  { id: 1, type: 'warning',  text: 'Western Region has 35% fewer FCRs than the quarterly target. Consider scheduling a coaching cadence review with regional managers.' },
  { id: 2, type: 'info',     text: 'Oncology submissions have grown 162% YTD — the highest growth rate across all therapeutic areas this year.' },
  { id: 3, type: 'critical', text: '12 FCRs are overdue by more than 7 days. Automated reminders have been sent; manager escalation is recommended.' },
  { id: 4, type: 'success',  text: 'Central Region exceeded their Q4 completion target by 18%, with an average coaching cadence of 14.8 days.' },
];


const typeStyle = {
  warning:  { bg: '#fffbeb', border: '#fde68a', dot: '#d97706', label: 'Warning'  },
  info:     { bg: '#eff6ff', border: '#bfdbfe', dot: '#2563eb', label: 'Insight'  },
  critical: { bg: '#fef2f2', border: '#fecaca', dot: '#dc2626', label: 'Alert'    },
  success:  { bg: '#f0fdf4', border: '#bbf7d0', dot: '#16a34a', label: 'Positive' },
};

const SUGGESTIONS = [
  'Which region has the lowest FCR completion rate?',
  'Show coaching trends for Oncology this quarter',
  'Who are the top 5 coaches by FCR count?',
  'What is driving the cadence increase in Western region?',
];

export default function AskAIPanel() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleAsk = (q = query) => {
    if (!q.trim()) return;
    setLoading(true);
    setResponse(null);
    setTimeout(() => {
      setLoading(false);
      setResponse(
        `Based on the current data, here's what I found for: "${q}".\n\n` +
        `This is a demo response. Once connected to the live backend, the AI will provide detailed, data-driven answers including charts and recommendations.`
      );
    }, 1200);
  };

  return (
    <div className="ask-ai-card">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
        <Sparkles size={16} color="#e8294d" />
        <span className="ask-ai-title">Ask AI</span>
      </div>
      <div className="ask-ai-sub">Get instant insights from your FCR data</div>

      <div className="ask-ai-input-row">
        <input
          id="ask-ai-input"
          className="ask-ai-input"
          type="text"
          placeholder="Ask anything about your FCR data..."
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAsk()}
          aria-label="Ask AI about FCR data"
        />
        <button
          id="btn-ask-ai-send"
          className="ask-ai-send"
          onClick={() => handleAsk()}
          title="Send query"
        >
          <Send size={14} />
        </button>
      </div>

      {/* Suggestion chips */}
      <div className="ask-ai-suggestions">
        {SUGGESTIONS.map((s, i) => (
          <button
            key={i}
            id={`ai-suggestion-${i}`}
            className="ai-suggestion-chip"
            onClick={() => { setQuery(s); handleAsk(s); }}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div style={{
          marginTop: 12, background: 'rgba(255,255,255,0.08)',
          borderRadius: 8, padding: '12px 14px',
          color: 'rgba(255,255,255,0.6)', fontSize: 12,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⚙</span>
          AI is analyzing your data...
        </div>
      )}

      {/* Response */}
      {response && !loading && (
        <div style={{
          marginTop: 12, background: 'rgba(255,255,255,0.1)',
          borderRadius: 8, padding: '12px 14px',
          color: 'rgba(255,255,255,0.85)', fontSize: 12, lineHeight: 1.6,
          border: '1px solid rgba(255,255,255,0.12)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 6 }}>
            <Sparkles size={12} color="#e8294d" />
            <span style={{ fontWeight: 600, color: '#fff' }}>AI Response</span>
          </div>
          {response}
        </div>
      )}

      {/* Divider */}
      <div style={{ height: 1, background: 'rgba(255,255,255,0.1)', margin: '14px 0' }} />

      {/* AI Insights */}
      <div style={{ fontWeight: 700, fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
        AI-Generated Insights
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {aiInsights.map(insight => {
          const style = typeStyle[insight.type] || typeStyle.info;
          return (
            <div
              key={insight.id}
              id={`insight-${insight.id}`}
              style={{
                background: style.bg, border: `1px solid ${style.border}`,
                borderRadius: 8, padding: '10px 12px',
                display: 'flex', alignItems: 'flex-start', gap: 8,
              }}
            >
              <span style={{
                width: 8, height: 8, borderRadius: '50%',
                background: style.dot, flexShrink: 0, marginTop: 3,
              }} />
              <div>
                <span style={{ fontSize: 10, fontWeight: 700, color: style.dot, textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 2 }}>
                  {style.label}
                </span>
                <span style={{ fontSize: 12, color: '#374151', lineHeight: 1.5 }}>{insight.text}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
