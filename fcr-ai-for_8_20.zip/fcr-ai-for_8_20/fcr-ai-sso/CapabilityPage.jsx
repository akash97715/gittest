import { BarChart2, TrendingUp, Award, Target } from 'lucide-react';

const capabilityStats = [
  { label: 'Competency Score',   value: '82%', sub: '+4% from last quarter', icon: Award,    color: '#c41230' },
  { label: 'Quality Rating',     value: '4.3',  sub: 'Avg coach quality (out of 5)', icon: Target,   color: '#2563eb' },
  { label: 'Behavior Adoption',  value: '76%', sub: 'Observed behaviors on track',  icon: TrendingUp,color: '#7c3aed' },
  { label: 'Impact Score',       value: '68%', sub: 'Correlation to sales performance', icon: BarChart2,color: '#059669'},
];

export default function CapabilityPage() {
  return (
    <>
      {/* Page Header */}
      <div style={{ marginBottom: 4 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#1a1a2e' }}>Capability & Quality</h1>
        <p style={{ fontSize: 13, color: '#6b7280', marginTop: 2 }}>
          Track coaching quality, competency scores, and behavioral alignment across your field teams.
        </p>
      </div>

      {/* Stats Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
        {capabilityStats.map((s, i) => (
          <div
            key={i}
            id={`capability-stat-${i}`}
            className="section-card"
            style={{ padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: 6 }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 34, height: 34, borderRadius: 8, background: `${s.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <s.icon size={17} color={s.color} />
              </div>
              <span style={{ fontSize: 12, color: '#6b7280', fontWeight: 500 }}>{s.label}</span>
            </div>
            <div style={{ fontSize: 28, fontWeight: 800, color: '#1a1a2e' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: '#9ca3af' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Placeholder Detail Card */}
      <div className="section-card" style={{ marginTop: 2 }}>
        <div className="section-card-header">
          <div className="section-card-title">Competency Breakdown by TA</div>
          <div className="section-card-sub">Detailed quality scores per therapeutic area will appear here once data is connected.</div>
        </div>
        <div className="section-card-body" style={{ textAlign: 'center', padding: '48px 20px', color: '#9ca3af' }}>
          <BarChart2 size={40} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Data Coming Soon</div>
          <div style={{ fontSize: 12 }}>
            Competency & quality analytics will be displayed here once the backend is connected.
          </div>
        </div>
      </div>
    </>
  );
}
