import jnjLogo from '../assets/logo.png';

export default function ConsentPage({ onAccept }) {
  return (
    <div style={{
      minHeight: '100vh',
      background: '#f0ede8',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Inter', sans-serif",
      padding: '32px 16px',
    }}>

      {/* J&J Logo */}
      <img
        src={jnjLogo}
        alt="Johnson & Johnson"
        style={{ height: 52, marginBottom: 28, objectFit: 'contain' }}
      />

      {/* Card */}
      <div style={{
        background: '#ffffff',
        borderRadius: 16,
        boxShadow: '0 4px 32px rgba(0,0,0,0.10)',
        padding: '40px 48px 32px',
        maxWidth: 580,
        width: '100%',
      }}>

        {/* Title */}
        <h1 style={{
          fontSize: 24,
          fontWeight: 800,
          color: '#1a1a2e',
          margin: '0 0 24px',
          letterSpacing: '-0.3px',
          lineHeight: 1.3,
        }}>
          AI Platform Usage Warning and Consent
        </h1>

        {/* Paragraphs */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <p style={{ fontSize: 13.5, color: '#374151', lineHeight: 1.75, margin: 0 }}>
            <strong>FCR-AI Analysis</strong> is powered by AI to assist with{' '}
            <span style={{ color: '#c41230' }}>Field Coaching Report (FCR)</span> data exploration,
            analysis, and insight generation. Outputs are generated based on available data and
            model interpretation and may be incomplete, outdated, or inaccurate. Users remain
            responsible for reviewing and validating insights against approved data sources and
            materials.
          </p>

          <p style={{ fontSize: 13.5, color: '#374151', lineHeight: 1.75, margin: 0 }}>
            <span style={{ color: '#c41230' }}>
              This platform is intended for internal business use only.
            </span>{' '}
            It is not designed for external distribution, customer interaction, promotional use,
            or clinical decision-making. All outputs should be considered supportive and
            directional, not authoritative.
          </p>

          <p style={{ fontSize: 13.5, color: '#374151', lineHeight: 1.75, margin: 0 }}>
            <span style={{ color: '#c41230' }}>
              Adhere to all J&amp;J compliance guardrails,
            </span>{' '}
            data governance policies, and applicable laws and regulations.
          </p>

          <p style={{ fontSize: 13.5, color: '#374151', lineHeight: 1.75, margin: 0 }}>
            <span style={{ color: '#c41230' }}>
              Outputs do not constitute medical, legal, regulatory, financial, or policy advice.
            </span>{' '}
            Always verify insights using{' '}
            <span style={{ color: '#c41230' }}>approved systems</span> of record and consult the
            appropriate teams when required.
          </p>
        </div>

        {/* Accept button */}
        <div style={{ textAlign: 'center', marginTop: 36 }}>
          <button
            id="btn-accept-consent"
            onClick={onAccept}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'linear-gradient(135deg, #c41230 0%, #9e0e26 100%)',
              color: '#fff',
              border: 'none',
              borderRadius: 10,
              padding: '14px 80px',
              fontSize: 15,
              fontWeight: 700,
              cursor: 'pointer',
              fontFamily: 'inherit',
              boxShadow: '0 4px 16px rgba(196,18,48,0.3)',
              transition: 'all 0.2s',
              letterSpacing: '0.01em',
            }}
            onMouseOver={e => {
              e.currentTarget.style.transform = 'translateY(-1px)';
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(196,18,48,0.42)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(196,18,48,0.3)';
            }}
          >
            Accept
          </button>
        </div>

        {/* Divider + links */}
        <div style={{ height: 1, background: '#f3f4f6', margin: '28px 0 16px' }} />

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          {['Privacy Policy', 'Legal Notice', 'Help & Support'].map((link, i, arr) => (
            <span key={link} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <a
                href="#"
                style={{ fontSize: 12, color: '#c41230', textDecoration: 'none', fontWeight: 500 }}
                onMouseOver={e => e.target.style.textDecoration = 'underline'}
                onMouseOut={e => e.target.style.textDecoration = 'none'}
              >{link}</a>
              {i < arr.length - 1 && <span style={{ color: '#d1d5db' }}>|</span>}
            </span>
          ))}
        </div>

        {/* Short warning */}
        <p style={{
          fontSize: 10,
          color: '#9ca3af',
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
          lineHeight: 1.6,
          margin: '14px 0 0',
          textAlign: 'left',
        }}>
          Warning Notice: This system is restricted solely to Johnson &amp; Johnson users for
          legitimate business only… &copy; 2026
        </p>
      </div>
    </div>
  );
}
