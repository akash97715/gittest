import { Download, ArrowUpDown } from 'lucide-react';
import { coverageData } from '../data/mockData';


export default function CoverageTable() {
  return (
    <div className="section-card">
      <div className="section-card-header">
        <div>
          <div className="section-card-title">Coverage by Supervisory Org</div>
          <div className="section-card-sub">Active coaches, FCR count, and avg cadence</div>
        </div>
        <div className="section-card-actions">
          <button id="btn-export-coverage" className="btn btn-outline">
            <Download size={12} /> Export
          </button>
        </div>
      </div>

      <div className="data-table-wrap">
        <table className="data-table" aria-label="Coverage by supervisory organization">
          <thead>
            <tr>
              <th>
                <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                  Region <ArrowUpDown size={10} style={{ opacity: 0.5 }} />
                </span>
              </th>
              <th>Active / Target</th>
              <th>FCR Count</th>
              <th>Avg Cadence (days)</th>
              <th>Completion</th>
            </tr>
          </thead>
          <tbody>
            {coverageData.map((row, i) => (
              <tr key={i} id={`coverage-row-${i}`}>
                <td style={{ fontWeight: 600 }}>{row.org}</td>
                <td>
                  <span style={{ fontWeight: 600 }}>{row.activeCoaches}</span>
                  <span style={{ color: '#9ca3af', fontSize: 12 }}> / {row.target}</span>
                </td>
                <td>{row.fcrs}</td>
                <td>
                  <span style={{
                    color: row.avgCadence > 20 ? '#dc2626' : row.avgCadence > 17 ? '#d97706' : '#16a34a',
                    fontWeight: 600,
                  }}>
                    {row.avgCadence}
                  </span>
                </td>
                <td>
                  <div className="progress-pill-wrap">
                    <div className="progress-pill-track">
                      <div
                        className="progress-pill-fill"
                        style={{
                          width: `${row.completion}%`,
                          background: row.completion >= 80 ? '#16a34a' : row.completion >= 65 ? '#d97706' : '#dc2626',
                        }}
                      />
                    </div>
                    <span className="progress-pill-text">{row.completion}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
