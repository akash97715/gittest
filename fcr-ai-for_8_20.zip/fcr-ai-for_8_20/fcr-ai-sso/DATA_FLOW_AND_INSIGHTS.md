# FCR AI Insights — Data Flow, Calculations & Insights Architecture
**For Meeting Presentation**

---

## 📊 System Overview

**FCR AI Insights** is a Johnson & Johnson field coaching analytics platform that:
- Aggregates **Field Coaching Report (FCR)** data from Amazon Redshift
- Tracks **coaching quality** across reps, regions, and therapeutic areas (TA)
- Uses **AI (Azure OpenAI)** to score coaching behaviors and generate insights
- Provides **real-time dashboards** and **AI-powered conversational analysis**

**Core Data Source:** `odp.dp_cust_pers_engagement_dly` — Redshift table with ~2,817 FCRs and millions of question-level rows

---

## 🏠 Page-by-Page Data & Calculations

### 1️⃣ **DASHBOARD PAGE** (`DashboardPage.jsx`)
**Purpose:** Executive summary of coaching program health

#### Data Fetched
- **`/api/kpis`** → Dashboard KPI cards (counts + percentages)
  - Total FCRs written (lifetime or filtered by timeframe)
  - Total reps coached
  - Submitted FCRs % (on-time submissions)
  - Average days to submit
  - Compliance rate (Field Observation = "Yes")
- **`/api/summary`** → Deep drill KPIs + breakdown by TA, region, trend
- **`/api/pins-summary`** → PINS coaching framework training flags

#### Key Calculations
| Metric | Formula | Why It Matters |
|--------|---------|-----------------|
| **Total FCRs** | `COUNT(DISTINCT survey_target_id)` where `chnl='SURVEY'` | Volume of coaching activity |
| **Submitted %** | `COUNT(submitted) / COUNT(total) * 100` | On-time submission health |
| **Avg Days to Submit** | `DATEDIFF(submitted_date, start_date)` | Coaching follow-up speed |
| **Compliance Rate** | `COUNT("Field Obs"="Yes") / COUNT(all "Field Obs") * 100` | % of field observations documented |
| **FCRs per Rep** | `total_fcrs / distinct_reps` | Coaching intensity |

#### Views (Tab-Based)
1. **KPI Cards** — Top-line numbers with trend context
2. **By TA Breakdown** — FCRs/reps segmented by IMM, ONC, NS, SCG
3. **By Region** — Geographic distribution (West, Central, Northeast, Southeast, East)
4. **Trend Chart** — Monthly FCR volume over 6 months
5. **Skill Proficiency Trend** — 12-month avg competency scores (1–4 scale)
6. **Training Skill Gaps** — PINS coaching framework training flags by section (P/I/N/S)

#### Filters Applied
- **Timeframe:** All time, 7, 30, 90, 180, 365 days, or custom date range
- **TA:** All or specific (IMM, ONC, NS, SCG)
- **Region:** All or specific

---

### 2️⃣ **CAPABILITY PAGE** (`CapabilityPage.jsx`)
**Purpose:** Deep dive into rep competency proficiency and performance distribution

#### Data Fetched
- **`/api/capability`** → Competency-level scoring, LEAD model, trends
  - Avg competency score (1–4 scale)
  - % of reps at or above target (3+)
  - Trend over 12 months
  - Breakdown by job level / role
  - Flagged FCRs with "Clear Development Need" (score 1)

#### Key Calculations

**Competency Scoring Scale:**
- **4** = Clear Strength (exceeds role expectations)
- **3** = Emerging Strength (meets expectations)
- **2** = Development Need (below target)
- **1** = Clear Development Need (significant gap)

**"% at Target"** = `COUNT(score >= 3) / COUNT(all) * 100`

**6-Month Trend:**
- Monthly avg: `AVG(competency_score)` grouped by month
- Visualized as line chart → shows upward/downward trajectory

**By Job Level Drill:**
- Grouped by `rep_desig` (rep designation)
- Shows top 8 levels with highest coaching volume
- Each row: avg score, FCR count, rep count

#### LEAD Model Competencies
- **Learn** — Customer learning & discovery
- **Engage** — Stakeholder engagement
- **Advance** — Scientific advancement
- **Deliver** — Delivery & results

*Scoring:* Learning (1) → Applying (2) → Leading (3)

#### Competency Categories
- **Selling Skills**
- **Healthcare Marketplace** (payer/HCP landscape)
- **Analytics & Insights** (data-driven decision-making)
- **Internal Partnerships** (cross-functional collaboration)
- **Account Management** (territory/account strategy)
- **Business Planning** (strategic planning)
- **Pre-Call Planning** (meeting preparation)
- **Stakeholder Mapping** (stakeholder analysis)

#### Compliance Tracking
- **Question:** "Was a field observation conducted?" (Yes/No)
- **Rate Calculation:** `COUNT("Yes") / COUNT(all) * 100`
- **Interpretation:** % of FCRs that included documented field observations

---

### 3️⃣ **FCRs PAGE** (`FCRsPage.jsx`)
**Purpose:** Browse individual FCRs, view details, and score coaching quality with AI

#### Data Structure
Two main tabs:

| Tab | Filter | Limit | Use Case |
|-----|--------|-------|----------|
| **All FCRs** | General coaching forms | 100 | Browse recent coaching activity |
| **PINS FCRs (FBMS)** | Only MSL/VESE engagement titles | 500 | Focus on advanced coaching framework |

#### Data Fetched
1. **`/api/fcrs?pinsOnly=true/false&limit=100/500&offset=0`**
   - Lists FCR metadata: coachee name, role, date, status, TA, region, territory
   - Status: Draft, Submitted, Late Submission, Completed
   - Returns: `{ total, rows }`

2. **`/api/fcr/:id`** (on detail panel open)
   - Full FCR breakdown: all questions + responses
   - Includes PINS narratives, coaching observations, action items

3. **`/api/pins-score`** (on "Score PINS" button click) — **AI-Powered**
   - Inputs: FCR ID + job level
   - Extracts PINS narratives (P/I/N/S sections)
   - Sends to Azure OpenAI with FBMS skill context
   - Returns: JSON with section scores (1–4), individual behavior scores, skill gaps, summary

#### PINS Framework (Planning, Investigate, Navigate, Secure)

**Each section scored 1–4 by GPT:**

**P – Planning for Perspective**
- P1: Strategic goals aligned to business partner strategy
- P2: Digital insights & pre-call preparation
- P3: Resource selection

**I – Investigate Issues**
- I1: Meeting objectives recap & HCP input invited
- I2: Open-ended questions & active listening
- I3: Surfaced motivators, barriers, unmet needs

**N – Navigate & Negotiate**
- N1: Confident scientific delivery
- N2: Addressed J&J / competitor misunderstandings
- N3: MAF/SA-aligned resources used

**S – Secure Action**
- S1: Objectives achieved with clinical reinforcement
- S2: Internal follow-up planned
- S3: VoC insights documented
- S4: CRM entry completed

#### FBMS Core Skills (Measured from PINS Behaviors)
1. **Data Gathering** — Insight collection, documentation
2. **Strategic Thinking** — Planning alignment, objective-setting
3. **Competitive Landscape** — Market/competitor knowledge
4. **Influencing** — Communication, persuasion, listening
5. **Clinical Expertise** — Scientific accuracy, resource use
6. **Problem Solving** — Root cause analysis, adaptability
7. **Cross-functional Collaboration** — Partnership effectiveness

#### Proficiency Targets by Job Level
**J&J Pay Grade Matrix (Official):**
- **PG30** (Entry MSL): Data Gathering (2), Influencing (2), Clinical (2)
- **PG31** (Senior MSL): Data Gathering (2), Influencing (3), Clinical (3)
- **PG40** (Principal): Data Gathering (3), Influencing (3), Strategic Thinking (3), Clinical (4)
- **PG41** (Director): Strategic Thinking (4), Competitive Landscape (4), Influencing (4), Clinical (4)

**Skill Gaps** = Actual Score − Target Score

#### What Happens on "Score PINS" Click
1. User clicks purple button → fetch full FCR detail
2. Extract all PINS narrative sections
3. Send to Azure OpenAI GPT with:
   - PINS narratives
   - Coachee job level (detected from designation)
   - FBMS skill definitions
   - Official proficiency targets for that level
4. GPT returns:
   - Scores for each behavior (P1-P3, I1-I3, N1-N3, S1-S4)
   - Aggregated section scores (P/I/N/S overall: 1–4)
   - Individual FBMS skill scores (7 skills: 1–4)
   - Skill gap analysis (actual − target)
   - Summary text
5. Results display in panel with:
   - Color-coded score badges (Blue=Expert, Green=Advanced, Amber=Skilled, Red=Awareness)
   - Skill gap visualization (dark panel with 7 skills + target markers)
   - "PDF" button appears → download 3-page coaching report

#### PDF Export
- **File:** `PinsPdfReport.jsx`
- **Format:** 3-page A4 PDF (using @react-pdf/renderer)
- **Content:**
  - Page 1: Header, FCR metadata, AI summary, Planning (P) section with behaviors
  - Page 2: Investigate (I) + Navigate (N) sections
  - Page 3: Secure (S) section, FBMS 7-skill panel with target gaps, compliance box
- **Naming:** `PINS_FCR_{FirstName}_{LastName}_{YYYY-MM-DD}.pdf`
- **Use Case:** Field director coaches share with coachees; business can download for training documentation

---

### 4️⃣ **ACTIVITY PAGE** (`ActivityPage.jsx`)
**Purpose:** Operational snapshot of coaching submissions & adoption

#### Data Source
- **Mock data** (currently not connected to live DB)
- Intended to show:
  - Daily/monthly submission trend
  - Status distribution (Draft, Submitted, Late, Completed)
  - Alerts & exceptions
  - Coverage by organization

#### Future Enhancement
- Could connect to `/api/fcrs` to show live submission rates
- Time-series of submission volume vs. target SLA

---

### 5️⃣ **SKILL PROFICIENCY TREND VIEW** (`SkillProficiencyTrendView.jsx`)
**Purpose:** Monitor coaching quality trajectory over 12 months

#### Data Fetched
- **`/api/capability`** (12-month trend data)
  - Monthly avg competency score
  - Monthly FCR count
- **`/api/pins-trend`**
  - Monthly PINS section scores (P/I/N/S)
  - Score proxy: % with "No training needed" mapped to 1–3 scale

#### Calculations

**Monthly Avg Score:**
```
AVG(competency_score) grouped by DATE_TRUNC('month', acty_dt)
```

**PINS Score Proxy:**
```
no_training_pct = COUNT("training needed" = 'No') / COUNT(all) * 100
score = 1 + (no_training_pct / 100) * 2  // maps 0–100% to 1–3 scale
```
- 0% no training (all need training) = score 1 (Awareness)
- 50% no training (mixed) = score 2 (Skilled)
- 100% no training (all proficient) = score 3 (Advanced)

#### Dual Chart
- **Primary (Bar):** Monthly FCR volume (coaching activity)
- **Secondary (Line):** Monthly avg skill score or PINS proficiency
- **Purpose:** Correlate volume with quality — are we coaching more AND better?

#### AI Insights (`/api/skill-trend-insight`)
- Post request with trend data
- GPT analyzes and returns:
  - **Trend Summary:** Overall direction (improving/declining)
  - **Strongest Months:** When quality peaked, why
  - **Areas of Concern:** Lowest scores, divergence between volume & quality
  - **Coaching Recommendations:** Next steps based on trends

---

### 6️⃣ **TRAINING SKILL GAPS VIEW** (`TrainingSkillGapsView.jsx`)
**Purpose:** Identify which PINS sections need the most coaching intervention

#### Data Fetched
- **`/api/pins-summary`**
  - Aggregate training flags by PINS section (P/I/N/S)
  - By job level
  - By rep (ranked by total flags)
  - By TA

#### PINS Summary Calculation

**Training Flag Query** (pure SQL, no GPT):
```sql
SELECT section (P|I|N|S), 
       COUNT(FCR_ID where response='Yes') as training_needed,
       COUNT(FCR_ID where response='No') as training_not_needed
FROM PINS_training_flag_rows
GROUP BY section
```

**% Need Training:**
```
training_needed / (training_needed + training_not_needed) * 100
```

**"Training Needed" Question:** Each PINS section ends with:
- "P/I/N/S Training Needed?" → Yes/No (field director's assessment)
- If "Yes" → coachee requires follow-up coaching in that section
- If "No" → coachee demonstrated proficiency in that section

#### Dashboard Cards (P/I/N/S)
Each card shows:
- **% of FCRs needing training** (large number)
- **Stacked bar:** Red (needs training) + Green (doesn't need) + Gray (no flag answered)
- **Metadata:** Total FCRs, flagged count

#### Reps at Risk
Ranked list of reps with highest training flag counts:
- Columns: Name, TA, Region, Total Flags, P/I/N/S breakdown
- Sort: descending by total flags
- Use case: Identify high-priority coaching targets

#### By Job Level Heatmap
- Rows: Job levels (PG30, PG31, PG40, PG41, Senior, etc.)
- Columns: PINS sections (P/I/N/S)
- Cell values: FCR count with training flags
- Identifies which job levels struggle with which competencies

---

### 7️⃣ **ASK AI PAGE** (`AskAIPage.jsx`)
**Purpose:** Natural language Q&A over FCR data (text-to-SQL)

#### Data Flow

**User asks question** → Example: "How many FCRs were written this quarter?"

1. **Step 1 — SQL Generation (GPT)**
   - System prompt provides:
     - Table schema (`odp.dp_cust_pers_engagement_dly`)
     - Column names & data types
     - Base filters (chnl, engagement_title pattern)
     - PINS framework definitions
     - Compliance question pattern
     - LEAD model patterns
   - User question + conversation history sent to GPT
   - GPT generates single Redshift SQL query

2. **Step 2 — SQL Execution**
   - Query validated for:
     - Write operation blocking (DROP, INSERT, etc.)
     - Unauthorized table references
   - Executed against Redshift
   - Results returned (up to 100 rows)

3. **Step 3 — Natural Language Answer (GPT)**
   - Results + original SQL + question sent back to GPT
   - GPT explains findings in plain English
   - Highlights patterns, anomalies, recommendations

#### Suggested Quick Queries
- "How many FCRs were written this quarter?"
- "Which region has the most coaching activity?"
- "Top 5 reps by FCR count"

#### Built-In Query Context
- LEAD scoring: Learning (1) → Applying (2) → Leading (3)
- Competency scale: 1–4
- PINS sections: P, I, N, S (mapped to question text patterns)
- Status: Draft, Submitted, Late Submission

---

## 🧠 AI & Insight Generation Flows

### Flow 1: FCR-Level Insight (`/api/fcr-insight`)
**Trigger:** User clicks "Get Insight" button on FCR detail panel

**Data Passed:**
- FCR metadata: coachee name, role, TA, region, coaching date, session duration
- Competency scores (avg per competency: 1–4)
- Written observations (open-text coaching notes)
- Action items (current + previous)
- Trend data (last 8 FCRs for this rep)

**GPT Prompt Template:**
```
You are a J&J field coaching advisor.
Analyze this FCR with context:
- Coachee: [name] ([role])
- Competency scores: [all 6 competencies with ratings]
- Coaching observations: [text notes]
- Progress trend: [last 8 FCR scores]

Provide analysis in 4 sections:
1. Overall Assessment (2 sent: performance, trajectory, context)
2. Key Strengths (with specific quotes from observations)
3. Priority Development Areas (gaps with competency names)
4. Coaching Recommendation (next steps for field director)
```

**Output:**
- 2500-word narrative
- Structured markdown with sections
- Specific competency references + observations quoted
- Actionable coaching steps

---

### Flow 2: PINS AI Scoring (`/api/pins-score`)
**Trigger:** User clicks "Score PINS" button on FCR detail panel

**Data Passed:**
- FCR ID
- Coachee job level (detected from designation or passed explicitly)

**Backend Actions:**
1. Query Redshift for all PINS rows:
   - Extract narratives for P/I/N/S sections
   - Extract training flags (Yes/No for each section)

2. Send to GPT with:
   - **Context:** FBMS definition (7 skills), observable behaviors (P1-P3, I1-I3, N1-N3, S1-S4)
   - **Narratives:** Full text from P/I/N/S sections
   - **Job level:** Detected pay grade (PG30/31/40/41)
   - **Proficiency targets:** Official J&J targets for that pay grade
   - **Prompt:** Score each behavior 1–4, aggregate to section scores, calculate skill gaps

3. GPT returns JSON:
   ```json
   {
     "sections": {
       "P": { "score": 3, "strength": "...", "opportunity": "...", "behaviors": [...] },
       ...
     },
     "skills": {
       "DataGathering": { "score": 3, "evidence": "..." },
       ...
     },
     "summary": "2–3 sentence overall summary",
     "gaps": { "DataGathering": { "actual": 2, "target": 3, "gap": -1 }, ... },
     "trainingFlags": { "P": true, "I": false, "N": null, "S": true }
   }
   ```

4. Frontend displays:
   - Color-coded section scores (blue/green/amber/red)
   - Skill proficiency vs. target visualization (7 skill bars with target markers)
   - Gap analysis (which skills below target)
   - Training flags per section (Yes/No/Not assessed)

---

### Flow 3: PINS Summary Insight (`/api/pins-insight`)
**Trigger:** Dashboard loads "Training Skill Gaps" view

**Data Passed:**
- Aggregate PINS summary: total FCRs, training flags by section, reps with most flags, job level breakdown
- Timeframe filters: TA, region, date range

**GPT Prompt:**
```
Analyze PINS training coverage:
- Total FCRs: [N]
- % needing training: [%]
- Training flags by section: [P/I/N/S counts]
- Job levels most affected: [top levels]
- Reps with highest flags: [top reps]

Provide insights in 4 sections:
1. Overall Assessment (training health)
2. Priority Areas (which sections, why)
3. Top Recommendations (specific actions)
4. Reps at Risk (name them, state action)
```

**Output:**
- Markdown with sections
- Data-driven (numbers + context)
- Actionable recommendations
- Call-outs for high-risk reps

---

### Flow 4: Skill Trend Insight (`/api/skill-trend-insight`)
**Trigger:** Skill Proficiency Trend view loads

**Data Passed:**
- Monthly trend: last 12 months of avg competency scores + FCR counts
- PINS trend: monthly P/I/N/S proficiency proxy scores
- Overall trajectory: improving/declining
- Latest skill score

**GPT Prompt:**
```
Analyze 12-month coaching skill trend:
- Scores: [monthly values]
- Volume: [monthly FCR counts]
- Overall direction: [improving/declining]
- Change: [+/- X points]

Provide in 4 sections:
1. Trend Summary (direction, pace, interpretation)
2. Strongest Months (when did quality peak? why?)
3. Areas of Concern (lowest scores, volume vs. quality mismatch)
4. Coaching Recommendations (next quarter focus)
```

**Output:**
- Markdown narrative
- Specific months referenced
- Volume-quality correlations highlighted
- Forward-looking recommendations

---

## 📈 Data Aggregation & Caching

### Caching Strategy
- **Cache TTL:** 5 minutes
- **Cached Endpoints:** `/api/summary`, `/api/kpis`, `/api/capability`, `/api/pins-summary`, `/api/pins-trend`
- **Why:** Redshift scans are expensive; repeat dashboard loads shouldn't re-query

### Cache Keys
```
cache_key = endpoint + JSON.stringify(query_filters)
Example: "summary:{"ta":"IMM","timeframe":"30"}"
```

### Backend Timeouts
- **`/api/fcrs`, `/api/fcr/:id`:** 25 seconds (Redshift large scans)
- **`/api/pins-summary`, `/api/pins-trend`:** 55 seconds (complex aggregations)
- **Default:** 5 minutes for slow queries

---

## 🔌 Real-Time Data Flow Diagram

```
USER INTERFACE
     ↓
[React Component]
     ↓
HTTP GET/POST
     ↓
Express API (port 8080)
     ↓
┌─────────────────────────────────────────────┐
│ ROUTING LOGIC                               │
│ • Filter building                           │
│ • Query construction                        │
│ • Cache lookup (TTL 5 min)                 │
└─────────────────────────────────────────────┘
     ↓
┌──────────────────┬──────────────────┐
│ CACHE HIT        │ CACHE MISS       │
│ Return cached    │ Query Redshift   │
│ results (fast)   │ Cache result     │
└──────────────────┴──────────────────┘
     ↓
Amazon Redshift
(odp.dp_cust_pers_engagement_dly)
     ↓
Parse rows → format JSON → return to frontend
     ↓
AI ENHANCEMENT (async)
┌──────────────────────────────────────────────────────────┐
│ For PINS scoring / Insights:                            │
│ 1. Extract narrative data                               │
│ 2. Format prompt with context + schema                  │
│ 3. POST to Azure OpenAI GPT-4                          │
│ 4. Parse JSON response                                  │
│ 5. Return to frontend                                   │
└──────────────────────────────────────────────────────────┘
     ↓
React State Update → Render to user
```

---

## 📊 Key Metrics for Presentation

### Volume Metrics
- **Total FCRs:** Count of unique coaching engagements
- **Total Reps Coached:** Distinct coachee count
- **FCRs per Rep:** Avg coaching intensity
- **FCRs by TA/Region:** Geographic/therapeutic area distribution

### Quality Metrics
- **Avg Competency Score:** 1–4 scale (higher = better)
- **% at Target:** Reps with score ≥3 (Emerging Strength or above)
- **% in Clear Development Need:** Score = 1 (flagged for intervention)
- **Compliance Rate:** % of FCRs with field observation documented

### Behavioral Metrics (PINS)
- **PINS Training Flags:** % of FCRs needing follow-up per section
- **Skill Gaps:** Actual vs. job-level target proficiency
- **FBMS Proficiency Scores:** 1–4 for each of 7 skills
- **Section Breakdown:** P/I/N/S individual scores

### Submission Health
- **Submitted %:** On-time FCR submissions
- **Late Submission %:** Overdue FCRs
- **Avg Days to Submit:** Speed of follow-up documentation
- **Draft %:** Incomplete/pending FCRs

---

## 🎯 How This Enables Business Decisions

| Business Question | Data Used | Insight Generated | Action |
|---|---|---|---|
| "Are we coaching at volume?" | Total FCRs, by TA/region/time | Adoption trend, where coaching is happening | Adjust resources to underperforming regions |
| "Is coaching quality improving?" | Avg competency score, 12-mo trend | Quality trajectory, volume-quality correlation | Invest in training if declining despite volume |
| "Which reps need intervention?" | PINS training flags, skill gaps | High-risk list by section (P/I/N/S) | Prioritize advanced coaching for flagged reps |
| "Are MSLs field-ready?" | FBMS skill scores vs. job targets | Skill gap analysis per pay grade | Tailor development by job level |
| "What's the top coaching gap?" | PINS section % needing training | Highest flagged section (e.g., "Negotiate" = 45%) | Focus next coaching initiative on that section |
| "Is field observation happening?" | Compliance rate | % with documented field obs | Reinforce CRM data-entry discipline |
| "Who are our top coaches?" | FCR count + avg quality per field director | High-volume, high-quality coaches | Certify as peer coaches / mentors |

---

## 🔐 Data Security & Governance

- **SSO Authentication:** Azure AD / Microsoft Identity (corporate login required)
- **Consent Flow:** Users must acknowledge Confidential data policy before using platform
- **Database Access:** Read-only queries to Redshift (no write/delete capability)
- **Query Validation:** AI-generated SQL blocked if attempts write operations or unauthorized table access
- **Environment Variables:** Sensitive credentials (API keys, DB passwords) stored in `.env` (not in code)

---

## 📝 Frequently Asked Questions

**Q: What if an FCR doesn't have PINS data?**
A: PINS scoring only appears for MSL/VESE engagement titles. Other form types (OCE, etc.) show standard competency scoring instead.

**Q: Why do skill scores vary between views?**
A: **Capability page** = avg of all competency questions. **PINS page** = AI-scored FBMS behaviors. Different data sources, same construct (quality).

**Q: How often is data updated?**
A: Database pulls are real-time (Redshift updates as iConnect records are submitted). Dashboard caches refresh every 5 min. PDFs generated on-demand when user clicks "PDF".

**Q: Can we export all FCRs?**
A: Individual PDFs can be downloaded per FCR. Bulk CSV export currently available on Activity page (growing feature).

**Q: What if Redshift is slow?**
A: Queries have 25–55 sec timeouts. If exceeded, returns timeout message. Users can narrow filters (add TA, region, or date range) to speed up.

---

## 🚀 Technical Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Frontend** | React 19 + Vite 8 | SPA with live charts, AI integrations |
| **Backend API** | Express.js 5 | RESTful routes, SQL building, Redshift queries |
| **Database** | Amazon Redshift (PostgreSQL) | Core data warehouse for FCR records |
| **AI Engine** | Azure OpenAI (GPT-4) | SQL generation, PINS scoring, insight synthesis |
| **Authentication** | Azure AD / MSAL | Corporate SSO, user identity |
| **PDF Generation** | @react-pdf/renderer | Client-side PINS coaching report download |
| **Charting** | Recharts + Recharts Radar | Responsive data visualizations |

---

## 📦 Deployment

- **Frontend Build:** `npx vite build` → `dist/` folder (pre-built React)
- **Backend:** Node.js running `server.js` on port 8080
- **Packaging:** `fcr-ai-deploy.zip` (0.85 MB) — ready for Azure Web App deployment
- **Environment Setup:** Port, Redshift credentials, OpenAI API key, Azure AD tenant ID

---

**Document Version:** 1.0 | **Last Updated:** 2026-07-07
