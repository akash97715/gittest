# FCR AI — Developer Onboarding Guide

> **For new developers joining this project.** This document explains everything:
> what the app does, how the code is organized, how to run it locally, how each piece connects,
> and what to watch out for. Read this top-to-bottom before touching any code.

---

## 1. What Is This App?

**FCR AI** is a web dashboard for J&J Medical Science Liaisons (MSLs).

MSL managers submit **Field Coaching Reports (FCRs)** after observing an MSL in the field.
Each FCR has ~42 questions rating the MSL on behaviors and competencies.
This app reads those FCRs from a database and provides:

- A **dashboard** with KPIs (compliance rates, submission trends, FBMS scores)
- A **FCRs table** to browse, filter, and search all coaching reports
- A **detail panel** for each FCR with full question/answer breakdown and AI-scored PINS analysis
- An **Ask AI** feature where managers can ask natural-language questions about the data
- A **Capability** view showing skill-level trends over time
- An **Activity** log of recent events
- A **Reference** page with guides

The app is **MSL/VESE only** — a global filter ensures only MSL and VESE Field Coaching Reports are shown (not other form types in the database).

---

## 2. Tech Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| Frontend | React | 19 | UI components |
| Build tool | Vite | 8 | Dev server, bundling |
| Backend | Express.js | 5 | REST API server |
| Database | Amazon Redshift | — | All FCR data (PostgreSQL-compatible) |
| AI | Azure OpenAI GPT | gpt-5.4 | PINS scoring, Ask AI, FCR insights |
| Auth | Azure AD / MSAL | — | J&J SSO login |
| PDF | @react-pdf/renderer | 4 | Export PINS reports to PDF |
| Charts | Recharts | 3 | Dashboard charts |
| Icons | Lucide React | — | All UI icons |
| Fonts | JohnsonDisplay | — | J&J brand font (local, in src/assets/Fonts/) |

---

## 3. Project Structure

```
fcr-ai-sso/
│
├── src/                          ← ALL frontend code lives here
│   ├── App.jsx                   ← Root component: auth gate + router
│   ├── main.jsx                  ← React entry point (mounts App)
│   ├── App.css                   ← Global styles
│   ├── index.css                 ← Base reset/typography
│   ├── authConfig.js             ← Azure AD / MSAL configuration
│   │
│   ├── pages/                    ← One file per page/route
│   │   ├── LoginPage.jsx         ← Unauthenticated landing page
│   │   ├── ConsentPage.jsx       ← Post-login role/consent screen
│   │   ├── DashboardPage.jsx     ← Main KPI dashboard
│   │   ├── FCRsPage.jsx          ← FCR table + detail panel (MOST COMPLEX)
│   │   ├── CapabilityPage.jsx    ← Skill proficiency trends
│   │   ├── AskAIPage.jsx         ← Natural language Q&A
│   │   ├── ActivityPage.jsx      ← Activity log
│   │   ├── ReferencePage.jsx     ← Documentation/guides
│   │   ├── SkillProficiencyTrendView.jsx  ← Sub-view for capability
│   │   └── TrainingSkillGapsView.jsx      ← Sub-view for skill gaps
│   │
│   ├── components/               ← Reusable UI components
│   │   ├── Sidebar.jsx           ← Left nav menu
│   │   ├── Topbar.jsx            ← Top header bar
│   │   ├── HeroCard.jsx          ← KPI summary cards
│   │   ├── AlertsBanner.jsx      ← Warning/info banners
│   │   ├── CoverageTable.jsx     ← Coverage metrics table
│   │   ├── RecentFCRsTable.jsx   ← Small FCR table for dashboard
│   │   ├── SubmissionsChart.jsx  ← Submissions trend chart
│   │   ├── AskAIPanel.jsx        ← Ask AI side panel
│   │   └── PinsPdfReport.jsx     ← PDF layout for PINS export
│   │
│   ├── data/
│   │   └── mockData.js           ← Static mock data (used for fallback)
│   │
│   └── assets/
│       └── Fonts/                ← JohnsonDisplay font files (.woff2 etc.)
│
├── server.js                     ← Express backend (ALL API endpoints here)
├── db.js                         ← Redshift connection pool configuration
├── .env                          ← Environment variables (credentials — DO NOT COMMIT)
├── package.json                  ← Dependencies and npm scripts
├── vite.config.js                ← Vite config (dev proxy: /api → :8080)
├── index.html                    ← HTML shell (Vite entry)
├── web.config                    ← Azure App Service IIS config
│
├── FCR_AI_INSIGHTS_DOCUMENTATION.md   ← 18-page full technical documentation
├── DATA_FLOW_AND_INSIGHTS.md          ← Data flow diagrams and insights
├── DEVELOPER_GUIDE.md                 ← This file
│
├── dist/                         ← Built frontend (Vite output, served by Express in prod)
├── deploy-staging/               ← Staging server copy
└── node_modules/                 ← Dependencies (do not touch)
```

> **Root-level duplicate files** (ActivityPage.jsx, AlertsBanner.jsx etc. at the root) are **old copies** — ignore them.
> The real code is always inside `src/`.

---

## 4. How to Run Locally

### Prerequisites
- Node.js 18+ (recommend Node 22 LTS)
- Access to J&J network / VPN (required for Redshift connection)
- The `.env` file (already in the repo)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Start the backend (Express API server on port 8080)
node --env-file=.env server.js

# 3. In a NEW terminal, start the frontend (Vite dev server on port 5173)
npm run dev
```

Then open **http://localhost:5173** in your browser.

> **Why two terminals?** In development, Vite (port 5173) handles the React frontend,
> and Express (port 8080) handles the API. Vite automatically proxies all `/api/*` requests
> to Express — this is configured in `vite.config.js`.

### Login
The app uses **J&J Azure AD SSO**. You must log in with your `@its.jnj.com` account.
After login, it reads your `jobTitle` from your Azure AD token to determine your role.

---

## 5. Environment Variables (.env)

```env
# Redshift (AWS database)
REDSHIFT_HOST=itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com
REDSHIFT_PORT=5439
REDSHIFT_DB=awprdrsdb
REDSHIFT_USER=vkrish53
REDSHIFT_PASSWORD=...

# Azure OpenAI (GPT)
AZURE_OPENAI_ENDPOINT=https://azr-iay-openai.openai.azure.com/
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_DEPLOYMENT=gpt-5.4
AZURE_OPENAI_API_VERSION=2025-01-01-preview
```

These variables are loaded in `server.js` and `db.js` via `dotenv`.
In production (Azure App Service), these are set as **Application Settings** in the Azure Portal (not the .env file).

---

## 6. Database

### Connection: `db.js`
Creates a PostgreSQL connection pool to Amazon Redshift:
```js
const pool = new Pool({
  host: process.env.REDSHIFT_HOST,
  port: 5439,
  database: process.env.REDSHIFT_DB,
  max: 10,           // max 10 concurrent connections
  min: 2,            // always keep 2 warm (avoids cold-start delay)
  idleTimeoutMillis: 30000,
  statement_timeout: 55000,   // kill any query > 55 seconds
});
```

### The Single Table: `odp.dp_cust_pers_engagement_dly`
**All FCR data lives in one table.** Key columns:

| Column | Description |
|--------|-------------|
| `survey_target_id` | FCR unique ID (full Salesforce ID, e.g. `a2zWQ0000049xJVYAY`) |
| `rep_first_nm` / `rep_last_nm` | MSL name |
| `engagement_title` | Form type (e.g. "MSL Field Coaching Report") |
| `acty_dt` | Coaching date |
| `survey_question_text` | The question asked |
| `survey_question_response` | Response: Awareness/Skilled/Advanced/Expert or Yes/No |
| `survey_question_response_text` | Free-text narrative written by the coach |
| `survey_question_order` | Order of question in the form |
| `chnl` | Channel type (SURVEY, etc.) |
| `terr_nm` | MSL territory |
| `ta_nm` | Therapeutic area |

**1 FCR = 30–42 rows** in this table (one row per question).

### MSL-Only Filter
Applied to ALL queries to ensure only MSL/VESE FCRs are shown:
```sql
(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
```
This constant is defined at the top of `server.js` as `MSL_FILTER`.

### Find an FCR's Full ID
The UI shows a short version (`49XJVYAY`). To query in DBeaver you need the full ID:
```sql
SELECT DISTINCT survey_target_id, rep_first_nm, rep_last_nm
FROM odp.dp_cust_pers_engagement_dly
WHERE (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
  AND survey_target_id LIKE '%49XJVYAY%';
```

---

## 7. Backend: `server.js`

All API logic is in this single file. Key structure:

```
server.js
├── Imports + env setup
├── MSL_FILTER constant (global SQL filter)
├── Cache setup (in-memory Map with TTL)
├── All API endpoints (app.get / app.post)
└── app.listen(8080)
```

### Cache System
To reduce Redshift load, results are cached in memory:
```js
const CACHE_TTL        = 5 * 60 * 1000;   // 5 min — general
const CACHE_TTL_FCR    = 2 * 60 * 1000;   // 2 min — FCRs list
const CACHE_TTL_DETAIL = 10 * 60 * 1000;  // 10 min — FCR detail
```
Cache keys are based on query parameters. The cache is per-instance (not shared between Azure instances).

### All API Endpoints

| Method | Endpoint | Purpose | Cached? |
|--------|----------|---------|---------|
| GET | `/api/kpis` | Dashboard KPI metrics | ✅ 5 min |
| GET | `/api/fcrs` | FCR list (paginated 50/page) | ✅ 2 min |
| GET | `/api/fcr/:id` | Single FCR all questions | ✅ 10 min |
| GET | `/api/summary` | Submission summary stats | ✅ 5 min |
| GET | `/api/fbms-trend` | FBMS score over time | ✅ 5 min |
| GET | `/api/pins-summary` | PINS training flag aggregates | ✅ 5 min |
| GET | `/api/pins-trend` | PINS scores trend over time | ✅ 5 min |
| GET | `/api/skill-proficiency` | Skill level breakdown | ✅ 5 min |
| POST | `/api/ask` | Ask AI — natural language Q&A | ❌ No |
| POST | `/api/fcr-insight` | AI insight for a single FCR | ❌ No |
| POST | `/api/pins-score` | AI PINS scoring for an FCR | ❌ No |

### Timeout Handling
Every endpoint has:
```js
res.setTimeout(28000, () => {
  if (!res.headersSent) res.status(504).json({ error: 'Query timed out' });
});
```
The `statement_timeout` in db.js (55s) acts as a database-level backstop.

---

## 8. Frontend: Key Files Explained

### `src/App.jsx` — Router & Auth Gate
```
App.jsx flow:
  → If not authenticated → show LoginPage
  → If authenticated but no consent → show ConsentPage
  → Otherwise → show full app with Sidebar + route to pages
```
Uses `@azure/msal-react` hooks (`useMsal`, `useIsAuthenticated`).
Role is read from `account.idTokenClaims.jobTitle`.

### `src/authConfig.js` — Azure AD Config
```js
clientId: "d33645b3-66c1-4adf-93c1-fde580806208"   // App registration in J&J Azure AD
authority: "https://login.microsoftonline.com/3ac94b33-..."
redirectUri: window.location.origin + "/"
```
`domainHint: "its.jnj.com"` forces J&J corporate login.

### `src/pages/FCRsPage.jsx` — Most Complex Page
This is the heart of the app. Understand this file first.

**Key state variables:**
- `fcrs` — array of FCR rows from `/api/fcrs`
- `selectedFcr` — currently open FCR in detail panel
- `currentPage` — pagination (50 rows per page)
- `activeTab` — "All FCRs" vs "PINS"
- `searchTerm`, `taFilter` — filter controls

**FBMS Score Calculation (done in browser, not DB):**
```js
const FBMS_SCORE = { Expert: 4, Advanced: 3, Skilled: 2, Awareness: 1 };

// Average all rated behavior responses for an FCR
const avg = behaviors.reduce((sum, b) => sum + FBMS_SCORE[b.response], 0) / behaviors.length;

// Map to label
if (avg >= 3.5) return 'Expert';
if (avg >= 2.5) return 'Advanced';
if (avg >= 1.5) return 'Skilled';
return 'Awareness';
```

**Pagination:**
- 50 rows per page (`PAGE_SIZE = 50`)
- `offset = (currentPage - 1) * PAGE_SIZE`
- UI shows Prev/Next buttons + numbered page pills

### `src/components/PinsPdfReport.jsx` — PDF Export
Uses `@react-pdf/renderer`. When user clicks "Export PDF" on a PINS-scored FCR,
this component renders the PINS analysis as a PDF download.

---

## 9. FBMS Scoring — How It Works

**FBMS = Field-Based Behavioral Management System** — a 1-4 competency scale.

| Score | Label | Meaning |
|-------|-------|---------|
| 1 | Awareness | Understands basics, needs significant development |
| 2 | Skilled | Meets expectations, competent |
| 3 | Advanced | Exceeds expectations, performs independently |
| 4 | Expert | Role model, coaches others |

**Where the data comes from:** `survey_question_response` column in Redshift.
Each question has a response of Awareness/Skilled/Advanced/Expert (or Yes/No for training flags).

**Where the calculation happens:** In the browser (React), not in the database.
The frontend reads all question responses for an FCR and averages the numeric scores.

**Score label thresholds:**
- ≥ 3.5 → Expert
- ≥ 2.5 → Advanced  
- ≥ 1.5 → Skilled
- < 1.5 → Awareness

---

## 10. PINS Scoring — How It Works

**PINS = Planning, Investigate, Navigate, Secure** — the 4 stages of an MSL field visit.

Unlike FBMS (which reads pre-existing response values), **PINS scores are generated by GPT in real-time**.

### Flow when user clicks "Score PINS":
1. Frontend calls `POST /api/pins-score` with `{ fcrId, jobLevel }`
2. Backend queries Redshift for all PINS narrative text (questions starting with PLAN/INVEST/NAVIGAT/SECURE/NEGOT)
3. Backend bundles narratives into a detailed GPT prompt
4. GPT-4 reads the prompt and returns JSON with:
   - Score (1-4) for each of P, I, N, S sections
   - Score for each individual behavior (P1, P2, P3, I1, I2, I3, N1, N2, N3, S1, S2, S3, S4)
   - Score for 7 FBMS skills (DataGathering, Influencing, ClinicalExpertise, etc.)
   - Strengths and opportunities text
   - 2-3 sentence overall summary
5. Backend computes skill gaps vs. job level targets (J&J pay grade matrix PG30-PG41)
6. Frontend displays the full breakdown with color-coded scores

**GPT temperature: 0.1** (almost deterministic — consistent scores across multiple calls)

---

## 11. Azure AD Authentication

```
User opens app
  → MSAL redirects to Microsoft login
  → User logs in with @its.jnj.com account
  → Azure AD returns access token + ID token
  → MSAL stores token in memory (not localStorage — more secure)
  → App reads jobTitle from ID token claims → determines role
  → ConsentPage shown once to confirm role
  → Full app unlocked
```

The Azure App Registration (`d33645b3-...`) is in the J&J tenant (`3ac94b33-...`).
Contact the J&J IAM team if login stops working (usually expired secrets or redirect URI issues).

---

## 12. Production Deployment (Azure)

### Infrastructure
- **App Service Plan:** azr-iay-fcrai-asp-dev (P1v3, 2 instances)
- **App Service:** azr-iay-fcr-ai-appsrvce-dev.azurewebsites.net
- **Resource Group:** AZR-IAY-Appservice-Development
- **Runtime:** Node 22 LTS on Linux
- **VNet:** AZR-IAY-eastus/hybridsubnet-appservice-fcrai-dev (for Redshift access)

### How Production Works (Different from Dev!)
In production:
- Express (`server.js`) serves BOTH the API **and** the built React frontend from `dist/`
- No separate Vite server — just one Node process
- Port is `process.env.PORT` (Azure injects this, usually 8080)
- `.env` is NOT used — credentials come from Azure App Service Application Settings

### `web.config`
Tells Azure IIS to route all requests to Node:
```xml
<handlers>
  <add name="iisnode" path="server.js" verb="*" modules="iisnode"/>
</handlers>
```

### Deploy Steps
```bash
# 1. Build the React frontend
npm run build:prod

# 2. Zip the project (excludes node_modules)
node build-zip.mjs

# 3. Upload fcr-ai-deploy.zip to Azure Portal
# Azure App Service → Deployment → Deploy from ZIP
```

---

## 13. Common Issues & Fixes

### "Loading timed out — please try again"
**Cause:** Redshift query took >28 seconds (connection pool exhausted or slow cluster).
**Fix:** Check `db.js` pool size (should be max:10). Check if Redshift cluster is "Resuming" from auto-pause (takes 3-5 min on first query).

### Blank screen after login
**Cause:** MSAL redirect URI mismatch. The `redirectUri` in `authConfig.js` must exactly match what's registered in the Azure App Registration.
**Fix:** In Azure Portal → App Registration → Authentication → check Redirect URIs.

### API returns 502 from AI endpoints
**Cause:** Azure OpenAI key expired or deployment name changed.
**Fix:** Check `.env` (local) or App Service Application Settings (production) — verify `AZURE_OPENAI_API_KEY` and `AZURE_OPENAI_DEPLOYMENT`.

### FCR detail panel shows no data
**Cause:** The FCR ID format — UI shows short version (`49XJVYAY`) but the actual DB ID is the full Salesforce ID (`a2zWQ0000049xJVYAY`). The backend stores the full ID.
**Fix:** No action needed — the backend always uses the full ID. This is only a display difference.

### "No PINS data found" on Score PINS
**Cause:** That FCR doesn't have PINS-format questions (some FCRs use a different question structure).
**Fix:** Only FCRs with questions starting with PLAN/INVEST/NAVIGAT/NEGOT/SECURE will have PINS data.

---

## 14. Key Files Quick Reference

| File | What to edit when... |
|------|---------------------|
| `server.js` | Adding/changing API endpoints, SQL queries, caching logic |
| `db.js` | Changing connection pool size, statement timeout |
| `src/pages/FCRsPage.jsx` | Changing FCR table, detail panel, FBMS calculation, pagination |
| `src/pages/DashboardPage.jsx` | Changing dashboard layout or KPI cards |
| `src/App.jsx` | Adding new pages/routes, changing auth flow |
| `src/authConfig.js` | Changing Azure AD tenant/client ID |
| `vite.config.js` | Changing dev server proxy or build settings |
| `src/components/PinsPdfReport.jsx` | Changing PDF export layout |
| `.env` | Updating database or OpenAI credentials |

---

## 15. Contacts

| Role | Contact | For |
|------|---------|-----|
| Infrastructure / Redshift | Vamsi | DB performance, cluster issues, network access |
| Azure / App Service | Azure DevOps team | Deployment, scaling, App Service config |
| J&J IAM | IAM team | Azure AD app registration, login issues |
| Data / Veeva | Data team | Redshift data questions, new columns |

---

*Last updated: July 2026*
