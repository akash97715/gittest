import AlertsBanner from '../components/AlertsBanner';
import HeroCard from '../components/HeroCard';
import SubmissionsChart from '../components/SubmissionsChart';
import CoverageTable from '../components/CoverageTable';
import RecentFCRsTable from '../components/RecentFCRsTable';
import AskAIPanel from '../components/AskAIPanel';

export default function DashboardPage() {
  return (
    <>
      <AlertsBanner />
      <HeroCard />

      {/* Two-column: Chart + Ask AI */}
      <div className="two-col-grid">
        <SubmissionsChart />
        <AskAIPanel />
      </div>

      <CoverageTable />
      <RecentFCRsTable />
    </>
  );
}
