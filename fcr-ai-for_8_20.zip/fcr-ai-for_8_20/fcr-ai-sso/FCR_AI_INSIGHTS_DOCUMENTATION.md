# FCR AI Insights — Comprehensive Technical & Functional Documentation

**Version:** 1.0  
**Date:** July 2026  
**Project:** FCR AI Insights Dashboard  
**Organization:** Johnson & Johnson — Scientific Affairs / Janssen  

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Solution Overview](#2-solution-overview)
3. [Technology Stack](#3-technology-stack)
4. [Data Sources](#4-data-sources)
5. [Data Flow & Ingestion](#5-data-flow--ingestion)
6. [Backend Architecture](#6-backend-architecture)
7. [Frontend Architecture](#7-frontend-architecture)
8. [API Endpoint Reference](#8-api-endpoint-reference)
9. [GPT / AI Integration](#9-gpt--ai-integration)
10. [Metrics & KPI Calculations](#10-metrics--kpi-calculations)
11. [Authentication & Security](#11-authentication--security)
12. [Caching Strategy](#12-caching-strategy)
13. [Deployment Process](#13-deployment-process)
14. [Troubleshooting Guide](#14-troubleshooting-guide)
15. [Performance Considerations](#15-performance-considerations)
16. [Future Enhancements](#16-future-enhancements)
17. [Appendix — Glossary & Quick Reference](#17-appendix--glossary--quick-reference)

---

## 1. Executive Summary

### What Is the Project?

**FCR AI Insights** is a React/Node.js web application that provides analytics and AI-powered insights on **Field Coaching Reports (FCRs)** submitted by Field Directors for MSL (Medical Science Liaison) professionals at Johnson & Johnson's Janssen Scientific Affairs division.

### Business Problem Being Solved

Field Directors observe MSLs during HCP (Healthcare Provider) meetings and complete Field Coaching Reports (FCRs) in iConnect (Veeva). However, this data lived in raw form in a data warehouse with no easy way to:

- Visualize an MSL's FBMS proficiency score over time
- Quickly identify which PINS skill areas need coaching attention
- Generate AI-powered analysis of coaching narratives
- Ask ad-hoc questions about team performance in plain English
- Export coaching reports as PDFs

**FCR AI Insights solves this** by pulling live data from Redshift, calculating proficiency scores, and presenting everything in a clean dashboard.

### Target Users

| User Role | Use Case |
|---|---|
| **Field Director (FD)** | Reviews coaching dashboards, scores PINS observations, tracks MSL development |
| **Regional Manager / Director** | Monitors team-level KPIs, identifies coaching gaps across territories |
| **MSL (Field Based Medical Science Liaison)** | Views own FCR detail, coaching feedback, training flags |
| **VP / Executive** | Views executive summary dashboard — submission rates, compliance, proficiency trends |
| **Data Analyst / Operations** | Uses Ask AI for ad-hoc queries — "How many MSLs scored Advanced in Q2?" |

### Expected Business Outcomes

- **Faster coaching insights** — no more manual Redshift/Excel analysis
- **Consistent FBMS scoring** — standardized 1-4 numeric scale across all FCRs
- **Training gap identification** — surfaced automatically from P/I/N/S flags
- **Compliance tracking** — scientific exchange compliance across all MSL interactions
- **AI-generated coaching summaries** — GPT summarizes 42 Q&A rows into actionable insights

### High-Level Workflow

```
Field Director observes MSL → fills FCR in iConnect (Veeva)
  → data syncs to Redshift daily
  → FCR AI Insights pulls live data
  → React dashboard displays proficiency scores, coaching narratives, AI analysis
  → FD/Manager reviews trends and identifies development priorities
```

---

## 2. Solution Overview

### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                     USER'S BROWSER                                   │
│                                                                      │
│   ┌─────────────────────────────────────────────────────────────┐   │
│   │           React 19 Frontend (Vite 8.0.12)                    │   │
│   │  Dashboard │ FCRs Page │ Capability │ Ask AI │ Training       │   │
│   └─────────────────┬───────────────────────────────────────────┘   │
└─────────────────────┼───────────────────────────────────────────────┘
                      │ HTTP REST API calls (JSON)
                      │ (same origin — Express serves React build)
┌─────────────────────▼───────────────────────────────────────────────┐
│              Azure App Service (AZR-IAY-FCRAI-SPN-IACDEV)           │
│                                                                      │
│   ┌───────────────────────────────────────────────────────────┐     │
│   │         Node.js Express 5 Backend (server.js)              │     │
│   │                                                           │     │
│   │  /api/kpis        → KPI hero card numbers                │     │
│   │  /api/summary     → Dashboard trend & breakdown          │     │
│   │  /api/fcrs        → FCR list with filters                │     │
│   │  /api/fcr/:id     → Single FCR detail (42 Q&A rows)      │     │
│   │  /api/rep-trend   → MSL proficiency trend over time      │     │
│   │  /api/capability  → FBMS skill breakdown                 │     │
│   │  /api/ask         → GPT text-to-SQL conversational AI    │     │
│   │  /api/fcr-insight → GPT FCR coaching summary             │     │
│   │  /api/pins-score  → GPT PINS behavior scoring            │     │
│   │  /api/pins-insight→ GPT PINS PDF narrative               │     │
│   └──────────┬────────────────────────────────┬──────────────┘     │
└──────────────┼────────────────────────────────┼────────────────────┘
               │ pg (PostgreSQL driver)          │ HTTPS REST
               │ port 5439                       │ api-key auth
┌──────────────▼──────────────┐  ┌──────────────▼────────────────────┐
│   Amazon Redshift (AWS)     │  │   Azure OpenAI GPT                │
│                             │  │   (gpt-5.4 deployment)            │
│   awprdrsdb                 │  │   azr-iay-openai.openai.azure.com │
│   odp.dp_cust_pers_         │  │                                   │
│   engagement_dly            │  │   Used for:                       │
│   (7,757 rows / 257 FCRs)   │  │   - Text-to-SQL (Ask AI)          │
│                             │  │   - FCR coaching summaries        │
│   Synced from:              │  │   - PINS behavior scoring         │
│   Veeva iConnect (daily)    │  └───────────────────────────────────┘
└─────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│         Azure Active Directory (SSO Authentication)                  │
│         Tenant: 3ac94b33-9135-4821-9502-eafda6592a35                 │
│         App Client ID: d33645b3-66c1-4adf-93c1-fde580806208         │
│         Domain Hint: its.jnj.com                                     │
└──────────────────────────────────────────────────────────────────────┘
```

### How Components Communicate

| From | To | Protocol | Auth |
|---|---|---|---|
| React Frontend | Express Backend | HTTP REST (same origin) | Azure AD token (via MSAL) |
| Express Backend | Amazon Redshift | PostgreSQL wire protocol (port 5439) | Username/password (.env) |
| Express Backend | Azure OpenAI | HTTPS REST | API Key (.env) |
| React Frontend | Azure AD | HTTPS OAuth 2.0 / MSAL | PKCE flow |

---

## 3. Technology Stack

### React 19 (Frontend)
- **Why chosen:** Latest stable React with concurrent features. Supports `useState`, `useEffect`, `useRef` patterns needed for FCR detail panel race condition prevention.
- **Purpose:** Renders the entire UI — Dashboard, FCRs page, Capability page, Ask AI chat, Sidebar, Topbar.
- **Key libraries:** `@azure/msal-react` (SSO), `recharts` (charts), `@react-pdf/renderer` (PDF export), `lucide-react` (icons).

### Vite 8.0.12 (Build Tool)
- **Why chosen:** Significantly faster than Create React App / Webpack. Hot Module Replacement (HMR) for development.
- **Purpose:** Bundles the React app into static files (`dist/`) that Express serves in production.
- **Config:** `vite.config.js` — proxies `/api/*` calls to `localhost:8080` during development.

### Express.js 5 (Backend)
- **Why chosen:** Minimal, fast Node.js HTTP framework. Express 5 adds async error handling natively.
- **Purpose:** Provides all REST API endpoints. Serves the React build as static files in production. Single server handles both frontend and API.
- **Port:** 8080 (configured via `process.env.PORT`).

### Amazon Redshift (Database)
- **Why chosen:** J&J's existing enterprise data warehouse where iConnect/Veeva coaching data already lives. No ETL required — data is already there.
- **Purpose:** Single source of truth for all FCR data. All analytics queries run against this.
- **Driver:** `pg` (node-postgres) — Redshift is PostgreSQL-compatible.
- **Table:** `odp.dp_cust_pers_engagement_dly`
- **Connection:** SSL required (`rejectUnauthorized: false`), port 5439.
- **Pool config:** max 5 connections, 55-second query timeout.

### Azure OpenAI GPT (AI Engine)
- **Why chosen:** J&J's approved enterprise AI service. Keeps data within J&J's Azure tenant — no data sent to public OpenAI.
- **Purpose:** Powers 4 features: text-to-SQL (Ask AI), FCR coaching summaries, PINS behavior scoring, PDF narrative generation.
- **Model:** `gpt-5.4` deployment at `azr-iay-openai.openai.azure.com`.
- **API Version:** `2025-01-01-preview`.
- **Auth:** API Key in `.env` file.

### Azure AD / MSAL (Authentication)
- **Why chosen:** J&J uses Azure AD for all enterprise SSO. Users log in with their J&J corporate credentials — no separate password management.
- **Purpose:** Authenticates users. Extracts job title and email from the Azure AD token to personalize the UI.
- **Library:** `@azure/msal-browser` + `@azure/msal-react`.
- **Scopes:** `User.Read` (reads basic profile from Microsoft Graph).

### @react-pdf/renderer (PDF Export)
- **Why chosen:** Pure JavaScript PDF generation — runs client-side in the browser, no server needed.
- **Purpose:** Generates downloadable PINS coaching report PDFs directly in the browser.
- **Component:** `src/components/PinsPdfReport.jsx`.

---

## 4. Data Sources

### Primary Table: `odp.dp_cust_pers_engagement_dly`

**Database:** `awprdrsdb` (Amazon Redshift)  
**Schema:** `odp`  
**Table Name:** `dp_cust_pers_engagement_dly`  
**Row count:** ~7,757 rows (257 unique FCRs × ~30-42 Q&A rows each)  
**Source system:** Veeva iConnect (J&J's CRM for field medical)  
**Refresh:** Daily sync from iConnect  
**Data ownership:** J&J Scientific Affairs / Data Engineering team

#### Key Columns

| Column | Data Type | Description | Example |
|---|---|---|---|
| `survey_target_id` | VARCHAR | Unique FCR identifier (internal) | `a2zWQ000004AODFYA4` |
| `chnl_engagement_id_value` | VARCHAR | Short display ID shown in UI | `4AODFYA4` |
| `chnl` | VARCHAR | Channel type — always `'SURVEY'` for FCRs | `SURVEY` |
| `engagement_title` | VARCHAR | Form name — identifies FCR type | `MSL/VESE Field Coaching Report` |
| `rep_wwid` | VARCHAR | MSL's unique employee ID (WWID) | `001234567` |
| `rep_first_nm` | VARCHAR | MSL first name | `Erin` |
| `rep_last_nm` | VARCHAR | MSL last name | `Ohman` |
| `rep_desig` | VARCHAR | MSL job title (raw, inconsistent) | `Medical Science Liaison GI South Texas` |
| `ownr_id` | VARCHAR | Field Director's Salesforce ID | `00560000002abcXYZ` |
| `ta` | VARCHAR | Therapeutic area code | `IMM`, `ONC`, `NS`, `SCG` |
| `acty_dt` | DATE | Coaching activity date | `2026-07-16` |
| `reg_nm` | VARCHAR | Region name | `South Region Field Director GI` |
| `distrc_nm` | VARCHAR | District name | `South GI District` |
| `terr_nm` | VARCHAR | Territory name | `South Texas GI MSL` |
| `survey_target_status` | VARCHAR | FCR status (Veeva internal value) | `Saved_vod` |
| `survey_status` | VARCHAR | Human-readable status | `Draft` |
| `survey_target_start_date` | TIMESTAMP | When FD started filling the form | `2026-07-16 09:00:00` |
| `survey_target_last_modified_date` | TIMESTAMP | When form was last saved/submitted | `2026-07-17 14:23:00` |
| `survey_target_session_duration` | VARCHAR | How long the field session was | `Two days` |
| `survey_target_action_item` | VARCHAR | Current action item | `Next Field Ride Q3` |
| `survey_target_previous_action_item` | VARCHAR | Previous action item for context | `Review PINS framework` |
| `survey_question_name` | VARCHAR | Internal question identifier | `planning_q1` |
| `survey_question_text` | VARCHAR | The actual question asked | `Developed strategically aligned goals...` |
| `survey_question_order` | INTEGER | Question display order (1-42) | `4` |
| `survey_question_response` | VARCHAR | The FD's answer choice | `Advanced` |
| `survey_question_response_text` | VARCHAR | Free-text narrative response | `-Has a great understanding of HCPs...` |
| `survey_question_answer_choice` | VARCHAR | Available answer options | `Expert|Advanced|Skilled|Awareness` |
| `company_nm` | VARCHAR | Company | `Johnson & Johnson` |
| `brand` | VARCHAR | Product brand | `Tremfya`, `Tecvayli` |

#### Important: Why Each FCR Has Multiple Rows
The table stores **one row per question per FCR**. Since each FCR has 42 questions, one FCR = ~42 rows. All SQL queries use `COUNT(DISTINCT survey_target_id)` for FCR counts and `GROUP BY survey_target_id` to get one-row-per-FCR.

#### MSL Filter — Critical
The app only shows **MSL/VESE** data. This is enforced by a global filter constant:
```sql
(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
```
This is applied to **every single SQL query** in the application. Without this filter, the app would also return CVM MSL knowledge surveys, rep coaching forms from other divisions, etc.

#### Data Quality Considerations
- `rep_desig` is raw and inconsistent — same title may appear as "Medical Science Liaison GI" or "MSL GI" — displayed as-is
- `acty_dt` can occasionally be NULL — ORDER BY uses `NULLS LAST`
- `engagement_title` contains the VESE/MSL identifier — used as the primary filter mechanism
- Currently all 257 FCRs have status `Saved_vod` (Draft) — no submitted FCRs exist yet

---

## 5. Data Flow & Ingestion

### Step-by-Step Flow

```
Step 1: Field Director completes FCR in Veeva iConnect
  ↓ (daily automated sync — managed by J&J Data Engineering)
Step 2: Data lands in Redshift table odp.dp_cust_pers_engagement_dly
  ↓ (query on page load or from in-memory cache)
Step 3: Express backend queries Redshift with MSL filter + any user filters
  ↓ (JSON response)
Step 4: React frontend receives JSON, calculates FBMS scores in JavaScript
  ↓ (optional: user clicks "Generate Insights")
Step 5: Express backend sends FCR data to Azure OpenAI GPT
  ↓ (GPT response)
Step 6: GPT returns AI coaching summary shown to user
```

### No ETL Pipeline Exists in This Application
This app does **not** have a data ingestion pipeline. It reads **live data directly from Redshift** on every request (with optional 5-minute in-memory caching for dashboard KPIs). The Redshift table is managed and refreshed by J&J's central Data Engineering team.

---

#BREAK



## 6. Backend Architecture

### File: `server.js`

The backend is a single Express.js file handling all API routes.

#### Startup Sequence
1. Load environment variables from `.env` via `dotenv/config`
2. Import Redshift connection pool from `db.js`
3. Define `MSL_FILTER` constant (applied globally)
4. Set up in-memory cache (Map-based, 5-minute TTL)
5. Register all API routes
6. Serve React `dist/` folder as static files
7. Start HTTP server on `process.env.PORT || 8080`

#### In-Memory Cache
```javascript
const _cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

function cacheGet(key) { /* returns null if expired */ }
function cacheSet(key, data) { /* stores with expiry timestamp */ }
```
- Applied to: `/api/summary` (dashboard KPIs, trends, breakdowns)
- Cache key includes query parameters so different filter combinations are cached separately
- Cache is lost on server restart (in-memory, not Redis)

#### Database Connection: `db.js`
```javascript
const pool = new Pool({
  host:     process.env.REDSHIFT_HOST,
  port:     5439,
  database: process.env.REDSHIFT_DB,
  user:     process.env.REDSHIFT_USER,
  password: process.env.REDSHIFT_PASSWORD,
  ssl:      { rejectUnauthorized: false },
  max:      5,                    // max concurrent connections
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  query_timeout: 55000,           // client-side abort after 55s
  statement_timeout: 55000,       // server-side Redshift cancel after 55s
});
```

---

## 7. Frontend Architecture

### File Structure

```
src/
├── App.jsx                    — Root component, routing logic, auth gate
├── main.jsx                   — Entry point, MsalProvider wrapper
├── authConfig.js              — Azure AD / MSAL configuration
├── index.css                  — Global styles, JohnsonDisplay @font-face
├── App.css                    — Layout styles (app-shell, sidebar, main-area)
├── assets/
│   └── Fonts/
│       ├── JohnsonDisplay-Regular.woff2
│       ├── JohnsonDisplay-RegularItalic.woff2
│       ├── JohnsonDisplay-Medium.woff2
│       └── JohnsonDisplay-MediumItalic.woff2
├── components/
│   ├── Sidebar.jsx            — Navigation sidebar (pulls role from Azure AD token)
│   ├── Topbar.jsx             — Top bar with user name and logout
│   ├── AlertsBanner.jsx       — Global alert messages
│   ├── HeroCard.jsx           — KPI hero card component
│   ├── RecentFCRsTable.jsx    — Recent FCRs table on dashboard
│   ├── CoverageTable.jsx      — Coverage/activity table
│   ├── SubmissionsChart.jsx   — FCR submission trend chart
│   └── PinsPdfReport.jsx      — PDF report generator (@react-pdf/renderer)
├── pages/
│   ├── LoginPage.jsx          — Microsoft SSO login screen
│   ├── ConsentPage.jsx        — Data use consent screen (required before access)
│   ├── DashboardPage.jsx      — Executive summary KPIs and charts
│   ├── FCRsPage.jsx           — FCR list + detail panel (main page)
│   ├── CapabilityPage.jsx     — FBMS skill proficiency breakdown
│   ├── AskAIPage.jsx          — Conversational AI query interface
│   ├── ReferencePage.jsx      — Reference documentation
│   ├── SkillProficiencyTrendView.jsx — Trend chart for skill scores over time
│   └── TrainingSkillGapsView.jsx — Training gaps analysis view
└── data/
    └── mockData.js            — Fallback mock data (used when backend unavailable)
```

### Authentication Flow in App.jsx

```javascript
// Step 1: Check Azure AD authentication
if (!isAuthenticated) return <LoginPage />;

// Step 2: Check data use consent
if (!hasConsented) return <ConsentPage onAccept={() => setHasConsented(true)} />;

// Step 3: Render main app with navigation
return (
  <div className="app-shell">
    <Sidebar active={active} onNavigate={setActive} />
    <main>{renderPage()}</main>
  </div>
);
```

### State Management
No Redux or external state library. Uses React's built-in `useState` and `useEffect`. State is local to each page component. Data flows top-down via props for shared components.

### Font
**JohnsonDisplay** — J&J brand font. Loaded via `@font-face` in `index.css` from local `woff2` files. Weights 300-400 use Regular, 500-900 use Medium. Google Fonts is NOT used.

---

## 8. API Endpoint Reference

### GET `/api/ping`
**Purpose:** Health check — tests Redshift connectivity.  
**Response:** `{ connected: true, db: "awprdrsdb", usr: "vkrish53" }`

---

### GET `/api/kpis`
**Purpose:** Dashboard hero card numbers.  
**Filters:** Hardcoded MSL filter only.  
**Response:**
```json
{
  "total_fcrs": 257,
  "total_reps": 189,
  "submitted": 0,
  "submitted_pct": 0,
  "avg_days_to_submit": null,
  "compliance_rate": 98.4,
  "non_compliant_count": 2
}
```

---

### GET `/api/summary`
**Purpose:** Full dashboard data — KPIs + TA breakdown + region breakdown + 6-month trend.  
**Query params:** `ta`, `timeframe`, `region`, `from`, `to`  
**Caching:** Yes — 5-minute TTL, cache key includes query params.  
**Response:**
```json
{
  "kpi": { "total_fcrs": 257, "total_reps": 189, ... },
  "by_ta": [{ "ta": "ONC", "fcrs": 98, "reps": 72 }, ...],
  "by_region": [{ "region": "Northeast", "fcrs": 45 }, ...],
  "trend": [{ "month": "Feb 26", "fcrs": 12 }, ...],
  "_cached": true
}
```

---

### GET `/api/fcrs`
**Purpose:** Paginated FCR list with optional filters.  
**Query params:** `ta`, `status`, `timeframe`, `search`, `limit` (default 100), `offset` (default 0), `pinsOnly`  
**Timeout:** 28 seconds  
**Response:**
```json
{
  "total": 257,
  "rows": [
    {
      "fcr_id": "a2zWQ000004AODFYA4",
      "survey_id": "4AODFYA4",
      "coachee_first": "Erin",
      "coachee_last": "Ohman",
      "coachee_role": "Medical Science Liaison GI South Texas",
      "ta": "Sci. Affairs",
      "coaching_date": "2026-07-16",
      "status": "Draft",
      "days_since_coaching": 5,
      "session_duration": "Two days",
      ...
    }
  ]
}
```

---

### GET `/api/fcr/:id`
**Purpose:** Full detail of a single FCR — all 42 Q&A rows.  
**Path param:** `:id` = `survey_target_id` (e.g., `a2zWQ000004AODFYA4`)  
**Timeout:** 25 seconds  
**Response:** Array of 42 row objects, each containing all columns including `survey_question_text`, `survey_question_response`, `survey_question_response_text`.

---

### GET `/api/rep-trend/:wwid`
**Purpose:** Last 20 FCR average FBMS scores for a specific MSL (for trend chart).  
**Path param:** `:wwid` = MSL's WWID.  
**Response:** Array of up to 20 objects `{ fcr_id, coaching_date, avg_score, rated_behaviors }`, ordered oldest-first for charting.

---

### GET `/api/capability`
**Purpose:** FBMS skill-level breakdown across all MSL FCRs.  
**Response:** Aggregated counts of Expert/Advanced/Skilled/Awareness per FBMS competency (DG, ST, CL, IO, CE, PS, CC).

---

### POST `/api/ask`
**Purpose:** Conversational AI — user asks a question, GPT generates SQL, SQL runs, GPT explains the results.  
**Body:** `{ question: "How many MSLs scored Advanced?", history: [] }`  
**Process:** 2 GPT calls + 1 Redshift query (see Section 9).  
**Response:**
```json
{
  "sql": "SELECT COUNT(DISTINCT rep_wwid) AS count ...",
  "rows": [{ "count": "34" }],
  "summary": "There are 34 MSLs who scored at the Advanced level...",
  "error": null
}
```

---

### POST `/api/fcr-insight`
**Purpose:** GPT-powered coaching analysis for a single FCR.  
**Body:** FCR data object with all 42 rows.  
**Response:** `{ insight: "AI coaching narrative text..." }`

---

### POST `/api/pins-score`
**Purpose:** GPT scores the PINS narrative sections (P/I/N/S) on a 1-3 scale.  
**Body:** FCR PINS observations.  
**Response:** `{ p_score: 3, i_score: 2, n_score: 3, s_score: 3, narrative: "..." }`

---

### POST `/api/pins-insight`
**Purpose:** GPT generates narrative text for PINS PDF report.  
**Body:** FCR PINS data.  
**Response:** `{ insight: "PDF narrative text..." }`

---

## 9. GPT / AI Integration

### GPT is used in 4 scenarios:

#### Scenario 1: Ask AI (Text-to-SQL) — `/api/ask`

**Two GPT calls happen sequentially:**

**Call 1 — SQL Generation:**
- System prompt: `SCHEMA_CONTEXT` (full table schema + always-apply filters + rules)
- User message: The question typed by the user
- `temperature: 0` (deterministic SQL output)
- `max_completion_tokens: 800`
- Output: Raw SQL query (no markdown, no explanation)

**Safety check after Call 1:**
- Block if SQL contains: `DROP`, `INSERT`, `UPDATE`, `DELETE`, `TRUNCATE`, `ALTER`, `CREATE`
- Block if SQL references any table other than `odp.dp_cust_pers_engagement_dly`

**Redshift execution:** Run the generated SQL against live data

**Call 2 — Result Explanation:**
- System prompt: "You are a senior FCR analytics expert — explain results in plain English"
- User message: Original question + SQL used + full result rows (JSON)
- `temperature: 0.2`
- `max_completion_tokens: 1500`
- Output: Plain English summary with numbers and names

**MSL-only guarantee:** The `SCHEMA_CONTEXT` includes the MSL filter in "ALWAYS apply these base filters" — so GPT always includes it in the SQL it generates.

#### Scenario 2: FCR Coaching Analysis — `/api/fcr-insight`
- GPT receives all 42 Q&A rows from one FCR
- Writes a plain-English coaching summary: strengths, development areas, specific behavior examples
- Uses `survey_question_response_text` (the FD's written narratives) as primary input

#### Scenario 3: PINS Behavior Scoring — `/api/pins-score`
- GPT scores Planning/Investigate/Navigate/Secure sections on 1-3 scale
- Based on the quality and specificity of the FD's coaching narratives

#### Scenario 4: PINS PDF Narrative — `/api/pins-insight`
- GPT generates a formatted narrative for the PDF export

### Hallucination Prevention
- `temperature: 0` for SQL generation → deterministic output
- SQL safety checks block write operations and unauthorized table access
- Result explanation is grounded in actual query results (`JSON.stringify(rows)` passed to GPT)
- GPT explicitly told: "Do NOT mention SQL or technical details in your response"

---

## 10. Metrics & KPI Calculations

### Total FCR Count
```sql
COUNT(DISTINCT survey_target_id)
```
Why DISTINCT: Each FCR = 42 rows in the table. Without DISTINCT, this would return 7,757+ instead of 257.

---

### Total MSLs Coached
```sql
COUNT(DISTINCT rep_wwid)
```
Counts unique MSL employee IDs, not FCRs.

---

### FCRs Per Rep
```sql
ROUND(COUNT(DISTINCT survey_target_id) / NULLIF(COUNT(DISTINCT rep_wwid), 0), 1)
```
`NULLIF(..., 0)` prevents division-by-zero when no reps exist.

---

### Submission Rate
```sql
ROUND(
  100.0 * COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END)
  / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1
) AS submitted_pct
```
Note: Currently 0% because all 257 FCRs are in `Saved_vod` (Draft) status.

---

### Days Since Coaching
```sql
DATEDIFF('day', MIN(acty_dt), CURRENT_DATE) AS days_since_coaching
```
Shown in the FCR list as "76d", "1d", etc.

---

### Days to Submit (Turnaround Time)
```sql
DATEDIFF('day', survey_target_start_date, survey_target_last_modified_date) AS days_to_submit
```
Measures how long from when the FD started the form to when they last saved/submitted it.

---

### FBMS Proficiency Score (Frontend Calculation)
**Scoring map:**
```javascript
const FBMS_SCORE = { Expert: 4, Advanced: 3, Skilled: 2, Awareness: 1 };
```

**Formula:**
```
avgScore = Σ(FBMS_SCORE[response]) / count(rated behaviors)
```

**Example — Erin Ohman (2.3 Skilled):**
```
4× Advanced = 4 × 3 = 12
8× Skilled  = 8 × 2 = 16
Total = 28 ÷ 12 behaviors = 2.33 → displayed as 2.3
```

**Label mapping:**
| Score Range | Label |
|---|---|
| ≥ 3.5 | Expert |
| ≥ 3.0 | Advanced |
| ≥ 2.0 | Skilled |
| < 2.0 | Awareness |

**Target:** ≥ 3.0 (Advanced) shown in the UI as the coaching goal.

Behaviors excluded from score: responses of "Not applicable to the observed interaction", "Yes/No" (compliance), "Area of strength", "Area of development", blank.

---

### Compliance Rate
```sql
ROUND(
  100.0 * COUNT(CASE WHEN survey_question_response = 'Yes' THEN 1 END)
  / NULLIF(COUNT(*), 0), 1
) AS compliance_rate
```
Applied only to the compliance question:
```sql
WHERE LOWER(survey_question_text) LIKE '%field observation%'
  AND survey_question_response IN ('Yes', 'No')
```
This is question 41 in the FCR: "During this field observation, did the FBMS engage in appropriate, non-promotional scientific exchange..."

---

### PINS Training Flags (P/I/N/S)
Each PINS section (Planning, Investigate, Navigate, Secure) has a training question:
- "Planning for Perspective: Training Needed?" → `survey_question_response = 'Yes'` or `'No'`

If `Yes` → flag shows ⚠ Training Needed. If `No` → shows ✓ Proficient.

---

### Avg FBMS Score (Backend — rep-trend endpoint)
```sql
ROUND(AVG(CASE
  WHEN survey_question_response = 'Expert'    THEN 4
  WHEN survey_question_response = 'Advanced'  THEN 3
  WHEN survey_question_response = 'Skilled'   THEN 2
  WHEN survey_question_response = 'Awareness' THEN 1
END), 2) AS avg_score
```
Also includes legacy LEAD model scores: `Clear Strength → 4`, `Emerging Strength → 3`, `Development Need → 2`, `Clear Development Need → 1`.

---

## 11. Authentication & Security

### Login Flow

```
1. User opens app → App.jsx checks useIsAuthenticated()
2. Not authenticated → LoginPage renders
3. User clicks "Sign In with Microsoft"
4. MSAL initiates OAuth2 PKCE flow with Azure AD
5. User redirected to login.microsoftonline.com (J&J SSO page)
6. User enters J&J credentials (jnj.com domain enforced via domainHint)
7. Azure AD issues ID token + access token
8. MSAL stores tokens in memory (not localStorage — security requirement)
9. User redirected back to app → useIsAuthenticated() returns true
10. ConsentPage shown → user accepts data use terms
11. Main app renders with user info from token
```

### MSAL Configuration
```javascript
// src/authConfig.js
export const msalConfig = {
  auth: {
    clientId: "d33645b3-66c1-4adf-93c1-fde580806208",     // App registration ID
    authority: "https://login.microsoftonline.com/3ac94b33-...", // J&J tenant
    redirectUri: window.location.origin + "/",
  },
  cache: {
    cacheLocation: "memory",          // Tokens in memory only (not localStorage)
    storeAuthStateInCookie: false,
  }
};
```

### User Role Detection
The sidebar and UI display the user's role from their Azure AD job title:
```javascript
const account = instance.getActiveAccount();
const jobTitle = account?.idTokenClaims?.jobTitle;
```
No hardcoded roles — pulled live from the Azure AD token.

### Secret Management
All secrets in `.env` file (not committed to Git — in `.gitignore`):
```
REDSHIFT_HOST    — database hostname
REDSHIFT_USER    — database username
REDSHIFT_PASSWORD — database password
AZURE_OPENAI_ENDPOINT — GPT service URL
AZURE_OPENAI_API_KEY — GPT service key
AZURE_OPENAI_DEPLOYMENT — model deployment name
```

### SQL Injection Prevention
Backend uses **parameterized queries** (`$1`, `$2`) for all user-supplied values:
```javascript
pool.query('SELECT ... WHERE ta = $1', [req.query.ta])
```
Dynamic filter conditions use whitelisted strings from a `STATUS_SQL` map — never direct string concatenation of user input.

### Ask AI Security
- All GPT-generated SQL is validated before execution
- Write operations (`DROP`, `INSERT`, `UPDATE`, `DELETE`, `TRUNCATE`, `ALTER`) are blocked
- Only `odp.dp_cust_pers_engagement_dly` is allowed — any other table reference is rejected with 400 error

---

## 12. Caching Strategy

### Current Implementation: In-Memory Cache (Map-based)

```javascript
const _cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes
```

**Cached endpoints:**
- `/api/summary` — Dashboard KPIs, trends, breakdown by TA and region

**Not cached:**
- `/api/fcrs` — List may change with filters; 2-3s query is acceptable
- `/api/fcr/:id` — Individual FCR detail; personalized
- `/api/ask` — Every question is unique
- `/api/fcr-insight` / `/api/pins-score` — GPT calls, always dynamic

**Cache key:** `summary:${JSON.stringify(req.query)}` — different filter combinations cached separately.

**Limitation:** Cache is lost on server restart. For persistent caching across restarts, Redis would be needed.

---

## 13. Deployment Process

### Environment Files

| File | Purpose | Committed? |
|---|---|---|
| `.env` | All secrets and credentials | ❌ No — in .gitignore |
| `vite.config.js` | Frontend build config | ✅ Yes |
| `web.config` | Azure App Service IIS config | ✅ Yes |
| `package.json` | Dependencies and scripts | ✅ Yes |

### Build Steps

**Development:**
```bash
node --env-file=.env server.js       # Start backend on port 8080
npx vite --port 5173                 # Start frontend dev server (proxies /api/* to 8080)
```

**Production build:**
```bash
npx vite build          # Generates dist/ folder
node build-zip.mjs      # Creates fcr-ai-deploy.zip (includes dist/ + server files)
```

**Deployment zip contents:**
```
fcr-ai-deploy.zip
├── dist/                  (React build — HTML, JS, CSS, fonts)
├── server.js              (Express backend)
├── db.js                  (Redshift connection pool)
├── package.json
└── web.config             (Azure App Service config)
```

### Azure App Service Deployment
1. Go to Azure Portal → `AZR-IAY-FCRAI-SPN-IACDEV` web app
2. Deployment Center → ZIP Deploy → upload `fcr-ai-deploy.zip`
3. Set Application Settings (Environment Variables) in Azure Portal:
   - `REDSHIFT_HOST`, `REDSHIFT_USER`, `REDSHIFT_PASSWORD`, `REDSHIFT_DB`
   - `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_DEPLOYMENT`, `AZURE_OPENAI_API_VERSION`
4. App starts on `node server.js` — serves React from `dist/` + handles all `/api/*` routes

### Adding New Users (SSO Access)
Azure Portal → Azure Active Directory → Enterprise Applications → `AZR-IAY-FCRAI-SPN-IACDEV` → Users and Groups → Add user/group → assign J&J employee by UPN (`employee@its.jnj.com`).

---

## 14. Troubleshooting Guide

### Issue 1: "Request timed out — please try again"
**Symptom:** FCR list or detail panel shows timeout error after 25-28 seconds.  
**Root cause:** Redshift query running too long (usually full table scan).  
**Resolution:**
1. Check if server.js has `MSL_FILTER` applied (reduces rows from 500k+ to 7,757)
2. Check for scalar subqueries inside SELECT (were removed previously — do not add back)
3. Verify Redshift cluster is healthy (AWS Console → Clusters → Query Monitoring)
**Prevention:** Always use `GROUP BY` to aggregate, never scalar subqueries per row.

---

### Issue 2: FCR count shows 0 or wrong number
**Symptom:** Dashboard shows 0 FCRs or wrong count.  
**Root cause:** MSL filter may be too restrictive or `engagement_title LIKE '%coaching%'` not matching.  
**Resolution:**
```sql
-- Run in DBeaver to verify raw data:
SELECT DISTINCT engagement_title, COUNT(*) as cnt
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY'
  AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
GROUP BY engagement_title
ORDER BY cnt DESC;
```
If `MSL/VESE Field Coaching Report` appears → filter is working.  
If not → the form name in Veeva may have changed.

---

### Issue 3: Ask AI returns no results or wrong data
**Symptom:** Ask AI gives 0 results for valid questions.  
**Root cause:** GPT may not be including the MSL filter in generated SQL.  
**Resolution:** Check `SCHEMA_CONTEXT` in server.js — "ALWAYS apply these base filters" must include:
```
AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
```
Also check AZURE_OPENAI_API_KEY is valid and not expired.

---

### Issue 4: Login page shows error / redirect loop
**Symptom:** Users can't log in or are redirected back to login repeatedly.  
**Root cause:** Azure AD app registration redirect URI mismatch.  
**Resolution:** Azure Portal → App Registrations → `d33645b3-...` → Authentication → ensure production URL is in redirect URIs (e.g., `https://your-app.azurewebsites.net/`).

---

### Issue 5: Fonts not loading (shows system font instead of JohnsonDisplay)
**Symptom:** UI shows a different font.  
**Root cause:** `woff2` files not included in deployment zip or `@font-face` path wrong.  
**Resolution:** Verify `dist/assets/` contains the 4 woff2 files after build. Check `index.css` `@font-face` declarations reference correct paths.

---

### Issue 6: FBMS score shows "0 behaviors rated"
**Symptom:** FCR detail opens but shows 0 in the proficiency badge.  
**Root cause:** `survey_question_response` values may be different from expected (`Expert`, `Advanced`, `Skilled`, `Awareness`).  
**Resolution:** Run in DBeaver:
```sql
SELECT DISTINCT survey_question_response
FROM odp.dp_cust_pers_engagement_dly
WHERE survey_target_id = '<FCR_ID>'
  AND chnl = 'SURVEY';
```
Check if any new response values appear. Update `FBMS_SCORE` map in FCRsPage.jsx if needed.

---

### Issue 7: Azure OpenAI "API key invalid" error
**Symptom:** Ask AI or Generate Insights returns 500 error.  
**Root cause:** `AZURE_OPENAI_API_KEY` in `.env` or Azure App Settings is expired/incorrect.  
**Resolution:** Get updated key from Azure Portal → Azure OpenAI → `azr-iay-openai` → Keys and Endpoint → regenerate Key 1 and update in App Settings.

---

## 15. Performance Considerations

### Current Bottlenecks

| Operation | Typical Time | Bottleneck |
|---|---|---|
| Dashboard load (no cache) | 5-8 seconds | 4 parallel Redshift queries |
| Dashboard load (cached) | < 100ms | Memory lookup |
| FCR list load | 2-4 seconds | Redshift GROUP BY dedup |
| FCR detail panel open | 3-6 seconds | Redshift full scan by ID |
| GPT coaching insight | 5-10 seconds | Azure OpenAI latency |
| FCR detail + GPT total | 10-15 seconds | Sequential: DB then GPT |

### Auto-Retry on Timeout
The FCR detail panel (`FCRsPage.jsx`) has automatic silent retry:
- If first request times out (504), automatically retries once after 800ms
- Uses `AbortController` to cancel stale requests when user switches FCRs
- Race condition prevention via `inflightRef` pattern

### Recommended Improvements (Not Yet Implemented)
1. **6-hour background pre-warming** — `setInterval` in server.js runs all queries on schedule so cache is always warm
2. **Load all 257 FCRs into memory** — filter client-side in Node.js; eliminates Redshift round-trip for FCR list
3. **Redshift materialized views** — pre-compute KPIs and FBMS averages; query goes from 5s to <1s
4. **Redis cache** — persistent cache that survives server restarts

---

## 16. Future Enhancements

### Near-Term
- [ ] Background cache pre-warming (6-hour refresh cycle) — eliminates dashboard loading spinner
- [ ] Pre-load all 257 FCRs into memory — instant filters
- [ ] Materialized views in Redshift — faster KPI queries
- [ ] FCR status filter expansion — handle new Veeva status values as they appear

### Medium-Term
- [ ] Mobile-responsive layout for FD access in the field
- [ ] Email alerts when FCR is overdue (>14 days since coaching, not submitted)
- [ ] Comparative view — "How does this MSL compare to region average?"
- [ ] Bulk PINS scoring — score multiple FCRs at once via GPT

### Long-Term
- [ ] Microsoft Fabric integration — semantic layer for more complex analytics
- [ ] Power BI embedded — for existing Power BI users who prefer that interface
- [ ] Expand to other coaching form types (Oncology-specific, Neuroscience-specific)
- [ ] Multi-tenant support — share platform with other J&J divisions

---

## 17. Appendix — Glossary & Quick Reference

### Glossary

| Term | Definition |
|---|---|
| **FCR** | Field Coaching Report — form completed by Field Director after observing an MSL |
| **MSL** | Medical Science Liaison — scientific field professional who engages with HCPs |
| **VESE** | Value Evidence & Scientific Engagement — companion field team to MSL |
| **FD** | Field Director — manager who coaches MSLs and writes FCRs |
| **HCP** | Healthcare Provider — doctor, nurse, pharmacist, etc. |
| **FBMS** | Field-Based Medical Science — the competency framework rated in FCRs |
| **PINS** | Planning / Investigate / Navigate / Secure — the 4 coaching dimensions |
| **TA** | Therapeutic Area — IMM (Immunology), ONC (Oncology), NS (Neuroscience), SCG |
| **WWID** | Worldwide ID — J&J employee unique identifier |
| **iConnect** | J&J's Veeva CRM platform used to create FCRs |
| **Veeva** | CRM platform; `_vod` suffix in status values means "Veeva Object Definition" |
| **Saved_vod** | Veeva status = Draft/In-progress FCR |
| **Submitted_vod** | Veeva status = Submitted FCR (not yet seen in MSL FCR data) |
| **AIDA** | AI Digital Assistant — J&J's internal AI tool for MSLs |
| **VoC** | Voice of Customer — insights captured from HCP conversations |
| **MAF** | Medical Affairs Framework — strategic alignment framework |
| **DG/ST/CL/IO/CE/PS/CC** | FBMS Core Skills: Data Gathering, Strategic Thinking, Competitive Landscape, Influencing Others, Clinical Expertise, Problem Solving, Cross-functional Collaboration |

### Quick Start Commands

```bash
# Start backend
cd C:\Users\MGrandhe\Downloads\Fcr-ai-sso
node --env-file=.env server.js

# Start frontend (development only)
npx vite --port 5173

# Build for production
npx vite build

# Create deployment zip
node build-zip.mjs

# Check Redshift connection
node -e "import('./db.js').then(({default:p})=>p.query('SELECT 1').then(r=>console.log('OK',r.rows)).finally(()=>p.end()))"
```

### DBeaver Connection

```
Host: itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com
Port: 5439
Database: awprdrsdb
Username: vkrish53
SSL: Required
```

### Environment Variables Required

```env
REDSHIFT_HOST=itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com
REDSHIFT_PORT=5439
REDSHIFT_DB=awprdrsdb
REDSHIFT_USER=vkrish53
REDSHIFT_PASSWORD=<password>
AZURE_OPENAI_ENDPOINT=https://azr-iay-openai.openai.azure.com/
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_DEPLOYMENT=gpt-5.4
AZURE_OPENAI_API_VERSION=2025-01-01-preview
PORT=8080
```

### Azure Resources

| Resource | Name | Purpose |
|---|---|---|
| App Service | AZR-IAY-FCRAI-SPN-IACDEV | Hosts the Node.js application |
| Azure OpenAI | azr-iay-openai | GPT model deployment |
| Azure AD App | d33645b3-66c1-4adf-93c1-fde580806208 | SSO authentication |
| AD Tenant | 3ac94b33-9135-4821-9502-eafda6592a35 | J&J tenant |

---

*End of Documentation — FCR AI Insights v1.0*  
*For questions contact: J&J Scientific Affairs Digital Team*
