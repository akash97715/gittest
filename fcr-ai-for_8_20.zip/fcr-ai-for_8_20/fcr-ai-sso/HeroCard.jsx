import { useState } from 'react';
import { Filter } from 'lucide-react';
import { kpiData, pipelineData } from '../data/mockData';


const TIMEFRAMES = ['Last 30 Days', 'Last 90 Days', 'YTD', 'Last 12 Months'];
const REGIONS    = ['All Regions', 'Northeast', 'Southeast', 'Central', 'Western', 'Southwest', 'Northwest', 'Mountain'];
const TAS        = ['All TAs', 'Oncology', 'Immunology', 'Neuroscience', 'Cardiovascular'];
const ROLES      = ['All Roles', 'MSL Manager', 'Field Director', 'Regional Manager'];
const COACHES    = ['All Coaches', 'Active Only', 'Inactive', 'Pre-Launch'];

export default function HeroCard() {
  const [filters, setFilters] = useState({
    timeframe: TIMEFRAMES[0],
    region: REGIONS[0],
    ta: TAS[0],
    role: ROLES[0],
    coach: COACHES[0],
  });

  const total = pipelineData.reduce((a, b) => a + b.value, 0);

  return (
    <div className="hero-card">
      <div className="hero-card-top">
        <div>
          <div className="hero-card-title">Coaching Adoption Overview</div>
          <div className="hero-card-heading">Field Coaching Report Insights</div>
        </div>

        {/* Filters */}
        <div className="hero-filters">
          {[
            { key: 'timeframe', opts: TIMEFRAMES },
            { key: 'region',    opts: REGIONS },
            { key: 'ta',        opts: TAS },
            { key: 'role',      opts: ROLES },
            { key: 'coach',     opts: COACHES },
          ].map(({ key, opts }) => (
            <select
              key={key}
              id={`filter-${key}`}
              className="hero-filter-select"
              value={filters[key]}
              onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))}
              aria-label={`Filter by ${key}`}
            >
              {opts.map(o => <option key={o}>{o}</option>)}
            </select>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="hero-kpis">
        <div className="kpi-cell">
          <span className="kpi-label">FCRs in View</span>
          <span className="kpi-value">{kpiData.fcrsInView.toLocaleString()}</span>
          <span className="kpi-sub">Total reports</span>
        </div>
        <div className="kpi-cell">
          <span className="kpi-label">Coaches w/ ≥1 FCR</span>
          <span className="kpi-value">{kpiData.coachesWithFCR}</span>
          <span className="kpi-sub">Active coaches</span>
        </div>
        <div className="kpi-cell">
          <span className="kpi-label">Pre-Launch Training</span>
          <span className="kpi-value">{kpiData.prelaunchComplete}</span>
          <span className="kpi-sub">Completion rate</span>
        </div>
        <div className="kpi-cell">
          <span className="kpi-label">Avg FCRs / Coach</span>
          <span className="kpi-value">{kpiData.avgFCRsPerCoach}</span>
          <span className="kpi-sub">Per coach (MTD)</span>
        </div>
        <div className="kpi-cell">
          <span className="kpi-label">Avg Days Between Obs</span>
          <span className="kpi-value">{kpiData.avgDaysBetweenObs}</span>
          <span className="kpi-sub">Coaching cadence</span>
        </div>
      </div>

      {/* Pipeline Bar */}
      <div className="pipeline-section">
        <div className="pipeline-bar-header">
          <span className="pipeline-bar-label">Pipeline Status</span>
          <div className="pipeline-legend">
            {pipelineData.map(seg => (
              <div key={seg.label} className="pipeline-legend-item">
                <span className="legend-dot" style={{ background: seg.color }} />
                {seg.label} ({seg.value}%)
              </div>
            ))}
          </div>
        </div>
        <div className="pipeline-bar-track" role="progressbar" aria-label="Pipeline status breakdown">
          {pipelineData.map(seg => (
            <div
              key={seg.label}
              className="pipeline-bar-segment"
              style={{ width: `${(seg.value / total) * 100}%`, background: seg.color }}
              title={`${seg.label}: ${seg.value}%`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
