# PHASE 1-2: INFRASTRUCTURE & BACKEND FOUNDATION
## Setting Up Data Pipeline

**Duration:** Week 1 (5 days)  
**Effort:** ~2 developer days  
**Complexity:** Low-Medium (mostly configuration)

---

## PHASE 1: DATABASE FOUNDATION (Days 1-3)

### What Problem Does This Solve?

**Without Phase 1:** Events have nowhere to go. Frontend sends data to... nowhere.  
**With Phase 1:** Redshift database ready to store millions of telemetry events reliably.

---

## PHASE 1 DELIVERABLES

### 1.1 Database Schema Creation
**Duration:** 30 minutes  
**Work:** Execute SQL script to create tables

#### Tables Created (5 total)

| Table Name | Purpose | Example Data |
|-----------|---------|--------------|
| **user_events** | Raw event storage | Login at 10:30am on Activity page |
| **user_sessions** | Session summary | "User X logged in 9:15am, out at 5:30pm, 47 actions" |
| **daily_usage_summary** | Daily rollups | "Aug 18: 42 users, 1,200 events, avg 28 min session" |
| **page_analytics** | Page metrics | "Activity page: 156 views, avg 45 sec, 12% bounce" |
| **button_analytics** | Feature usage | "Export button: 89 clicks, 34 unique users" |

#### Data Retention Policy
- **Keep for:** 90 days (rolling window)
- **Archive:** Older data automatically archived
- **Disaster recovery:** Daily backups to S3

**Why 90 days?** Gives us 3 months of trend analysis while managing costs. Older data archived separately if audit needed.

---

### 1.2 Database Connectivity Validation
**Duration:** 15 minutes  
**Work:** Run test queries

#### Success Test
```
✅ Database responds
✅ All 5 tables exist
✅ Indexes created
✅ Test data inserts successfully
✅ Query returns results in <100ms
```

**Real-world test:**
```
Test Query: "Count events from last hour"
Expected: Returns 0 (no events yet)
Actual:   Returns 0 ✅
Response Time: 47ms ✅
```

### 1.3 Performance Baseline Established
**Duration:** 15 minutes  
**Work:** Document capacity numbers

#### Baseline Numbers (What We Know We Can Handle)
| Metric | Value | Safety Margin |
|--------|-------|--------------|
| Events per second | 50 | 5x headroom |
| Concurrent users | 100 | Tested |
| Query response time | <100ms | Acceptable for dashboards |
| Data retention | 90 days | 1 million events = ~3GB |

**Why this matters:** We know the database can handle Phase 3-5 traffic before we turn it on.

---

## PHASE 1 VALUE DELIVERED

```
┌─────────────────────────────────────┐
│ PHASE 1 OUTCOME                     │
├─────────────────────────────────────┤
│ ✅ Reliable data storage ready      │
│ ✅ Database capacity proven         │
│ ✅ Zero data loss infrastructure    │
│ ✅ Automatic backup configured      │
│ ✅ Query performance validated      │
│                                     │
│ Cost: $0 (uses existing Redshift)  │
│ User Impact: None (backend only)   │
└─────────────────────────────────────┘
```

---

---

## PHASE 2: BACKEND INTEGRATION (Days 3-5)

### What Problem Does This Solve?

**Without Phase 2:** Database exists, but no way to send data to it.  
**With Phase 2:** Backend APIs ready to receive events, validate them, and store them safely.

---

## PHASE 2 DELIVERABLES

### 2.1 API Endpoints Deployment (30 minutes)

#### 6 Endpoints Created

**Endpoint 1: POST /api/telemetry**
- **Purpose:** Main event ingestion endpoint
- **Data In:** Batch of 10 events from frontend
- **Process:** Validate → Store → Acknowledge
- **Data Out:** `{ success: true, eventsReceived: 10 }`
- **User Value:** Events reliably delivered to database

**Endpoint 2: GET /api/telemetry/user-sessions**
- **Purpose:** Retrieve user session history
- **Data In:** days=7, limit=50
- **Returns:** Last 50 sessions in past 7 days
- **Example:** "User John logged in Mon 9am, out 5:30pm, 45 events"
- **User Value:** See who used app when

**Endpoint 3: GET /api/telemetry/user/:userId**
- **Purpose:** Individual user activity
- **Data In:** userId, optional days filter
- **Returns:** All events for that user
- **Example:** "John viewed Activity, clicked Export, spent 3 hours"
- **User Value:** Understand individual user behavior

**Endpoint 4: GET /api/telemetry/page-analytics**
- **Purpose:** Page performance metrics
- **Data In:** days=7
- **Returns:** All pages with metrics
- **Data Returned:**
  ```
  Activity page:
    - Views: 156
    - Avg time: 45 seconds
    - Bounce rate: 12%
  
  Capability page:
    - Views: 89
    - Avg time: 23 seconds
    - Bounce rate: 34%
  ```
- **User Value:** Know which pages engage users

**Endpoint 5: GET /api/telemetry/button-analytics**
- **Purpose:** Feature adoption tracking
- **Data In:** limit=20, sortBy=clicks
- **Returns:** Top 20 buttons by clicks
- **Data Returned:**
  ```
  Export button:
    - Clicks: 234
    - Unique users: 89
    - Adoption: 89%
  
  Email Report button:
    - Clicks: 23
    - Unique users: 12
    - Adoption: 12%
  ```
- **User Value:** Identify popular vs. neglected features

**Endpoint 6: GET /api/telemetry/daily-summary**
- **Purpose:** Daily aggregated KPIs
- **Data In:** days=30
- **Returns:** Daily rollup for trend analysis
- **Data Returned:**
  ```
  Aug 17: 42 active users, 1,200 events, 23.4 min avg session
  Aug 16: 39 active users, 1,050 events, 21.1 min avg session
  Aug 15: 45 active users, 1,400 events, 26.3 min avg session
  ```
- **User Value:** See engagement trends over time

#### Functional Flow: How Endpoints Work Together

```
SCENARIO: User navigates the app for 2 hours

10:00 AM - User logs in
  ↓
Frontend sends: POST /api/telemetry
  { events: [
      { eventType: 'user_login', userId: 'john123', ... },
      { eventType: 'page_view', page: 'activity', ... }
    ]
  }
  ↓
Backend validates: ✅ Valid format, valid event types
  ↓
Redshift stores: INSERT INTO telemetry.user_events
  ↓
Endpoint confirms: { success: true, eventsReceived: 2 }

10:45 AM - Manager queries: GET /api/telemetry/page-analytics?days=1
  ↓
Backend queries: SELECT page, COUNT(*), AVG(time_spent)...
  ↓
Returns: Activity page has 45 views, avg 32 sec
  ↓
Dashboard shows: "Activity page is popular ✓"

Manager later queries: GET /api/telemetry/button-analytics?sortBy=clicks
  ↓
Returns: Top 10 buttons with click counts
  ↓
Manager sees: "Export button has 89 clicks" → It's important ✓
```

---

### 2.2 Event Validation & Quality Assurance (20 minutes)

#### What Gets Validated?
Before any event enters the database, it's checked:

| Validation Check | Example | Reject? |
|-----------------|---------|---------|
| **Event type valid?** | Is it one of: login, logout, page_view, button_click, etc.? | ❌ If "xyz_event" |
| **User ID present?** | Does event have userId? | ❌ If missing |
| **Session ID present?** | Does event have sessionId? | ❌ If missing |
| **Timestamp valid?** | Is timestamp in ISO format? | ❌ If "Jan 1" |
| **JSON structure ok?** | Is event data valid JSON? | ❌ If corrupted |

#### Example: What Happens to Bad Events

```
Frontend sends event:
{
  eventType: "invalid_type",  ← Not in allowed list
  userId: "john",
  timestamp: "Aug 18"  ← Not ISO format
}

Validation Result: ❌ REJECTED
Why: 
  - eventType "invalid_type" not recognized
  - timestamp not ISO format (should be "2026-08-18T10:30:00Z")

Response: HTTP 400
{
  error: "Invalid event type: invalid_type"
}

Database: Event NOT stored
Frontend: Can retry with correct format
```

**Why this matters:** Bad data pollutes analytics. By validating, we ensure reports are always accurate.

---

### 2.3 Error Handling & Reliability (15 minutes)

#### What Happens When Things Go Wrong?

**Scenario 1: Network Glitch**
```
Frontend sends batch
  ↓
Network timeout
  ↓
Frontend retries in 5 seconds
  ↓
Success ✅
```

**Scenario 2: Database Temporarily Down**
```
Events received: 10
Database unavailable: Partial failure
  ↓
Backend response: { success: false, stored: 7, failed: 3 }
Frontend logs failed event IDs
  ↓
Frontend retries failed events after 30 seconds
  ↓
All 3 retry successfully ✅
```

**Scenario 3: User Closes App Before Events Send**
```
User generates events: 15
App closes before batch sends
  ↓
Local storage saves unsent events in browser
  ↓
User reopens app next morning
  ↓
App sends saved events + new events
  ↓
All 15 old events delivered ✅
```

---

## PHASE 2 VALUE DELIVERED

```
┌─────────────────────────────────────────┐
│ PHASE 2 OUTCOME                         │
├─────────────────────────────────────────┤
│ ✅ Backend ready to receive events      │
│ ✅ 6 analytics APIs operational         │
│ ✅ Data quality assured via validation  │
│ ✅ Resilient to failures/retries        │
│ ✅ Events flow reliably to database     │
│                                         │
│ Cost: Coding only (no new infrastructure)
│ User Impact: None yet (backend only)   │
│ Readiness: Can now accept frontend data│
└─────────────────────────────────────────┘
```

---

## PHASE 1-2 COMPLETE FLOW

### From User Action to Database Storage

```
                     PHASE 2 BACKEND LAYER
                     ─────────────────────

User clicks        API Endpoint validates    Database
"Export"           incoming event batch      stores
  ↓                   ↓                         ↓
Event              6 endpoints ready          Data ready
captured           to receive data            for queries
                   (no data yet)
                   
                   PHASE 1 INFRASTRUCTURE LAYER
                   ─────────────────────────────
                   Database ready
                   Tables created
                   Connections tested
                   Capacity proven
```

### Success Criteria (End of Phase 2)

| Criteria | Status |
|----------|--------|
| Database schema deployed | ✅ (Phase 1) |
| Database responds quickly | ✅ (Phase 1) |
| Backup/retention configured | ✅ (Phase 1) |
| API endpoints deployed | ✅ (Phase 2) |
| Event validation working | ✅ (Phase 2) |
| Error handling robust | ✅ (Phase 2) |
| No data loss on failures | ✅ (Phase 2) |

---

## WHAT'S STILL MISSING

After Phase 2, we have the **infrastructure** but not yet the **usage**.

```
Database: ✅ Ready
Backend APIs: ✅ Ready
Frontend Instrumentation: ❌ Not yet
User Tracking: ❌ Not yet
Analytics Data: ❌ Not yet

Next: Phase 3 (Frontend Initialization)
```

---

## DEPENDENCIES & TIMING

```
Phase 1 (Database)
  ├─ 3 days
  └─ Completion: Day 3 at end of day

Phase 2 (Backend APIs)
  ├─ Depends: Phase 1 complete
  ├─ 2 days
  └─ Completion: Day 5 at end of day

Status End of Week 1: Infrastructure 100% ready
Next Phase Start: Monday Week 2
```

---

## KEY ADVANTAGES OF THIS SEQUENCING

### Why Not Do Everything at Once?

| Approach | Pros | Cons |
|----------|------|------|
| **Sequential (Our Plan)** | Test each phase independently; catch issues early; low risk rollback | Takes more calendar time |
| **All at Once** | Faster calendar time | If something breaks, entire system broken; hard to debug; risky |

**We chose sequential because:** The 2-day difference is worth the massive reduction in risk and debugging difficulty.

---

## SIGN-OFF CHECKLIST

**By End of Phase 1-2, We Confirm:**
- [ ] Database deployed and tested
- [ ] API endpoints live and validated
- [ ] Error handling prevents data loss
- [ ] Backup policy documented
- [ ] Team trained on API specs
- [ ] Monitoring alerts configured

---

## QUESTIONS FOR PHASE 1-2

1. **Database:** Are we comfortable using existing Redshift or need new cluster?
2. **Data Retention:** Is 90-day retention window acceptable, or need longer?
3. **Performance:** Are <100ms query response times acceptable for dashboards?
4. **Backup:** Should we archive telemetry data separately for compliance?

---

**Next Document:** Phase 3-4 User Tracking & Insights
