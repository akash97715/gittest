# PHASE 3-4: USER TRACKING & ENGAGEMENT METRICS
## Telemetry Begins - Data Collection Starts

**Duration:** Week 2 (4 days)  
**Effort:** ~3 developer days  
**Complexity:** Medium (frontend integration)

---

## PHASE 3: FRONTEND INITIALIZATION (Days 1-2)

### What Problem Does This Solve?

**Without Phase 3:** Backend ready, but frontend has no way to talk to it.  
**With Phase 3:** When users log in, telemetry automatically activates and starts tracking their session.

---

## PHASE 3: TELEMETRY GOES LIVE

### 3.1 Telemetry Service Activation (20 minutes)

#### What Happens When User Logs In

```
BEFORE PHASE 3                          AFTER PHASE 3
─────────────────────────────────────────────────────

User logs in                            User logs in
    ↓                                       ↓
No tracking                             Telemetry service initializes
    ↓                                       ↓
User navigates                          Session ID generated
    ↓                                       ↓
No data collected                       User context captured:
                                        - Name: John Smith
                                        - Email: john.smith@company.com
                                        - Login time: 10:30 AM
                                        
                                        Ready to track all actions
```

#### Session ID Generation
**What is a Session ID?**  
Unique identifier for one user's use of the app. Like a visit ticket.

```
Example Session:
Session ID: "abc-123-def"
User: john.smith@company.com
Start: Aug 18, 10:30 AM
End: Aug 18, 5:15 PM
Duration: 6h 45m
Total Events: 234

This session ID ties together ALL events from that day.
```

#### Technical Flow (User Doesn't See This)
```
User clicks login
    ↓
Azure authenticates user
    ↓
App loads
    ↓
App.jsx lifecycle hook fires
    ↓
TelemetryService.init() called
    Parameters: userId, userName, userEmail
    ↓
Session ID generated: uuid-v4 (random, unique)
    ↓
First event logged: "user_login"
    ↓
Event batching starts (collect events for 30 seconds)
    ↓
Ready to track page views, button clicks, etc.
```

---

### 3.2 Session Tracking Benefits

#### What We Learn From Sessions

| Session Data | Business Value |
|--------------|------------------|
| **Login time** | Know when users prefer to work (early morning? late afternoon?) |
| **Session duration** | How engaged are they? (15 min = quick check-in vs. 2hr = deep work) |
| **Event count** | More events = more interaction with app |
| **Logout time** | Which time of day do users leave? |

#### Example: Session Patterns

```
Aug 18 Sessions:
User: Sarah (Manager)
  - 9:00 AM - 9:30 AM: 12 events (morning standup check?)
  - 2:00 PM - 4:30 PM: 87 events (deep analysis work)
  - Avg daily engagement: 99 events/day

User: Mike (Analyst)
  - 10:00 AM - 11:30 AM: 45 events (setup, exploration)
  - Rest of day: No activity
  - Avg daily engagement: 45 events/day

Insight: Sarah very engaged, Mike checks in once daily
→ Could target feature announcements to different users differently
```

---

### 3.3 Local Storage for Offline Support (10 minutes)

#### What If User Closes App Before Events Send?

```
Scenario: User working on important report, power dies before sending events

Timeline:
2:15 PM - User logged in, working
2:45 PM - Generated 25 events (all tracked locally)
2:46 PM - Power failure, events not yet sent
    ↓
Events stored in browser's local storage
    ↓
Next morning - User logs in again
    ↓
App detects: "25 unsent events in local storage"
    ↓
App sends old events FIRST, then new events
    ↓
All 25 events delivered ✅
    ↓
No data loss ✅
```

**Why this matters:** We don't lose data even if user's computer crashes.

---

## PHASE 3 VALUE DELIVERED

```
At end of Phase 3:
─────────────────

✅ Telemetry initialization works
✅ Sessions tracked automatically
✅ User context captured
✅ Events flow to backend
✅ First data visible in database

Database now has:
- Login events
- Session records
- User information tied to events

Example query result:
"Aug 18: 42 users logged in, 12 sessions still active"
```

---

---

## PHASE 4: PAGE TRACKING & ENGAGEMENT (Days 3-4)

### What Problem Does This Solve?

**Without Phase 4:** We know "John logged in" but not what he did.  
**With Phase 4:** We know exactly which pages John visited, in what order, and how long he spent on each.

---

## PHASE 4: PAGE-LEVEL ENGAGEMENT METRICS

### 4.1 Automatic Page View Tracking (30 minutes)

#### How It Works (User Perspective)

```
User's Experience:
─────────────────

1. Logs in
   ↓ [Telemetry invisible to user]
   
2. Clicks "Activity" page
   ↓ [Page loads normally]
   
3. Reads dashboard for 45 seconds
   ↓ [No changes to UI]
   
4. Clicks "Capability" page
   ↓ [Telemetry notes: "Spent 45 seconds on Activity"]
   
5. Looks at Capability page for 23 seconds
   ↓ [No changes to UI]
   
6. Logs out
   ↓ [All events sent to backend]


Backend sees:
─────────────

Event: page_view (Activity)
  Time: 10:30:00 AM

Event: page_exit (Activity)  ← Auto-calculated
  Duration: 45 seconds

Event: page_view (Capability)
  Time: 10:30:45 AM

Event: page_exit (Capability)
  Duration: 23 seconds

Database now has engagement data ✅
```

### 4.2 Time-Spent Calculation (Automatic)

#### How It Works

```
Formula: Time Spent = When I Left - When I Arrived

Example:
Page view timestamp: 10:30:00
Page exit timestamp:  10:30:45
Duration:           45 seconds
```

**Completely automatic.** No code to add to each page. One implementation handles all pages.

#### What We Measure

| Metric | Example | Interpretation |
|--------|---------|-----------------|
| **Avg time on Activity** | 45 sec | High engagement ✓ |
| **Avg time on Capability** | 12 sec | Low engagement - needs work ✗ |
| **Bounce rate** | 15% | 15% of visitors left without further action |
| **Page views** | 156/day | Baseline traffic |

---

### 4.3 Page-Level Insights (What We Learn)

#### Example Dashboard After Phase 4

```
PAGE ANALYTICS REPORT - Last 7 Days
════════════════════════════════════

Activity Page:
  ├─ Total Views: 156
  ├─ Avg Time Spent: 45 seconds
  ├─ Bounce Rate: 12%
  └─ Trend: ↑ Up 5% from last week (good!)

Capability Page:
  ├─ Total Views: 89
  ├─ Avg Time Spent: 23 seconds
  ├─ Bounce Rate: 34%
  └─ Trend: ↓ Down 8% from last week (problem?)

Ask AI Page:
  ├─ Total Views: 45
  ├─ Avg Time Spent: 58 seconds
  ├─ Bounce Rate: 8%
  └─ Trend: ↑ Up 12% from last week (very good!)

Reference Page:
  ├─ Total Views: 12
  ├─ Avg Time Spent: 8 seconds
  ├─ Bounce Rate: 67%
  └─ Trend: ↓ Down 20% from last week (underutilized)
```

#### Business Decisions Enabled

```
BEFORE Phase 4 (Guessing):
"We should focus on Activity page because...
 well, it seems important?"

AFTER Phase 4 (Data-Driven):
"Activity page gets 156 views/week with 45 sec avg engagement.
 Capability page gets only 89 views with 23 sec engagement.
 → Focus on making Activity even better
 → Redesign Capability to boost engagement"
```

---

### 4.4 User Journey Patterns

#### How Users Navigate

```
EXAMPLE USER JOURNEY 1 - Product Manager (Sarah)
──────────────────────────────────────────────

9:00 AM: Login
        ↓
9:00-9:15: Activity page (15 min, thorough review) ← Deep engagement
        ↓
9:15-9:25: Capability page (10 min, specific analysis)
        ↓
9:25-10:00: Ask AI page (35 min, feature exploration) ← Wow! High engagement
        ↓
10:00: Logout

Insight: Sarah uses Ask AI heavily → Ensure it works perfectly


EXAMPLE USER JOURNEY 2 - Casual User (Mike)
─────────────────────────────────────────

10:00 AM: Login
         ↓
10:00-10:05: Activity page (5 min, quick scan)
         ↓
10:05: Logout

Insight: Mike does quick check-ins → Ensure homepage loads fast
```

#### What This Reveals

| Pattern | Insight |
|---------|---------|
| Users spend >30s on Ask AI | Feature is valuable, very engaging |
| Users skip Reference page | Either don't need it OR can't find it |
| Users view Activity first, then others | Activity = entry point, core feature |
| 67% bounce from Reference page | This page needs redesign/improvement |

---

## PHASE 3-4 VALUE DELIVERED

```
End of Phase 4:
───────────────

✅ All pages tracked for engagement
✅ Time spent calculated automatically  
✅ Bounce rates identified
✅ User journey patterns visible
✅ Page performance compared

Database has:
- 1000+ page view/exit events
- Session data linked to page visits
- Engagement metrics by page
- User navigation patterns

Example queries now possible:
Q: "Which page gets most engagement?"
A: "Ask AI page: 45 sec avg, growing 12%/week"

Q: "Are users finding the Reference page?"
A: "Only 12 views in 7 days, 67% bounce rate - needs work"

Q: "What's the typical user journey?"
A: "Activity → Capability → Ask AI → Exit"
   (This tells us the natural flow works well)
```

---

## PHASE 3-4 COMPLETE FLOW

### From User Session to Page Analytics

```
                    PHASE 4: PAGE TRACKING
                    ─────────────────────

User navigates to Activity page (10:00 AM)
    ↓
Page view event created + timestamp recorded
    ↓
User reads for 45 seconds
    ↓
User clicks Capability page
    ↓
Page exit event created
    ↓
Duration calculated: 45 seconds
    ↓
Stored in database:
    - page_view: Activity
    - page_exit: Activity (45 seconds)
    - page_view: Capability
    ↓


                    PHASE 3: SESSION TRACKING
                    ─────────────────────────
                    
All events linked to same session ID
Session duration = login to logout
Event count = all page views + interactions
User context = John, john@company.com

Result: Complete session understanding ✅
```

---

## CRITICAL INSIGHTS FROM PHASE 3-4

### Session Engagement
```
Question: "How engaged is our user base?"
Answer: "42 users logged in today, avg session 28 minutes, 234 events/user"
Benchmark: 
  - <10 min = Low engagement (quick check-in)
  - 10-30 min = Medium engagement (typical use)
  - >30 min = High engagement (power user, deep work)
```

### Page Performance
```
Question: "Which pages work best?"
Answer: 
  - Activity: 45 sec avg (✓ Good)
  - Capability: 23 sec avg (? Could be better)
  - Ask AI: 58 sec avg (✓✓ Excellent)
  - Reference: 8 sec avg (✗ Underperforming)

Action:
  - Reference page needs redesign
  - Ask AI page is a success - promote it
  - Capability page needs investigation
```

### User Behavior
```
Question: "What's our typical user journey?"
Answer:
  - 87% visit Activity page first
  - 65% then go to Capability
  - 45% visit Ask AI
  - 12% visit Reference

Implication: Clear hierarchy of page importance
  Activity = core, Ask AI = secondary but engaging
  Reference = needs discovery boost
```

---

## SUCCESS METRICS: END OF PHASE 3-4

| Metric | Threshold |
|--------|-----------|
| Sessions tracked | >50/day |
| Page views captured | >200/day |
| Session duration data | Complete and accurate |
| Time spent calculations | Verified in spot checks |
| User journey patterns | Clearly visible |
| Database queries | <100ms response time |

---

## DEPENDENCIES & TIMING

```
Phase 1-2 (Infrastructure) - Week 1
        ↓ (Completed - ready for phase 3)

Phase 3 (Frontend Init)
  ├─ Telemetry service initialization
  ├─ Session ID generation
  ├─ User context capture
  └─ 2 days (Days 1-2 of Week 2)
        ↓ (Completed - data flowing)

Phase 4 (Page Tracking)
  ├─ Page view tracking
  ├─ Time spent calculations
  ├─ Navigation patterns
  └─ 2 days (Days 3-4 of Week 2)
        ↓ (Completed)

Phase 5 (Next): Feature/Button tracking
```

---

## REAL EXAMPLE: A DAY IN THE LIFE

### What Happens in One 8-Hour Workday

```
09:00 - John logs in
         ↓ Session ID: abc-123
         ↓ Event: user_login
         ↓ Telemetry active

09:00-09:45 - Activity page
         ↓ Event: page_view (Activity)
         ↓ John reads dashboard, scrolls
         ↓ 45 minutes pass
         ↓ [Batched events sent every 30 sec]

09:45 - Clicks Capability page
         ↓ Event: page_exit (Activity, 45 sec duration)
         ↓ Event: page_view (Capability)

09:45-10:10 - Capability page
         ↓ 25 minutes on page
         ↓ [Events batched and sent]

10:10-11:30 - Ask AI page
         ↓ 80 minutes (power user!)
         ↓ High engagement signal

11:30-12:00 - Activity page (returns)
         ↓ 30 minutes (reviews trends)

12:00 - John logs out
         ↓ Event: user_logout
         ↓ Final events batch sent
         ↓ Session closed


DATABASE NOW RECORDS:
─────────────────────
Session Summary:
  - User: john
  - Duration: 3 hours
  - Events: 12+ (1 per 15 minutes)
  - Pages visited: Activity, Capability, Ask AI
  - Most time spent: Ask AI (80 minutes)

Page Analytics Updated:
  - Activity views: +2
  - Capability views: +1
  - Ask AI views: +1
  - Ask AI avg time: +80 minutes to calculation

Dashboard reflects: John is power user, Ask AI is super engaging ✅
```

---

## WHAT'S STILL MISSING

After Phase 3-4, we understand **WHO** uses the app and **WHERE** they spend time.

We don't yet know:
- ❌ **WHAT buttons/features** they click
- ❌ **Feature adoption rates**
- ❌ **Which features are popular vs. neglected**

**Next: Phase 5 (Feature Tracking)**

---

## QUESTIONS FOR PHASE 3-4

1. **Session tracking:** How often should we aggregate session summaries? (Real-time vs. hourly?)
2. **Page time calculation:** Should we exclude time if user is idle (tab not focused)?
3. **Data privacy:** Are we comfortable tracking individual user page visits?
4. **Retention:** Should we keep detailed page-level data for 90 days or move to summaries after 30?

---

**Next Document:** Phase 5+ Feature Tracking & Analytics Dashboard
