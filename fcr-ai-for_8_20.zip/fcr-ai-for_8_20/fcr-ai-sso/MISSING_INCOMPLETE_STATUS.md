# Missing, Placeholder & Mock Data Status
**Application Coverage Report**

---

## ✅ FULLY LIVE & CONNECTED (7 Features)

### 1. **Dashboard Summary KPIs** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/kpis`, `/api/summary`
- **Data:** Real coaching volumes, submissions %, compliance rates
- **What Shows:** Total FCRs, submitted %, avg days to submit, by-region breakdown, by-TA breakdown

### 2. **Dashboard Trends** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/capability` (12-month trend)
- **Data:** Monthly competency scores, FCR volumes over time
- **What Shows:** 6-month chart showing avg skill score trend

### 3. **Capability Page — Competency Analysis** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/capability`
- **Data:** All competency scores (1–4), by-job-level breakdown, compliance rate
- **What Shows:** Avg score, % at target, competency breakdown, by-level ranking

### 4. **FCRs Page — All FCRs Tab** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/fcrs`, `/api/fcr/:id`
- **Data:** All coaching records (100 limit), full FCR detail on click
- **What Shows:** List view with search/filter, FCR detail panel with competency breakdown

### 5. **FCRs Page — PINS FCRs (FBMS) Tab** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/fcrs?pinsOnly=true&limit=500`, `/api/pins-score`
- **Data:** MSL/VESE coaching forms only (~231 records), PINS AI scoring
- **What Shows:** PINS FCR list, "Score PINS" button, AI-scored behaviors, skill gaps, PDF download

### 6. **Training Skill Gaps View** ✅
- **Status:** LIVE (connected to Redshift)
- **Endpoint:** `/api/pins-summary`
- **Data:** Training flags by PINS section (P/I/N/S), by-job-level, by-rep with flags
- **What Shows:** % needing training per section, rep attention list, job-level heatmap

### 7. **Ask AI Page** ✅
- **Status:** LIVE (connected to Redshift + Azure OpenAI)
- **Endpoint:** `/api/ask`
- **Data:** Natural language Q&A over FCR table, text-to-SQL generation
- **What Shows:** Ask questions, get SQL-based answers with AI explanation

---

## ⏳ PARTIALLY BUILT / WAITING (3 Features)

### 1. **Skill Proficiency Trend View** ⏳ (80% Done)
- **Status:** Component exists, data fetches LIVE, but **AI Insights not wired**
- **What Works:** Chart showing 12-month skill trend + PINS trend
- **What's Missing:** 
  - ❌ `/api/skill-trend-insight` endpoint exists but **not called from frontend**
  - ❌ "Insights" section that should show AI analysis (hidden/not rendering)
  - **Fix needed:** Add button to fetch AI insights, display markdown results

### 2. **Activity Page** ⏳ (50% Built)
- **Status:** UI designed, but **using MOCK data, not live data**
- **What's Mock:**
  - ❌ Adoption Snapshot (KPI cards) — showing fake numbers
  - ❌ Submissions Trend chart — fake daily/monthly data
  - ❌ Coverage by Org table — fake team data
  - ❌ Alerts section — placeholder "10 alerts"
- **Source:** `mockData.js` (kpiData, submissionsDaily, submissionsMonthly, coverageData)
- **What Could Be Live:**
  - Could fetch `/api/fcrs` for real submission trend
  - Could fetch `/api/summary` for real adoption numbers
  - Could create `/api/coverage` endpoint for org-level data (if exists in DB)
- **Blocker:** Need confirmation — is "Coverage by Org" data available in Redshift? If yes, can connect quickly.

### 3. **FCR-Level Insight** ⏳ (Built but Not Exposed)
- **Status:** Backend endpoint `/api/fcr-insight` exists, **but no UI button to trigger it**
- **What's Built:** 
  - ✅ Endpoint analyzes FCR competency + observations
  - ✅ Returns 2500-word coaching analysis with 4 sections
  - ✅ GPT-generated narrative
- **What's Missing:**
  - ❌ **No "Get Insight" button** in FCR detail panel
  - ❌ No way for user to trigger this analysis
  - **Fix needed:** Add button next to "Score PINS", call endpoint, display results

---

## ❌ NOT YET BUILT (2 Features)

### 1. **Reference Page** ❌
- **Status:** Shows "Coming Soon" placeholder
- **UI Location:** Sidebar navigation (rarely used in meeting context)
- **Purpose:** Was intended to show PINS coaching framework definitions + FBMS skills guide
- **Current State:** Static reference data exists in `ReferencePage.jsx` (PINS definitions hardcoded) but page layout not complete
- **Priority:** LOW — static reference, not analytical

### 2. **Settings Panel** ❌
- **Status:** Not implemented
- **Alert Message:** "Settings panel coming soon"
- **Purpose:** Would allow users to customize timeframes, TA filters, etc.
- **Current State:** Could add via modal or slide-out panel
- **Priority:** LOW — filters already available on each page

---

## 🎭 PLACEHOLDER / INCOMPLETE SECTIONS (3 Items)

### 1. **Capability Page — "Data Coming Soon" Message** 🎭
- **Location:** CapabilityPage.jsx line 50
- **What's Shown:** Placeholder card saying "Data Coming Soon"
- **Status:** This is a detail card that's **not being populated**
- **What's Behind It:** Section exists but logic to fill it is incomplete
- **Fix:** Likely just needs to populate detail card from capability data

### 2. **Export Functionality** 🎭
- **Location:** Activity Page → Export dropdown
- **Current Status:**
  - ✅ CSV export: Partially working (converts data to CSV)
  - ❌ PDF export: Shows "coming soon"
  - ❌ Excel export: Shows "coming soon"
- **What Works:** Can export to CSV locally
- **What's Missing:** PDF/Excel export logic (could use same PDF library for PINS reports)

### 3. **Settings Menu** 🎭
- **Location:** Top-right gear icon
- **Status:** Shows alert "Settings panel coming soon"
- **What's Behind It:** Nothing — just an alert dialog

---

## 📊 Mock Data Usage Summary

### What's Using Mock Data
| Component | File | Data Type | Records | Status |
|-----------|------|-----------|---------|--------|
| **Activity Page — KPIs** | mockData.js | Dashboard numbers | 8 fields | 100% mock |
| **Activity Page — Submissions Daily** | mockData.js | Time series | 33 days | 100% mock, synthetic |
| **Activity Page — Submissions Monthly** | mockData.js | Time series | 5 months | 100% mock |
| **Activity Page — Coverage by Org** | mockData.js | Table data | 4 orgs | 100% mock |
| **Activity Page — Recent FCRs** | mockData.js | FCR list | 10 rows | 100% mock |
| **HeroCard Component** | mockData.js | Pipeline counts | 4 statuses | 100% mock |
| **CoverageTable Component** | mockData.js | Org coverage | 4 rows | 100% mock |

**Total:** ~50 mock data rows used (all on Activity Page)

---

## 🔧 Fix Priority Map

| What's Missing | Impact | Effort | Priority |
|---|---|---|---|
| **Connect Activity Page to Live Data** | High — shows real adoption metrics | Medium (2 hrs) | 🔴 HIGH |
| **Wire "Get Insight" Button in FCR Panel** | Medium — adds coaching narrative | Low (30 min) | 🟡 MEDIUM |
| **Finish Skill Trend Insights Button** | Medium — adds trend analysis | Low (30 min) | 🟡 MEDIUM |
| **Export to PDF/Excel** | Low — convenience feature | High (4 hrs) | 🟢 LOW |
| **Finish Reference Page UI** | Very Low — static reference | Medium (2 hrs) | 🟢 LOW |
| **Settings Panel** | Very Low — nice-to-have | Low (1 hr) | 🟢 LOW |

---

## 🚀 Quick Fix Checklist

### Can Be Done in 1 Hour
- [ ] Add "Get Insight" button to FCR detail panel (wire `/api/fcr-insight`)
- [ ] Wire "Get Insights" button to Skill Trend view (call `/api/skill-trend-insight`)
- [ ] Replace Activity Page KPI cards with live `/api/summary` data
- [ ] Replace Activity Page Coverage table with live data (if endpoint available)

### Can Be Done in 2-4 Hours
- [ ] Complete Activity Page live data connection (volume trend + org coverage)
- [ ] Finish PDF export for all report types
- [ ] Complete Reference Page UI styling

### Longer Term
- [ ] Settings/preferences panel
- [ ] Excel export functionality

---

## 📝 For Your Meeting

**You can confidently say:**

> "**Live Data:** Dashboard, Capability analysis, FCRs, PINS scoring, Training Gaps, Ask AI — all connected to real Redshift data.
> 
> **Waiting on:** Activity Page (ready to connect), a couple of AI insight buttons (easy fix), export features (nice-to-have).
> 
> **Mock Data Used:** Only Activity Page uses sample data for demo purposes; can swap to live Redshift feeds in ~2 hours.
> 
> **Overall:** 85% of the app is production-ready with live data; remaining 15% are enhancements that don't block core functionality."

---

**Document Version:** 1.0 | **Date:** 2026-07-07
