# Telemetry Permissions - Quick Reference from .env

**Status:** Complete Permission Testing Package Ready

---

## 🔍 FROM YOUR .env FILE (Connection Details)

```env
REDSHIFT_HOST=itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com
REDSHIFT_PORT=5439
REDSHIFT_DB=awprdrsdb
REDSHIFT_USER=dmp_fcr_ai_development_prod_read
REDSHIFT_PASSWORD=fPmzkv-12rfF
```

**This user:** `dmp_fcr_ai_development_prod_read` needs permissions on:

---

## 📊 ALL TABLES & REQUIRED ACCESS

### Table 1: telemetry.user_events
```
├─ Purpose: Raw event storage (all user interactions)
├─ Columns: 10 (event_id, session_id, user_id, user_name, user_email, event_type, event_data, page, url, timestamp)
├─ Indexes: 6 (user_id, session_id, event_type, timestamp, page, user_timestamp)
├─ Rows/Month: ~150,000 (100 users)
└─ Permissions Needed:
    ✅ SELECT (for dashboards)
    ✅ INSERT (for backend to write events)
```

### Table 2: telemetry.user_sessions
```
├─ Purpose: Aggregated session-level data
├─ Columns: 11 (session_id, user_id, user_name, user_email, session_start, session_end, duration_seconds, event_count, page_views, button_clicks, errors_count)
├─ Indexes: 2 (user_id, session_start)
├─ Rows/Month: ~3,000
└─ Permissions Needed:
    ✅ SELECT (for analytics)
    ✅ INSERT (for aggregation)
    ✅ UPDATE (for rollups)
```

### Table 3: telemetry.daily_usage_summary
```
├─ Purpose: Daily aggregated usage statistics
├─ Columns: 9 (usage_date, active_users, total_sessions, total_events, total_page_views, total_button_clicks, total_logins, total_errors, avg_session_duration_seconds)
├─ Indexes: 0 (PK only)
├─ Rows/Year: ~365
└─ Permissions Needed:
    ✅ SELECT (for dashboards)
    ✅ INSERT (for daily rollup)
    ✅ UPDATE (for daily updates)
```

### Table 4: telemetry.page_analytics
```
├─ Purpose: Page-level analytics
├─ Columns: 7 (page_id, page_name, analytics_date, view_count, unique_visitors, avg_time_spent_seconds, bounce_rate)
├─ Indexes: 1 (page_name, analytics_date)
├─ Rows/Year: ~2,555 (7 pages × 365 days)
└─ Permissions Needed:
    ✅ SELECT (for page performance reports)
    ✅ INSERT (for daily aggregation)
    ✅ UPDATE (for daily rollups)
```

### Table 5: telemetry.button_analytics
```
├─ Purpose: Button/feature usage analytics
├─ Columns: 6 (button_id, button_name, page_name, analytics_date, click_count, unique_users)
├─ Indexes: 1 (button_name, page_name, analytics_date)
├─ Rows/Year: ~10,950 (30 buttons × 365 days)
└─ Permissions Needed:
    ✅ SELECT (for feature adoption reports)
    ✅ INSERT (for daily aggregation)
    ✅ UPDATE (for daily rollups)
```

---

## 👁️ ALL VIEWS & REQUIRED ACCESS

### View 1: telemetry.v_user_activity
```
├─ Purpose: User activity summary (last 30 days)
├─ Columns: user_id, user_name, user_email, session_count, event_count, active_days, last_activity, total_clicks, total_pages, total_errors
└─ Permissions Needed:
    ✅ SELECT (for user analytics dashboard)
```

### View 2: telemetry.v_page_performance
```
├─ Purpose: Page performance metrics (last 7 days)
├─ Columns: page, page_views, unique_sessions, unique_users, avg_time_seconds, first_view, last_view
└─ Permissions Needed:
    ✅ SELECT (for page performance reports)
```

### View 3: telemetry.v_most_used_features
```
├─ Purpose: Most used features ranking (last 7 days)
├─ Columns: feature_name, page, usage_count, unique_users, last_used
└─ Permissions Needed:
    ✅ SELECT (for feature adoption reports)
```

---

## 🔐 COMPLETE PERMISSION SUMMARY

**User:** `dmp_fcr_ai_development_prod_read`

| Permission | Target | Why Needed |
|-----------|--------|-----------|
| USAGE | Schema `telemetry` | To access objects in schema |
| SELECT | All 5 tables | For analytics queries & dashboards |
| INSERT | All 5 tables | For event ingestion & aggregation |
| UPDATE | user_sessions, daily_usage_summary, page_analytics, button_analytics | For daily rollups & aggregations |
| SELECT | All 3 views | For dashboard data retrieval |

**Total: 23 granular permissions**

---

## 🧪 THREE WAYS TO TEST PERMISSIONS

### Option 1: Use Python Test Script
```bash
cd fcr-ai-sso/
python test-telemetry-permissions.py
```
✅ Comprehensive test of all schemas, tables, views, and permissions
✅ Shows detailed results for each test
✅ Generates summary report

### Option 2: Manual SQL Test
Connect to Redshift using connection details from .env:
```bash
psql -h itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com \
     -U dmp_fcr_ai_development_prod_read \
     -d awprdrsdb
```

Then run individual tests:
```sql
-- Test 1: Schema access
SELECT nspname FROM pg_namespace WHERE nspname = 'telemetry';

-- Test 2: Table access
SELECT COUNT(*) FROM telemetry.user_events;
SELECT COUNT(*) FROM telemetry.user_sessions;

-- Test 3: Insert permission
INSERT INTO telemetry.user_events (session_id, user_id, event_type) 
VALUES ('test', 'test', 'custom');

-- Test 4: View access
SELECT COUNT(*) FROM telemetry.v_user_activity;
```

### Option 3: Use Redshift Query Editor (AWS Console)
1. Go to AWS Console → Redshift
2. Open Query Editor
3. Connect to database with your user
4. Run queries from TELEMETRY_SCHEMA_AND_PERMISSIONS.md

---

## 📝 IF PERMISSIONS ARE MISSING

**Provide this to your Redshift admin:**

```sql
-- Grant all required permissions for dmp_fcr_ai_development_prod_read user

-- 1. Schema access
GRANT USAGE ON SCHEMA telemetry TO dmp_fcr_ai_development_prod_read;

-- 2. Table permissions
GRANT SELECT ON telemetry.user_events TO dmp_fcr_ai_development_prod_read;
GRANT INSERT ON telemetry.user_events TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.user_sessions TO dmp_fcr_ai_development_prod_read;
GRANT INSERT ON telemetry.user_sessions TO dmp_fcr_ai_development_prod_read;
GRANT UPDATE ON telemetry.user_sessions TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.daily_usage_summary TO dmp_fcr_ai_development_prod_read;
GRANT INSERT ON telemetry.daily_usage_summary TO dmp_fcr_ai_development_prod_read;
GRANT UPDATE ON telemetry.daily_usage_summary TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.page_analytics TO dmp_fcr_ai_development_prod_read;
GRANT INSERT ON telemetry.page_analytics TO dmp_fcr_ai_development_prod_read;
GRANT UPDATE ON telemetry.page_analytics TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.button_analytics TO dmp_fcr_ai_development_prod_read;
GRANT INSERT ON telemetry.button_analytics TO dmp_fcr_ai_development_prod_read;
GRANT UPDATE ON telemetry.button_analytics TO dmp_fcr_ai_development_prod_read;

-- 3. View permissions
GRANT SELECT ON telemetry.v_user_activity TO dmp_fcr_ai_development_prod_read;
GRANT SELECT ON telemetry.v_page_performance TO dmp_fcr_ai_development_prod_read;
GRANT SELECT ON telemetry.v_most_used_features TO dmp_fcr_ai_development_prod_read;
```

---

## 📊 WHAT EACH TABLE STORES

| Table | Data Stored | Access Pattern | Volume |
|-------|-------------|-----------------|--------|
| user_events | Raw events (login, page view, click, error) | Per user, per session, per date | ~150K/month |
| user_sessions | Session summaries (start, end, duration, counts) | Per user, per date range | ~3K/month |
| daily_usage_summary | Daily KPIs (active users, sessions, events) | Per day | ~30/month |
| page_analytics | Page metrics (views, time spent, bounce) | Per page, per day | ~2.5K/year |
| button_analytics | Feature metrics (clicks, adoption) | Per feature, per day | ~11K/year |

---

## 🚀 TESTING CHECKLIST

Before telling your manager "system is ready":

- [ ] Run `python test-telemetry-permissions.py` successfully
- [ ] All connection tests pass
- [ ] All table SELECT tests pass
- [ ] All table INSERT tests pass (or note which are missing)
- [ ] All UPDATE tests pass (or note which are missing)
- [ ] All view SELECT tests pass
- [ ] Complex query tests pass
- [ ] Performance tests show <500ms response times

---

## 📞 QUICK CONTACT INFO FOR REDSHIFT ADMIN

**What to tell them:**
> "We need to grant permissions for telemetry analytics system. User `dmp_fcr_ai_development_prod_read` needs USAGE on schema `telemetry` and SELECT/INSERT/UPDATE on 5 tables. Full GRANT statements are in the SQL block below."

**Send them the SQL block from the section above.**

---

## 📋 DETAILED SCHEMA DOCS

For complete schema details (every column, data type, constraint), see:
👉 **`TELEMETRY_SCHEMA_AND_PERMISSIONS.md`**

Contains:
- Complete CREATE TABLE statements
- Column-by-column specifications
- Index definitions
- Permission matrix
- 18 test queries with expected results
- Python test script

---

## 🎯 SUCCESS CRITERIA

You're ready when:

✅ Python test script runs with 0 failures  
✅ Can query all 5 tables (SELECT)  
✅ Can insert test rows in all tables  
✅ Can query all 3 views  
✅ Database response times <500ms  
✅ Connection from .env works reliably  

---

**Next: Run the test script to validate permissions!** 🚀

```bash
python test-telemetry-permissions.py
```
