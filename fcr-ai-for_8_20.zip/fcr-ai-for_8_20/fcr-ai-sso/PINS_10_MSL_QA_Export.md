# 10 MSL PINS Field Coaching Reports — Full Q&A Export
Generated: 2026-07-07 18:37:45
Source: Live Redshift · FBMS MSL/VESE Forms Only
Total PINS FCRs available: 241

---

## 1. Hazeline Hakansson
**FCR ID:** a2zWQ0000041ftFYAQ
**Form:** MSL/VESE Field Coaching Report
**Role:** Sr Medical Science Liaison  Immunology
**TA:** Scientific Affairs (Janssen) | **Region:** Northeast | **Territory:** Upstate New York, NY
**Coaching Date:** 2026-07-03
**Session Duration:** One day
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Skilled | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Skilled | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Skilled | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of development | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Incorporated insights from prior engagements into meeting objectives and engagement planning across two appointments with Tier 1 HCPs to support continuity of scientific exchange and advancement of MAF strategic objectives.  Planned use of a data visualization resource prior to field engagements whi… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Skilled | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Skilled | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Skilled | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of development | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Used open‑ended and probing questions to explore clinical perspectives and experiences which generated high‑quality, actionable insights aligned to strategic listening priorities.  Adjusted scientific discussion in real time based on HCP responses and insights to enable tailored engagement aligned t… |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Skilled | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Skilled | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Skilled | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of development | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Applied HCP‑tailored scientific knowledge and addressed questions and misunderstandings with accurate explanations.  This supported interpretation of evidence and reinforced scientific credibility.    Tremfya was not consistently incorporated alongside Icotyde during portfolio discussions, limiting … |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Skilled | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Skilled | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Skilled | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Reviewed approach for documenting interactions and voice‑of‑customer insights to support accurate capture of scientific exchange and shared back impactful, actionable VOC to inform MAF strategy.  	 Key points were summarized and next steps and follow up were identified and secured resulting in conti… |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Incorporated insights from prior engagements into meeting objectives and engagement planning across two appointments with Tier 1 HCPs to support continuity of scientific exchange and advancement of MAF strategic objectives.

Planned use of a data visualization resource prior to field engagements which enhanced preparedness to communicate scientific information aligned to anticipated HCP interests.

Coached on opportunity for field-day planning to maximize opportunities for Tier 1 and Tier 2 stakeholder engagement throughout the day and strategies to foster commercial partnership for account planning opportunities.   

ACTION: Continue to implement strategies discussed to grow relationships with newer HCPs in territory to support autonomous, strategic territory maximization for the long-term.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Used open‑ended and probing questions to explore clinical perspectives and experiences which generated high‑quality, actionable insights aligned to strategic listening priorities.

Adjusted scientific discussion in real time based on HCP responses and insights to enable tailored engagement aligned to HCP needs and perspectives.

Follow-up questions on listening-priority topics could be more tailored beyond asking for thoughts in order to explore underlying drivers or perspectives.  This will help to generate more actionable VOC beyond surface level perspectives.  

ACTION: For future HCP meetings, incorporate tailored probing questions about impact of data on clinical practice and understand why in order to deepen insights.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Applied HCP‑tailored scientific knowledge and addressed questions and misunderstandings with accurate explanations.  This supported interpretation of evidence and reinforced scientific credibility.  

Tremfya was not consistently incorporated alongside Icotyde during portfolio discussions, limiting opportunity to assess understanding of the label update, explore comparative perspectives, and generate portfolio-focused insights.  
ACTION: intentionally integrate scientific exchange for Tremfya in addition to Icotyde into most HCP engagements.

Data Visualization resources were presented primarily as a tool rather than being integrated into the clinical discussion resulting in limited opportunity to connect the visualization to patient care considerations and the HCP’s practice experience.  
ACTION: Practice and apply a discussion approach that links the visualization to a representative patient scenario and associated clinical decision points.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Reviewed approach for documenting interactions and voice‑of‑customer insights to support accurate capture of scientific exchange and shared back impactful, actionable VOC to inform MAF strategy. 
	
Key points were summarized and next steps and follow up were identified and secured resulting in continuity of the relationship.


---

## 2. Joseph Lance Salazar
**FCR ID:** a2zWQ0000041VQrYAM
**Form:** MSL/VESE Field Coaching Report
**Role:** Dir Sci Aff V&ESE Field
**TA:** Scientific Affairs (Janssen) | **Region:** VESE Field Channel Strategy and Operations Director | **Territory:** VESE Field SAL (National 4)
**Coaching Date:** 2026-07-02
**Session Duration:** 1 hour
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Expert | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Not applicable to the observed interaction | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Advanced | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Prep was clear in meeting with OptumCare. Clearly identified customer needs and whats important. |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Advanced | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Expert | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Great follow up questions to get a root inquiry |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Expert | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Expert | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Expert | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Great responses to customers questions related to competitive immunology portfolio |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Advanced | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Expert | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Expert | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | N/A |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Prep was clear in meeting with OptumCare. Clearly identified customer needs and whats important.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Great follow up questions to get a root inquiry

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Great responses to customers questions related to competitive immunology portfolio

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

N/A


---

## 3. Danny Mcnatty
**FCR ID:** a2zWQ0000041VsHYAU
**Form:** MSL/VESE Field Coaching Report
**Role:** Dir Sci Aff V&ESE Field
**TA:** Scientific Affairs (Janssen) | **Region:** VESE Field Channel Strategy and Operations Director | **Territory:** VESE Field SAL (National 4)
**Coaching Date:** 2026-07-02
**Session Duration:** 1 hour
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Expert | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Not applicable to the observed interaction | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Expert | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | presentation planned out well and clear from customer comments |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Expert | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Advanced | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Great anticipation of questions and connection with Clinical lead |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Expert | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Expert | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Expert | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | N/A |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Expert | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Expert | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Advanced | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | N/A |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

presentation planned out well and clear from customer comments

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Great anticipation of questions and connection with Clinical lead

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

N/A

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

N/A


---

## 4. Amy Hale
**FCR ID:** a2zWQ0000041VInYAM
**Form:** MSL/VESE Field Coaching Report
**Role:** Dir Sci Aff V&ESE Field
**TA:** Scientific Affairs (Janssen) | **Region:** VESE Field Channel Strategy and Operations Director | **Territory:** VESE Field (National 4)
**Coaching Date:** 2026-07-02
**Session Duration:** 1 hour
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Advanced | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Not applicable to the observed interaction | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Advanced | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Presentation flow and delivery of information dialed in for the audience. |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Advanced | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Advanced | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Discussed. |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Expert | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Not applicable to the observed interaction | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Advanced | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Delivered presentation at good pace for audience to digest and consider asking questions. Presentation style is confident but inviting. |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Advanced | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Advanced | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Advanced | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | N/A |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Presentation flow and delivery of information dialed in for the audience.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Discussed.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Delivered presentation at good pace for audience to digest and consider asking questions. Presentation style is confident but inviting.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

N/A


---

## 5. Kelly Hawks
**FCR ID:** a2zWQ0000041RNFYA2
**Form:** MSL/VESE Field Coaching Report
**Role:** PRINCIPAL MSL ONCOLOGY
**TA:** Scientific Affairs (Janssen) | **Region:** Head, Hematology Field Medical, East | **Territory:** ONC Heme MSL - E.VA - E.WV - Washington DC
**Coaching Date:** 2026-07-02
**Session Duration:** Half day
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Advanced | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Not applicable to the observed interaction | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Expert | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Outstanding pre-call planning and preparation across both engagements at Inova, a strategically important account within your territory. Your level of account awareness enabled you to enter each discussion with clear objectives, relevant context, and a tailored engagement strategy.  For the engageme… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Skilled | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Expert | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Expert | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Excellent job entering both engagements with purposeful, strategic questions and a clear plan for insight generation.  Effectively explored awareness and implementation of recent REMS updates while assessing operational experiences with TEC/TAL therapies in a natural and consultative manner.  Demons… |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Expert | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Advanced | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Expert | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Excellent use of knowledge-checking techniques to assess awareness of important TECVAYLI updates, including changes to hospitalization requirements, without making the HCP feel tested or challenged. Your approach facilitated scientific exchange while maintaining a positive engagement experience.  Ef… |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Advanced | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Expert | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Expert | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Great job positioning yourself as an accessible, trusted scientific resource for Radha and reinforcing your commitment to supporting her ongoing information needs.  For the meeting with Dr. Medlin and the cellular therapy team, there was an opportunity to more explicitly secure follow-up actions and… |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Outstanding pre-call planning and preparation across both engagements at Inova, a strategically important account within your territory. Your level of account awareness enabled you to enter each discussion with clear objectives, relevant context, and a tailored engagement strategy.

For the engagement with Radha, you demonstrated a comprehensive understanding of the evolving account landscape, including recent staffing changes, her expanding responsibilities, leadership role within NCODA, and her work on a high-impact PQI. This preparation positioned you to engage as a trusted scientific partner while appropriately supporting the discussion around topics of mutual interest.

Excellent job leveraging multiple sources of intelligence and preparation resources to understand both the scientific and professional priorities of Dr. Medlin. Your ability to align the conversation with his goals and interests reflects a highly strategic approach to account management.

For the engagement with Dr. Medlin and the cellular therapy team, your preparation was particularly impressive. You entered the meeting with a sophisticated understanding of team dynamics, individual stakeholder roles, organizational objectives, recent scholarly activities, and the program's evolution. This level of nuance allowed you to tailor your engagement approach appropriately for each participant. Outstanding prepping of the entire internal team as well so that we could have a very successful engagement. 

Your preparation also demonstrated a deep understanding of the cellular therapy program's strategic priorities, publication interests, operational goals, and future direction. This enabled highly relevant discussions around opportunities for support and collaboration.

Overall, your preparation for both meetings exemplified best practices within the PINS framework and created the foundation for highly productive scientific exchanges.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Excellent job entering both engagements with purposeful, strategic questions and a clear plan for insight generation.

Effectively explored awareness and implementation of recent REMS updates while assessing operational experiences with TEC/TAL therapies in a natural and consultative manner.

Demonstrated skill in exploring Radha's work on the NCODA PQI initiative by asking thoughtful, relevant questions that helped inform the discussion without appearing directive. Your approach fostered a collaborative exchange while maintaining appropriate scientific objectivity.

Outstanding investigation of referral patterns, program development goals, and operational needs during the discussion with Dr. Medlin and the cellular therapy team.

Successfully uncovered several high-value insights, including the team's experience with bendamustine lymphodepletion, perceived benefits of this approach, and plans to potentially publish their findings.

Effectively explored the team's experiences with cyclosporine management of IEC-HS and generated meaningful insights that may inform future internal understanding.

Throughout both engagements, you balanced insight generation with relationship-building and created an environment that encouraged open and productive discussion.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Excellent use of knowledge-checking techniques to assess awareness of important TECVAYLI updates, including changes to hospitalization requirements, without making the HCP feel tested or challenged. Your approach facilitated scientific exchange while maintaining a positive engagement experience.

Effectively navigated discussions toward relevant and timely scientific resources, including high-risk subgroup definitions and TEC-3 subgroup analyses, based on the interests and needs expressed during the conversations.

During the discussion with Radha, you demonstrated exceptional emotional intelligence and situational awareness. You appropriately assessed the dynamics surrounding recent staffing changes and adapted your approach to maintain a productive and comfortable dialogue.

Strong job leveraging existing relationships and common connections to establish rapport and create a collaborative environment that encouraged meaningful scientific discussion.

Your scientific acumen was particularly impressive. You were able to confidently discuss the Stanford bendamustine experience and respond in real time to complex questions related to ruxolitinib-based management of CARVYKTI adverse events.

You clearly understood Dr. Medlin's professional motivations and interests. Your discussion around his publication efforts and contributions to helping other programs develop resonated strongly and further strengthened the relationship.

Opportunity for Growth: During formal multidisciplinary meetings such as the engagement with Dr. Medlin and his team, consider spending additional time at the beginning of the discussion explicitly co-creating the agenda. While you effectively communicated the meeting objectives, asking participants what they hope to accomplish during the meeting can help further align expectations and ensure mutual value creation. This approach may be particularly impactful during longer engagements where multiple stakeholders are present and can help reinforce the perception of a balanced scientific exchange rather than a primarily information-gathering discussion.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Great job positioning yourself as an accessible, trusted scientific resource for Radha and reinforcing your commitment to supporting her ongoing information needs.

For the meeting with Dr. Medlin and the cellular therapy team, there was an opportunity to more explicitly secure follow-up actions and future engagement opportunities, particularly after discussions regarding ASH and ASTCT participation.

Consider being more direct in identifying next steps, confirming follow-up topics, and obtaining agreement on future touchpoints before closing meetings of this nature.

A potential future opportunity may be facilitating connections between the Inova team and the Indiana cellular therapy program, given common interests in program development, operational considerations, and publication activities.

Overall, both engagements strengthened existing relationships and created several meaningful opportunities for continued scientific exchange and future collaboration.


---

## 6. Callie Jellots
**FCR ID:** a2zWQ00000412FBYAY
**Form:** MSL/VESE Field Coaching Report
**Role:** —
**TA:** Scientific Affairs (Janssen) | **Region:** Northeast | **Territory:** Western Pennsylvania
**Coaching Date:** 2026-07-02
**Session Duration:** Two days
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Skilled | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Skilled | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Skilled | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Scheduled multiple engagements with Tier 1 HCPs during two field days in a rural geography. This supported strategic scientific engagement and demonstrated continuity of HCP relationship-building from prior introductions.  Incorporated insights from prior HCP interactions into pre-call planning and … |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Awareness | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Awareness | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Awareness | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of development | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Outlined meeting objectives and referenced prior discussions during engagement which supported continuity of scientific exchange and progression of stakeholder dialogue.  Available discussion time was not explicitly confirmed at the start of the interaction which reduced ability to align content to … |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Skilled | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Awareness | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Not applicable to the observed interaction | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of development | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Effectively communicated scientific exchange and addressed questions with accurate explanations.  This supported interpretation of evidence and reinforced scientific credibility.  Appropriately adapted for dialogue based engagement based on HCP non-verbal cues which kept the HCP engaged.  Responses … |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Awareness | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Skilled | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Skilled | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of development | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Reviewed approach for documenting interactions and voice‑of‑customer insights to support accurate capture of scientific exchange and share back impactful, actionable VOC to inform MAF strategy.   Coached on ensuring capture of both Tremfya and Icotyde discussions in iConnect logging to reflect portf… |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Scheduled multiple engagements with Tier 1 HCPs during two field days in a rural geography. This supported strategic scientific engagement and demonstrated continuity of HCP relationship-building from prior introductions.

Incorporated insights from prior HCP interactions into pre-call planning and anticipated potential questions and objections.  This supported tailored scientific dialogue aligned to stakeholder priorities.

Conducted preparation for an in-depth research interest discussion to support confident engagement, responsiveness to complex questions, and identification of potential partnership opportunities.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Outlined meeting objectives and referenced prior discussions during engagement which supported continuity of scientific exchange and progression of stakeholder dialogue.

Available discussion time was not explicitly confirmed at the start of the interaction which reduced ability to align content to HCP availability and priorities.  
ACTION: ask the HCP to confirm available time and discussion priorities if non-verbal cues are indicating they are in a rush.

Open-ended questions were limited during the initial phase and throughout the discussion with Jasmine which reduced opportunity to tailor scientific dialogue to stated priorities and interests.  
ACTION:  incorporate at least two open-ended questions within the first five minutes of the next engagement and use that information to tailor your approach accordingly.

Follow-up questions on listening-priority topics did not consistently explore underlying drivers or perspectives resulting in limited generation of actionable insights beyond practice patterns.  
ACTION: Practice asking probing questions about impact of data on clinical practice and understand why in order to deepen insights.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Effectively communicated scientific exchange and addressed questions with accurate explanations.  This supported interpretation of evidence and reinforced scientific credibility.

Appropriately adapted for dialogue based engagement based on HCP non-verbal cues which kept the HCP engaged.

Responses to competitor-related questions and objections were not consistently delivered with depth and confidence indicating opportunity to continue to grow acumen within the disease area over time. 
ACTION: Continue self-learning to review and practice key competitor data and objection-handling scenarios.

Discussion of APEX data did not consistently extend beyond core label update verbiage resulting in limited opportunity for broader portfolio dialogue and scientific exchange.  
ACTION: Prepare and incorporate at least two discussion points linking APEX data to portfolio strategy during the next relevant HCP engagement.  Practice leveraging open-ended questions to guide your approach accordingly as discussed during the coaching session.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Reviewed approach for documenting interactions and voice‑of‑customer insights to support accurate capture of scientific exchange and share back impactful, actionable VOC to inform MAF strategy. 

Coached on ensuring capture of both Tremfya and Icotyde discussions in iConnect logging to reflect portfolio conversations.

Clearly outlined next steps and follow‑up actions with the HCP which supported continuity of scientific exchange and longitudinal ownership of territory strategy.

End-of-meeting summary did not consistently synthesize key discussion points prior to close due to running out of time.  This reduced opportunity to reinforce takeaways and agreed-upon actions.  
ACTION: Confirm available time throughout the engagement and deliver a concise summary of key points prior to concluding.


---

## 7. Adaobi Amobi-Mccloud
**FCR ID:** a2zWQ000003vgvFYAQ
**Form:** MSL/VESE Field Coaching Report
**Role:** SENIOR MSL ONCOLOGY
**TA:** Scientific Affairs (Janssen) | **Region:** Head, Hematology Field Medical, East | **Territory:** ONC Heme MSL - Upstate NY - Long Island
**Coaching Date:** 2026-07-01
**Session Duration:** One day
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Expert | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Expert | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Advanced | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -The proactive myeloma landscape resource was utilized to set the stage and support introductory discussion. -Tec-3 slides were appropriate for the audience. -Clear verbal references to supporting resources can enhance navigation of complex questions and create follow-up opportunities (e.g., Tecvayl… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Advanced | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Advanced | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Objectives (Tec-3 education, implementation, and patient identification) were appropriately outlined, and previous discussions with Dr. Jamshed were effectively recapped. -Engaged a diverse group of stakeholders (nurses, PAs, fellows, PharmD), facilitating discussions that were relevant and tailore… |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Advanced | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Skilled | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Advanced | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of development | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Created an open, dialogue-driven presentation environment that encouraged attendees to ask questions throughout. -Observed a knowledge gap related to q4-week dosing included in the Tecvayli label; recommend reviewing Tec-3 label updates and understanding implications for monitoring the third step-u… |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Advanced | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Not applicable to the observed interaction | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Not applicable to the observed interaction | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | No | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Multiple follow-up opportunities were identified, particularly with the pharmacist regarding Tec-9 and with the PA on infections and dosing intervals. -Coached on the importance of meeting efficiency—maximizing time to engage all stakeholders, not just those who attended the presentation -Encourage… |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-The proactive myeloma landscape resource was utilized to set the stage and support introductory discussion.
-Tec-3 slides were appropriate for the audience.
-Clear verbal references to supporting resources can enhance navigation of complex questions and create follow-up opportunities (e.g., Tecvayli SRL for less frequent dosing; bispecifics deck for community providers for infection prophylaxis recommendations).

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Objectives (Tec-3 education, implementation, and patient identification) were appropriately outlined, and previous discussions with Dr. Jamshed were effectively recapped.
-Engaged a diverse group of stakeholders (nurses, PAs, fellows, PharmD), facilitating discussions that were relevant and tailored to each discipline.
-Consider leveraging downtime to engage stakeholders individually as they enter the room; these targeted, smaller conversations can lead to impactful insights and follow-up opportunities.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Created an open, dialogue-driven presentation environment that encouraged attendees to ask questions throughout.
-Observed a knowledge gap related to q4-week dosing included in the Tecvayli label; recommend reviewing Tec-3 label updates and understanding implications for monitoring the third step-up dose.
-Identified “Navigate/Negotiate” as an area for development, with opportunities to pivot and gather additional insights during challenging questions (e.g., reframing questions on antibacterial use for Tec-3 to explore current infection prophylaxis practices; using MRD frequency questions to understand how it is applied in practice, if at all).

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Multiple follow-up opportunities were identified, particularly with the pharmacist regarding Tec-9 and with the PA on infections and dosing intervals.
-Coached on the importance of meeting efficiency—maximizing time to engage all stakeholders, not just those who attended the presentation
-Encouraged Adaobi to engage with three nurses who arrived after the presentation; this additional interaction led to potential follow-up opportunities with the inpatient -nursing team—an important stakeholder as the site considers initiating SUD.
-iConnect documentation is an area of focus, calls and insights must be documented within 3 business days.


---

## 8. Jeffrey Pasucal
**FCR ID:** a2zWQ000003vyIfYAI
**Form:** MSL/VESE Field Coaching Report
**Role:** Medical Science Liaison
**TA:** Scientific Affairs (Janssen) | **Region:** ONC GU MSL - National | **Territory:** ONC GU MSL - AR / S.IL / S.MO / W.TN
**Coaching Date:** 2026-07-01
**Session Duration:** One day
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Skilled | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Skilled | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Skilled | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | - Stated meeting objections at start of each interaction and discussed previous interactions with KOLs which was last in January - Prostate Updates from ASCO GU were specifically requested as it was a group of Medical Oncologists.  - Sentiment identification of Selective Users - most GU patients are… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Skilled | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Skilled | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of development | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | - Recapped previous engagement and invited input at start of discussion to ensure topics were still relevant  - Asked relevant probing questions and uncovered new treatment drivers (ex: comfort with other ARPI therapies and questions on rash management)  - Coaching focused on continuing to thoughtfu… |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Advanced | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Advanced | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Skilled | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | - Main focus on ASCO GU updates for Medical Oncologist and APPs  - Identified HCP misunderstandings and provided clarification specifically closing knowledge gaps on rash management with Erleada  - Focus on GU MAF Priorities including RWE and TARgeting initiatives  - Engaged beyond slides in scienti… |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Skilled | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Advanced | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Skilled | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | - Clearly identified next steps in relation to these KOLs which will be transitioning with our redeployment and communicated clare next steps to incoming MSL  - 1 insight captured in iConnect on APRI clinical decision making criteria   - Coaching focused on timely documentation (3 business days) in … |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

- Stated meeting objections at start of each interaction and discussed previous interactions with KOLs which was last in January
- Prostate Updates from ASCO GU were specifically requested as it was a group of Medical Oncologists. 
- Sentiment identification of Selective Users - most GU patients are coming to them for continuation of care (urologist have already started arpi in hormone sensitive) 
- Prepared key resources for objectives and discussion 
- Jeff has been an early adopter of H1 and encouraged him to continue to use our digital tools to elevate effectiveness 
- Coached on ensuring printed handouts are available in anticipation of KOL discussions. Did not have rash management infographic readily printed and had to follow-up following meeting.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

- Recapped previous engagement and invited input at start of discussion to ensure topics were still relevant 
- Asked relevant probing questions and uncovered new treatment drivers (ex: comfort with other ARPI therapies and questions on rash management) 
- Coaching focused on continuing to thoughtfully explore HCP ques (ex: opportunity to further question why HCP preferred Erleada) and consistently communicating with purpose during longer evening engagement

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

- Main focus on ASCO GU updates for Medical Oncologist and APPs 
- Identified HCP misunderstandings and provided clarification specifically closing knowledge gaps on rash management with Erleada 
- Focus on GU MAF Priorities including RWE and TARgeting initiatives 
- Engaged beyond slides in scientific dialogue and confidently addressed questions

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

- Clearly identified next steps in relation to these KOLs which will be transitioning with our redeployment and communicated clare next steps to incoming MSL 
- 1 insight captured in iConnect on APRI clinical decision making criteria  
- Coaching focused on timely documentation (3 business days) in iConnect for engagement and insights and capturing actionable insights to increase usability and impact


---

## 9. Olivia Costa
**FCR ID:** a2zWQ000003xIaHYAU
**Form:** MSL/VESE Field Coaching Report
**Role:** SENIOR MSL ONCOLOGY
**TA:** Scientific Affairs (Janssen) | **Region:** Head, Hematology Field Medical, East | **Territory:** ONC Heme MSL - ME - NH - VT - N.NY
**Coaching Date:** 2026-07-01
**Session Duration:** One day
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Advanced | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Expert | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Expert | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Goals and objectives for the meeting were thoughtfully developed and shared with the FD in advance. -Multiple resources (iConnect, health system websites, and cross-functional partners) were utilized to prepare for the meeting. -Appropriate context and background were provided to the FD ahead of th… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Advanced | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Expert | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Expert | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Meeting objectives were clearly articulated at the start, providing an effective framework for the discussion. -Demonstrated excellent use of open-ended questions to identify and address barriers related to BsAb and CAR-T utilization. -Effectively utilized active listening to discern and understand… |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Expert | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Not applicable to the observed interaction | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Expert | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Facilitated and fostered exceptional scientific exchange; slides and resources were used minimally (if at all) only when appropriate.  -Effectively leveraged the NE infographic to succinctly and accurately address the HCP’s questions regarding MNT and colitis. -Opportunity to improve in navigating … |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Expert | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Not applicable to the observed interaction | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Expert | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | -Objectives were successfully achieved across the meetings, with documented interest or follow-up opportunities identified in 2 of 3 observed interactions. -High-quality insights were captured and entered into iConnect within three business days. |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Goals and objectives for the meeting were thoughtfully developed and shared with the FD in advance.
-Multiple resources (iConnect, health system websites, and cross-functional partners) were utilized to prepare for the meeting.
-Appropriate context and background were provided to the FD ahead of the meeting.
-Relevant resources were identified for the meeting, including the use of the NE infographic.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Meeting objectives were clearly articulated at the start, providing an effective framework for the discussion.
-Demonstrated excellent use of open-ended questions to identify and address barriers related to BsAb and CAR-T utilization.
-Effectively utilized active listening to discern and understand key motivators and objections.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Facilitated and fostered exceptional scientific exchange; slides and resources were used minimally (if at all) only when appropriate. 
-Effectively leveraged the NE infographic to succinctly and accurately address the HCP’s questions regarding MNT and colitis.
-Opportunity to improve in navigating and reorienting the HCP back to the original discussion and objectives, as one pharmacist initiated an unrelated discussion that accounted for a significant portion of the meeting.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

-Objectives were successfully achieved across the meetings, with documented interest or follow-up opportunities identified in 2 of 3 observed interactions.
-High-quality insights were captured and entered into iConnect within three business days.


---

## 10. Radhika Jhaveri
**FCR ID:** a2zWQ000004010DYAQ
**Form:** MSL/VESE Field Coaching Report
**Role:** Medical Science Liaison
**TA:** Scientific Affairs (Janssen) | **Region:** ONC GU MSL - National | **Territory:** ONC GU MSL - W.MA / RI
**Coaching Date:** 2026-07-01
**Session Duration:** One and half days
**Status:** Draft
**Training Flags:** P:No | I:No | N:No | S:No
**Total Q&A Rows:** 42

### Questions & Answers

| # | Question | Response | Notes |
|---|----------|----------|-------|
| 1 | Reports must follow Clear Communications standards and reflect accurate, objective information.  Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported immediately per company requirements. | — | — |
| 2 | Aligning to FBMS Core Skills •	Data Gathering and Analysis (DG) •	Strategic Thinking (ST)  •	Competitive Landscape (CL) •	Influencing Others (IO) •	Clinical Expertise (CE) •	Problem Solving (PS) •	Cross-functional Collaboration (CC) | — | — |
| 3 | Planning for Perspective of PINS:  Meeting Objectives & Resources | — | — |
| 4 | Developed strategically aligned goals, reflecting a strong understanding of business partner’s account strategy and translated it into clear, actionable objectives (ST, CL) | Skilled | — |
| 5 | Incorporated useful insights using digital tools (i.e., AI Digital Assistant-AIDA), clinical and market access readiness and business priorities (DG) | Skilled | — |
| 6 | Selected resources supported the stated strategy and objectives and addressed anticipated objections (CE, DG) | Skilled | — |
| 7 | Planning for Perspective of PINS, Impressions | — | — |
| 8 | Rate the overall quality of the Planning for Perspective | Area of strength | — |
| 9 | Planning for Perspective:  Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Radhika spent timing prior to ASCO reviewing each physician profile via H1.  She spoke to peers and partners to better understand the HCPs insights such as needs and interests.  She reviewed the previous iConnect entries for each physician and even reached out to the predecessor MSL for input, espec… |
| 10 | Planning for Perspective: Training Needed? | No | — |
| 11 | Identify specific training needs and date for follow-up: | — | — |
| 12 | Investigate Issues of PINS:  Engagement & Communication Strategies | — | — |
| 13 | Outlined meeting objectives, recapped previous discussions, invited HCP or PHDM input and adjusted as needed (IO) | Skilled | — |
| 14 | Engaged HCPs or PHDMs with open-ended questions, active listening, and clear communication to ensure mutual understanding (IO, PS) | Skilled | — |
| 15 | Investigate Issues of PINS:  Insight Gathering | — | — |
| 16 | Identified HCP or PHDM motivators, barriers, objections, and unmet needs to capture actionable insights (DG, PS) | Skilled | — |
| 17 | Investigate Issues of PINS, Impressions | — | — |
| 18 | Rate the overall quality of the Investigate Issues | Area of strength | — |
| 19 | Investigate Issues: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Radhika asked appropriate probing questions to better understand the physicians views on the treatment landscape.  She probed to understand the HCPs sphere of influence within the context of the institution.  With Dr. Chaudry she was able to gain insight into each team member's area of specialty at … |
| 20 | Investigate Issues: Training Needed? | No | — |
| 21 | Identify specific training needs and date for follow-up: | — | — |
| 22 | Navigate and Negotiate Needs of PINS:  Scientific Engagement & Knowledge Transfer | — | — |
| 23 | Confidently delivered key data and seamlessly facilitated scientific exchange to meet the needs of the HCPs or PHDMs (CE, IO) | Skilled | — |
| 24 | Confidently addressed HCP’s or PHDM’s misunderstanding of J&J or competitor data, helping to overcome barriers and close knowledge gaps (IO, CL) | Skilled | — |
| 25 | Used role-aligned, approved scientific, resources (i.e., Slide Decks, One-Pagers, Infographics) aligned with MAF/SA strategy (i.e., Core Asset Themes), HCP or PHDM needs and identified field medical opportunities for Documented Interests (CE, ST) | Skilled | — |
| 26 | Navigate and Negotiate Needs of PINS, Impressions | — | — |
| 27 | Rate the overall quality of the Navigate and Negotiate Needs | Area of strength | — |
| 28 | Navigate and Negotiate Needs: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Radhika was focused on addressing identified needs and confident in her data delivery. She used appropriate resources to address HCP questions. HCP acknowledged what data was most meaningful to them and what level of outcome would be needed to truly be a differentiator for them.  This led to valuabl… |
| 29 | Navigate and Negotiate Needs: Training Needed? | No | — |
| 30 | Identify specific training needs and date for follow-up: | — | — |
| 31 | Secure Action of PINS:  Meeting Effectiveness & Follow-Up Actions | — | — |
| 32 | Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps (ST) | Skilled | — |
| 33 | Appropriate follow-up planned with internal partners (CC) | Skilled | — |
| 34 | Documentation of actionable insights (VoC) (DG) | Skilled | — |
| 35 | Appropriate documentation in CRM system (i.e, Veeva, iConnect) (DG) | Yes | — |
| 36 | Secure Action of PINS, Impressions | — | — |
| 37 | Rate the overall quality of the Secure Action | Area of strength | — |
| 38 | Secure Action: Comment on observations, specific examples, and coaching provided (N/A if not applicable): | — | Radhika was able to obtain future appointments with each KOL.  She learned the best way to contact each physician and what location was best.  She also obtained recommendations for APPs where appropriate.  She documented each interaction and I coached to the value of entering medical insights and wh… |
| 39 | Secure Action: Training Needed? | No | — |
| 40 | Identify specific training needs and date for follow-up: | — | — |
| 41 | During this field observation, did the FBMS engage in appropriate, non promotional scientific exchange consistent with their medical role, Company policies, and medical–commercial independence? | Yes | — |
| 42 | If you answered “No,” briefly describe the potential non compliance and any coaching or corrective actions taken. For suspected HCC policy concerns, escalate to your Health Care Compliance Officer per Company procedures. | — | — |

### PINS Coaching Narratives (Full Text)

**Planning for Perspective: 
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Radhika spent timing prior to ASCO reviewing each physician profile via H1.  She spoke to peers and partners to better understand the HCPs insights such as needs and interests.  She reviewed the previous iConnect entries for each physician and even reached out to the predecessor MSL for input, especially around the HCPs sentiment on our products.  She reviewed our resources in advance of ASCO and brought copies with her in preparation of the discussions occurring at the meeting. She was thorough in her preparation. She even created HCP profile slides to better help herself learn about each provider. I coached her on approved resources to support planned discussions.

**Investigate Issues:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Radhika asked appropriate probing questions to better understand the physicians views on the treatment landscape.  She probed to understand the HCPs sphere of influence within the context of the institution.  With Dr. Chaudry she was able to gain insight into each team member's area of specialty at DFCI.  Her probing led to Dr. Chaudry's ability to be specific in his area of interest and what data would be of most interest to him.  Coached  on additional ways to probe for insights from the physician and in one instance where a probing question might have been appropriate.

**Navigate and Negotiate Needs:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Radhika was focused on addressing identified needs and confident in her data delivery. She used appropriate resources to address HCP questions. HCP acknowledged what data was most meaningful to them and what level of outcome would be needed to truly be a differentiator for them.  This led to valuable insights that will help her in future engagements.

**Secure Action:
Comment on observations, specific examples, and coaching provided (N/A if not applicable):**

Radhika was able to obtain future appointments with each KOL.  She learned the best way to contact each physician and what location was best.  She also obtained recommendations for APPs where appropriate.  She documented each interaction and I coached to the value of entering medical insights and what a good medical insight looks like.


---

