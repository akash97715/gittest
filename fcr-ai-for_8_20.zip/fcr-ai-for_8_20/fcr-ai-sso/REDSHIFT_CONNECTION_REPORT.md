# Redshift Connectivity Test Report
**Date:** August 13, 2026  
**Service Account:** dmp_fcr_ai_development_prod_read  
**Database:** awprdrsdb (Amazon Redshift)

---

## Executive Summary

✓ **Connectivity:** SUCCESS - Service account can connect to Redshift  
✗ **Table Access:** FAILED - Insufficient permissions on ODP schema/table

### Current Status
The service account has **network connectivity** to Redshift but **lacks read permissions** on the required ODP table.

---

## Test Results

### Test 1: Network & Authentication ✓
- **Status:** PASSED
- **Details:** 
  - Successfully connected to Redshift cluster
  - Credentials are valid and account is not locked
  - Hostname, port, and SSL settings are correct

### Test 2: ODP Schema Access ✗
- **Status:** FAILED  
- **Issue:** ODP schema is NOT visible to the current user
- **Error:** The schema doesn't appear in `information_schema.schemata` query results
- **Cause:** User lacks `USAGE` permission on schema `odp`

### Test 3: ODP Table Access ✗
- **Status:** FAILED
- **Issue:** Cannot read `odp.dp_cust_pers_engagement_dly` table
- **Error Message:** `permission denied for relation dp_cust_pers_engagement_dly`
- **Cause:** User lacks `SELECT` permission on the table

### Test 4: Sample Queries ✗
- **Status:** SKIPPED (due to table access failure)
- All analytics queries blocked by permission error

---

## Root Cause Analysis

The service account `dmp_fcr_ai_development_prod_read` is missing the following permissions:

| Permission | Schema/Object | Status |
|---|---|---|
| USAGE | odp (schema) | ✗ MISSING |
| SELECT | odp.dp_cust_pers_engagement_dly | ✗ MISSING |
| SELECT | All tables in odp | ✗ MISSING |

---

## Required Actions

### Step 1: Contact Redshift Administrator

Provide them with this SQL to execute in Redshift (as superuser):

```sql
-- Grant schema usage
GRANT USAGE ON SCHEMA odp TO dmp_fcr_ai_development_prod_read;

-- Grant SELECT on all existing tables in odp schema
GRANT SELECT ON ALL TABLES IN SCHEMA odp TO dmp_fcr_ai_development_prod_read;

-- Grant SELECT on all future tables in odp schema
ALTER DEFAULT PRIVILEGES IN SCHEMA odp 
GRANT SELECT ON TABLES TO dmp_fcr_ai_development_prod_read;
```

### Step 2: Verify Permissions After Grant

Once the admin executes the above, re-run the test script to verify:

```bash
python test-redshift-access.py
```

### Step 3: Expected Results After Fix

Once permissions are granted, you should see:
- ✓ ODP schema visible
- ✓ Table is readable
- ✓ Row count displayed
- ✓ Sample queries execute successfully
- ✓ Analytics data retrieved

---

## Connection Details (For Reference)

| Parameter | Value |
|---|---|
| Host | itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com |
| Port | 5439 |
| Database | awprdrsdb |
| Service Account | dmp_fcr_ai_development_prod_read |
| Schema | odp |
| Table | dp_cust_pers_engagement_dly |
| SSL | Required (sslmode=require) |

---

## Next Steps

1. **Immediate:**
   - Share this report with your Redshift/AWS data team
   - Ask them to execute the GRANT statements above
   - Set a timeframe for permission updates

2. **Once Permissions Are Granted:**
   - Re-run `test-redshift-access.py` to verify
   - Start the FCR AI dashboard backend
   - Deploy to production

3. **Dashboard Features Depending on This Table:**
   - Dashboard KPI cards
   - FCR listing and filtering
   - Coaching history and trends
   - PINS framework analysis
   - AI-powered insights
   - Compliance reporting

---

## Test Scripts Location

- **Full Connectivity Test:** `test-redshift-connectivity.py`
- **Permissions Diagnostic:** `test-redshift-access.py`

Run either script anytime to verify Redshift connectivity status.

---

## Support Contact

For issues or questions:
- Check `.env` file has correct credentials
- Verify Redshift cluster is running
- Contact your Redshift admin for permission issues
- Review AWS security groups for port 5439 access

