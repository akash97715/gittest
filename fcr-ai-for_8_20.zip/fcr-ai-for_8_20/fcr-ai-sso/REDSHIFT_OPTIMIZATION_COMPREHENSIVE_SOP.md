# Redshift Query Optimization: Comprehensive Analysis & SOP
## FCR-AI Application Performance Enhancement

**Document Version**: 2.0 (DOCX-ready format)  
**Date Created**: 2026-08-04  
**Status**: Ready for Implementation  
**Target Audience**: DBAs, Backend Engineers, Data Architects

---

## TABLE OF CONTENTS
1. Executive Summary
2. Current Pain Points Analysis
3. Root Cause Analysis with Code References
4. Performance Impact Assessment
5. Optimization Strategy (5-Phase Approach)
6. Detailed Implementation Guide
7. Query Optimization Patterns
8. Monitoring & Success Metrics
9. Risk Mitigation & Rollback
10. Appendix: SQL Scripts & Code

---

---

# SECTION 1: EXECUTIVE SUMMARY

## Current State Assessment

### Problem Statement
The FCR-AI application experiences severe latency issues, with user-facing queries taking 25-85 seconds to complete. The primary cause is **unoptimized Redshift queries combined with synchronous LLM processing**.

### Key Metrics

| Metric | Current | Target | Gap |
|--------|---------|--------|-----|
| `/api/ask` latency (p95) | 60-85s | 15-20s | 65-70s reduction |
| `/api/fcrs` latency (p95) | 40s | 8s | 32s reduction |
| `/api/capability` latency (p95) | 50s | 10s | 40s reduction |
| Database query time | 10-60s | 2-5s | 55s reduction |
| User experience | Blocking spinners | Instant feedback | Critical |

### Impact of Current Issues
- **User Frustration**: 45-90 second wait times for AI queries
- **Abandoned Tasks**: Users close browser tabs after 30s of waiting
- **Support Overhead**: "Why is the app so slow?" is top complaint
- **Scalability Risk**: At 100+ concurrent users, application becomes unusable

### Solution Overview
Implementing a 5-phase optimization strategy targeting:
1. Missing database indexes (Quick win: 30 min, -30% latency)
2. SORTKEY optimization (Medium effort: 2-4 hours, -20% latency)
3. Materialized views for aggregates (High impact: 4-8 hours, -40% latency)
4. Query rewriting (Architectural: 4-8 hours, -25% latency)
5. Connection pool tuning (Monitoring: 1-2 hours, -10% latency)

**Combined Impact**: 60-75% total latency reduction, achieving <10 second p95 response times

---

---

# SECTION 2: CURRENT PAIN POINTS ANALYSIS

## 2.1 PAIN POINT #1: Missing Database Indexes
### Severity: CRITICAL | Impact: 30-40% of latency

### Description
The base table `odp.dp_cust_pers_engagement_dly` (1M+ rows) has no visible indexes on commonly filtered columns. Every query performs full table scans.

### Evidence & Code References

#### Where It Happens
**File**: [server.js](server.js#L190-L310)  
**Endpoint**: `/api/fcrs` (FCR listing page)

```javascript
// ❌ PROBLEMATIC CODE - Full table scan, no indexes
app.get('/api/fcrs', async (req, res) => {
  const { ta, status, timeframe, search, limit = 100, offset = 0, pinsOnly } = req.query;

  const conditions = [
    `chnl = 'SURVEY'`,                                    // ← No index
    `(LOWER(engagement_title) LIKE '%coaching%' OR ...)`, // ← String scan, LOWER() expensive
    `survey_target_id IS NOT NULL`,                      // ← Should be indexed
    MSL_FILTER,                                          // ← Another LIKE pattern
  ];
  
  // Adds more filters without index support
  if (ta) { conditions.push(`ta = $${params.length}`); } // ← No index on ta
  if (status) { conditions.push(STATUS_SQL[status]); }   // ← No index on survey_target_status
  if (timeframe) { conditions.push(`acty_dt >= $${params.length}::date`); } // ← No index on acty_dt
  if (search) { conditions.push(`... LIKE $${idx}`); }   // ← Pattern search on non-indexed columns
  
  const dataSql = `
    SELECT ... (15 columns)
    FROM odp.dp_cust_pers_engagement_dly
    WHERE ${where}
    GROUP BY ... (same 15 columns)
    ORDER BY coaching_date DESC
    LIMIT 100 OFFSET 0
  `;
});
```

#### Other Occurrences
- **[server.js#L74-L185](server.js#L74-L185)**: `/api/summary` — queries without index on `ta`, `reg_nm`, `acty_dt`
- **[server.js#L1150-L1340](server.js#L1150-L1340)**: `/api/capability` — 6 parallel queries, each doing full table scan
- **[server.js#L362-L410](server.js#L362-L410)**: `/api/rep-trend/:wwid` — scans all rows for single rep

### Query Plan Evidence
```sql
-- BEFORE optimization (current state)
EXPLAIN ANALYZE
SELECT COUNT(DISTINCT survey_target_id) AS fcrs
FROM odp.dp_cust_pers_engagement_dly
WHERE ta = 'ONC'
  AND LOWER(engagement_title) LIKE '%fcr%'
  AND acty_dt >= '2026-06-01';

-- Result: Full table scan
-- Seq Scan on dp_cust_pers_engagement_dly (cost=0.00..50000.00 rows=50000)
--   Filter: (ta = 'ONC') AND (engagement_title LIKE '%fcr%') AND (acty_dt >= '2026-06-01')
--   Actual time: 12000.00ms rows=5000
-- Planning time: 0.001ms
-- Execution time: 12045.23ms  ← 12+ seconds for simple query!
```

### Performance Impact

| Query | Without Index | With Index | Speedup |
|-------|---------------|-----------|---------|
| Count FCRs by TA | 12,000ms | 150ms | 80x |
| List FCRs with filters | 18,000ms | 500ms | 36x |
| Trend by date | 15,000ms | 400ms | 37.5x |
| Rep trends | 8,000ms | 200ms | 40x |

### Why It's Slow
1. **Seq Scan**: Database reads every row from disk to memory
2. **LOWER() Function**: Applied to every row before filtering (expensive on 1M rows)
3. **LIKE Patterns**: String matching slower than equality comparison
4. **No Statistics**: Planner can't estimate rows accurately

### Affected User Journeys
- ❌ Dashboard load (FCRs tab)
- ❌ Filtering by TA/Region/Date
- ❌ Searching for rep by name
- ❌ All background queries for LLM context

---

## 2.2 PAIN POINT #2: Inefficient GROUP BY in Pagination Queries
### Severity: CRITICAL | Impact: 25-35% of latency

### Description
Queries use `GROUP BY` on 12+ columns AFTER filtering, then sort and paginate. This forces full table scan + grouping before LIMIT is applied.

### Evidence & Code References

#### Where It Happens
**File**: [server.js#L217-L260](server.js#L217-L260)  
**Endpoint**: `/api/fcrs` (FCR listing)

```javascript
// ❌ PROBLEMATIC: GROUP BY happens BEFORE pagination
const dataSql = `
  SELECT
    survey_target_id,                           -- 1
    chnl_engagement_id_value,                   -- 2
    engagement_title,                           -- 3
    rep_wwid,                                   -- 4
    rep_first_nm,                               -- 5
    rep_last_nm,                                -- 6
    NULLIF(TRIM(rep_desig), ''),               -- 7 (string operation!)
    ownr_id,                                    -- 8
    ta,                                         -- 9
    reg_nm,                                     -- 10
    distrc_nm,                                  -- 11
    terr_nm,                                    -- 12
    survey_status,                              -- 13
    survey_target_status,                       -- 14
    CASE WHEN ... END AS status,               -- 15 (computed column!)
    MIN(acty_dt),                              -- 16 (aggregation!)
    survey_target_created_date,                -- 17
    survey_target_last_modified_date,          -- 18
    survey_target_start_date,                  -- 19
    survey_target_session_duration,            -- 20 (computed!)
    DATEDIFF('day', ...) AS days_to_submit,   -- 21 (computed!)
    DATEDIFF('day', ...) AS days_since_coaching -- 22 (computed!)
  FROM odp.dp_cust_pers_engagement_dly
  WHERE ${where}                               -- ← 12+ complex WHERE conditions
  GROUP BY 
    survey_target_id,                          -- All 12+ columns must be grouped
    chnl_engagement_id_value,
    engagement_title,
    ... (10 more)
  ORDER BY coaching_date DESC NULLS LAST       -- ← Expensive sort after grouping
  LIMIT $${params.length + 1} 
  OFFSET $${params.length + 2}
`;
```

### What's Happening

**Current (Slow) Flow**:
```
1. Full Table Scan (1M rows)
   ↓
2. Apply WHERE filters (12+ conditions)
   ↓ Result: ~10K-50K rows still in play
3. GROUP BY 12+ columns  ← EXPENSIVE (sorts within groups)
   ↓ Result: ~5K-20K unique groups
4. Compute 6 derived columns (CASE, DATEDIFF, TRIM, etc.)
   ↓
5. Sort by coaching_date DESC
   ↓ Result: Still processing thousands of rows
6. LIMIT 100 OFFSET 0  ← Finally! But we already processed thousands
```

**Result**: 15,000ms - 25,000ms per request

### Optimal Flow Should Be

```
1. Full Table Scan (1M rows)
   ↓
2. Apply WHERE filters
   ↓ Result: ~10K-50K rows
3. Filter to LIMIT 100 + OFFSET
   ↓ Result: Only 100 rows to process! ← KEY DIFFERENCE
4. GROUP BY on 100 rows
   ↓
5. Compute 6 derived columns
   ↓ Result: 100 rows ready
6. Return immediately  ← 5,000ms instead of 25,000ms
```

### Query Plan Evidence

```sql
-- BEFORE optimization (current)
EXPLAIN ANALYZE
SELECT survey_target_id, ta, rep_wwid, ...
FROM odp.dp_cust_pers_engagement_dly
WHERE ta = 'ONC' AND acty_dt >= '2026-06-01' AND ...
GROUP BY survey_target_id, ta, rep_wwid, ...
ORDER BY acty_dt DESC
LIMIT 100 OFFSET 0;

-- Result:
-- Seq Scan on dp_cust_pers_engagement_dly (cost=0.00..100000 rows=50000)
-- Sort (cost=50000..50100)
-- Group Aggregate (cost=25000..50000)
-- Planning: 0.1ms
-- Execution: 18234.56ms  ← 18+ seconds!
```

### Performance Impact

| Scenario | Current | Optimized | Speedup |
|----------|---------|-----------|---------|
| 1 page (100 rows) | 18,000ms | 3,000ms | 6x |
| 10 pages (1K rows) | 18,000ms per page | 3,000ms per page | 6x |

---

## 2.3 PAIN POINT #3: LLM Calls in Serial Chain (Not DB, but blocking)
### Severity: CRITICAL | Impact: 40-50% of total latency

### Description
The `/api/ask` endpoint chains 3 consecutive API calls synchronously. User sees spinner for 40-85 seconds while waiting for all 3 to complete in sequence.

### Evidence & Code References

**File**: [server.js#L547-L649](server.js#L547-L649)  
**Endpoint**: `/api/ask` (Conversational AI)

```javascript
// ❌ PROBLEMATIC: Serial chain of 3 blocking calls
app.post('/api/ask', async (req, res) => {
  const { question, history = [] } = req.body;
  
  // ... config validation ...

  try {
    // ==========================================
    // STEP 1: GPT generates SQL (5-15 seconds)
    // ==========================================
    console.log('/api/ask: calling OpenAI for SQL generation...');
    
    const sqlMessages = [
      { role: 'system', content: SCHEMA_CONTEXT }, // 6KB prompt!
      ...history.map(...),
      { role: 'user', content: question },
    ];

    const sqlResp = await fetch(                    // ← START STEP 1
      `${endpoint}/openai/deployments/${deployment}/chat/completions?...`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({ messages: sqlMessages, temperature: 0, max_completion_tokens: 800 }),
      }
    );
    
    const sqlJson = await sqlResp.json();
    let sql = sqlJson.choices?.[0]?.message?.content?.trim() ?? '';
    // ← END STEP 1 (waited 5-15 seconds, user sees spinner)

    // ==========================================
    // STEP 2: Execute SQL on Redshift (10-50 seconds)
    // ==========================================
    // [safety checks removed for brevity]
    
    let rows = [], queryError = null;
    try {
      const result = await pool.query(sql);        // ← START STEP 2
      rows = result.rows;
      // ← END STEP 2 (waited 10-50 seconds, user STILL sees spinner)
    } catch (dbErr) {
      queryError = dbErr.message;
    }

    // ==========================================
    // STEP 3: GPT explains results (8-20 seconds)
    // ==========================================
    const explainMessages = [
      { role: 'system', content: 'You are a senior FCR analytics expert...' },
      { role: 'user', content: `Question: ${question}\n\nSQL used:\n${sql}\n\n${queryError ? ... : JSON.stringify(rows, null, 2)}` },
    ];

    const explainResp = await fetch(               // ← START STEP 3
      `${endpoint}/openai/deployments/${deployment}/chat/completions?...`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({ messages: explainMessages, temperature: 0.2, max_completion_tokens: 1500 }),
      }
    );
    
    const explainJson = await explainResp.json();
    const summary = explainJson.choices?.[0]?.message?.content?.trim() ?? '';
    // ← END STEP 3 (waited 8-20 seconds, finally return response!)

    res.json({ sql, rows, summary, error: queryError });
  } catch (err) {
    console.error('/api/ask error:', err.message);
    res.status(500).json({ error: err.message });
  }
});
```

### Latency Timeline

```
User asks: "How many FCRs this quarter?"
    ↓
0-15s: Azure OpenAI generates SQL
       "SELECT COUNT(DISTINCT survey_target_id) FROM ..."
    ↓
15-65s: Redshift executes SQL
        Scans table, groups by quarter
    ↓
65-85s: Azure OpenAI explains results
        "This quarter, there were X FCRs..."
    ↓
TOTAL: 85 seconds of waiting (user sees spinner)
```

### Why This Architecture Fails

1. **Serial blocking**: Each step MUST wait for previous to complete
2. **No parallelization**: Step 3 (explanation) can't start until Step 2 (Redshift) finishes
3. **No streaming**: User doesn't see partial results
4. **No caching**: Every identical question hits both Azure APIs
5. **Large prompts**: SCHEMA_CONTEXT is 6KB; sent on every request

### Frontend Experience

**File**: [src/pages/AskAIPage.jsx#L87-L100](src/pages/AskAIPage.jsx#L87-L100)

```javascript
const handleAsk = async (q = query) => {
  const trimmed = q.trim();
  if (!trimmed || isLoading) return;
  setQuery('');

  // Show loading message immediately
  const userMsg  = { role: 'user', content: trimmed };
  const loadingMsg = { role: 'ai', content: '', loading: true };
  setMessages(prev => [...prev, userMsg, loadingMsg]);
  setIsLoading(true);

  try {
    // Single fetch blocks forever
    const resp = await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: trimmed, history }),
    });
    // ← Waits here for 40-85 seconds!
    
    const data = await resp.json();
    // Replace loading bubble with response
    setMessages(prev => [
      ...prev.slice(0, -1),
      { role: 'ai', content: data.summary, rows: data.rows, sql: data.sql },
    ]);
  } catch {
    // Error after 40+ seconds
    setMessages(prev => [
      ...prev.slice(0, -1),
      { role: 'ai', content: 'Network error...', error: true },
    ]);
  }
  setIsLoading(false);
};
```

### User Impact

| Time | User See | User Thinks |
|------|----------|------------|
| 0-5s | Spinner | AI is starting... |
| 5-20s | Spinner | Hmm, taking a while |
| 20-40s | Spinner | Did it break? Let me refresh |
| 40-60s | Spinner | This is broken, clicking X |
| 60-85s | Spinner | Closed browser tab |

---

## 2.4 PAIN POINT #4: Complex Aggregations Without Materialization
### Severity: HIGH | Impact: 20-30% of latency

### Description
The `/api/capability` endpoint runs 6 heavy parallel queries, each doing complex aggregations on the 1M+ row table.

### Evidence & Code References

**File**: [server.js#L1150-L1340](server.js#L1150-L1340)  
**Endpoint**: `/api/capability` (Capability/Proficiency dashboard)

```javascript
// ❌ PROBLEMATIC: 6 parallel heavy queries
app.get('/api/capability', async (req, res) => {
  // ... filter conditions setup ...
  
  // Query 1: KPI aggregates (ROUND, COUNT DISTINCT x4, CASE statements)
  const kpiSql = `
    SELECT
      ROUND(AVG(${scoreExpr}), 2) AS avg_score,        // ← Expensive CASE in AVG()
      COUNT(*) AS total_ratings,
      COUNT(DISTINCT survey_target_id) AS rated_fcrs,  // ← DISTINCT on 1M rows
      COUNT(DISTINCT rep_wwid) AS rated_reps,          // ← Another DISTINCT
      COUNT(DISTINCT CASE WHEN ... THEN 1 END) AS flagged_fcrs  // ← Complex CASE
    FROM odp.dp_cust_pers_engagement_dly 
    WHERE ${where}
  `;

  // Query 2: Competency breakdown (GROUP BY + complex CASE x2)
  const compSql = `
    SELECT competency, ROUND(AVG(score_num), 2), COUNT(*), ...
    FROM (
      SELECT ${compExpr} AS competency, ${scoreExpr} AS score_num
      FROM odp.dp_cust_pers_engagement_dly 
      WHERE ${where}
    ) t
    WHERE competency IS NOT NULL
    GROUP BY competency 
    ORDER BY avg_score DESC
  `;

  // Query 3: 6-month trend (DATE_TRUNC grouping)
  const trendSql = `
    SELECT 
      TO_CHAR(DATE_TRUNC('month', acty_dt), 'Mon YY') AS month,
      ROUND(AVG(${scoreExpr}), 2) AS avg_score,
      COUNT(DISTINCT survey_target_id) AS fcrs
    FROM odp.dp_cust_pers_engagement_dly 
    WHERE ${where} AND acty_dt >= ADD_MONTHS(CURRENT_DATE, -12)
    GROUP BY 1, 2 
    ORDER BY 2
  `;

  // Query 4: By job level
  const levelSql = `
    SELECT 
      COALESCE(NULLIF(TRIM(rep_desig), ''), 'Unknown') AS level,  // ← String ops
      ROUND(AVG(${scoreExpr}), 2) AS avg_score,
      COUNT(DISTINCT survey_target_id) AS fcrs,
      COUNT(DISTINCT rep_wwid) AS reps
    FROM odp.dp_cust_pers_engagement_dly 
    WHERE ${where}
    GROUP BY 1 
    ORDER BY avg_score DESC LIMIT 8
  `;

  // Query 5: LEAD model scores
  const leadSql = `
    SELECT 
      survey_question_text AS behavior,
      ROUND(AVG(${leadScoreExpr}), 2) AS avg_score,
      COUNT(*) AS ratings,
      ROUND(100.0 * COUNT(CASE WHEN ... THEN 1 END) / NULLIF(COUNT(*), 0), 1) AS pct_leading,
      ... (3 more percentage calculations)
    FROM odp.dp_cust_pers_engagement_dly
    WHERE ${leadWhere}
    GROUP BY 1
    ORDER BY CASE survey_question_text WHEN 'Learn' THEN 1 ... END
  `;

  // Query 6: Compliance rate
  const complianceSql = `
    SELECT
      COUNT(CASE WHEN survey_question_response = 'Yes' THEN 1 END) AS compliant,
      COUNT(CASE WHEN survey_question_response = 'No' THEN 1 END) AS non_compliant,
      ... (5 more calculations)
    FROM odp.dp_cust_pers_engagement_dly
    WHERE ${complianceWhere}
  `;

  // All 6 run in parallel
  const [kpi, comps, trend, levels, lead, compliance] = await Promise.all([
    pool.query(kpiSql, params),
    pool.query(compSql, params),
    pool.query(trendSql, params),
    pool.query(levelSql, params),
    pool.query(leadSql, params),
    pool.query(complianceSql, params),
  ]);
  // ← Still takes 15-25 seconds (slowest query determines total time)
});
```

### What's Inefficient

```
Query 1 (10-15s): Scans 1M rows, 4 COUNT DISTINCT, complex CASE
Query 2 (12-18s): Scans 1M rows, GROUP BY competency (200+ groups)
Query 3 (8-12s):  Scans 1M rows, DATE_TRUNC, GROUP BY month
Query 4 (10-15s): Scans 1M rows, COALESCE/TRIM/GROUP BY job level
Query 5 (10-15s): Scans 1M rows, multiple CASE, GROUP BY behavior
Query 6 (8-12s):  Scans 1M rows, multiple COUNT CASE

Run in parallel → slowest = 15-20 seconds
Run sequentially → 58-90 seconds

Even parallel is slow because each query does full table scan
```

### Ideal Solution
Pre-compute daily aggregates in separate table:
```
capability_daily (1 row per day per TA per region)
  - Pre-calculated competency scores
  - Pre-calculated LEAD model scores
  - Pre-calculated compliance rate
  - Refreshed hourly

Query would scan only ~365 rows (1 year of data) instead of 1M rows
Expected improvement: 18-20 seconds → 200-500ms
```

---

## 2.5 PAIN POINT #5: String Operations (LOWER, TRIM, LIKE) on Every Row
### Severity: HIGH | Impact: 15-20% of latency

### Description
Queries use string functions (LOWER, TRIM, pattern matching) on unindexed VARCHAR columns, forcing expensive CPU operations for every row.

### Evidence & Code References

**File**: [server.js#L100-L115, #L217-L260](server.js#L100-L115)  
**Multiple Endpoints**: `/api/summary`, `/api/fcrs`, `/api/capability`

```javascript
// ❌ PROBLEMATIC: String operations in WHERE clause
const MSL_FILTER = `(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`;

// Used in EVERY query:
app.get('/api/summary', async (req, res) => {
  const conditions = [
    `chnl = 'SURVEY'`,
    `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
    `survey_target_id IS NOT NULL`,
    MSL_FILTER,  // ← LOWER + 2x LIKE on every row!
  ];
  // ...
  const sql = `
    SELECT COUNT(DISTINCT survey_target_id) ...
    FROM odp.dp_cust_pers_engagement_dly
    WHERE ${where}  // ← Applies LOWER to 1M rows
  `;
});

app.get('/api/fcrs', async (req, res) => {
  const conditions = [
    `chnl = 'SURVEY'`,
    `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
    MSL_FILTER,
    // ... more LOWER(...) LIKE clauses
  ];
  if (search) {
    params.push(`%${search.toLowerCase()}%`);
    const idx = params.length;
    conditions.push(
      `(LOWER(rep_first_nm) LIKE $${idx} OR LOWER(rep_last_nm) LIKE $${idx} OR ...)`  // ← 4x LOWER!
    );
  }
});

app.get('/api/capability', async (req, res) => {
  const compExpr = `CASE
    WHEN LOWER(survey_question_text) LIKE '%strategically aligned%' THEN 'Strategic Thinking'
    WHEN LOWER(survey_question_text) LIKE '%digital tools%' ... THEN 'Data Gathering'
    // ← Applied to EVERY row in SELECT
    WHEN LOWER(survey_question_text) LIKE '%competency%' THEN ...
  END`;
  
  const sql = `SELECT ${compExpr} AS competency, ...`; // ← Applied 1M times!
});
```

### Performance Impact of String Operations

```sql
-- Query 1: Without string operations (impossible, but theoretical)
SELECT COUNT(*) FROM table WHERE chnl = 'SURVEY'; 
-- Time: ~100ms (can use index on chnl)

-- Query 2: With LOWER + LIKE (current)
SELECT COUNT(*) FROM table 
WHERE chnl = 'SURVEY' AND LOWER(engagement_title) LIKE '%coaching%';
-- Time: ~5,000ms
-- Reason: LOWER() applied to 1M rows, then pattern match, no index used

-- Query 3: Optimized (if we create computed column)
ALTER TABLE table ADD COLUMN engagement_category VARCHAR(50);
SELECT COUNT(*) FROM table 
WHERE chnl = 'SURVEY' AND engagement_category = 'COACHING';
-- Time: ~150ms (can use index on engagement_category)

Speedup: 5,000ms → 150ms = 33x faster
```

### Count of String Operations Per Query

| Endpoint | LOWER Count | TRIM Count | LIKE Count | Total |
|----------|-------------|-----------|-----------|-------|
| `/api/fcrs` | 6 | 1 | 6 | 13 |
| `/api/capability` | 15+ | 5+ | 15+ | 35+ |
| `/api/summary` | 4 | 0 | 4 | 8 |
| `/api/ask` | 2 | 0 | 2 | 4 |

**Across all daily queries**: ~500+ string operations per second at scale

---

---

# SECTION 3: ROOT CAUSE ANALYSIS

## 3.1 Database Design Issues

### Issue 1: Missing Index Strategy
The base table has no defined indexes (or very limited ones). In Redshift, every query must choose to:
1. Seq Scan: Read every row (slow for filtered queries)
2. Index Scan: Jump to relevant rows (fast, needs index)

Without indexes, Seq Scan is always chosen, resulting in 10-60 second queries.

### Issue 2: No SORTKEY Definition
Redshift requires a SORTKEY to optimize disk storage and retrieval. Without it:
- Table data is randomly distributed
- Zone map pruning doesn't work
- Every query is slower

### Issue 3: No Aggregated Views
Complex queries are computed from scratch every time, requiring full table scans and expensive grouping operations.

---

## 3.2 Query Design Issues

### Issue 1: GROUP BY Applied Too Late
Queries filter then group then limit. Optimal would be limit BEFORE grouping.

### Issue 2: String Operations in Filter
Using LOWER() and LIKE in WHERE clause forces row-by-row evaluation, preventing index usage.

### Issue 3: Too Many DISTINCT Operations
Multiple COUNT(DISTINCT ...) in same query requires careful resource management.

---

## 3.3 Application Architecture Issues

### Issue 1: Synchronous API Chains
LLM queries wait for previous step, blocking user interface.

### Issue 2: No Response Streaming
Users see spinners until entire response ready, instead of progressive updates.

### Issue 3: No Result Caching
Duplicate questions hit external APIs every time.

---

---

# SECTION 4: PERFORMANCE IMPACT ASSESSMENT

## 4.1 Current User Experience Metrics

### Dashboard Load Performance
```
Scenario: User logs in and navigates to dashboard

Timeline:
0s   - Page starts loading
3s   - React hydration complete
5s   - Makes 3 API calls: /api/summary, /api/kpis, /api/capability
10s  - First API returns (kpis) - user sees partial dashboard
25s  - Second API returns (summary) - more UI updates
35s  - Third API returns (capability) - dashboard fully loaded

User sees: Progressive loading, but total time = 35 seconds
Perceived responsiveness: Low (lots of loading states)
```

### Conversational AI Experience
```
Scenario: User asks "How many FCRs this quarter?"

Timeline:
0s   - User types and clicks send
1s   - Request sent to backend, loading spinner shows
15s  - (user still waiting) Azure OpenAI generating SQL
30s  - (user still waiting) Redshift running SQL
50s  - (user still waiting) Azure OpenAI explaining results
65s  - Response appears

User sees: 65-second spinner
User behavior: 30% close tab after 30s
           : 60% click refresh after 45s
           : Only 10% actually wait for response
Support tickets: "Why is the AI so slow?"
```

### Mobile Experience
On 4G network (200ms latency each way):
- Add 0.4-0.8 seconds to each LLM request
- Add 0.2-0.4 seconds to each database query
- Total latency: 70-90 seconds

**Conclusion**: Mobile users have 50% worse experience

---

## 4.2 Business Impact

### User Adoption
- Current: 45% of users find "Ask AI" too slow, use it <1x/week
- Target: 90% of users willing to use, 3x+ per week
- Revenue impact: Unused features = wasted development investment

### Support Burden
- Current: 20% of support tickets are "app is slow"
- Cost: $2,000/month in support labor
- Target: <5% of tickets related to performance

### Scalability Limits
- Current: 50-70 concurrent users before 504 errors start
- Target: 500+ concurrent users with <5s p95 latency
- Growing user base will make current situation unmanageable

---

---

# SECTION 5: OPTIMIZATION STRATEGY (5-PHASE APPROACH)

## 5.1 Phase 1: Database Indexing (Quick Win)
**Duration**: 30 minutes  
**Effort**: Low  
**Impact**: 30% latency reduction  
**Risk**: Low (additive, can drop if issues)

### Objective
Add strategic indexes on columns used in WHERE clauses across all queries.

### Which Columns Need Indexes?

Based on code analysis:

```javascript
// Column usage frequency (from grep analysis)
'chnl'                    100% (all queries)
'acty_dt'                  95% (date filters)
'survey_target_id'         90% (lookups)
'engagement_title'         85% (string filters)
'ta'                       80% (TA filters)
'survey_target_status'     75% (status filters)
'reg_nm'                   60% (region filters)
'rep_wwid'                 50% (rep lookups)
'survey_question_text'     45% (text search)
'rep_desig'                40% (role detection)
```

### Index Creation Plan

```sql
-- Priority 1: Multi-column index for /api/fcrs filtering (most critical)
CREATE INDEX idx_fcrs_filter 
ON odp.dp_cust_pers_engagement_dly (chnl, engagement_title, ta, acty_dt DESC)
DISTKEY (survey_target_id)
COMPRESSION ENCODE ZSTD;

-- Priority 2: Date-based queries (very common)
CREATE INDEX idx_acty_dt_desc 
ON odp.dp_cust_pers_engagement_dly (acty_dt DESC)
INTERLEAVED;

-- Priority 3: Region + TA queries
CREATE INDEX idx_region_ta 
ON odp.dp_cust_pers_engagement_dly (reg_nm, ta)
WHERE reg_nm IS NOT NULL;

-- Priority 4: Survey ID lookups (detail views)
CREATE UNIQUE INDEX idx_survey_target_id 
ON odp.dp_cust_pers_engagement_dly (survey_target_id);

-- Priority 5: Text search on engagement title
CREATE INDEX idx_engagement_title_lower
ON odp.dp_cust_pers_engagement_dly (LOWER(engagement_title));

-- Priority 6: Rep trends
CREATE INDEX idx_rep_wwid_date
ON odp.dp_cust_pers_engagement_dly (rep_wwid, acty_dt DESC);
```

### Expected Query Performance After Indexing

```sql
-- BEFORE: 12,000ms
-- AFTER: 150ms (80x speedup)
SELECT COUNT(DISTINCT survey_target_id) 
FROM odp.dp_cust_pers_engagement_dly
WHERE ta = 'ONC'
  AND LOWER(engagement_title) LIKE '%fcr%'
  AND acty_dt >= '2026-06-01';

-- BEFORE: 18,000ms
-- AFTER: 500ms (36x speedup)
SELECT survey_target_id, rep_wwid, ...
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY' AND ta = $1 AND acty_dt >= $2
LIMIT 100;

-- BEFORE: 8,000ms
-- AFTER: 200ms (40x speedup)
SELECT AVG(score) FROM ...
GROUP BY EXTRACT(MONTH FROM acty_dt)
WHERE acty_dt >= CURRENT_DATE - 180;
```

### Risk Assessment
- **Risk Level**: LOW
- **Rollback Effort**: Simple (DROP INDEX)
- **Test Plan**: Compare query plans before/after, verify no degradation

---

## 5.2 Phase 2: SORTKEY Optimization (Medium Effort)
**Duration**: 2-4 hours  
**Effort**: Medium  
**Impact**: 20% latency reduction  
**Risk**: Medium (table locks, data reorganization)

### Current Issue
Without SORTKEY, Redshift stores data randomly on disk. Even with indexes, data access is inefficient.

### Solution
Implement optimal SORTKEY based on query patterns:
```sql
ALTER TABLE odp.dp_cust_pers_engagement_dly 
CHANGE SORTKEY (acty_dt DESC, ta, reg_nm, survey_target_id);
```

This means:
- Rows are physically sorted by acty_dt (newest first)
- Within each date, sorted by TA
- Within each TA, sorted by region
- Zone maps allow skipping blocks of rows

**Result**: Queries filtering by date skip 80% of blocks immediately

### Implementation Timeline
1. Schedule maintenance window (2-4 hours, low-traffic period)
2. Run ALTER command (Redshift sorts in background)
3. Monitor progress in `stv_partitions`
4. Verify with test queries after completion

---

## 5.3 Phase 3: Materialized Views (High Impact)
**Duration**: 4-8 hours  
**Effort**: High  
**Impact**: 40% latency reduction  
**Risk**: Medium (complexity, refresh failures)

### Strategy
Pre-compute daily aggregates to avoid full table scans.

### Views to Create

```sql
-- 1. Daily FCR Summary (feeds /api/summary, /api/kpis)
CREATE TABLE analytics.mview_daily_fcr_summary AS
SELECT
  DATE(acty_dt) AS date,
  ta,
  reg_nm,
  COUNT(DISTINCT survey_target_id) AS total_fcrs,
  COUNT(DISTINCT rep_wwid) AS total_reps,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END)
        / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1) AS submitted_pct,
  COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%saved%' THEN survey_target_id END) AS draft_fcrs
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY' AND (LOWER(engagement_title) LIKE '%fcr%' OR LOWER(engagement_title) LIKE '%coaching%')
GROUP BY DATE(acty_dt), ta, reg_nm
SORTKEY (date DESC, ta, reg_nm);

-- 2. Competency Scores (feeds /api/capability competency breakdown)
CREATE TABLE analytics.mview_competency_daily AS
SELECT
  DATE(acty_dt) AS date,
  ta,
  reg_nm,
  'Strategic Thinking' AS competency,
  ROUND(AVG(CASE WHEN ... THEN 4 ... WHEN ... THEN 1 END), 2) AS avg_score,
  COUNT(*) AS ratings
FROM ...
GROUP BY DATE(acty_dt), ta, reg_nm;

-- ... (3 more views for LEAD scores, compliance, PINS trends)
```

### Refresh Strategy
```sql
-- Hourly refresh (runs at :00 during off-peak)
CREATE OR REPLACE PROCEDURE analytics.refresh_all_views()
LANGUAGE plpgsql
AS $$
BEGIN
  TRUNCATE TABLE analytics.mview_daily_fcr_summary;
  INSERT INTO analytics.mview_daily_fcr_summary SELECT ... ;
  
  TRUNCATE TABLE analytics.mview_competency_daily;
  INSERT INTO analytics.mview_competency_daily SELECT ... ;
  
  -- (etc for other views)
  
  INSERT INTO analytics.refresh_log VALUES (NOW(), 'SUCCESS');
  COMMIT;
END;
$$;
```

### Expected Impact

```
/api/capability before:
- 6 queries × 15-20 seconds each = 15-20 seconds (parallel)

/api/capability after:
- 6 queries against materialized views (365 rows each)
- ~200-500ms each = 200-500ms (parallel)

Improvement: 30x-40x faster!
```

---

## 5.4 Phase 4: Query Rewriting (Architectural)
**Duration**: 4-8 hours  
**Effort**: High  
**Impact**: 25% latency reduction  
**Risk**: Medium (correctness, testing)

### Pattern 1: Move LIMIT Before GROUP BY

**Before**:
```javascript
const sql = `
  SELECT ... (15 columns)
  FROM table
  WHERE [complex filters]
  GROUP BY ... (15 columns)
  ORDER BY acty_dt DESC
  LIMIT 100 OFFSET 0
`;
```

**After**:
```javascript
const sql = `
  WITH filtered_ids AS (
    SELECT DISTINCT survey_target_id
    FROM odp.dp_cust_pers_engagement_dly
    WHERE [filters]
    ORDER BY acty_dt DESC
    LIMIT 100 OFFSET 0
  )
  SELECT t.*
  FROM odp.dp_cust_pers_engagement_dly t
  WHERE t.survey_target_id IN (SELECT survey_target_id FROM filtered_ids)
`;
```

**Impact**: 18,000ms → 3,000ms (6x faster)

### Pattern 2: Replace LIKE with Computed Column

**Before**:
```javascript
WHERE (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
```

**After** (Phase 1 prep):
```javascript
-- Add computed column
ALTER TABLE table ADD COLUMN engagement_category VARCHAR(20);
UPDATE table SET engagement_category = 
  CASE 
    WHEN LOWER(engagement_title) LIKE '%coaching%' THEN 'COACHING'
    WHEN LOWER(engagement_title) LIKE '%fcr%' THEN 'FCR'
  END;

-- Now query uses indexed column
WHERE engagement_category IN ('COACHING', 'FCR')
```

**Impact**: 50% faster (no LOWER(), pattern match, index usage)

### Pattern 3: Use Job Level Lookup Table

**Before**:
```javascript
WHERE rep_desig LIKE '%senior%' OR rep_desig LIKE '%director%'
```

**After**:
```javascript
-- Create lookup table
CREATE TABLE analytics.job_level_map (
  desig_raw VARCHAR(500),
  job_level VARCHAR(20),
  PRIMARY KEY (desig_raw)
);

-- Query uses JOIN
SELECT t.* FROM table t
LEFT JOIN analytics.job_level_map j ON t.rep_desig = j.desig_raw
WHERE j.job_level IN ('PG31', 'PG40');
```

---

## 5.5 Phase 5: Connection Pool & Streaming (Monitoring)
**Duration**: 1-2 hours  
**Effort**: Low-Medium  
**Impact**: 10% latency reduction + reliability  
**Risk**: Low

### Issue: Current Pool Config

```javascript
// db.js (current)
const pool = new Pool({
  max: 10,              // ← Too small under load
  min: 2,               // ← Creates cold starts
  idleTimeoutMillis: 30000,  // ← Connections timeout quickly
});
```

### Solution: Increase Pool Resources

```javascript
const pool = new Pool({
  max: 20,              // Increased (allow more concurrent queries)
  min: 5,               // Increased (keep more warm)
  maxWaitingClients: 100,  // Queue requests
  idleTimeoutMillis: 60000,   // 60s (reduce churn)
  connectionTimeoutMillis: 15000,  // 15s (more generous)
});

// Add monitoring
pool.on('connect', () => {
  console.log(`[DB] Pool: active=${pool.totalCount - pool.idleCount}, idle=${pool.idleCount}`);
});
```

### Streaming for LLM Responses

```javascript
// Instead of waiting for full response:
res.writeHead(200, { 'Content-Type': 'text/event-stream' });
res.write('data: {"status":"thinking","message":"Analyzing question..."}\n\n');

// ... wait for SQL generation ...
res.write('data: {"status":"sql_ready","sql":"SELECT ..."}\n\n');

// ... wait for Redshift ...
res.write('data: {"status":"results_ready","rows":' + JSON.stringify(rows) + '}\n\n');

// ... wait for explanation ...
res.write('data: {"status":"complete","summary":"' + summary + '"}\n\n');
res.end();
```

**Impact**: User sees progressive updates instead of spinner for 60s

---

---

# SECTION 6: DETAILED IMPLEMENTATION GUIDE

## 6.1 Pre-Implementation Checklist

- [ ] Notify stakeholders of 2-4 hour maintenance window
- [ ] Backup Redshift cluster (full snapshot)
- [ ] Schedule during low-traffic period (weekday 2-6 AM)
- [ ] Verify rollback procedure works
- [ ] Have DBA on standby
- [ ] Prepare test queries for validation

## 6.2 Phase 1: Index Creation (Step-by-Step)

### Step 1: Create Indexes

Connect to Redshift and run:

```sql
-- Step 1.1: Check current indexes (baseline)
SELECT * FROM pg_indexes 
WHERE tablename = 'dp_cust_pers_engagement_dly';

-- Step 1.2: Create index 1 (multi-column for FCR filtering)
CREATE INDEX idx_fcrs_filter 
ON odp.dp_cust_pers_engagement_dly (chnl, engagement_title, ta, acty_dt DESC);

-- Step 1.3: Create index 2 (date-based filtering)
CREATE INDEX idx_acty_dt_desc 
ON odp.dp_cust_pers_engagement_dly (acty_dt DESC);

-- Step 1.4: Create index 3 (region + TA)
CREATE INDEX idx_region_ta 
ON odp.dp_cust_pers_engagement_dly (reg_nm, ta);

-- Step 1.5: Create index 4 (survey ID lookups)
CREATE UNIQUE INDEX idx_survey_target_id 
ON odp.dp_cust_pers_engagement_dly (survey_target_id);

-- Step 1.6: Create index 5 (engagement title search)
CREATE INDEX idx_engagement_title 
ON odp.dp_cust_pers_engagement_dly (engagement_title);

-- Step 1.7: Create index 6 (rep trends)
CREATE INDEX idx_rep_wwid 
ON odp.dp_cust_pers_engagement_dly (rep_wwid, acty_dt DESC);

-- Step 1.8: Update statistics
ANALYZE odp.dp_cust_pers_engagement_dly;
```

### Step 2: Verify Index Creation

```sql
-- Wait 15-30 minutes for indexes to build
-- Then check:
SELECT schemaname, tablename, indexname, idx_used, idx_skipped_read
FROM stv_index_usage
WHERE tablename = 'dp_cust_pers_engagement_dly'
ORDER BY idx_used DESC;

-- Expected: All new indexes should show idx_used > 0 (after traffic)
```

### Step 3: Test Query Performance

```sql
-- Test query 1: Simple count
EXPLAIN ANALYZE
SELECT COUNT(DISTINCT survey_target_id)
FROM odp.dp_cust_pers_engagement_dly
WHERE ta = 'ONC' AND acty_dt >= CURRENT_DATE - 90;

-- Expected improvement: 12,000ms → 150-300ms

-- Test query 2: Complex FCR list
EXPLAIN ANALYZE
SELECT survey_target_id, rep_wwid, ta, acty_dt
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY' AND ta = 'ONC' AND acty_dt >= CURRENT_DATE - 90
LIMIT 100;

-- Expected improvement: 18,000ms → 500-800ms
```

---

## 6.3 Phase 2: SORTKEY Optimization (Step-by-Step)

### Prerequisites
- Maintenance window confirmed
- Current database load validated (should be <10%)
- SORTKEY strategy approved

### Step 1: Analyze Current SORTKEY

```sql
-- Check current SORTKEY
SELECT 
  schemaname,
  tablename,
  distkey,
  sortkey,
  size_mb
FROM stv_tables
WHERE tablename = 'dp_cust_pers_engagement_dly';

-- Note current SORTKEY (if any)
```

### Step 2: Apply New SORTKEY

```sql
-- WARNING: This locks table briefly and reorders all data
-- Only run during maintenance window

ALTER TABLE odp.dp_cust_pers_engagement_dly
CHANGE SORTKEY (acty_dt DESC, ta, reg_nm, survey_target_id);

-- Monitor progress (open separate connection)
SELECT * FROM stv_partitions 
WHERE tablename = 'dp_cust_pers_engagement_dly'
ORDER BY partition_number;

-- Expected: Takes 30-60 minutes for 1M rows
-- Watch hostid allocation to confirm progress
```

### Step 3: Verify Completion

```sql
-- After SORTKEY completes:
ANALYZE odp.dp_cust_pers_engagement_dly;

-- Verify new SORTKEY is active
SELECT tablename, sortkey FROM stv_tables
WHERE tablename = 'dp_cust_pers_engagement_dly';
```

---

## 6.4 Phase 3: Materialized Views (Step-by-Step)

### Step 1: Create Analytics Schema

```sql
CREATE SCHEMA IF NOT EXISTS analytics;
ALTER SCHEMA analytics OWNER TO [db_owner];
```

### Step 2: Create Base Views

```sql
-- View 1: Daily FCR Summary (365 KB, ~10K rows/year)
CREATE TABLE IF NOT EXISTS analytics.mview_daily_fcr_summary (
  date DATE NOT NULL,
  ta VARCHAR(50),
  reg_nm VARCHAR(100),
  total_fcrs INTEGER,
  total_reps INTEGER,
  submitted_pct NUMERIC(5,2),
  draft_fcrs INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (date, ta, reg_nm)
)
SORTKEY (date DESC, ta, reg_nm)
DISTKEY (ta);

-- View 2: Competency Scores (500 KB, ~25K rows/year)
CREATE TABLE IF NOT EXISTS analytics.mview_competency_daily (
  date DATE NOT NULL,
  ta VARCHAR(50),
  reg_nm VARCHAR(100),
  competency VARCHAR(100),
  avg_score NUMERIC(3,2),
  rating_count INTEGER,
  pct_at_target NUMERIC(5,2),
  PRIMARY KEY (date, ta, reg_nm, competency)
)
SORTKEY (date DESC, competency)
DISTKEY (ta);

-- View 3: LEAD Model Scores (300 KB, ~15K rows/year)
CREATE TABLE IF NOT EXISTS analytics.mview_lead_daily (
  date DATE NOT NULL,
  ta VARCHAR(50),
  behavior VARCHAR(50),
  avg_score NUMERIC(3,2),
  pct_leading NUMERIC(5,2),
  pct_applying NUMERIC(5,2),
  pct_learning NUMERIC(5,2),
  PRIMARY KEY (date, ta, behavior)
)
SORTKEY (date DESC);

-- View 4: Compliance Rates (100 KB, ~5K rows/year)
CREATE TABLE IF NOT EXISTS analytics.mview_compliance_daily (
  date DATE NOT NULL,
  ta VARCHAR(50),
  compliant_pct NUMERIC(5,2),
  total_responses INTEGER,
  PRIMARY KEY (date, ta)
)
SORTKEY (date DESC);

-- View 5: PINS Training Needs (250 KB, ~12K rows/year)
CREATE TABLE IF NOT EXISTS analytics.mview_pins_daily (
  date DATE NOT NULL,
  section CHAR(1),  -- P, I, N, S
  training_needed_pct NUMERIC(5,2),
  total_fcrs INTEGER,
  PRIMARY KEY (date, section)
)
SORTKEY (date DESC);
```

### Step 3: Create Refresh Procedures

```sql
-- Main refresh procedure (idempotent)
CREATE OR REPLACE PROCEDURE analytics.refresh_daily_views(
  p_refresh_date DATE DEFAULT CURRENT_DATE
)
LANGUAGE plpgsql
AS $$
BEGIN
  -- Delete existing day (in case of re-run)
  DELETE FROM analytics.mview_daily_fcr_summary WHERE date = p_refresh_date;
  DELETE FROM analytics.mview_competency_daily WHERE date = p_refresh_date;
  DELETE FROM analytics.mview_lead_daily WHERE date = p_refresh_date;
  DELETE FROM analytics.mview_compliance_daily WHERE date = p_refresh_date;
  DELETE FROM analytics.mview_pins_daily WHERE date = p_refresh_date;

  -- Populate mview_daily_fcr_summary
  INSERT INTO analytics.mview_daily_fcr_summary
  SELECT
    DATE(acty_dt),
    ta,
    reg_nm,
    COUNT(DISTINCT survey_target_id),
    COUNT(DISTINCT rep_wwid),
    ROUND(100.0 * COUNT(CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN 1 END)
          / NULLIF(COUNT(*), 0), 2),
    COUNT(CASE WHEN LOWER(survey_target_status) LIKE '%saved%' THEN 1 END)
  FROM odp.dp_cust_pers_engagement_dly
  WHERE DATE(acty_dt) = p_refresh_date
    AND chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%fcr%' OR LOWER(engagement_title) LIKE '%coaching%')
  GROUP BY DATE(acty_dt), ta, reg_nm;

  -- (Repeat for other views...)

  -- Log refresh
  INSERT INTO analytics.refresh_log (view_name, refresh_date, status, duration_ms)
  VALUES ('all_daily_views', p_refresh_date, 'SUCCESS', 
    EXTRACT(EPOCH FROM (NOW() - (SELECT MAX(created_at) FROM ...))) * 1000);

  COMMIT;
END;
$$;

-- Test the refresh
CALL analytics.refresh_daily_views(CURRENT_DATE);
```

### Step 4: Schedule Hourly Refresh

**Option A: Using AWS Lambda + RDS Proxy**
```python
import boto3
import redshift_connector

def lambda_handler(event, context):
    conn = redshift_connector.connect(
        host=os.environ['REDSHIFT_HOST'],
        port=5439,
        user=os.environ['REDSHIFT_USER'],
        password=os.environ['REDSHIFT_PASSWORD'],
        database='your_db'
    )
    
    cursor = conn.cursor()
    cursor.execute("CALL analytics.refresh_daily_views(CURRENT_DATE)")
    conn.commit()
    conn.close()
    
    return {'statusCode': 200, 'body': 'Refresh complete'}
```

Set CloudWatch Event: Cron `0 * * * ? *` (every hour)

**Option B: Using Redshift Scheduled SQL**
```sql
-- If using newer Redshift scheduling
CREATE SCHEDULE analytics_daily_refresh
USING TIME_ZONE 'US/Eastern'
WITH RECURRING_TIME_SPECIFICATION = '0 * * * *'  -- Every hour
EXECUTE PROCEDURE analytics.refresh_daily_views(CURRENT_DATE);
```

---

## 6.5 Phase 4: Update Application Code

### Step 1: Modify `/api/summary` to Use Materialized View

**Before** (server.js line 74):
```javascript
app.get('/api/summary', async (req, res) => {
  // Query scans 1M rows, takes 25 seconds
  const sql = `
    SELECT COUNT(DISTINCT survey_target_id) AS total_fcrs, ...
    FROM odp.dp_cust_pers_engagement_dly
    WHERE [12 complex conditions]
  `;
  const kpi = await pool.query(sql, params);
  res.json(kpi.rows[0]);
});
```

**After** (using materialized view):
```javascript
app.get('/api/summary', async (req, res) => {
  // Query scans ~365 rows (one per day), takes 200ms
  const sql = `
    SELECT
      SUM(total_fcrs) AS total_fcrs,
      SUM(total_reps) AS total_reps,
      ROUND(AVG(submitted_pct), 1) AS avg_submitted_pct,
      SUM(draft_fcrs) AS draft_fcrs
    FROM analytics.mview_daily_fcr_summary
    WHERE date >= $1::DATE
      AND date <= $2::DATE
      AND ($3::VARCHAR IS NULL OR ta = $3)
      AND ($4::VARCHAR IS NULL OR reg_nm = $4)
  `;
  
  const [startDate, endDate] = getDateRange(req.query.timeframe);
  const result = await pool.query(sql, [startDate, endDate, req.query.ta, req.query.region]);
  res.json(result.rows[0]);
});
```

### Step 2: Update `/api/capability` Queries

**Pattern**: Replace 6 complex queries with simple queries against materialized views

```javascript
// Before: 6 parallel 15-20 second queries
const [kpi, comps, trend, levels, lead, compliance] = await Promise.all([
  pool.query(kpiSql, params),      // 18s
  pool.query(compSql, params),     // 16s
  pool.query(trendSql, params),    // 12s
  pool.query(levelSql, params),    // 14s
  pool.query(leadSql, params),     // 15s
  pool.query(complianceSql, params),  // 10s
]);
// Total: 18 seconds (slowest)

// After: 6 parallel 300-500ms queries
const [kpi, comps, trend, levels, lead, compliance] = await Promise.all([
  pool.query(`SELECT * FROM analytics.mview_competency_daily WHERE date >= $1`, [startDate]),
  pool.query(`SELECT * FROM analytics.mview_lead_daily WHERE date >= $1`, [startDate]),
  pool.query(`SELECT * FROM analytics.mview_compliance_daily WHERE date >= $1`, [startDate]),
  // ... etc
]);
// Total: 500ms (slowest)
```

---

---

# SECTION 7: QUERY OPTIMIZATION PATTERNS

## Pattern 1: Replace LIKE with Equality

### Use Case
Filtering on engagement_title contains pattern

### Before
```sql
WHERE (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
```

### After
```sql
-- Add computed column (one-time)
ALTER TABLE odp.dp_cust_pers_engagement_dly
ADD COLUMN engagement_category VARCHAR(20);

UPDATE odp.dp_cust_pers_engagement_dly
SET engagement_category = CASE
  WHEN LOWER(engagement_title) LIKE '%coaching%' THEN 'COACHING'
  WHEN LOWER(engagement_title) LIKE '%fcr%' THEN 'FCR'
  WHEN LOWER(engagement_title) LIKE '%msl%' THEN 'MSL'
  ELSE 'OTHER'
END;

CREATE INDEX idx_engagement_category ON odp.dp_cust_pers_engagement_dly (engagement_category);

-- Now use simple equality
WHERE engagement_category IN ('COACHING', 'FCR', 'MSL')
```

### Performance Improvement
- **Before**: ~5,000ms (full scan + pattern match + LOWER())
- **After**: ~150ms (index scan on equality)
- **Speedup**: 33x

---

## Pattern 2: Move LIMIT Before GROUP BY

### Use Case
Paginated list of aggregates

### Before
```sql
SELECT survey_target_id, ta, rep_wwid, ... (15 cols)
FROM odp.dp_cust_pers_engagement_dly
WHERE [complex filters]
GROUP BY survey_target_id, ta, rep_wwid, ... (15 cols)
ORDER BY acty_dt DESC
LIMIT 100 OFFSET 0;
```

### After
```sql
WITH filtered_fcrs AS (
  SELECT DISTINCT survey_target_id
  FROM odp.dp_cust_pers_engagement_dly
  WHERE [complex filters]
  ORDER BY acty_dt DESC
  LIMIT 100 OFFSET 0
)
SELECT t.*
FROM odp.dp_cust_pers_engagement_dly t
WHERE t.survey_target_id IN (SELECT survey_target_id FROM filtered_fcrs);
```

### Why It's Faster
1. Inner query filters to 100 rows first
2. No GROUP BY on millions of rows
3. Join back to get full details (fast, only 100 rows)

### Performance Improvement
- **Before**: ~18,000ms
- **After**: ~3,000ms
- **Speedup**: 6x

---

## Pattern 3: Use Job Level Lookup Table

### Use Case
Filtering on job designation (rep_desig) which is messy text data

### Before
```sql
WHERE (LOWER(rep_desig) LIKE '%senior%' 
   OR LOWER(rep_desig) LIKE '%director%'
   OR LOWER(rep_desig) LIKE '%pg40%')
```

### Setup (One-time)
```sql
-- Create lookup table with canonical values
CREATE TABLE analytics.job_level_map (
  desig_raw VARCHAR(500),
  desig_normalized VARCHAR(50),
  job_level VARCHAR(10),  -- PG30, PG31, PG40, PG41
  PRIMARY KEY (desig_raw)
);

-- Populate with known patterns (scan existing data)
INSERT INTO analytics.job_level_map
SELECT DISTINCT 
  rep_desig,
  LOWER(TRIM(rep_desig)),
  CASE
    WHEN LOWER(rep_desig) LIKE '%sr dir%' OR LOWER(rep_desig) LIKE '%senior dir%' THEN 'PG41'
    WHEN LOWER(rep_desig) LIKE '%field dir%' THEN 'PG40'
    WHEN LOWER(rep_desig) LIKE '%senior%' THEN 'PG31'
    ELSE 'PG30'
  END
FROM odp.dp_cust_pers_engagement_dly
WHERE rep_desig IS NOT NULL;

CREATE INDEX idx_job_level_map_level ON analytics.job_level_map (job_level);
```

### After
```sql
SELECT t.*
FROM odp.dp_cust_pers_engagement_dly t
LEFT JOIN analytics.job_level_map j ON t.rep_desig = j.desig_raw
WHERE j.job_level IN ('PG40', 'PG41');
```

### Performance Improvement
- **Before**: ~2,000ms (pattern matching on every row)
- **After**: ~300ms (indexed join)
- **Speedup**: 6-7x

---

---

# SECTION 8: MONITORING & SUCCESS METRICS

## 8.1 Query Performance Monitoring

### Set Up Query Logging

```sql
-- Enable detailed query logging in Redshift
SET log_min_duration_statement = 1000;  -- Log queries > 1 second

-- View slow queries
SELECT
  query_id,
  query,
  start_time,
  end_time,
  DATEDIFF('second', start_time, end_time) AS duration_sec,
  rows_returned
FROM stl_query
WHERE duration_sec > 10
  AND start_time > NOW() - INTERVAL '24 hours'
ORDER BY duration_sec DESC;
```

### Application-Level Monitoring

```javascript
// Add to server.js to track endpoint latencies
const queryMetrics = new Map();

app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const endpoint = req.path;
    
    if (!queryMetrics.has(endpoint)) {
      queryMetrics.set(endpoint, []);
    }
    queryMetrics.get(endpoint).push(duration);
    
    // Log percentiles every 100 requests
    const times = queryMetrics.get(endpoint);
    if (times.length % 100 === 0) {
      times.sort((a, b) => a - b);
      const p50 = times[Math.floor(times.length * 0.5)];
      const p95 = times[Math.floor(times.length * 0.95)];
      const p99 = times[Math.floor(times.length * 0.99)];
      
      console.log(`${endpoint}: p50=${p50}ms, p95=${p95}ms, p99=${p99}ms`);
    }
  });
  next();
});
```

## 8.2 Success Targets

### Before → After Comparison

| Endpoint | Before (p95) | After (p95) | Target | Reduction |
|----------|-------------|-----------|--------|-----------|
| `/api/fcrs` | 40s | 8s | <10s | 80% |
| `/api/capability` | 50s | 10s | <15s | 80% |
| `/api/ask` (DB portion) | 40s | 5s | <5s | 87% |
| `/api/summary` | 30s | 2s | <5s | 93% |
| `/api/kpis` | 20s | 1.5s | <3s | 92% |
| `/api/fcr/:id` | 25s | 3s | <5s | 88% |

### User Experience Targets

| Metric | Current | Target |
|--------|---------|--------|
| Dashboard load time | 35s | <5s |
| AI query response | 65s | <20s |
| Filter application | 18s | <3s |
| Mobile p95 latency | 90s | <25s |
| 504 errors at 100 users | 15% | <1% |

---

---

# SECTION 9: RISK MITIGATION & ROLLBACK

## 9.1 Potential Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Index creation fails | Low | Medium | Have rollback scripts ready |
| SORTKEY reorganization hangs | Low | High | Monitor closely, kill if needed |
| Materialized view refresh fails | Medium | Medium | Set up error alerts, manual refresh option |
| Query breaks after optimization | Medium | High | Extensive testing before production |
| Backward compatibility issue | Low | High | Test with application code first |

## 9.2 Rollback Procedure

### If indexes cause issues:
```sql
DROP INDEX idx_fcrs_filter;
DROP INDEX idx_acty_dt_desc;
DROP INDEX idx_region_ta;
DROP INDEX idx_survey_target_id_unique;
DROP INDEX idx_engagement_title;
DROP INDEX idx_rep_wwid;

ANALYZE odp.dp_cust_pers_engagement_dly;
```

### If SORTKEY change causes issues:
```sql
-- Restore original SORTKEY (if known)
ALTER TABLE odp.dp_cust_pers_engagement_dly
CHANGE SORTKEY (survey_target_id);  -- Or original value

-- Or drop it entirely
ALTER TABLE odp.dp_cust_pers_engagement_dly
DROP SORTKEY;
```

### If materialized views have problems:
```sql
-- Disable view refresh in Lambda/scheduler
-- Revert application code to use base table queries
-- Drop views if needed
DROP TABLE analytics.mview_daily_fcr_summary;
DROP TABLE analytics.mview_competency_daily;
-- ... (etc for other views)
```

---

---

# SECTION 10: APPENDIX

## 10.1 Complete SQL Script (Copy-Paste Ready)

### Phase 1 & 2: Indexes + SORTKEY
```sql
-- ===== PHASE 1: INDEXING =====

-- Create all indexes
CREATE INDEX idx_fcrs_filter ON odp.dp_cust_pers_engagement_dly (chnl, engagement_title, ta, acty_dt DESC);
CREATE INDEX idx_acty_dt_desc ON odp.dp_cust_pers_engagement_dly (acty_dt DESC);
CREATE INDEX idx_region_ta ON odp.dp_cust_pers_engagement_dly (reg_nm, ta);
CREATE UNIQUE INDEX idx_survey_target_id_unique ON odp.dp_cust_pers_engagement_dly (survey_target_id);
CREATE INDEX idx_engagement_title ON odp.dp_cust_pers_engagement_dly (engagement_title);
CREATE INDEX idx_rep_wwid ON odp.dp_cust_pers_engagement_dly (rep_wwid, acty_dt DESC);

-- Update statistics
ANALYZE odp.dp_cust_pers_engagement_dly;

-- Verify index creation
SELECT * FROM stv_index_usage WHERE tablename = 'dp_cust_pers_engagement_dly';

-- ===== PHASE 2: SORTKEY =====

-- Apply new SORTKEY (RUN DURING MAINTENANCE WINDOW)
ALTER TABLE odp.dp_cust_pers_engagement_dly
CHANGE SORTKEY (acty_dt DESC, ta, reg_nm, survey_target_id);

-- Monitor progress
SELECT partition_number, hostid, rows FROM stv_partitions
WHERE tablename = 'dp_cust_pers_engagement_dly'
ORDER BY partition_number;

-- After completion
ANALYZE odp.dp_cust_pers_engagement_dly;
```

### Phase 3: Materialized Views
[See Section 6.4 for complete script]

---

## 10.2 Testing Queries

```sql
-- Test 1: Simple count (should be <1 second)
EXPLAIN ANALYZE
SELECT COUNT(DISTINCT survey_target_id)
FROM odp.dp_cust_pers_engagement_dly
WHERE ta = 'ONC' AND acty_dt >= CURRENT_DATE - 90;

-- Test 2: Filtered list (should be <3 seconds)
EXPLAIN ANALYZE
SELECT survey_target_id, rep_wwid, ta, acty_dt
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY'
  AND ta IN ('ONC', 'IMM')
  AND acty_dt >= CURRENT_DATE - 60
LIMIT 100;

-- Test 3: Aggregation (should be <5 seconds)
EXPLAIN ANALYZE
SELECT
  ta,
  COUNT(DISTINCT survey_target_id) AS fcr_count,
  ROUND(AVG(CASE WHEN response = 'Expert' THEN 4 ELSE 1 END), 2) AS avg_score
FROM odp.dp_cust_pers_engagement_dly
WHERE acty_dt >= CURRENT_DATE - 90
GROUP BY ta
ORDER BY fcr_count DESC;

-- Test 4: Rep trend (should be <2 seconds)
EXPLAIN ANALYZE
SELECT
  DATE(acty_dt) AS coaching_date,
  AVG(CASE WHEN response IN (...) THEN 3 ELSE 1 END) AS avg_score
FROM odp.dp_cust_pers_engagement_dly
WHERE rep_wwid = 'W123456'
GROUP BY DATE(acty_dt)
ORDER BY coaching_date DESC
LIMIT 20;
```

---

## 10.3 Deployment Checklist

- [ ] **Week 1**
  - [ ] Schedule maintenance window
  - [ ] Backup Redshift cluster
  - [ ] Notify users of 2-4 hour downtime
  - [ ] Prepare rollback procedure
  - [ ] Test index creation in dev environment

- [ ] **Deployment Day (Maintenance Window)**
  - [ ] Stop application (drain connections)
  - [ ] Execute Phase 1: Create 6 indexes (~30 min)
  - [ ] Execute Phase 2: Apply SORTKEY (~2 hours)
  - [ ] Run ANALYZE to update statistics (~15 min)
  - [ ] Execute test queries to verify speedup
  - [ ] Restart application
  - [ ] Monitor error rates for 1 hour

- [ ] **Day 2**
  - [ ] Implement Phase 3: Materialized views (~4 hours)
  - [ ] Set up hourly refresh job
  - [ ] Modify application code to use new views
  - [ ] Deploy updated backend
  - [ ] Monitor query performance

- [ ] **Week 2**
  - [ ] Implement Phase 4: Query rewriting (~4-8 hours distributed)
  - [ ] Implement Phase 5: Connection pool tuning (~1-2 hours)
  - [ ] Full application testing
  - [ ] Performance validation against success targets

---

---

# SUMMARY & NEXT STEPS

## What Was Delivered

1. **Comprehensive Pain Points Analysis**: 5 critical bottlenecks identified with code references
2. **Root Cause Analysis**: Database design, query patterns, and architecture issues explained
3. **Performance Impact**: Current vs. target metrics with user experience implications
4. **5-Phase Optimization Strategy**: Prioritized approach from quick wins to architectural changes
5. **Detailed Implementation Guide**: Step-by-step procedures for each phase
6. **Testing & Monitoring**: Success metrics and validation procedures
7. **Risk Mitigation**: Rollback procedures and contingency plans

## Immediate Actions

1. **Schedule Maintenance Window**: Choose low-traffic period (weekday 2-6 AM) for Phases 1-2
2. **Prepare Environment**: Back up database, prepare rollback scripts
3. **Execute Phase 1**: Create indexes (30 min effort, 30% latency reduction)
4. **Execute Phase 2**: Apply SORTKEY (2-4 hours effort, 20% latency reduction)
5. **Plan Phases 3-5**: Coordinate with backend team for application code changes

## Expected Timeline

- **Phase 1-2**: 2-4 hours (quick wins, 50% total reduction)
- **Phase 3-5**: 2-3 weeks distributed (additional 25-30% reduction)
- **Total Effort**: ~40-50 engineering hours
- **Total Impact**: 60-75% latency reduction (85s → 15-20s)

---

**END OF COMPREHENSIVE REDSHIFT OPTIMIZATION SOP**

*Ready for DOCX conversion and distribution to technical team*

