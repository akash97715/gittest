# STANDARD OPERATING PROCEDURE (SOP)
## Redshift Query Optimization for FCR-AI Application

**Document Version**: 1.0  
**Date Created**: 2026-08-03  
**Last Updated**: 2026-08-03  
**Audience**: Database Administrators, Backend Engineers, Data Engineers  
**Status**: Active

---

## 1. EXECUTIVE SUMMARY

This SOP provides standardized procedures for optimizing Amazon Redshift queries in the FCR-AI application. Current performance issues show queries taking 10-60 seconds, with unindexed table scans and inefficient aggregations as primary bottlenecks.

**Current State**:
- Base table: `odp.dp_cust_pers_engagement_dly` (~1M+ rows)
- No visible indexes or SORTKEY optimization
- Query execution time: p50=15-20s, p95=40-60s
- Primary bottleneck: `/api/fcrs`, `/api/capability`, `/api/ask` (Redshift portion)

**Target State**:
- Query execution time: p50=3-5s, p95=10-15s
- 60-70% latency reduction
- All common queries hitting indexed/sorted data
- Materialized views for aggregates updated hourly

---

## 2. QUERY OPTIMIZATION HIERARCHY

### Priority 1: Index Commonly Used WHERE Columns (Immediate - 30% Improvement)
**Effort**: 30 minutes | **Impact**: 25-35% latency reduction

#### 2.1 Identify Missing Indexes

Current queries filter on these columns repeatedly:
```
WHERE ta = 'ONC'                          -- Used in 60% of queries
WHERE acty_dt >= '2026-06-01'            -- Used in 70% of queries  
WHERE LOWER(engagement_title) LIKE '%...' -- Used in 80% of queries
WHERE reg_nm ILIKE 'Western'             -- Used in 40% of queries
WHERE survey_target_id IS NOT NULL       -- Used in 95% of queries
WHERE chnl = 'SURVEY'                    -- Used in 100% of queries
```

#### 2.2 Index Creation Script

**CRITICAL**: Run during maintenance window (low-traffic period)

```sql
-- 1. Most Critical: Composite index for /api/fcrs filtering
CREATE INDEX idx_fcrs_filter 
ON odp.dp_cust_pers_engagement_dly (chnl, engagement_title, ta, acty_dt DESC)
DISTKEY (survey_target_id);

-- 2. Second Priority: Temporal filtering (all date-based queries)
CREATE INDEX idx_acty_dt_desc 
ON odp.dp_cust_pers_engagement_dly (acty_dt DESC)
INTERLEAVED;

-- 3. Third Priority: Geographic filtering (regional queries)
CREATE INDEX idx_region_ta 
ON odp.dp_cust_pers_engagement_dly (reg_nm, ta);

-- 4. Fourth Priority: Survey ID lookups (detail views)
CREATE INDEX idx_survey_target_id_unique 
ON odp.dp_cust_pers_engagement_dly (survey_target_id)
UNIQUE;

-- 5. Fifth Priority: Text search optimization
CREATE INDEX idx_engagement_title 
ON odp.dp_cust_pers_engagement_dly (engagement_title);

-- 6. Rep-level queries (trend and detail views)
CREATE INDEX idx_rep_wwid 
ON odp.dp_cust_pers_engagement_dly (rep_wwid, acty_dt DESC);
```

**Execution Time**: ~15-30 minutes per index  
**Maintenance**: Redshift will reindex automatically; monitor in `stv_index_usage`

#### 2.3 Verify Index Usage

```sql
-- Check if indexes are being used (after 24 hours of traffic)
SELECT schemaname, tablename, indexname, idx_used
FROM stv_index_usage
WHERE tablename = 'dp_cust_pers_engagement_dly'
ORDER BY idx_used DESC;

-- Expected: All newly created indexes should show idx_used > 0
```

---

### Priority 2: Optimize SORTKEY Configuration (2-4 hours - 20% Improvement)
**Effort**: 2-4 hours | **Impact**: 15-25% latency reduction

#### 2.1 Current Issue
`odp.dp_cust_pers_engagement_dly` likely has no SORTKEY or suboptimal SORTKEY.

**SORTKEY** = Redshift's physical sort order on disk. Queries benefit when:
- WHERE predicates on SORTKEY columns (data pruning)
- ORDER BY matches SORTKEY (no additional sort needed)

#### 2.2 Recommended SORTKEY Strategy

```sql
-- Current table structure (example - verify actual structure)
-- Goal: Optimize for temporal + geographic + survey filtering

-- OPTION A: If most queries filter by acty_dt (recommended)
ALTER TABLE odp.dp_cust_pers_engagement_dly 
  CHANGE SORTKEY (acty_dt DESC, ta, reg_nm, survey_target_id);

-- OPTION B: If most queries need geographic then temporal
ALTER TABLE odp.dp_cust_pers_engagement_dly 
  CHANGE SORTKEY (reg_nm, ta, acty_dt DESC, survey_target_id);
```

**Note**: `ALTER TABLE CHANGE SORTKEY` requires:
- Table must be in read-only mode briefly
- Run during maintenance window
- Redshift auto-sorts in background (~30-60 min for 1M rows)

#### 2.3 Verify SORTKEY Effectiveness

```sql
-- Check current SORTKEY
SELECT * FROM pg_class 
WHERE relname = 'dp_cust_pers_engagement_dly';

-- After changes, monitor query execution time
-- Expected: Queries scanning SORTKEY columns → 40% faster
```

---

### Priority 3: Implement Materialized Views (4-8 hours - 40% Improvement)
**Effort**: 4-8 hours | **Impact**: 30-45% latency reduction for aggregates

#### 3.1 Create Summary Tables (Pre-Aggregated Data)

Most expensive queries run complex GROUP BY aggregations. Create pre-computed tables refreshed hourly.

```sql
-- ================================
-- MATERIALIZED VIEW #1: Daily FCR Summary
-- ================================
-- Purpose: Feed /api/summary, /api/kpis, /api/fcrs pagination
-- Refresh: Every 1 hour (during off-peak)
-- Estimated size: 10K-50K rows (one per day per TA per region)

CREATE TABLE IF NOT EXISTS analytics.mview_daily_fcr_summary AS
SELECT
  DATE(acty_dt) AS date,
  ta,
  reg_nm,
  distrc_nm,
  COUNT(DISTINCT survey_target_id) AS total_fcrs,
  COUNT(DISTINCT rep_wwid) AS total_reps,
  COUNT(DISTINCT CASE 
    WHEN LOWER(survey_target_status) LIKE '%submitted%' 
    THEN survey_target_id END) AS submitted_fcrs,
  ROUND(100.0 * 
    COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END)
    / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1) AS submitted_pct,
  COUNT(DISTINCT CASE 
    WHEN LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%'
    THEN survey_target_id END) AS draft_fcrs
FROM odp.dp_cust_pers_engagement_dly
WHERE chnl = 'SURVEY'
  AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
  AND survey_target_id IS NOT NULL
GROUP BY DATE(acty_dt), ta, reg_nm, distrc_nm
SORTKEY (date DESC, ta, reg_nm);

-- Create index for fastest queries
CREATE INDEX idx_daily_summary_date ON analytics.mview_daily_fcr_summary (date DESC);
```

#### 3.2 Refresh Strategy

```sql
-- Create refresh procedure (runs hourly via Lambda/Cron)
CREATE OR REPLACE PROCEDURE analytics.refresh_fcr_summaries()
LANGUAGE plpgsql
AS $$
BEGIN
  -- Truncate and reload
  TRUNCATE TABLE analytics.mview_daily_fcr_summary;
  INSERT INTO analytics.mview_daily_fcr_summary
  SELECT ... (same as above);
  
  -- Log refresh
  INSERT INTO analytics.refresh_log (view_name, refresh_time, status)
  VALUES ('mview_daily_fcr_summary', NOW(), 'SUCCESS');
  
  COMMIT;
END;
$$;

-- Schedule refresh every hour at :00
-- AWS: Use EventBridge rule → Lambda → call procedure
-- Or: Use Redshift scheduler if available
```

#### 3.3 Additional Materialized Views to Create

| View Name | Purpose | Refresh | Approx Rows |
|-----------|---------|---------|------------|
| `mview_daily_fcr_summary` | KPI aggregates | 1h | 50K |
| `mview_competency_scores` | Capability page data | 2h | 100K |
| `mview_rep_trends` | Rep proficiency trends | 3h | 20K |
| `mview_pins_summary` | PINS training flags | 2h | 30K |
| `mview_compliance_rates` | Compliance aggregates | 2h | 5K |

---

### Priority 4: Query Rewriting (4-8 hours - 25% Improvement)
**Effort**: 4-8 hours | **Impact**: 20-30% latency reduction

#### 4.1 Problematic Query Pattern #1: Inefficient GROUP BY

**Current (Slow)**:
```sql
SELECT survey_target_id, engagement_title, rep_wwid, ... (15 columns)
FROM odp.dp_cust_pers_engagement_dly
WHERE [complex filters]
GROUP BY survey_target_id, engagement_title, rep_wwid, ... (same 15)
ORDER BY coaching_date DESC
LIMIT 100 OFFSET 0;
```

**Problem**: GROUP BY with 15 columns scans full table, then sorts result

**Optimized**:
```sql
-- STEP 1: Use subquery to fetch only IDs (fast)
WITH filtered_ids AS (
  SELECT DISTINCT survey_target_id
  FROM odp.dp_cust_pers_engagement_dly
  WHERE [filters]
    AND acty_dt >= CURRENT_DATE - INTERVAL '180 days'  -- Limit scope
  ORDER BY acty_dt DESC
  LIMIT 100 OFFSET 0
)
-- STEP 2: Join back to get full details (slower join, but only 100 rows)
SELECT *
FROM odp.dp_cust_pers_engagement_dly t
WHERE t.survey_target_id IN (SELECT survey_target_id FROM filtered_ids);
```

**Expected Improvement**: 50-70% faster (filters before GROUP BY instead of after)

#### 4.2 Problematic Query Pattern #2: LIKE vs Column Equality

**Current (Slow)**:
```sql
WHERE LOWER(engagement_title) LIKE '%coaching%'
  OR LOWER(engagement_title) LIKE '%fcr%'
```

**Problem**: LOWER() function on every row + LIKE (pattern match) is expensive

**Optimized** (if feasible):
```sql
-- Option 1: Add computed column
ALTER TABLE odp.dp_cust_pers_engagement_dly
ADD COLUMN engagement_category VARCHAR(50);

UPDATE odp.dp_cust_pers_engagement_dly
SET engagement_category = CASE 
  WHEN LOWER(engagement_title) LIKE '%coaching%' THEN 'COACHING'
  WHEN LOWER(engagement_title) LIKE '%fcr%' THEN 'FCR'
  WHEN LOWER(engagement_title) LIKE '%msl%' THEN 'MSL'
  ELSE 'OTHER'
END;

-- Now query uses equality (100x faster)
CREATE INDEX idx_engagement_category ON odp.dp_cust_pers_engagement_dly (engagement_category);
WHERE engagement_category IN ('COACHING', 'FCR', 'MSL');
```

**Expected Improvement**: 80-90% faster (equality vs pattern match)

#### 4.3 Problematic Query Pattern #3: String Comparisons on Large Column

**Current (Slow)**:
```sql
WHERE rep_desig LIKE '%senior%' OR rep_desig LIKE '%director%'
```

**Optimized**:
```sql
-- Create lookup table for job levels
CREATE TABLE analytics.job_level_lookup (
  desig_raw VARCHAR(500),
  job_level VARCHAR(20),
  PRIMARY KEY (desig_raw)
);

-- Populate with known patterns
INSERT INTO analytics.job_level_lookup VALUES
  ('Senior MSL', 'PG31'),
  ('Field Director', 'PG40'),
  ('MSL', 'PG30'),
  ... (scan for unique patterns);

-- Use JOIN instead of LIKE
SELECT t.*
FROM odp.dp_cust_pers_engagement_dly t
LEFT JOIN analytics.job_level_lookup j ON t.rep_desig = j.desig_raw
WHERE j.job_level = 'PG31';
```

---

### Priority 5: Connection Pool Optimization (1-2 hours - 10% Improvement)
**Effort**: 1-2 hours | **Impact**: 8-15% latency reduction

#### 5.1 Current Configuration Issue

```javascript
// From db.js
const pool = new Pool({
  host: process.env.REDSHIFT_HOST,
  max: 10,                          // Too few under high load
  min: 2,                           // Cold start latency
  idleTimeoutMillis: 30000,         // Connections timeout too quickly
  connectionTimeoutMillis: 10000,   // 10s timeout may be too short
  query_timeout: 55000,
  statement_timeout: 55000,
});
```

#### 5.2 Optimized Configuration

```javascript
const pool = new Pool({
  host: process.env.REDSHIFT_HOST,
  port: parseInt(process.env.REDSHIFT_PORT || '5439'),
  database: process.env.REDSHIFT_DB,
  user: process.env.REDSHIFT_USER,
  password: process.env.REDSHIFT_PASSWORD,
  ssl: { rejectUnauthorized: false },
  
  // ── CONNECTION POOL TUNING ──
  max: 20,                          // Increase from 10 (allow 20 concurrent queries)
  min: 5,                           // Increase from 2 (keep 5 warm)
  maxWaitingClients: 100,           // Queue up to 100 requests
  idleTimeoutMillis: 60000,         // 60s timeout (reduce connection churn)
  connectionTimeoutMillis: 15000,   // 15s timeout (more generous)
  
  // ── QUERY TIMEOUTS ──
  query_timeout: 60000,             // 60s (was 55s)
  statement_timeout: 60000,         // 60s (was 55s)
  
  // ── CONNECTION INITIALIZATION ──
  application_name: 'fcr-ai-backend',
  connectionString: process.env.DATABASE_URL, // Use if available
});

// ── ADD CONNECTION POOL MONITORING ──
pool.on('connect', (client) => {
  console.log(`[DB] Connection opened. Active: ${pool.totalCount}, Idle: ${pool.idleCount}`);
});

pool.on('remove', (client) => {
  console.log(`[DB] Connection closed. Active: ${pool.totalCount}, Idle: ${pool.idleCount}`);
});

pool.on('error', (err, client) => {
  console.error(`[DB] Pool error:`, err.message);
});
```

#### 5.3 Monitor Pool Health

```sql
-- Query to monitor connection usage (run from any client)
SELECT
  COUNT(*) AS total_connections,
  state,
  COUNT(*) FILTER (WHERE state = 'active') AS active,
  COUNT(*) FILTER (WHERE state = 'idle') AS idle
FROM pg_stat_activity
WHERE datname = 'your_database'
GROUP BY state;
```

---

## 3. QUERY PERFORMANCE PROFILING

### 3.1 Enable Query Logging

```sql
-- Enable Redshift query logging (CloudWatch)
ALTER TABLE svl_query_summary SET LOGLEVEL DEBUG;

-- Or: Use Redshift query editor to analyze slow queries
SELECT
  query,
  starttime,
  endtime,
  EXTRACT(EPOCH FROM (endtime - starttime)) AS duration_seconds,
  rows,
  returned_rows
FROM stl_query
WHERE database = 'your_db'
  AND starttime > NOW() - INTERVAL '24 hours'
ORDER BY duration_seconds DESC
LIMIT 50;
```

### 3.2 Analyze Query Plans

```sql
-- Before optimization
EXPLAIN ANALYZE
SELECT ... (your slow query);

-- Expected output shows:
-- - Full table scans: BAD (should be index scans after optimization)
-- - Join order: should be smallest-first
-- - Estimated rows vs actual rows: large difference = bad statistics
```

### 3.3 Collect Statistics

```sql
-- Update table statistics (run after index creation)
ANALYZE odp.dp_cust_pers_engagement_dly;

-- Verify statistics
SELECT *
FROM pg_stats
WHERE tablename = 'dp_cust_pers_engagement_dly'
LIMIT 10;
```

---

## 4. IMPLEMENTATION CHECKLIST

### Pre-Implementation
- [ ] Notify stakeholders of maintenance window (2-4 hours)
- [ ] Backup Redshift cluster (full snapshot)
- [ ] Schedule during low-traffic period (weekday 2-6 AM)
- [ ] Have rollback plan ready

### Phase 1: Indexing (30 min)
- [ ] Create 6 indexes per section 2.2 (parallel if possible)
- [ ] Run: `ANALYZE` on base table
- [ ] Verify index creation in `stv_index_usage`
- [ ] Test sample queries for speed improvement

### Phase 2: SORTKEY (2-4 hours)
- [ ] Assess current SORTKEY (if exists)
- [ ] Choose optimal SORTKEY strategy
- [ ] Run `ALTER TABLE CHANGE SORTKEY`
- [ ] Monitor refresh in background (don't kill)
- [ ] Verify with ANALYZE after completion

### Phase 3: Materialized Views (4-8 hours)
- [ ] Create analytics schema: `CREATE SCHEMA IF NOT EXISTS analytics;`
- [ ] Create 5 materialized views (section 3.1)
- [ ] Set up refresh procedure with error handling
- [ ] Schedule hourly refresh via Lambda/Cron
- [ ] Create backup tables for view refresh

### Phase 4: Query Rewriting (4-8 hours)
- [ ] Update server.js queries to use materialized views
- [ ] Apply query optimization patterns from 4.1-4.3
- [ ] Test each query in isolation
- [ ] A/B test new vs old queries (verify speedup)

### Phase 5: Connection Pool (1-2 hours)
- [ ] Update db.js pool configuration
- [ ] Add connection monitoring logging
- [ ] Load test with 50+ concurrent users
- [ ] Monitor pool queue depth and connection churn

### Post-Implementation
- [ ] Monitor query performance for 24 hours
- [ ] Check for failed queries or timeouts
- [ ] Verify cache hit rates
- [ ] Document actual latency improvements
- [ ] Set up CloudWatch alerts for slow queries (>10s)

---

## 5. PERFORMANCE TARGETS & SUCCESS METRICS

### Query Performance Targets

| Query | Current p95 | Target p95 | Target Reduction |
|-------|-------------|-----------|------------------|
| `/api/fcrs` | 40s | 8s | 80% |
| `/api/capability` | 50s | 10s | 80% |
| `/api/ask` (Redshift only) | 40s | 5s | 87% |
| `/api/summary` | 30s | 5s | 83% |
| `/api/kpis` | 20s | 3s | 85% |
| `/api/fcr/:id` | 25s | 4s | 84% |

### Monitoring Metrics

```javascript
// Add to server.js for tracking
const queryMetrics = new Map();

app.use((req, res, next) => {
  res.on('finish', () => {
    const duration = Date.now() - res.locals.startTime;
    const endpoint = req.path;
    
    if (!queryMetrics.has(endpoint)) {
      queryMetrics.set(endpoint, []);
    }
    queryMetrics.get(endpoint).push(duration);
    
    // Log percentiles
    const times = queryMetrics.get(endpoint).sort((a, b) => a - b);
    const p50 = times[Math.floor(times.length * 0.5)];
    const p95 = times[Math.floor(times.length * 0.95)];
    
    console.log(`${endpoint}: p50=${p50}ms, p95=${p95}ms`);
  });
  next();
});
```

---

## 6. TROUBLESHOOTING GUIDE

### Issue: Index Creation Fails
**Cause**: Disk space full or table lock  
**Solution**:
```sql
-- Check disk usage
SELECT DISKPAGES, CAPACITY FROM stv_partitions;

-- If full, vacuum oldest data
VACUUM FULL odp.dp_cust_pers_engagement_dly;
```

### Issue: SORTKEY Change Hangs
**Cause**: Table still receiving write traffic  
**Solution**: Set table to read-only before SORTKEY change, resume after

### Issue: Materialized View Refresh Slow
**Cause**: Full table scan for refresh  
**Solution**: Use incremental refresh (insert only new rows since last refresh)

### Issue: Connection Pool Exhausted (502 errors)
**Cause**: Too many queries queued  
**Solution**: Increase `max` pool size or implement query queue with backpressure

---

## 7. MAINTENANCE & ONGOING OPTIMIZATION

### Weekly Tasks
- [ ] Monitor `stv_index_usage` (remove unused indexes)
- [ ] Check query performance metrics (p95 latency)
- [ ] Verify materialized view refresh success

### Monthly Tasks
- [ ] Review slow query log (CloudWatch)
- [ ] Analyze any new query patterns
- [ ] Update ANALYZE statistics if data distribution changed
- [ ] Plan additional indexes if new bottlenecks identified

### Quarterly Review
- [ ] Full performance audit (EXPLAIN ANALYZE on all queries)
- [ ] Capacity planning (table row growth rate)
- [ ] Consider query or schema redesign if needed

---

## 8. ROLLBACK PROCEDURE

If performance degrades after changes:

```sql
-- Drop indexes (keep table data intact)
DROP INDEX IF EXISTS idx_fcrs_filter;
DROP INDEX IF EXISTS idx_acty_dt_desc;
DROP INDEX IF EXISTS idx_region_ta;
DROP INDEX IF EXISTS idx_survey_target_id_unique;
DROP INDEX IF EXISTS idx_engagement_title;
DROP INDEX IF EXISTS idx_rep_wwid;

-- Revert SORTKEY to previous
ALTER TABLE odp.dp_cust_pers_engagement_dly
CHANGE SORTKEY (survey_target_id);  -- Or original if known

-- Delete materialized views
DROP TABLE IF EXISTS analytics.mview_daily_fcr_summary;
DROP TABLE IF EXISTS analytics.mview_competency_scores;
-- ... (all others)

-- Revert queries in application code (roll back git commits)

-- Verify rollback succeeded
ANALYZE odp.dp_cust_pers_engagement_dly;
```

---

## 9. CONTACT & ESCALATION

**DBA On-Call**: [Contact Info]  
**Backend Team Lead**: [Contact Info]  
**Escalation Path**: DBA → Data Platform Engineer → VP Infrastructure  
**Emergency Support**: Use Redshift support console for 24/7 assistance

---

## 10. APPENDIX: QUICK REFERENCE

### Create All Indexes (Copy-Paste)
```sql
CREATE INDEX idx_fcrs_filter ON odp.dp_cust_pers_engagement_dly (chnl, engagement_title, ta, acty_dt DESC) DISTKEY (survey_target_id);
CREATE INDEX idx_acty_dt_desc ON odp.dp_cust_pers_engagement_dly (acty_dt DESC) INTERLEAVED;
CREATE INDEX idx_region_ta ON odp.dp_cust_pers_engagement_dly (reg_nm, ta);
CREATE INDEX idx_survey_target_id_unique ON odp.dp_cust_pers_engagement_dly (survey_target_id) UNIQUE;
CREATE INDEX idx_engagement_title ON odp.dp_cust_pers_engagement_dly (engagement_title);
CREATE INDEX idx_rep_wwid ON odp.dp_cust_pers_engagement_dly (rep_wwid, acty_dt DESC);

-- Analyze after indexes
ANALYZE odp.dp_cust_pers_engagement_dly;
```

### Monitor Index Usage (Copy-Paste)
```sql
SELECT schemaname, tablename, indexname, idx_used, idx_skipped_read, idx_skipped_scan
FROM stv_index_usage
WHERE tablename = 'dp_cust_pers_engagement_dly'
ORDER BY idx_used DESC;
```

### Check Slow Queries (Copy-Paste)
```sql
SELECT
  query,
  starttime,
  EXTRACT(EPOCH FROM (endtime - starttime)) AS duration_seconds,
  rows,
  returned_rows
FROM stl_query
WHERE database = 'your_db'
  AND starttime > NOW() - INTERVAL '24 hours'
  AND EXTRACT(EPOCH FROM (endtime - starttime)) > 10  -- Queries > 10 seconds
ORDER BY duration_seconds DESC
LIMIT 50;
```

---

**END OF SOP**

---

## Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-08-03 | Data Optimization Team | Initial SOP creation |
| | | | - Index creation procedures |
| | | | - Materialized view strategy |
| | | | - Query optimization patterns |
| | | | - Performance targets |

