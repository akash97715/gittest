import { useState } from 'react';
import { Search, Download, ExternalLink } from 'lucide-react';
import { recentFCRs } from '../data/mockData';


const statusClass = {
  'Completed':   'badge-completed',
  'Submitted':   'badge-submitted',
  'Draft':       'badge-draft',
  'Overdue':     'badge-overdue',
  'In Progress': 'badge-inprogress',
};

export default function RecentFCRsTable() {
  const [search, setSearch] = useState('');
  const [filterTA, setFilterTA] = useState('All');

  const allTAs = ['All', ...new Set(recentFCRs.map(r => r.ta))];

  const filtered = recentFCRs.filter(r => {
    const matchSearch =
      r.id.toLowerCase().includes(search.toLowerCase()) ||
      r.manager.toLowerCase().includes(search.toLowerCase()) ||
      r.msl.toLowerCase().includes(search.toLowerCase()) ||
      r.ta.toLowerCase().includes(search.toLowerCase());
    const matchTA = filterTA === 'All' || r.ta === filterTA;
    return matchSearch && matchTA;
  });

  return (
    <div className="section-card">
      <div className="section-card-header">
        <div>
          <div className="section-card-title">Recent Field Coaching Reports</div>
          <div className="section-card-sub">{filtered.length} reports</div>
        </div>
        <div className="section-card-actions">
          {/* TA Filter */}
          <select
            id="filter-ta-table"
            value={filterTA}
            onChange={e => setFilterTA(e.target.value)}
            style={{
              height: 30, padding: '0 10px', border: '1px solid #e5e7eb',
              borderRadius: 6, fontFamily: 'inherit', fontSize: 12,
              background: '#f9fafb', color: '#374151', outline: 'none',
            }}
            aria-label="Filter by therapeutic area"
          >
            {allTAs.map(ta => <option key={ta}>{ta}</option>)}
          </select>

          {/* Search */}
          <div className="table-search">
            <Search className="search-icon" />
            <input
              id="search-fcrs"
              type="text"
              placeholder="Search reports..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              aria-label="Search field coaching reports"
            />
          </div>

          <button id="btn-export-fcrs" className="btn btn-outline">
            <Download size={12} /> Export
          </button>
        </div>
      </div>

      <div className="data-table-wrap">
        <table className="data-table" aria-label="Recent field coaching reports">
          <thead>
            <tr>
              <th>FCR ID</th>
              <th>Manager</th>
              <th>MSL</th>
              <th>Therapeutic Area</th>
              <th>Date</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} style={{ textAlign: 'center', color: '#9ca3af', padding: '24px' }}>
                  No reports match your search.
                </td>
              </tr>
            ) : (
              filtered.map((row, i) => (
                <tr key={row.id} id={`fcr-row-${i}`}>
                  <td>
                    <span style={{ fontFamily: 'monospace', fontSize: 12, color: '#c41230', fontWeight: 600 }}>
                      {row.id}
                    </span>
                  </td>
                  <td style={{ fontWeight: 500 }}>{row.manager}</td>
                  <td>{row.msl}</td>
                  <td>
                    <span style={{
                      fontSize: 11, padding: '2px 8px', borderRadius: 4,
                      background: '#f3f4f6', color: '#374151', fontWeight: 500,
                    }}>
                      {row.ta}
                    </span>
                  </td>
                  <td style={{ color: '#6b7280', fontSize: 12 }}>
                    {new Date(row.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td>
                    <span className={`badge ${statusClass[row.status]}`}>{row.status}</span>
                  </td>
                  <td>
                    <button
                      id={`btn-view-fcr-${i}`}
                      className="btn btn-ghost"
                      title={`View ${row.id}`}
                      style={{ padding: '4px 6px' }}
                    >
                      <ExternalLink size={13} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
