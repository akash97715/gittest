import { RefreshCw, Download } from 'lucide-react';

// ── Exact PINS data from user ──────────────────────────────────────────────────
const PINS = [
  {
    letter: 'P',
    title: 'Planning for Perspective',
    description:
      "Develops the HCP / PHDM perspective ahead of the interaction, strategically aligned objectives reflecting the commercial partner's account strategy, insights from digital pre-call tools (e.g. AIDA, HI), and resource selection that supports the planned objectives and anticipated objections.",
    behaviours: [
      {
        text: "Developed strategically aligned goals reflecting business partner's account strategy and translated it into clear, actionable objectives.",
        skills: ['Strategic Thinking', 'Competitive'],
      },
      {
        text: 'Incorporated insights using digital tools (e.g. AIDA), clinical and market access readiness, and business priorities.',
        skills: ['Data Gathering'],
      },
      {
        text: 'Selected resources support the stated strategy and objectives and address anticipated objections.',
        skills: ['Clinical Expertise', 'Data Gathering'],
      },
    ],
    hasOpportunity: true,
  },
  {
    letter: 'I',
    title: 'Investigate Issues',
    description:
      "Investigates the HCP / PHDM's situation in the interaction, recaps prior discussions, asks open-ended questions, listens actively, and surfaces motivators, barriers, objections, and unmet needs to capture actionable insights.",
    behaviours: [
      {
        text: 'Outlined meeting objectives, recapped previous discussions, invited HCP / PHDM input and adjusted as needed.',
        skills: ['Influencing'],
      },
      {
        text: 'Engaged HCPs / PHDMs with open-ended questions, active listening, and clear communication.',
        skills: ['Influencing', 'Problem Solving'],
      },
      {
        text: 'Identified HCP / PHDM motivators, barriers, objections, and unmet needs to capture actionable insights.',
        skills: ['Data Gathering', 'Problem Solving'],
      },
    ],
    hasOpportunity: true,
  },
  {
    letter: 'N',
    title: 'Navigate and Negotiate Needs',
    description:
      "Navigates the scientific discussion and negotiates around the HCP / PHDM's needs, confidently delivers key data, addresses misunderstandings of J&J or competitor data, and uses approved, role-aligned resources tied to MAF / SA strategy and Documented Interests.",
    behaviours: [
      {
        text: 'Confidently delivered key data and seamlessly facilitated scientific exchange to meet HCP / PHDM needs.',
        skills: ['Clinical Expertise', 'Influencing'],
      },
      {
        text: 'Confidently addressed HCP / PHDM misunderstanding of J&J or competitor data, helping close knowledge gaps.',
        skills: ['Influencing', 'Competitive'],
      },
      {
        text: 'Used role-aligned, approved scientific resources aligned with MAF / SA strategy and identified Documented Interests.',
        skills: ['Clinical Expertise', 'Strategic Thinking'],
      },
    ],
    hasOpportunity: false,
  },
  {
    letter: 'S',
    title: 'Secure Action',
    description:
      'Secures the right next action, meeting objectives achieved with appropriate clinical reinforcement, named follow-up with internal partners, actionable VoC captured, and CRM (Veeva / iConnect) entry completed.',
    behaviours: [
      {
        text: 'Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps.',
        skills: ['Strategic Thinking'],
      },
      {
        text: 'Appropriate follow-up planned with internal partners.',
        skills: ['Cross-functional'],
      },
      {
        text: 'Documentation of actionable insights (VoC).',
        skills: ['Data Gathering'],
      },
      {
        text: 'Appropriate documentation in CRM system (e.g. Veeva, iConnect).',
        skills: ['Data Gathering'],
      },
    ],
    hasOpportunity: true,
  },
];

// ── 7 FBMS Skills ──────────────────────────────────────────────────────────────
const FBMS_SKILLS = [
  {
    name: 'Data Gathering and Analysis',
    behaviors: [
      'Incorporates insights from AIDA, Isi, and other digital pre-call tools',
      'Identifies HCP / PHDM motivators, barriers, objections, and unmet needs',
      'Captures actionable VoC and documents in CRM (Veeva / iConnect)',
    ],
  },
  {
    name: 'Strategic Thinking',
    behaviors: [
      "Develops strategically aligned goals reflecting commercial partner's account strategy",
      'Translates strategy into clear, actionable meeting objectives',
      'Secures next steps with appropriate clinical reinforcement',
    ],
  },
  {
    name: 'Competitive Landscape',
    behaviors: [
      'Discusses competitive landscape with depth (e.g. journal-club readiness)',
      'Addresses HCP misunderstanding of competitor data',
      'Positions J&J data versus class to close knowledge gaps',
    ],
  },
  {
    name: 'Influencing Others',
    behaviors: [
      'Outlines objectives, recaps prior discussions, and invites HCP / PHDM input',
      'Engages with open-ended questions and active listening',
      'Closes knowledge gaps confidently and respectfully',
    ],
  },
  {
    name: 'Clinical Expertise',
    behaviors: [
      'Confidently delivers key data and facilitates scientific exchange',
      'Uses approved, role-aligned resources (decks, Core Asset Themes, one-pagers)',
      'Aligns resource selection to MAF / SA strategy and HCP need',
    ],
  },
  {
    name: 'Problem Solving',
    behaviors: [
      'Probes barriers with follow-up questions to surface root causes',
      'Listens for keywords to identify probing opportunities',
      'Uses insights gathered to adjust approach in-call',
    ],
  },
  {
    name: 'Cross-functional Collaboration',
    behaviors: [
      'Plans appropriate follow up with internal partners',
      'Hands off clearly to Medical Affairs / Clinical Ops',
      'Closes the loop on commitments made to HCPs and partners',
    ],
  },
];

// ── Proficiency matrix ─────────────────────────────────────────────────────────
const SKILL_COLS = ['Data Gathering', 'Strategic Thinking', 'Competitive', 'Influencing', 'Clinical Expertise', 'Problem Solving', 'Cross-functional'];
const PROFICIENCY_ROWS = [
  { level: 'L1 – Associate FBMS', scores: [1, 1, 1, 2, 2, 1, 2] },
  { level: 'L2 – FBMS',           scores: [2, 2, 2, 2, 2, 2, 2] },
  { level: 'L3 – Senior FBMS',    scores: [2, 2, 2, 3, 3, 2, 2] },
  { level: 'L4 – Principal FBMS', scores: [3, 3, 3, 3, 3, 3, 3] },
  { level: 'L5 – Director FBMS',  scores: [3, 3, 3, 3, 3, 3, 3] },
];

// ── Skill tag colour map ───────────────────────────────────────────────────────
const TAG_COLORS = {
  'Strategic Thinking':  { bg: '#fef3c7', text: '#92400e' },
  'Competitive':         { bg: '#dbeafe', text: '#1e40af' },
  'Data Gathering':      { bg: '#f3e8ff', text: '#6b21a8' },
  'Clinical Expertise':  { bg: '#d1fae5', text: '#065f46' },
  'Influencing':         { bg: '#fce7f3', text: '#9d174d' },
  'Problem Solving':     { bg: '#ffedd5', text: '#9a3412' },
  'Cross-functional':    { bg: '#e0f2fe', text: '#0369a1' },
  'Cross-functional Collaboration': { bg: '#e0f2fe', text: '#0369a1' },
};

function SkillTag({ label }) {
  const c = TAG_COLORS[label] || { bg: '#f3f4f6', text: '#374151' };
  return (
    <span style={{
      display: 'inline-flex', padding: '2px 8px', borderRadius: 4,
      background: c.bg, color: c.text, fontSize: 11, fontWeight: 600,
      whiteSpace: 'nowrap', border: `1px solid ${c.text}22`,
    }}>
      {label}
    </span>
  );
}

const scoreStyle = (s) => {
  if (s === 1) return { bg: '#fecaca', text: '#991b1b' };
  if (s === 2) return { bg: '#fed7aa', text: '#9a3412' };
  return { bg: '#bbf7d0', text: '#14532d' };
};

// ── PINS Section card ──────────────────────────────────────────────────────────
function PINSCard({ item }) {
  return (
    <div style={{
      background: '#fff',
      border: '1px solid #e5e7eb',
      borderRadius: 8,
      marginBottom: 14,
      overflow: 'hidden',
    }}>
      {/* Title row */}
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '14px 18px 10px' }}>
        <div style={{
          width: 30, height: 30, borderRadius: '50%',
          background: '#c41230', color: '#fff',
          fontWeight: 800, fontSize: 14,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          {item.letter}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111827', marginBottom: 4 }}>
            {item.title}
          </div>
          <div style={{ fontSize: 12, color: '#6b7280', lineHeight: 1.6 }}>
            {item.description}
          </div>
        </div>
      </div>

      {/* Behaviours label */}
      <div style={{ padding: '0 18px 6px 18px' }}>
        <div style={{
          fontSize: 9.5, fontWeight: 700, color: '#9ca3af',
          textTransform: 'uppercase', letterSpacing: '0.07em',
          borderTop: '1px solid #f3f4f6', paddingTop: 10, marginBottom: 10,
        }}>
          Observable Behaviours Rated in This Section · With the Skill(s) Each Behaviour Maps To
        </div>

        {/* Behaviour rows */}
        {item.behaviours.map((b, bi) => (
          <div key={bi} style={{ display: 'flex', gap: 10, marginBottom: 12 }}>
            {/* Number circle */}
            <div style={{
              width: 22, height: 22, borderRadius: '50%',
              background: '#f9fafb', border: '1px solid #e5e7eb',
              color: '#6b7280', fontSize: 11, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, marginTop: 1,
            }}>
              {bi + 1}
            </div>
            <div>
              <div style={{ fontSize: 12.5, color: '#1f2937', lineHeight: 1.55, marginBottom: 5 }}>
                {b.text}
              </div>
              <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                {b.skills.map(s => <SkillTag key={s} label={s} />)}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Strength / Opportunity footer */}
      <div style={{ display: 'grid', gridTemplateColumns: item.hasOpportunity ? '1fr 1fr' : '1fr', borderTop: '1px solid #f0f0f0' }}>
        <div style={{ padding: '10px 18px', borderRight: item.hasOpportunity ? '1px solid #f0f0f0' : 'none', background: '#f9fef9' }}>
          <div style={{ fontSize: 9, fontWeight: 800, color: '#059669', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 3 }}>
            Strength Looks Like
          </div>
          <div style={{ fontSize: 11.5, color: '#374151' }}>Specific evidence, behaviours observed, examples.</div>
        </div>
        {item.hasOpportunity && (
          <div style={{ padding: '10px 18px', background: '#fffdf5' }}>
            <div style={{ fontSize: 9, fontWeight: 800, color: '#d97706', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 3 }}>
              Opportunity Looks Like
            </div>
            <div style={{ fontSize: 11.5, color: '#374151' }}>Gap with concrete next-step recommendation.</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────────
export default function ReferencePage() {
  return (
    <>
      {/* Page header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 6 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: '#111827' }}>Reference</h1>
          <p style={{ fontSize: 13, color: '#6b7280', marginTop: 3 }}>
            The <strong>PINS</strong> framework, the <strong>7 FBMS</strong> skills, and the proficiency-by-level matrix
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#6b7280' }}>
            <RefreshCw size={11} color="#16a34a" />
            Synced from iConnect · 4h ago
          </div>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 12px', border: '1px solid #e5e7eb', borderRadius: 6, background: '#fff', fontSize: 12, fontWeight: 600, color: '#374151', cursor: 'pointer', fontFamily: 'inherit' }}>
            <Download size={12} /> Export <span style={{ fontSize: 10 }}>▾</span>
          </button>
        </div>
      </div>

      {/* ── PINS Framework container ── */}
      <div style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 10, padding: '16px 18px', marginBottom: 14 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span style={{ fontSize: 16 }}>📋</span>
          <span style={{ fontSize: 15, fontWeight: 800, color: '#111827' }}>PINS Framework</span>
        </div>
        <p style={{ fontSize: 12, color: '#6b7280', lineHeight: 1.7, marginBottom: 16 }}>
          Each Field Coaching Report is structured around four reflection sections,{' '}
          <strong style={{ color: '#374151' }}>Planning for Perspective</strong>,{' '}
          <strong style={{ color: '#374151' }}>Investigate Issues</strong>,{' '}
          <strong style={{ color: '#374151' }}>Navigate &amp; Negotiate Needs</strong>,{' '}
          <strong style={{ color: '#374151' }}>Secure Action</strong>, and every observable behaviour
          question inside a section maps back to one or more of the 7 FBMS skills.
        </p>

        {/* 4 PINS cards */}
        {PINS.map(item => <PINSCard key={item.letter} item={item} />)}
      </div>

      {/* ── 7 FBMS Core Skills ── */}
      <div id="fbms-skills" style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 10, padding: '16px 18px', marginBottom: 14 }}>
        <div style={{ fontSize: 15, fontWeight: 800, color: '#111827', marginBottom: 2 }}>The 7 FBMS Core Skills</div>
        <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 14 }}>Linked to the iConnect skill taxonomy</div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {FBMS_SKILLS.map(skill => (
            <div key={skill.name} style={{ border: '1px solid #e5e7eb', borderRadius: 8, padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>{skill.name}</span>
                <span style={{ fontSize: 9, fontWeight: 800, background: '#fee2e2', color: '#c41230', padding: '2px 7px', borderRadius: 4, textTransform: 'uppercase', letterSpacing: '0.06em', flexShrink: 0, marginLeft: 8 }}>Skill</span>
              </div>
              <div style={{ fontSize: 9, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Observable Behaviors</div>
              {skill.behaviors.map((b, i) => (
                <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 5 }}>
                  <span style={{ color: '#c41230', flexShrink: 0, marginTop: '1px' }}>•</span>
                  <span style={{ fontSize: 12, color: '#374151', lineHeight: 1.5 }}>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* ── Proficiency by Job Level ── */}
      <div id="proficiency-table" style={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 10, padding: '16px 18px', marginBottom: 14 }}>
        <div style={{ fontSize: 15, fontWeight: 800, color: '#111827', marginBottom: 3 }}>Proficiency Required by Job Level</div>
        <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 14 }}>
          1 = Awareness · 2 = Skilled · 3 = Advanced (per JNJ ACR rubric)
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', padding: '8px 14px', background: '#f9fafb', borderBottom: '2px solid #e5e7eb', fontSize: 11, fontWeight: 700, color: '#6b7280', whiteSpace: 'nowrap' }}>Job Level</th>
                {SKILL_COLS.map(col => (
                  <th key={col} style={{ textAlign: 'center', padding: '8px 10px', background: '#f9fafb', borderBottom: '2px solid #e5e7eb', fontSize: 10, fontWeight: 700, color: '#6b7280', whiteSpace: 'nowrap' }}>{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PROFICIENCY_ROWS.map((row, ri) => (
                <tr key={ri}>
                  <td style={{ padding: '9px 14px', borderBottom: '1px solid #f3f4f6', fontWeight: 600, color: '#111827', whiteSpace: 'nowrap' }}>{row.level}</td>
                  {row.scores.map((score, si) => {
                    const c = scoreStyle(score);
                    return (
                      <td key={si} style={{ padding: '7px 10px', borderBottom: '1px solid #f3f4f6', textAlign: 'center' }}>
                        <span style={{
                          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                          width: 34, height: 26, borderRadius: 6,
                          background: c.bg, color: c.text, fontWeight: 700, fontSize: 13,
                        }}>
                          {score}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Legend */}
        <div style={{ display: 'flex', gap: 14, marginTop: 14, flexWrap: 'wrap' }}>
          {[{ s: 1, label: 'Awareness' }, { s: 2, label: 'Skilled' }, { s: 3, label: 'Advanced' }].map(({ s, label }) => {
            const c = scoreStyle(s);
            return (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6b7280' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 20, borderRadius: 4, background: c.bg, color: c.text, fontWeight: 700, fontSize: 11 }}>{s}</span>
                {label}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
