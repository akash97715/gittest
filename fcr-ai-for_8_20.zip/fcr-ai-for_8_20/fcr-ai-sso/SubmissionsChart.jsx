import { useState } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from 'recharts';
import { submissionsMonthly } from '../data/mockData';
import { Download } from 'lucide-react';


const SERIES = [
  { key: 'Oncology',      color: '#c41230' },
  { key: 'Immunology',    color: '#2563eb' },
  { key: 'Neuroscience',  color: '#7c3aed' },
  { key: 'Cardiovascular',color: '#059669' },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8,
      padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
      fontFamily: 'inherit', fontSize: 12,
    }}>
      <div style={{ fontWeight: 700, marginBottom: 6, color: '#1a1a2e' }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
          <span style={{ width: 8, height: 8, borderRadius: 2, background: p.color, display: 'inline-block' }} />
          <span style={{ color: '#6b7280' }}>{p.name}:</span>
          <span style={{ fontWeight: 600, color: '#1a1a2e' }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function SubmissionsChart() {
  const [hiddenSeries, setHiddenSeries] = useState({});

  const toggleSeries = (key) => {
    setHiddenSeries(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="section-card">
      <div className="section-card-header">
        <div>
          <div className="section-card-title">Submissions Over Time</div>
          <div className="section-card-sub">Monthly FCR submissions by therapeutic area</div>
        </div>
        <div className="section-card-actions">
          <button id="btn-export-chart" className="btn btn-outline">
            <Download size={12} /> Export
          </button>
        </div>
      </div>

      {/* Custom Legend (clickable) */}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', padding: '10px 20px 0' }}>
        {SERIES.map(s => (
          <button
            key={s.key}
            id={`legend-${s.key.toLowerCase()}`}
            onClick={() => toggleSeries(s.key)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: 'inherit', fontSize: 12, fontWeight: 500,
              color: hiddenSeries[s.key] ? '#9ca3af' : '#374151',
              opacity: hiddenSeries[s.key] ? 0.5 : 1,
              transition: 'opacity 0.2s',
            }}
            aria-label={`Toggle ${s.key} series`}
          >
            <span style={{ width: 10, height: 10, borderRadius: 2, background: s.color, display: 'inline-block' }} />
            {s.key}
          </button>
        ))}
      </div>

      <div className="section-card-body chart-container">
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={submissionsMonthly} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
            <defs>
              {SERIES.map(s => (
                <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor={s.color} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={s.color} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            {SERIES.map(s => (
              !hiddenSeries[s.key] && (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  stroke={s.color}
                  strokeWidth={2}
                  fill={`url(#grad-${s.key})`}
                  dot={false}
                  activeDot={{ r: 4, strokeWidth: 2 }}
                />
              )
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
