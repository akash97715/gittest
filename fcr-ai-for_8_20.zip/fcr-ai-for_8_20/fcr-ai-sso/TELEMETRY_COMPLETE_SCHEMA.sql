-- ════════════════════════════════════════════════════════════════════════════════
-- TELEMETRY DATABASE SCHEMA - ALL TABLES
-- Amazon Redshift + Apache Kafka
-- ════════════════════════════════════════════════════════════════════════════════

-- Create telemetry schema
CREATE SCHEMA IF NOT EXISTS telemetry;

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 1: user_events (Raw Event Log - All User Actions)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.user_events (
    event_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    -- Identifiers
    session_id VARCHAR(100) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    -- Event Details
    event_type VARCHAR(50) NOT NULL,
    event_data SUPER,
    page VARCHAR(100),
    url VARCHAR(2048),
    
    -- Timestamps
    timestamp TIMESTAMP DEFAULT GETDATE(),
    
    -- Kafka Tracking (New)
    kafka_topic VARCHAR(100),
    kafka_partition INT,
    kafka_offset BIGINT,
    processed_at TIMESTAMP,
    
    CONSTRAINT event_type_check CHECK (event_type IN (
        'user_login', 'user_logout', 'page_view', 'page_exit',
        'button_click', 'search', 'data_export', 'api_call',
        'error', 'session_start', 'session_end', 'custom'
    ))
)
DISTKEY (user_id)
SORTKEY (timestamp DESC);

-- Indexes
CREATE INDEX idx_user_events_user_id ON telemetry.user_events (user_id);
CREATE INDEX idx_user_events_session_id ON telemetry.user_events (session_id);
CREATE INDEX idx_user_events_event_type ON telemetry.user_events (event_type);
CREATE INDEX idx_user_events_timestamp ON telemetry.user_events (timestamp);
CREATE INDEX idx_user_events_page ON telemetry.user_events (page);
CREATE INDEX idx_user_events_user_timestamp ON telemetry.user_events (user_id, timestamp DESC);
CREATE INDEX idx_user_events_kafka_offset ON telemetry.user_events (kafka_offset);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 2: user_sessions (Aggregated - One Row Per Session)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.user_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    session_start TIMESTAMP,
    session_end TIMESTAMP,
    duration_seconds INT,
    
    event_count INT DEFAULT 0,
    page_views INT DEFAULT 0,
    button_clicks INT DEFAULT 0,
    errors_count INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
)
DISTKEY (user_id)
SORTKEY (session_start DESC);

-- Indexes
CREATE INDEX idx_user_sessions_user_id ON telemetry.user_sessions (user_id);
CREATE INDEX idx_user_sessions_session_start ON telemetry.user_sessions (session_start DESC);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 3: daily_usage_summary (Daily KPI Rollups)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.daily_usage_summary (
    usage_date DATE PRIMARY KEY,
    
    active_users INT,
    total_sessions INT,
    total_events INT,
    total_page_views INT,
    total_button_clicks INT,
    total_logins INT,
    total_errors INT,
    
    avg_session_duration_seconds DECIMAL(10, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
)
SORTKEY (usage_date DESC);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 4: page_analytics (Page Performance By Date)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.page_analytics (
    page_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    page_name VARCHAR(100),
    analytics_date DATE,
    
    view_count INT DEFAULT 0,
    unique_visitors INT DEFAULT 0,
    avg_time_spent_seconds DECIMAL(10, 2),
    bounce_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
)
DISTKEY (page_name)
SORTKEY (analytics_date DESC);

-- Indexes
CREATE INDEX idx_page_analytics_page_date ON telemetry.page_analytics (page_name, analytics_date DESC);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 5: button_analytics (Feature Adoption By Date)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.button_analytics (
    button_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    button_name VARCHAR(255),
    page_name VARCHAR(100),
    analytics_date DATE,
    
    click_count INT DEFAULT 0,
    unique_users INT DEFAULT 0,
    adoption_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
)
DISTKEY (button_name)
SORTKEY (analytics_date DESC);

-- Indexes
CREATE INDEX idx_button_analytics_button_page_date ON telemetry.button_analytics (button_name, page_name, analytics_date DESC);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 6: kafka_event_tracking (Deduplication & Idempotency)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.kafka_event_tracking (
    dedup_id VARCHAR(255) PRIMARY KEY,
    
    kafka_topic VARCHAR(100),
    kafka_partition INT,
    kafka_offset BIGINT,
    
    event_id BIGINT,
    session_id VARCHAR(100),
    user_id VARCHAR(100),
    
    processing_status VARCHAR(50),
    processed_at TIMESTAMP,
    error_message VARCHAR(1000),
    
    created_at TIMESTAMP DEFAULT GETDATE(),
    updated_at TIMESTAMP DEFAULT GETDATE()
)
DISTKEY (user_id)
SORTKEY (created_at DESC);

-- Indexes
CREATE INDEX idx_dedup_id ON telemetry.kafka_event_tracking (dedup_id);
CREATE INDEX idx_kafka_offset ON telemetry.kafka_event_tracking (kafka_partition, kafka_offset);
CREATE INDEX idx_processing_status ON telemetry.kafka_event_tracking (processing_status);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 7: kafka_consumer_offsets (Consumer Group State & Recovery)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.kafka_consumer_offsets (
    consumer_group_id VARCHAR(100),
    topic_name VARCHAR(100),
    partition_id INT,
    
    last_committed_offset BIGINT,
    last_committed_timestamp TIMESTAMP,
    
    lag_events INT,
    consumer_instance VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT GETDATE(),
    updated_at TIMESTAMP DEFAULT GETDATE(),
    
    PRIMARY KEY (consumer_group_id, topic_name, partition_id)
)
DISTKEY (consumer_group_id)
SORTKEY (updated_at DESC);

-- Indexes
CREATE INDEX idx_consumer_lag ON telemetry.kafka_consumer_offsets (consumer_group_id, lag_events);

-- ════════════════════════════════════════════════════════════════════════════════
-- TABLE 8: event_processing_status (Pipeline Observability & Debugging)
-- ════════════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS telemetry.event_processing_status (
    event_tracking_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    event_id BIGINT,
    dedup_id VARCHAR(255),
    
    stage VARCHAR(50),
    stage_status VARCHAR(50),
    
    timestamp_received TIMESTAMP,
    timestamp_validated TIMESTAMP,
    timestamp_stored TIMESTAMP,
    timestamp_aggregated TIMESTAMP,
    timestamp_archived TIMESTAMP,
    
    processing_duration_ms INT,
    error_details VARCHAR(1000),
    
    created_at TIMESTAMP DEFAULT GETDATE()
)
DISTKEY (dedup_id)
SORTKEY (created_at DESC);

-- Indexes
CREATE INDEX idx_event_stage ON telemetry.event_processing_status (stage, stage_status);
CREATE INDEX idx_processing_duration ON telemetry.event_processing_status (processing_duration_ms DESC);

-- ════════════════════════════════════════════════════════════════════════════════
-- SUMMARY: ALL TABLES
-- ════════════════════════════════════════════════════════════════════════════════

/*

TABLE 1: user_events (Raw Event Log)
──────────────────────────────────────
Columns:
  - event_id (PK)
  - session_id, user_id, user_name, user_email
  - event_type, event_data, page, url
  - timestamp
  - kafka_topic, kafka_partition, kafka_offset, processed_at
Storage: ~2.5GB (450K rows × 90 days)
Purpose: Complete audit log of all events

TABLE 2: user_sessions (Session Aggregates)
─────────────────────────────────────────────
Columns:
  - session_id (PK)
  - user_id, user_name, user_email
  - session_start, session_end, duration_seconds
  - event_count, page_views, button_clicks, errors_count
  - created_at
Storage: ~50MB (15K sessions × 90 days)
Purpose: Fast session queries

TABLE 3: daily_usage_summary (Daily KPIs)
───────────────────────────────────────────
Columns:
  - usage_date (PK)
  - active_users, total_sessions, total_events
  - total_page_views, total_button_clicks, total_logins, total_errors
  - avg_session_duration_seconds
  - created_at
Storage: ~1MB (90 rows)
Purpose: Sub-100ms dashboard queries

TABLE 4: page_analytics (Page Performance)
───────────────────────────────────────────
Columns:
  - page_id (PK)
  - page_name, analytics_date
  - view_count, unique_visitors
  - avg_time_spent_seconds, bounce_rate
  - created_at
Storage: ~5MB (360 rows: 4 pages × 90 days)
Purpose: Track which pages engage users

TABLE 5: button_analytics (Feature Adoption)
──────────────────────────────────────────────
Columns:
  - button_id (PK)
  - button_name, page_name, analytics_date
  - click_count, unique_users, adoption_rate
  - created_at
Storage: ~15MB (1,800 rows: 20 buttons × 90 days)
Purpose: Track which features users adopt

TABLE 6: kafka_event_tracking (Deduplication)
──────────────────────────────────────────────
Columns:
  - dedup_id (PK)
  - kafka_topic, kafka_partition, kafka_offset
  - event_id, session_id, user_id
  - processing_status, processed_at, error_message
  - created_at, updated_at
Storage: ~100MB (450K rows)
Purpose: Exactly-once processing, prevent duplicates

TABLE 7: kafka_consumer_offsets (Consumer State)
─────────────────────────────────────────────────
Columns:
  - consumer_group_id, topic_name, partition_id (PK)
  - last_committed_offset, last_committed_timestamp
  - lag_events, consumer_instance
  - created_at, updated_at
Storage: ~1MB (3 consumer groups × 3 partitions × 3 days)
Purpose: Consumer recovery, lag tracking

TABLE 8: event_processing_status (Pipeline Observability)
──────────────────────────────────────────────────────────
Columns:
  - event_tracking_id (PK)
  - event_id, dedup_id
  - stage, stage_status
  - timestamp_received, timestamp_validated, timestamp_stored
  - timestamp_aggregated, timestamp_archived
  - processing_duration_ms, error_details
  - created_at
Storage: ~100MB (450K rows)
Purpose: Track event journey, debug latency

TOTAL STORAGE: ~2.7GB
RETENTION: 90 days hot, archive older data to blob storage

*/

-- ════════════════════════════════════════════════════════════════════════════════
-- END OF SCHEMA
-- ════════════════════════════════════════════════════════════════════════════════
