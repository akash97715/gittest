/**
 * Telemetry Database Schema
 * Run this SQL in Redshift to set up telemetry tables
 */

const telemetrySchema = `
-- ════════════════════════════════════════════════════════════════
-- TELEMETRY SCHEMA & TABLES
-- ════════════════════════════════════════════════════════════════

-- Create telemetry schema
CREATE SCHEMA IF NOT EXISTS telemetry;

-- ────────────────────────────────────────────────────────────────
-- Table: user_events
-- Stores all user interaction events
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS telemetry.user_events (
    event_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    -- Session & User Info
    session_id VARCHAR(100) NOT NULL,
    user_id VARCHAR(100),
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    -- Event Details
    event_type VARCHAR(50) NOT NULL,  -- 'page_view', 'button_click', 'error', etc.
    event_data VARCHAR(MAX),           -- JSON data (use SUPER for native JSON in Redshift)
    page VARCHAR(100),                 -- Current page/route
    url VARCHAR(2048),                 -- Full URL
    
    -- Timestamps
    timestamp TIMESTAMP DEFAULT GETDATE(),
    
    -- Indexes for queries
    CONSTRAINT event_type_check CHECK (event_type IN (
        'user_login', 'user_logout', 'page_view', 'page_exit',
        'button_click', 'search', 'data_export', 'api_call',
        'error', 'session_start', 'session_end', 'custom'
    ))
);

-- Create indexes for common queries
CREATE INDEX idx_user_events_user_id ON telemetry.user_events (user_id);
CREATE INDEX idx_user_events_session_id ON telemetry.user_events (session_id);
CREATE INDEX idx_user_events_event_type ON telemetry.user_events (event_type);
CREATE INDEX idx_user_events_timestamp ON telemetry.user_events (timestamp);
CREATE INDEX idx_user_events_page ON telemetry.user_events (page);
CREATE INDEX idx_user_events_user_timestamp ON telemetry.user_events (user_id, timestamp DESC);

-- ────────────────────────────────────────────────────────────────
-- Table: user_sessions
-- Aggregated session information
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS telemetry.user_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    session_start TIMESTAMP,
    session_end TIMESTAMP,
    duration_seconds INT,
    
    event_count INT DEFAULT 0,
    page_views INT DEFAULT 0,
    button_clicks INT DEFAULT 0,
    errors_count INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
);

CREATE INDEX idx_user_sessions_user_id ON telemetry.user_sessions (user_id);
CREATE INDEX idx_user_sessions_session_start ON telemetry.user_sessions (session_start DESC);

-- ────────────────────────────────────────────────────────────────
-- Table: daily_usage_summary
-- Daily aggregated usage statistics
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS telemetry.daily_usage_summary (
    usage_date DATE PRIMARY KEY,
    
    active_users INT,
    total_sessions INT,
    total_events INT,
    total_page_views INT,
    total_button_clicks INT,
    total_logins INT,
    total_errors INT,
    
    avg_session_duration_seconds DECIMAL(10, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);

-- ────────────────────────────────────────────────────────────────
-- Table: page_analytics
-- Page-level analytics
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS telemetry.page_analytics (
    page_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    page_name VARCHAR(100),
    analytics_date DATE,
    
    view_count INT DEFAULT 0,
    unique_visitors INT DEFAULT 0,
    avg_time_spent_seconds DECIMAL(10, 2),
    bounce_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);

CREATE INDEX idx_page_analytics_page_date ON telemetry.page_analytics (page_name, analytics_date DESC);

-- ────────────────────────────────────────────────────────────────
-- Table: button_analytics
-- Button click analytics
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS telemetry.button_analytics (
    button_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    button_name VARCHAR(255),
    page_name VARCHAR(100),
    analytics_date DATE,
    
    click_count INT DEFAULT 0,
    unique_users INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
);

CREATE INDEX idx_button_analytics_button_page_date ON telemetry.button_analytics (button_name, page_name, analytics_date DESC);

-- ════════════════════════════════════════════════════════════════
-- TELEMETRY DATA RETENTION POLICY
-- ════════════════════════════════════════════════════════════════

-- Archive old events (keep 90 days in active table, older data in archive)
-- Can be implemented as a scheduled task/lambda

-- Example: Delete events older than 90 days
-- DELETE FROM telemetry.user_events WHERE timestamp < DATEADD(day, -90, GETDATE());

-- Redshift supports distkey and sortkey for optimization:
ALTER TABLE telemetry.user_events 
  DISTKEY (user_id)
  SORTKEY (timestamp DESC);

ALTER TABLE telemetry.user_sessions 
  DISTKEY (user_id)
  SORTKEY (session_start DESC);

-- ════════════════════════════════════════════════════════════════
-- VIEWS FOR REPORTING
-- ════════════════════════════════════════════════════════════════

-- User Activity View
CREATE OR REPLACE VIEW telemetry.v_user_activity AS
SELECT 
    user_id,
    user_name,
    user_email,
    COUNT(DISTINCT session_id) as session_count,
    COUNT(*) as event_count,
    COUNT(DISTINCT DATE(timestamp)) as active_days,
    MAX(timestamp) as last_activity,
    COUNT(CASE WHEN event_type = 'button_click' THEN 1 END) as total_clicks,
    COUNT(CASE WHEN event_type = 'page_view' THEN 1 END) as total_pages,
    COUNT(CASE WHEN event_type = 'error' THEN 1 END) as total_errors
FROM telemetry.user_events
WHERE timestamp >= DATEADD(day, -30, GETDATE())
GROUP BY user_id, user_name, user_email;

-- Page Performance View
CREATE OR REPLACE VIEW telemetry.v_page_performance AS
SELECT 
    page,
    COUNT(*) as page_views,
    COUNT(DISTINCT session_id) as unique_sessions,
    COUNT(DISTINCT user_id) as unique_users,
    ROUND(AVG(CAST(event_data->>'timeSpentSeconds' AS FLOAT)), 2) as avg_time_seconds,
    MIN(timestamp) as first_view,
    MAX(timestamp) as last_view
FROM telemetry.user_events
WHERE event_type = 'page_view'
    AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY page;

-- Most Used Features View
CREATE OR REPLACE VIEW telemetry.v_most_used_features AS
SELECT 
    CAST(event_data->>'button' AS VARCHAR) as feature_name,
    CAST(event_data->>'page' AS VARCHAR) as page,
    COUNT(*) as usage_count,
    COUNT(DISTINCT user_id) as unique_users,
    MAX(timestamp) as last_used
FROM telemetry.user_events
WHERE event_type = 'button_click'
    AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY CAST(event_data->>'button' AS VARCHAR), CAST(event_data->>'page' AS VARCHAR)
ORDER BY usage_count DESC;
`;

console.log(telemetrySchema);
