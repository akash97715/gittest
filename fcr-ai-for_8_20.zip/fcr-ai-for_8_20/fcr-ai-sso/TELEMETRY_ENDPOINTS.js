#!/usr/bin/env node
/**
 * Telemetry Service - Backend API Endpoints
 * Receives telemetry events from frontend and stores in database
 */

const telemetryEndpoints = `
// ────────────────────────────────────────────────────────────────
// TELEMETRY ENDPOINTS (add to server.js)
// ────────────────────────────────────────────────────────────────

// POST /api/telemetry — Receive telemetry events from frontend
app.post('/api/telemetry', async (req, res) => {
  try {
    const { events, batchCount, timestamp } = req.body;
    
    if (!events || !Array.isArray(events)) {
      return res.status(400).json({ error: 'Invalid events format' });
    }

    // Insert events into database
    for (const event of events) {
      try {
        await pool.query(
          \`INSERT INTO telemetry.user_events 
            (session_id, user_id, user_name, user_email, event_type, event_data, page, url, timestamp)
           VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $8, $9)\`,
          [
            event.sessionId,
            event.userId,
            event.userName,
            event.userEmail,
            event.eventType,
            JSON.stringify(event.eventData),
            event.eventData?.page || null,
            event.url,
            event.timestamp || new Date().toISOString(),
          ]
        );
      } catch (err) {
        console.error('Failed to insert telemetry event:', err.message);
        // Don't fail the entire batch if one event fails
      }
    }

    res.json({
      success: true,
      eventsReceived: events.length,
      message: \`Received \${batchCount || events.length} telemetry events\`,
    });
  } catch (error) {
    console.error('/api/telemetry error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/user-sessions — Get user sessions
app.get('/api/telemetry/user-sessions', async (req, res) => {
  try {
    const { days = 7, limit = 50 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        session_id,
        user_id,
        user_name,
        user_email,
        MIN(timestamp) as session_start,
        MAX(timestamp) as session_end,
        COUNT(*) as event_count,
        COUNT(DISTINCT event_type) as event_types,
        MAX(EXTRACT(EPOCH FROM (MAX(timestamp) - MIN(timestamp)))) as duration_seconds
      FROM telemetry.user_events
      WHERE timestamp >= NOW() - INTERVAL '\${days} days'
      GROUP BY session_id, user_id, user_name, user_email
      ORDER BY session_start DESC
      LIMIT \${limit}\`
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('/api/telemetry/user-sessions error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/user/:userId — Get user activity summary
app.get('/api/telemetry/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { days = 30 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        user_id,
        user_name,
        user_email,
        COUNT(DISTINCT session_id) as total_sessions,
        COUNT(*) as total_events,
        COUNT(DISTINCT event_type) as unique_event_types,
        COUNT(DISTINCT DATE(timestamp)) as active_days,
        MIN(timestamp) as first_activity,
        MAX(timestamp) as last_activity,
        COUNT(CASE WHEN event_type = 'user_login' THEN 1 END) as login_count,
        COUNT(CASE WHEN event_type = 'page_view' THEN 1 END) as page_views,
        COUNT(CASE WHEN event_type = 'button_click' THEN 1 END) as button_clicks,
        COUNT(CASE WHEN event_type = 'error' THEN 1 END) as error_count
      FROM telemetry.user_events
      WHERE user_id = $1
        AND timestamp >= NOW() - INTERVAL '\${days} days'
      GROUP BY user_id, user_name, user_email\`,
      [userId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found in telemetry' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('/api/telemetry/user/:userId error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/page-analytics — Get page view analytics
app.get('/api/telemetry/page-analytics', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        page,
        COUNT(*) as page_views,
        COUNT(DISTINCT session_id) as unique_sessions,
        COUNT(DISTINCT user_id) as unique_users,
        ROUND(AVG((event_data->>'timeSpentSeconds')::float), 2) as avg_time_spent_seconds
      FROM telemetry.user_events
      WHERE page IS NOT NULL
        AND timestamp >= NOW() - INTERVAL '\${days} days'
      GROUP BY page
      ORDER BY page_views DESC\`
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('/api/telemetry/page-analytics error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/button-clicks — Most clicked buttons
app.get('/api/telemetry/button-clicks', async (req, res) => {
  try {
    const { days = 7, limit = 20 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        event_data->>'button' as button_name,
        event_data->>'page' as page,
        COUNT(*) as click_count,
        COUNT(DISTINCT session_id) as unique_sessions,
        COUNT(DISTINCT user_id) as unique_users
      FROM telemetry.user_events
      WHERE event_type = 'button_click'
        AND timestamp >= NOW() - INTERVAL '\${days} days'
      GROUP BY event_data->>'button', event_data->>'page'
      ORDER BY click_count DESC
      LIMIT \${limit}\`
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('/api/telemetry/button-clicks error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/errors — Application errors
app.get('/api/telemetry/errors', async (req, res) => {
  try {
    const { days = 7, limit = 50 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        timestamp,
        user_id,
        user_name,
        page,
        event_data->>'message' as error_message,
        COUNT(*) as occurrence_count
      FROM telemetry.user_events
      WHERE event_type = 'error'
        AND timestamp >= NOW() - INTERVAL '\${days} days'
      GROUP BY timestamp, user_id, user_name, page, event_data->>'message'
      ORDER BY timestamp DESC
      LIMIT \${limit}\`
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('/api/telemetry/errors error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/usage-summary — Overall usage dashboard
app.get('/api/telemetry/usage-summary', async (req, res) => {
  try {
    const { days = 30 } = req.query;
    
    const result = await pool.query(
      \`SELECT 
        COUNT(DISTINCT user_id) as active_users,
        COUNT(DISTINCT session_id) as total_sessions,
        COUNT(*) as total_events,
        COUNT(DISTINCT DATE(timestamp)) as active_days,
        COUNT(CASE WHEN event_type = 'user_login' THEN 1 END) as total_logins,
        ROUND(AVG(
          CASE WHEN event_type = 'session_end' 
          THEN (event_data->>'totalSessionDurationSeconds')::float 
          END
        ), 2) as avg_session_duration_seconds,
        COUNT(CASE WHEN event_type = 'error' THEN 1 END) as total_errors
      FROM telemetry.user_events
      WHERE timestamp >= NOW() - INTERVAL '\${days} days'\`
    );
    
    res.json({
      timeframe: \`Last \${days} days\`,
      ...result.rows[0],
    });
  } catch (error) {
    console.error('/api/telemetry/usage-summary error:', error.message);
    res.status(500).json({ error: error.message });
  }
});
`;

console.log(telemetryEndpoints);
