/**
 * TELEMETRY EVENTS REFERENCE
 * 
 * Comprehensive list of all events captured by the telemetry system
 * with examples and purpose
 */

# Telemetry Events Reference Guide

## Event Types Overview

The telemetry system captures 12 different event types across 3 categories:

### 1. Session & Authentication Events
- `user_login` - User logs into the application
- `session_start` - Session begins (after login)
- `session_end` - Session ends (logout or timeout)

### 2. Navigation & Interaction Events
- `page_view` - User navigates to a page
- `page_exit` - User leaves a page
- `button_click` - User clicks a button or interactive element
- `search` - User performs search or applies filters
- `data_export` - User exports data (PDF, CSV, etc.)

### 3. Performance & Error Events
- `api_call` - Backend API is called
- `error` - Application error occurs
- `custom` - Custom application events

---

## Detailed Event Specifications

### 1. USER_LOGIN

**When:** User successfully authenticates

**Data Captured:**
```json
{
  "eventType": "user_login",
  "userId": "user-12345",
  "userName": "John Doe",
  "userEmail": "john.doe@jnj.com",
  "sessionId": "session_1234567890_abc123",
  "timestamp": "2026-08-13T09:30:00Z",
  "page": "login",
  "eventData": {
    "authMethod": "azure-ad",
    "loginDuration": 2.5
  }
}
```

**Why We Track It:**
- ✅ Count daily active users (DAU)
- ✅ Track login trends over time
- ✅ Identify access patterns
- ✅ Compliance & audit requirements

**Example Query:**
```sql
SELECT COUNT(DISTINCT user_id) as daily_active_users
FROM telemetry.user_events
WHERE event_type = 'user_login'
  AND DATE(timestamp) = CURRENT_DATE;
```

---

### 2. SESSION_START

**When:** Session begins (usually right after login)

**Data Captured:**
```json
{
  "eventType": "session_start",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "timestamp": "2026-08-13T09:30:05Z",
  "eventData": {
    "browserAgent": "Mozilla/5.0...",
    "ipAddress": "192.168.1.1",
    "deviceType": "desktop"
  }
}
```

**Why We Track It:**
- ✅ Track session count
- ✅ Device & browser insights
- ✅ Geographic distribution (via IP)
- ✅ User session metrics

---

### 3. SESSION_END

**When:** User logs out or session times out

**Data Captured:**
```json
{
  "eventType": "session_end",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "timestamp": "2026-08-13T10:45:00Z",
  "eventData": {
    "durationSeconds": 4500,
    "eventCount": 42,
    "lastPage": "dashboard"
  }
}
```

**Why We Track It:**
- ✅ Calculate session duration
- ✅ Track user engagement
- ✅ Count total events per session
- ✅ Identify session churn

**Example Query:**
```sql
SELECT 
  user_id,
  AVG(CAST(eventData->>'durationSeconds' AS FLOAT)) as avg_session_duration
FROM telemetry.user_events
WHERE event_type = 'session_end'
GROUP BY user_id;
```

---

### 4. PAGE_VIEW

**When:** User navigates to a new page

**Data Captured:**
```json
{
  "eventType": "page_view",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:35:00Z",
  "url": "https://app.example.com/fcrs?filter=open",
  "eventData": {
    "pageName": "FCRs",
    "pageTitle": "FCRs",
    "referrer": "dashboard"
  }
}
```

**Why We Track It:**
- ✅ Track most visited pages
- ✅ Calculate pages per session
- ✅ Identify navigation patterns
- ✅ UX analysis (page flow)

**Example Query:**
```sql
SELECT 
  page,
  COUNT(*) as page_views,
  COUNT(DISTINCT user_id) as unique_users
FROM telemetry.user_events
WHERE event_type = 'page_view'
  AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY page
ORDER BY page_views DESC;
```

---

### 5. PAGE_EXIT

**When:** User leaves a page (but stays in session)

**Data Captured:**
```json
{
  "eventType": "page_exit",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:42:30Z",
  "eventData": {
    "timeOnPageSeconds": 450,
    "nextPage": "dashboard",
    "interactionCount": 8
  }
}
```

**Why We Track It:**
- ✅ Calculate time spent per page
- ✅ Identify bounce pages
- ✅ Track navigation flow
- ✅ UX improvements (which pages users abandon)

---

### 6. BUTTON_CLICK

**When:** User clicks on any interactive button

**Data Captured:**
```json
{
  "eventType": "button_click",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:40:00Z",
  "eventData": {
    "button": "export_pdf",
    "context": {
      "selectedCount": 5,
      "exportFormat": "pdf"
    }
  }
}
```

**Why We Track It:**
- ✅ Track feature adoption
- ✅ Identify most-used features
- ✅ Find unused features (deprecation candidates)
- ✅ User behavior insights

**Example Query:**
```sql
SELECT 
  eventData->>'button' as feature,
  COUNT(*) as click_count,
  COUNT(DISTINCT user_id) as unique_users
FROM telemetry.user_events
WHERE event_type = 'button_click'
  AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY eventData->>'button'
ORDER BY click_count DESC
LIMIT 20;
```

---

### 7. SEARCH

**When:** User performs a search or applies filters

**Data Captured:**
```json
{
  "eventType": "search",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:38:00Z",
  "eventData": {
    "searchTerm": "john doe",
    "filters": {
      "status": "open",
      "region": "north",
      "timeRange": "7days"
    },
    "resultsCount": 23
  }
}
```

**Why We Track It:**
- ✅ Track common searches
- ✅ Identify search patterns
- ✅ Find zero-result searches (content gaps)
- ✅ Filter usage patterns

---

### 8. DATA_EXPORT

**When:** User exports data (PDF, CSV, Excel, etc.)

**Data Captured:**
```json
{
  "eventType": "data_export",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:45:00Z",
  "eventData": {
    "exportType": "pdf",
    "recordCount": 10,
    "duration": 2.5
  }
}
```

**Why We Track It:**
- ✅ Track export frequency
- ✅ Identify most-exported formats
- ✅ Measure export volume
- ✅ Compliance tracking (data access logs)

---

### 9. API_CALL

**When:** Backend API is invoked

**Data Captured:**
```json
{
  "eventType": "api_call",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "timestamp": "2026-08-13T09:41:00Z",
  "eventData": {
    "endpoint": "/api/fcrs/list",
    "method": "GET",
    "statusCode": 200,
    "responseTimeMs": 234,
    "recordsReturned": 50
  }
}
```

**Why We Track It:**
- ✅ Monitor API performance
- ✅ Identify slow endpoints
- ✅ Track error rates by endpoint
- ✅ Capacity planning

**Example Query:**
```sql
SELECT 
  eventData->>'endpoint' as endpoint,
  COUNT(*) as call_count,
  AVG(CAST(eventData->>'responseTimeMs' AS FLOAT)) as avg_response_time_ms,
  STDDEV(CAST(eventData->>'responseTimeMs' AS FLOAT)) as std_dev
FROM telemetry.user_events
WHERE event_type = 'api_call'
  AND timestamp >= DATEADD(hour, -24, GETDATE())
GROUP BY eventData->>'endpoint'
ORDER BY avg_response_time_ms DESC;
```

---

### 10. ERROR

**When:** Application error occurs

**Data Captured:**
```json
{
  "eventType": "error",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "fcrs",
  "timestamp": "2026-08-13T09:43:15Z",
  "eventData": {
    "errorMessage": "Cannot read property 'id' of undefined",
    "errorStack": "at handleExport (FCRsPage.jsx:123)...",
    "context": {
      "action": "export",
      "fcrId": "a2z..."
    },
    "userAgent": "Mozilla/5.0..."
  }
}
```

**Why We Track It:**
- ✅ Identify top errors (debugging priority)
- ✅ Error frequency & patterns
- ✅ User impact assessment
- ✅ Regression detection

**Example Query:**
```sql
SELECT 
  eventData->>'errorMessage' as error_message,
  COUNT(*) as occurrence_count,
  COUNT(DISTINCT user_id) as affected_users,
  MAX(timestamp) as last_occurrence
FROM telemetry.user_events
WHERE event_type = 'error'
  AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY eventData->>'errorMessage'
ORDER BY occurrence_count DESC
LIMIT 20;
```

---

### 11. CUSTOM

**When:** Application-specific events

**Data Captured:**
```json
{
  "eventType": "custom",
  "userId": "user-12345",
  "sessionId": "session_1234567890_abc123",
  "page": "ask-ai",
  "timestamp": "2026-08-13T09:50:00Z",
  "eventData": {
    "eventName": "ai_question_asked",
    "question": "What is the status of FCR 12345?",
    "questionLength": 42,
    "topic": "fcr_status"
  }
}
```

**Why We Track It:**
- ✅ Track feature-specific usage (AI questions)
- ✅ AI adoption metrics
- ✅ Question category analysis
- ✅ Feature enhancement insights

---

## Event Summary Table

| Event Type | Frequency | Purpose | Example |
|------------|-----------|---------|---------|
| `user_login` | 1-10x/day | User identity | User logs in |
| `session_start` | 1-10x/day | Session tracking | After login |
| `session_end` | 1-10x/day | Session metrics | After logout |
| `page_view` | 10-100x/day | Navigation | Visit page |
| `page_exit` | 10-100x/day | Time on page | Leave page |
| `button_click` | 50-500x/day | Feature usage | Click export |
| `search` | 10-50x/day | Search patterns | Filter results |
| `data_export` | 5-50x/day | Export volume | Export PDF |
| `api_call` | 100-1000x/day | Performance | API latency |
| `error` | 0-50x/day | Errors | Exception |
| `custom` | 10-100x/day | Features | AI questions |

---

## Data Flow Example

### User Interacting with App

```
10:00:00 - User logs in
  └─> EVENT: user_login
  └─> EVENT: session_start

10:00:05 - User navigates to Dashboard
  └─> EVENT: page_view (page=dashboard)

10:05:00 - User navigates to FCRs
  └─> EVENT: page_exit (page=dashboard, timeOnPageSeconds=300)
  └─> EVENT: page_view (page=fcrs)

10:07:30 - User applies filter
  └─> EVENT: search (filters={status:open, region:north})
  └─> EVENT: api_call (endpoint=/api/fcrs/list, responseTime=234ms)

10:08:00 - User clicks Export button
  └─> EVENT: button_click (button=export_pdf)
  └─> EVENT: data_export (exportType=pdf, recordCount=10, duration=2.5s)

10:08:05 - Export complete
  └─> EVENT: api_call (endpoint=/api/fcrs/export, responseTime=2500ms)

10:30:00 - User logs out
  └─> EVENT: page_exit (page=fcrs, timeOnPageSeconds=1200)
  └─> EVENT: session_end (durationSeconds=1800, eventCount=42)
```

**Analysis Results:**
```
Session Duration: 30 minutes
Pages Visited: 2 (dashboard, fcrs)
Features Used: search, export
API Calls: 2 (list, export)
Total Events: 11
```

---

## Analytics Reports Generated

### Real-Time Reports

#### Active Users Now
```sql
SELECT COUNT(DISTINCT user_id) as active_users
FROM telemetry.user_events
WHERE timestamp >= DATEADD(minute, -5, GETDATE());
```

#### Current Page Views
```sql
SELECT page, COUNT(*) as viewers
FROM telemetry.user_events
WHERE event_type = 'page_view'
  AND timestamp >= DATEADD(minute, -5, GETDATE())
GROUP BY page;
```

---

### Daily Reports

#### Daily Active Users
```sql
SELECT 
  DATE(timestamp) as report_date,
  COUNT(DISTINCT user_id) as active_users,
  COUNT(DISTINCT session_id) as sessions,
  COUNT(*) as total_events
FROM telemetry.user_events
WHERE DATE(timestamp) >= DATEADD(day, -30, GETDATE())
GROUP BY DATE(timestamp)
ORDER BY report_date DESC;
```

#### Top Features
```sql
SELECT 
  eventData->>'button' as feature,
  COUNT(*) as usage_count
FROM telemetry.user_events
WHERE event_type = 'button_click'
  AND DATE(timestamp) = CURRENT_DATE
GROUP BY eventData->>'button'
ORDER BY usage_count DESC;
```

---

### Weekly Reports

#### Page Performance
```sql
SELECT 
  page,
  COUNT(*) as page_views,
  COUNT(DISTINCT user_id) as unique_users,
  AVG(CAST(eventData->>'timeOnPageSeconds' AS FLOAT)) as avg_time_seconds
FROM telemetry.user_events
WHERE event_type IN ('page_view', 'page_exit')
  AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY page
ORDER BY page_views DESC;
```

---

## Retention Policy

### Raw Events (Hot)
- **Retention:** 90 days
- **Storage:** ~5-10 MB/month
- **Table:** `telemetry.user_events`
- **Purpose:** Real-time analysis

### Aggregated Daily (Warm)
- **Retention:** 1 year
- **Storage:** Minimal (compressed)
- **Table:** `telemetry.daily_usage_summary`
- **Purpose:** Trends & historical comparison

### Archive (Cold)
- **Retention:** 3 years (per compliance)
- **Storage:** S3 or external archive
- **Purpose:** Compliance & legal holds

---

## Privacy & Compliance

### Data Classification
- ✅ **User ID:** Identified (hash of Azure AD ID)
- ✅ **User Name:** Identified (display name)
- ⚠️ **Email:** Identified (corporate email)
- ❌ **No PII:** Passwords, SSN, card numbers never stored
- ❌ **No Sensitive Data:** Patient data, trade secrets excluded

### Compliance Considerations
- **GDPR:** Right to data export (via API)
- **CCPA:** Right to deletion (implement archival)
- **HIPAA:** Don't store healthcare data in events
- **SOX:** Audit trail maintained

### Data Subject Rights
- **Right to Access:** User can request their data via `/api/telemetry/user/:userId`
- **Right to Deletion:** Implement archive & purge process
- **Right to Portability:** Export data as JSON

---

## Example Dashboards

### Executive Dashboard
- 📊 Active Users (last 30 days)
- 📈 Session Trend (daily)
- ⏱️ Avg Session Duration
- 🔴 Error Rate %

### Product Manager Dashboard
- 🎯 Feature Adoption (top 10 buttons)
- 🚀 New Feature Usage
- 📄 Page Performance
- 🔍 Search Queries (top 20)

### DevOps Dashboard
- ⚡ API Response Times (p50, p95, p99)
- ❌ Error Frequency by Type
- 📊 Event Volume Trend
- 💾 Storage Growth

---

## Support & Questions

See `TELEMETRY_IMPLEMENTATION_GUIDE.md` and `TELEMETRY_SYSTEM_DOCUMENTATION.md` for:
- Complete setup instructions
- Integration examples
- API reference
- Troubleshooting guide

---

**Version:** 1.0  
**Last Updated:** 2026-08-13
