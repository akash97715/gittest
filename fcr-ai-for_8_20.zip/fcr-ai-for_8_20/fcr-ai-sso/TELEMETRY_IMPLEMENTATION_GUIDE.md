/**
 * Telemetry Integration Guide
 * Step-by-step guide to integrate telemetry into the FCR AI app
 */

const integrationGuide = `
# FCR AI - User Telemetry & Tracking Implementation Guide

## Overview

This guide explains how to implement comprehensive user tracking and telemetry for the FCR AI application. The system tracks:
- User logins and sessions
- Page views and time spent
- Button clicks and feature usage
- Errors and performance metrics
- Search and filter actions
- Data exports

## Architecture

\`\`\`
Frontend (React)  →  TelemetryService  →  Backend API (/api/telemetry)  →  Redshift Database
  ↓
Tracks interactions in real-time
\`\`\`

---

## Implementation Steps

### Step 1: Create Telemetry Directory Structure

\`\`\`bash
mkdir -p src/services
mkdir -p src/components/Telemetry
\`\`\`

### Step 2: Copy Telemetry Service

The \`telemetryService.js\` file is already provided in \`src/services/\`.

### Step 3: Update App.jsx - Initialize Telemetry

\`\`\`jsx
import { telemetry } from './services/telemetryService';
import { useEffect } from 'react';
import { useMsal } from '@azure/msal-react';

export default function App() {
  const { accounts } = useMsal();
  
  useEffect(() => {
    // Initialize telemetry after authentication
    if (accounts && accounts.length > 0) {
      const account = accounts[0];
      telemetry.init(
        account.localAccountId || account.homeAccountId,
        account.name || 'Unknown',
        account.username || account.homeAccountId
      );
    }
  }, [accounts]);
  
  // ... rest of your code
}
\`\`\`

### Step 4: Track Page Navigation

In \`App.jsx\` or your router:

\`\`\`jsx
const renderPage = () => {
  switch (active) {
    case 'summary':
      telemetry.trackPageView('summary', 'Dashboard');
      return <DashboardPage />;
    case 'capability':
      telemetry.trackPageView('capability', 'Capability');
      return <CapabilityPage />;
    case 'fcrs':
      telemetry.trackPageView('fcrs', 'FCRs');
      return <FCRsPage />;
    // ... etc
  }
};
\`\`\`

### Step 5: Track Button Clicks

In your components:

\`\`\`jsx
import { telemetry } from '../services/telemetryService';

export function MyComponent() {
  const handleClick = () => {
    telemetry.trackButtonClick('export_fcr', {
      fcr_id: 'a2zWQ000004AODFYA4',
      export_format: 'pdf'
    });
    // ... handle export logic
  };
  
  return <button onClick={handleClick}>Export as PDF</button>;
}
\`\`\`

### Step 6: Track Search/Filters

\`\`\`jsx
const handleSearch = (searchTerm, filters) => {
  telemetry.trackSearch(searchTerm, {
    ta: filters.ta,
    status: filters.status,
    region: filters.region
  });
  // ... perform search
};
\`\`\`

### Step 7: Track API Calls

Wrap your API calls:

\`\`\`jsx
const fetchData = async (endpoint) => {
  const startTime = performance.now();
  try {
    const response = await fetch(endpoint);
    const endTime = performance.now();
    
    telemetry.trackApiCall(
      endpoint,
      'GET',
      response.status,
      endTime - startTime
    );
    
    return await response.json();
  } catch (error) {
    telemetry.trackError(error.message, error.stack);
    throw error;
  }
};
\`\`\`

### Step 8: Track Errors

\`\`\`jsx
import { telemetry } from '../services/telemetryService';

try {
  // some code
} catch (error) {
  telemetry.trackError(
    error.message,
    error.stack,
    { feature: 'fcr_detail', action: 'load' }
  );
}
\`\`\`

### Step 9: Add Backend Endpoints

Add these endpoints to \`server.js\`:

Copy the content from \`TELEMETRY_ENDPOINTS.js\` into your \`server.js\` file.

### Step 10: Create Database Schema

Run the SQL from \`TELEMETRY_DATABASE_SCHEMA.sql\` in your Redshift database:

\`\`\`bash
# Using psql or Redshift Query Editor
psql -h <redshift-host> -U <username> -d awprdrsdb -f TELEMETRY_DATABASE_SCHEMA.sql
\`\`\`

---

## Usage Examples

### Example 1: Track Dashboard Page Load

\`\`\`jsx
// In DashboardPage.jsx
import { telemetry } from '../services/telemetryService';
import { useEffect } from 'react';

export default function DashboardPage() {
  useEffect(() => {
    telemetry.trackPageView('dashboard', 'Dashboard');
  }, []);
  
  return (
    // ... your dashboard content
  );
}
\`\`\`

### Example 2: Track Filter Application

\`\`\`jsx
const handleApplyFilters = () => {
  telemetry.trackSearch('', {
    ta: selectedTA,
    status: selectedStatus,
    region: selectedRegion,
    timeframe: selectedTimeframe
  });
  
  // Fetch filtered data...
};
\`\`\`

### Example 3: Track Export Action

\`\`\`jsx
const handleExportPDF = (fcrId) => {
  telemetry.trackExport('pdf', 1);
  // Generate and download PDF...
};

const handleExportMultiple = (count) => {
  telemetry.trackExport('csv', count);
  // Export multiple FCRs as CSV...
};
\`\`\`

### Example 4: Track Feature Usage

\`\`\`jsx
const handleAskAI = (question) => {
  telemetry.trackButtonClick('ask_ai', {
    question_length: question.length,
    page: 'ask_ai'
  });
  // Send question to AI...
};
\`\`\`

---

## Telemetry Dashboard

Access telemetry reports via API endpoints:

- \`GET /api/telemetry/usage-summary?days=30\` - Overall usage stats
- \`GET /api/telemetry/user-sessions?days=7\` - Recent user sessions
- \`GET /api/telemetry/user/:userId?days=30\` - Individual user activity
- \`GET /api/telemetry/page-analytics?days=7\` - Page view analytics
- \`GET /api/telemetry/button-clicks?days=7\` - Most used features
- \`GET /api/telemetry/errors?days=7\` - Application errors

### Example: Get Usage Summary

\`\`\`bash
curl http://localhost:8080/api/telemetry/usage-summary?days=30
\`\`\`

Response:
\`\`\`json
{
  "timeframe": "Last 30 days",
  "active_users": 45,
  "total_sessions": 287,
  "total_events": 5234,
  "total_logins": 89,
  "avg_session_duration_seconds": 1245.50,
  "total_errors": 12
}
\`\`\`

---

## Best Practices

### 1. Sensitive Data
❌ DO NOT track:
- Passwords
- Credit cards
- Social security numbers
- API keys

✅ DO track:
- User IDs
- Page names
- Button names
- Feature usage
- Error messages (without sensitive data)

### 2. Performance
- Events are batched (10 events per batch)
- Batches sent every 30 seconds
- Offline events are queued
- Large events queued up to 100

### 3. Privacy & Compliance
- Respect user privacy
- Implement data retention policy (90 days default)
- Allow users to opt-out if required
- GDPR: Be prepared to export/delete user data

### 4. Event Naming
Use consistent, descriptive event names:
- \`page_view\` - Page navigation
- \`button_click\` - UI interactions
- \`search\` - Search/filter
- \`error\` - Exceptions
- \`api_call\` - Backend requests

---

## Data Retention

Default policy: Keep 90 days of raw events in \`user_events\` table.

Archive older data or implement:
- Monthly summary tables
- Aggregate before archive
- Move to cold storage

Run periodically:
\`\`\`sql
DELETE FROM telemetry.user_events 
WHERE timestamp < DATEADD(day, -90, GETDATE());
\`\`\`

---

## Monitoring & Alerts

### Track Key Metrics

1. **User Engagement**
   - Active users per day
   - Session duration
   - Pages per session
   - Return user rate

2. **Feature Usage**
   - Most used buttons/features
   - Least used features
   - Export frequency

3. **Application Health**
   - Error rate
   - Page load performance
   - API response times

4. **User Experience**
   - Time to complete tasks
   - Bounce rate
   - Navigation patterns

---

## Example: Create Analytics Dashboard

Create a new page \`src/pages/AnalyticsPage.jsx\`:

\`\`\`jsx
import { useEffect, useState } from 'react';

export default function AnalyticsPage() {
  const [summary, setSummary] = useState(null);
  const [pageAnalytics, setPageAnalytics] = useState([]);
  const [buttonAnalytics, setButtonAnalytics] = useState([]);

  useEffect(() => {
    // Fetch usage summary
    fetch('/api/telemetry/usage-summary?days=30')
      .then(r => r.json())
      .then(setSummary);

    // Fetch page analytics
    fetch('/api/telemetry/page-analytics?days=7')
      .then(r => r.json())
      .then(setPageAnalytics);

    // Fetch button analytics
    fetch('/api/telemetry/button-clicks?days=7')
      .then(r => r.json())
      .then(setButtonAnalytics);
  }, []);

  if (!summary) return <div>Loading...</div>;

  return (
    <div>
      <h1>FCR AI Analytics</h1>
      
      <div className="kpi-cards">
        <div className="card">
          <h3>Active Users</h3>
          <p className="value">{summary.active_users}</p>
        </div>
        <div className="card">
          <h3>Total Sessions</h3>
          <p className="value">{summary.total_sessions}</p>
        </div>
        <div className="card">
          <h3>Avg Session Duration</h3>
          <p className="value">{Math.round(summary.avg_session_duration_seconds)}s</p>
        </div>
        <div className="card">
          <h3>Total Errors</h3>
          <p className="value" style={{color: summary.total_errors > 10 ? 'red' : 'green'}}>
            {summary.total_errors}
          </p>
        </div>
      </div>

      <h2>Page Analytics</h2>
      <table>
        <thead>
          <tr>
            <th>Page</th>
            <th>Views</th>
            <th>Unique Visitors</th>
            <th>Avg Time (s)</th>
          </tr>
        </thead>
        <tbody>
          {pageAnalytics.map(page => (
            <tr key={page.page_name}>
              <td>{page.page_name}</td>
              <td>{page.view_count}</td>
              <td>{page.unique_visitors}</td>
              <td>{page.avg_time_spent_seconds}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Most Used Features</h2>
      <table>
        <thead>
          <tr>
            <th>Button</th>
            <th>Page</th>
            <th>Clicks</th>
            <th>Unique Users</th>
          </tr>
        </thead>
        <tbody>
          {buttonAnalytics.map((btn, i) => (
            <tr key={i}>
              <td>{btn.button_name}</td>
              <td>{btn.page}</td>
              <td>{btn.click_count}</td>
              <td>{btn.unique_users}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
\`\`\`

---

## Troubleshooting

### Events not being sent?

1. Check network tab in browser DevTools
2. Verify \`/api/telemetry\` endpoint is working
3. Check browser console for errors
4. Ensure user is authenticated

### Events sent but not in database?

1. Verify database schema exists
2. Check Redshift connectivity
3. Review \`REDSHIFT_CONNECTION_REPORT.md\` for permission issues
4. Check server logs for errors

### Performance impact?

1. Events are batched and sent asynchronously
2. Typical impact: < 1% CPU overhead
3. For 100 users, expect ~5-10MB/month storage

---

## File Checklist

✅ \`src/services/telemetryService.js\` - Frontend telemetry service
✅ \`TELEMETRY_ENDPOINTS.js\` - Backend API endpoints (copy to server.js)
✅ \`TELEMETRY_DATABASE_SCHEMA.sql\` - Database tables and views
✅ Update \`src/App.jsx\` - Initialize telemetry
✅ Update components - Track button clicks
✅ Create \`src/pages/AnalyticsPage.jsx\` - Dashboard for analytics

---

## Support & Questions

For issues or enhancements:
1. Check this guide
2. Review telemetryService.js comments
3. Check server logs (/api/telemetry errors)
4. Review database queries in TELEMETRY_ENDPOINTS.js

---

## Version History

- v1.0 - Initial implementation
- Supports: logins, page views, button clicks, errors, API calls, custom events
- Events: batch sent every 30s or when queue reaches 10 items
- Retention: 90 days in primary table
`;

console.log(integrationGuide);
