# Telemetry Implementation Plan

## Repository Architecture Analysis

### Current Patterns (to follow):

**Backend:**
- Single `db.js` exports a `Pool` instance connecting to Redshift
- Routes defined directly in `server.js` with inline logic (no separate route files)
- Env vars loaded via `dotenv/config` at server startup
- Simple structure: queries → caching → responses

**Frontend:**
- React + Vite with MSAL auth
- State-based page navigation (no React Router)
- Components are separate (Sidebar, Topbar, etc.)
- MSAL integration via `MsalProvider` wrapper

**Database:**
- PostgreSQL client (`pg` module)
- Connection pooling with SSL enabled

---

## Implementation Plan

### 1. **New Files Structure**

```
fcr-ai-sso/
├── server.js                           (existing, ADD route)
├── db.js                               (existing, NO CHANGES)
├── telemetryDb.js                      (NEW — separate pool for telemetry PostgreSQL)
├── src/
│   ├── services/
│   │   └── telemetryService.js        (NEW — frontend service)
│   └── constants/
│       └── telemetry.js               (NEW — event types & payload schema)
├── backend/
│   ├── telemetry/
│   │   ├── eventWriter.js             (NEW — DB writes, dedup, batching)
│   │   ├── publisher.js               (NEW — transport switch: direct/kafka)
│   │   └── constants.js               (NEW — event types, shared with frontend)
├── .env                               (existing, VERIFY telemetry vars)
└── .env.example                       (UPDATED — add placeholders)
```

### 2. **Shared Event Schema** (`backend/telemetry/constants.js`)

**Purpose:** Single source of truth, importable by both frontend and backend

```javascript
export const VALID_EVENT_TYPES = [
  'user_login',
  'user_logout',
  'session_start',
  'session_end',
  'page_view',
  'page_exit',
  'button_click',
  'search',
  'data_export',
  'api_call',
  'error',
  'custom'
];

export const createEventPayload = (type, data) => ({
  event_type: type,
  event_data: data || {},
  timestamp: new Date().toISOString()
});

export const TELEMETRY_CONFIG = {
  BATCH_SIZE: parseInt(process.env.TELEMETRY_BATCH_SIZE) || 10,
  FLUSH_INTERVAL_MS: parseInt(process.env.TELEMETRY_FLUSH_INTERVAL_MS) || 30000,
  ENABLED: process.env.TELEMETRY_ENABLED === 'true',
  TRANSPORT: process.env.TELEMETRY_TRANSPORT || 'direct' // 'direct' or 'kafka'
};
```

### 3. **Backend: Postgres Connection Pool** (`telemetryDb.js`)

**Pattern:** Same as existing `db.js`, but for Azure PostgreSQL

```javascript
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const telemetryPool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
  max: 10,
  min: 2,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

telemetryPool.on('error', (err) => {
  console.error('Telemetry pool error:', err.message);
});

export default telemetryPool;
```

### 4. **Backend: Event Writer** (`backend/telemetry/eventWriter.js`)

**Purpose:** Dedup check, batch inserts into `user_events`, update `event_processing_status`

**Key:**
- Uses `INSERT ... ON CONFLICT DO NOTHING` for deduplication
- Batch inserts (not row-by-row)
- Called by both direct API route AND future Kafka consumer
- Never throws; logs errors and continues

```javascript
// Pseudocode structure:
export async function writeEvents(events, telemetryPool) {
  if (!events.length) return;

  // 1. Generate dedup_id for each event
  const eventsWithDedupId = events.map(e => ({
    ...e,
    dedup_id: generateDedupId(e.userId, e.sessionId, e.timestamp, e.eventType)
  }));

  // 2. Batch insert into user_events with ON CONFLICT
  // 3. Write to event_processing_status for each event
  // 4. Return count of inserted vs skipped
}

function generateDedupId(userId, sessionId, timestamp, eventType) {
  return crypto
    .createHash('sha256')
    .update(`${userId}|${sessionId}|${timestamp}|${eventType}`)
    .digest('hex');
}
```

### 5. **Backend: Publisher** (`backend/telemetry/publisher.js`)

**Pattern:** Transport abstraction (direct now, Kafka later)

**Key:**
- Checks `TELEMETRY_TRANSPORT` env var
- Routes to `eventWriter` (direct) or Kafka producer (future)
- Returns immediately (fire-and-forget)
- API route never references transport directly

```javascript
// Pseudocode:
export async function publish(events) {
  if (TELEMETRY_CONFIG.TRANSPORT === 'kafka') {
    // Future: Send to Kafka producer
    // await kafkaProducer.send({ topic: KAFKA_TOPIC, messages: [...] });
  } else {
    // Direct to DB (current)
    await eventWriter.writeEvents(events);
  }
  // Fire and forget — no error blocking
}
```

### 6. **Backend: Telemetry Route** (in `server.js`)

**Endpoint:** `POST /api/telemetry`

**Behavior:**
- Validate event_type against `VALID_EVENT_TYPES`
- Reject invalid events with 400
- Call `publisher.publish()` (async, no await)
- Return 200 immediately
- Never block user request on telemetry failure

```javascript
app.post('/api/telemetry', async (req, res) => {
  const { events } = req.body; // Array of events

  // Validate
  const invalid = events.filter(e => !VALID_EVENT_TYPES.includes(e.event_type));
  if (invalid.length > 0) {
    return res.status(400).json({ error: 'Invalid event types', invalid });
  }

  // Fire and forget
  publisher.publish(events).catch(err => {
    console.error('Telemetry publish error:', err.message);
  });

  res.status(200).json({ received: events.length });
});
```

### 7. **Frontend: TelemetryService** (`src/services/telemetryService.js`)

**Pattern:** Singleton service, follows frontend conventions

**Key:**
- Session ID generated on first call, persisted in `sessionStorage`
- Batch queue with flush on size OR interval
- Flush on page unload
- localStorage retry for offline
- Helpers: `trackEvent`, `trackPageView`, `trackButtonClick`, `trackSearch`, `trackError`
- No-op when `TELEMETRY_ENABLED` is false

```javascript
class TelemetryService {
  constructor() {
    this.enabled = import.meta.env.VITE_TELEMETRY_ENABLED === 'true';
    this.sessionId = this._getOrCreateSessionId();
    this.eventQueue = [];
    this.flushTimer = null;
    
    // Batch settings (from env)
    this.batchSize = parseInt(import.meta.env.VITE_TELEMETRY_BATCH_SIZE || '10');
    this.flushIntervalMs = parseInt(import.meta.env.VITE_TELEMETRY_FLUSH_INTERVAL_MS || '30000');
    
    if (this.enabled) {
      this._startFlushTimer();
      window.addEventListener('beforeunload', () => this.flush());
    }
  }

  trackEvent(eventType, data = {}) {
    if (!this.enabled) return;
    const event = {
      event_type: eventType,
      event_data: data,
      session_id: this.sessionId,
      timestamp: new Date().toISOString()
    };
    this._enqueue(event);
  }

  trackPageView(pageName, url) {
    this.trackEvent('page_view', { page_name: pageName, url });
  }

  trackButtonClick(buttonName, pageName) {
    this.trackEvent('button_click', { button_name: buttonName, page_name: pageName });
  }

  trackSearch(query) {
    this.trackEvent('search', { query });
  }

  trackError(errorMessage, errorCode = null) {
    this.trackEvent('error', { message: errorMessage, code: errorCode });
  }

  _enqueue(event) {
    this.eventQueue.push(event);
    if (this.eventQueue.length >= this.batchSize) {
      this.flush();
    }
  }

  async flush() {
    if (!this.enabled || this.eventQueue.length === 0) return;
    const batch = [...this.eventQueue];
    this.eventQueue = [];

    try {
      const response = await fetch('/api/telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events: batch })
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
    } catch (err) {
      // Save to localStorage for offline retry
      this._saveTolocalStorage(batch);
      console.error('Telemetry flush failed:', err.message);
    }
  }

  _startFlushTimer() {
    this.flushTimer = setInterval(() => this.flush(), this.flushIntervalMs);
  }

  _getOrCreateSessionId() {
    let sessionId = sessionStorage.getItem('telemetrySessionId');
    if (!sessionId) {
      sessionId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('telemetrySessionId', sessionId);
    }
    return sessionId;
  }

  _saveTolocalStorage(events) {
    const key = 'telemetry_offline_queue';
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    localStorage.setItem(key, JSON.stringify([...existing, ...events]));
  }
}

export const telemetryService = new TelemetryService();
```

### 8. **Frontend: Page Tracking Integration** (in `App.jsx`)

**Pattern:** Hook page navigation and send page_view/page_exit events

```javascript
// In App.jsx or a custom hook
useEffect(() => {
  telemetryService.trackPageView(active, window.location.pathname);

  return () => {
    // Calculate time-on-page
    const timeOnPage = Date.now() - pageEntryTime;
    telemetryService.trackEvent('page_exit', {
      page_name: active,
      time_on_page_ms: timeOnPage
    });
  };
}, [active]);
```

### 9. **Frontend: Button Click Tracking** (in components)

**Pattern:** Add click handler to important buttons

```javascript
// In component (e.g., Sidebar.jsx)
const handleNavigate = (page) => {
  telemetryService.trackButtonClick(`nav_${page}`, 'sidebar');
  onNavigate(page);
};
```

### 10. **Environment Variables** (`.env` — already mostly configured)

```env
# Telemetry PostgreSQL (Azure)
TELEMETRY_DB_HOST=aiaypd03.postgres.database.azure.com
TELEMETRY_DB_PORT=5432
TELEMETRY_DB_NAME=fcrai_org
TELEMETRY_DB_USER=sa-its-aiaypd03-fcrai-dev
TELEMETRY_DB_PASSWORD=O>-wP7u2SZ
TELEMETRY_DB_SCHEMA=telemetry
TELEMETRY_DB_SSL=true

# Transport switch
TELEMETRY_TRANSPORT=direct    # flip to 'kafka' later

# Kafka (unused for now, ready for future)
KAFKA_BROKERS=
KAFKA_TOPIC=telemetry_events
KAFKA_CLIENT_ID=fcrai-telemetry-producer

# Behavior
TELEMETRY_ENABLED=true
TELEMETRY_BATCH_SIZE=10
TELEMETRY_FLUSH_INTERVAL_MS=30000

# Frontend env vars (for Vite — add to .env)
VITE_TELEMETRY_ENABLED=true
VITE_TELEMETRY_BATCH_SIZE=10
VITE_TELEMETRY_FLUSH_INTERVAL_MS=30000
```

---

## Key Design Decisions

| Aspect | Decision | Rationale |
|--------|----------|-----------|
| **Separate Pool** | New `telemetryDb.js` for Azure PostgreSQL | Isolates telemetry from main Redshift queries |
| **Dedup ID** | SHA256(userId + sessionId + timestamp + eventType) | Deterministic, works with Kafka producer |
| **Batch Writes** | Events batched by size or time before insert | Reduces DB round-trips, better performance |
| **Fire-and-Forget** | Telemetry never blocks API responses | User experience unaffected by telemetry failures |
| **Transport Switch** | Env var `TELEMETRY_TRANSPORT` | Zero-code change to swap to Kafka |
| **localStorage Retry** | Queue on flush failure | Improves data collection during outages |
| **Session ID** | Per-browser, persisted in sessionStorage | Correlates events from same user session |

---

## Future Kafka Migration

Once Kafka is ready:
1. Set `TELEMETRY_TRANSPORT=kafka`
2. Implement Kafka producer in `publisher.js`
3. Implement Kafka consumer that calls `eventWriter.writeEvents()`
4. **No changes needed to API routes, frontend, or event schema**

---

## Integration Checklist

- [ ] Create `telemetryDb.js` (Postgres pool for telemetry)
- [ ] Create `backend/telemetry/constants.js` (event types)
- [ ] Create `backend/telemetry/eventWriter.js` (batch dedup insert)
- [ ] Create `backend/telemetry/publisher.js` (transport abstraction)
- [ ] Add `POST /api/telemetry` route to `server.js`
- [ ] Create `src/services/telemetryService.js` (frontend service)
- [ ] Create `src/constants/telemetry.js` (frontend event types)
- [ ] Update `App.jsx` for page tracking
- [ ] Update components for button click tracking
- [ ] Create `.env.example` with all placeholders
- [ ] Test: verify events in Azure PostgreSQL `telemetry.user_events` table
- [ ] Test: offline queue with localStorage

---

## Questions Before Implementation

1. **Frontend env vars:** Should frontend use same `TELEMETRY_*` vars from `.env` or separate `VITE_*` vars for Vite bundling?
   - **Answer:** Separate `VITE_*` vars (Vite best practice)

2. **MSAL context:** Should telemetry capture user info from MSAL context (user_id, user_email)?
   - **Answer:** Yes, extract from `useAccount()` hook in App.jsx

3. **Error tracking:** Should frontend telemetry auto-capture uncaught errors?
   - **Answer:** Add error boundary + global error handler

4. **API call tracking:** Should backend auto-track all `/api/*` calls, or just telemetry route?
   - **Answer:** Start simple, track manually in key routes

Ready to implement? Proceed with step-by-step code generation following this plan.
