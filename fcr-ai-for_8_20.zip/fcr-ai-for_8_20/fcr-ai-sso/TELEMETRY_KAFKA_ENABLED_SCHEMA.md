# TELEMETRY TABLE SCHEMA - KAFKA-ENABLED VERSION
## Updated Design with Kafka Stream Processing

**Date:** August 19, 2026  
**Database:** Amazon Redshift  
**Stream Processing:** Apache Kafka  
**Approach:** 8 tables (original 5 + 3 new for Kafka tracking)

---

## ARCHITECTURE WITH KAFKA

```
Frontend (React)
    ↓
POST /api/telemetry (batched events)
    ↓
Backend (Node.js)
    ├─ Validate events
    ├─ Publish to Kafka topic: "telemetry-events"
    └─ Return 202 (Accepted, processing)
    ↓
Kafka Topic: "telemetry-events"
    ├─ Partition 0: events for user A, B, C
    ├─ Partition 1: events for user D, E, F
    ├─ Partition 2: events for user G, H, I
    └─ 3-day retention
    ↓
Consumer Group 1: "redshift-writer"
    └─ Consumes → Validates → Writes to Redshift
    
Consumer Group 2: "blob-archiver"
    └─ Consumes → Compresses → Archives to Blob Storage
    
Consumer Group 3: "real-time-dashboard" (future)
    └─ Consumes → Aggregates → Live metrics
    ↓
Redshift Tables:
├─ user_events (from Kafka consumer)
├─ user_sessions (aggregated)
├─ daily_usage_summary (aggregated)
├─ page_analytics (aggregated)
├─ button_analytics (aggregated)
├─ kafka_event_tracking (for idempotency)
├─ kafka_consumer_offsets (consumer group state)
└─ event_deduplication (dedup log)
```

---

## ORIGINAL 5 TABLES (Unchanged)

### TABLE 1: user_events
```sql
CREATE TABLE telemetry.user_events (
    event_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    session_id VARCHAR(100) NOT NULL,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    event_type VARCHAR(50) NOT NULL,
    event_data SUPER,
    page VARCHAR(100),
    url VARCHAR(2048),
    
    timestamp TIMESTAMP DEFAULT GETDATE(),
    
    -- NEW: Track source and processing status
    kafka_topic VARCHAR(100),              -- Which Kafka topic this came from
    kafka_partition INT,                   -- Which partition
    kafka_offset BIGINT,                   -- Offset in partition (for recovery)
    processed_at TIMESTAMP,                -- When we processed from Kafka
    
    CONSTRAINT event_type_check CHECK (event_type IN (
        'user_login', 'user_logout', 'page_view', 'page_exit',
        'button_click', 'search', 'data_export', 'api_call',
        'error', 'session_start', 'session_end', 'custom'
    ))
);

-- Indexes (same as before, plus new ones)
CREATE INDEX idx_user_events_user_id ON telemetry.user_events (user_id);
CREATE INDEX idx_user_events_session_id ON telemetry.user_events (session_id);
CREATE INDEX idx_user_events_event_type ON telemetry.user_events (event_type);
CREATE INDEX idx_user_events_timestamp ON telemetry.user_events (timestamp);
CREATE INDEX idx_user_events_page ON telemetry.user_events (page);
CREATE INDEX idx_user_events_user_timestamp ON telemetry.user_events (user_id, timestamp DESC);

-- NEW: Track Kafka offset for recovery
CREATE INDEX idx_user_events_kafka_offset ON telemetry.user_events (kafka_offset);
```

**Why new columns?**
- `kafka_topic, kafka_partition, kafka_offset`: Enable replay from Kafka if needed
- `processed_at`: Track when event was consumed from Kafka (vs original timestamp)
- These enable **exactly-once processing** semantics

---

### TABLE 2: user_sessions (Unchanged)
```sql
CREATE TABLE telemetry.user_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    session_start TIMESTAMP,
    session_end TIMESTAMP,
    duration_seconds INT,
    
    event_count INT DEFAULT 0,
    page_views INT DEFAULT 0,
    button_clicks INT DEFAULT 0,
    errors_count INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

---

### TABLE 3: daily_usage_summary (Unchanged)
```sql
CREATE TABLE telemetry.daily_usage_summary (
    usage_date DATE PRIMARY KEY,
    
    active_users INT,
    total_sessions INT,
    total_events INT,
    total_page_views INT,
    total_button_clicks INT,
    total_logins INT,
    total_errors INT,
    
    avg_session_duration_seconds DECIMAL(10, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

---

### TABLE 4: page_analytics (Unchanged)
```sql
CREATE TABLE telemetry.page_analytics (
    page_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    page_name VARCHAR(100),
    analytics_date DATE,
    
    view_count INT DEFAULT 0,
    unique_visitors INT DEFAULT 0,
    avg_time_spent_seconds DECIMAL(10, 2),
    bounce_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

---

### TABLE 5: button_analytics (Unchanged)
```sql
CREATE TABLE telemetry.button_analytics (
    button_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    button_name VARCHAR(255),
    page_name VARCHAR(100),
    analytics_date DATE,
    
    click_count INT DEFAULT 0,
    unique_users INT DEFAULT 0,
    adoption_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

---

## NEW TABLES FOR KAFKA (3 NEW)

### TABLE 6: kafka_event_tracking (Deduplication & Idempotency)

**Purpose:** Kafka can deliver same event twice. Use this to detect duplicates and ensure exactly-once processing.

```sql
CREATE TABLE telemetry.kafka_event_tracking (
    dedup_id VARCHAR(255) PRIMARY KEY,          -- Unique identifier for event
    
    kafka_topic VARCHAR(100),                   -- Source topic
    kafka_partition INT,                        -- Source partition
    kafka_offset BIGINT,                        -- Source offset
    
    event_id BIGINT,                            -- FK to user_events (after processed)
    session_id VARCHAR(100),                    -- Session reference
    user_id VARCHAR(100),                       -- User reference
    
    processing_status VARCHAR(50),              -- 'received', 'processed', 'failed'
    processed_at TIMESTAMP,                     -- When processed
    error_message VARCHAR(1000),                -- If failed, why?
    
    created_at TIMESTAMP DEFAULT GETDATE(),
    updated_at TIMESTAMP DEFAULT GETDATE()
);
```

**Why each column?**

| Column | Why |
|--------|-----|
| **dedup_id** | Unique per event (UUID from frontend). Detect if same event arrives twice from Kafka. |
| **kafka_topic, partition, offset** | Track exactly where event came from. Enable replay from specific offset. |
| **event_id** | Link to stored event. "This dedup_id resulted in event_id 12345." |
| **processing_status** | 'received' = got from Kafka, 'processed' = stored in Redshift, 'failed' = error. |
| **error_message** | If failed, why? "Invalid event type", "Database constraint violation", etc. |
| **processed_at** | When did we process it? Track processing latency. |
| **updated_at** | When did status last change? |

**Example workflow:**
```
Event arrives from Kafka with dedup_id "evt-abc-123"
↓
Check kafka_event_tracking: dedup_id exists? NO
↓
Insert into user_events
↓
Update kafka_event_tracking: processing_status = 'processed'
↓
--- LATER: Same event arrives AGAIN (Kafka retry) ---
↓
Check kafka_event_tracking: dedup_id exists? YES (already processed)
↓
Skip duplicate, return success (idempotent)
```

**Indexes:**
```sql
CREATE INDEX idx_dedup_id ON telemetry.kafka_event_tracking (dedup_id);
-- "Is this event duplicate?" — Fast O(1) lookup

CREATE INDEX idx_kafka_offset ON telemetry.kafka_event_tracking (kafka_partition, kafka_offset);
-- "Show events from partition 0, offset 1000+" — Range query for replay

CREATE INDEX idx_processing_status ON telemetry.kafka_event_tracking (processing_status);
-- "Show all failed events" → Retry logic
```

---

### TABLE 7: kafka_consumer_offsets (Consumer Group State)

**Purpose:** Track where each Kafka consumer group is. "redshift-writer group has processed up to offset 50,000 in partition 0."

```sql
CREATE TABLE telemetry.kafka_consumer_offsets (
    consumer_group_id VARCHAR(100),             -- "redshift-writer", "blob-archiver"
    topic_name VARCHAR(100),                    -- "telemetry-events"
    partition_id INT,                           -- 0, 1, 2, etc.
    
    last_committed_offset BIGINT,               -- Last offset successfully processed
    last_committed_timestamp TIMESTAMP,         -- When committed
    
    lag_events INT,                             -- Uncommitted events (lag)
    consumer_instance VARCHAR(100),             -- Which instance processed?
    
    created_at TIMESTAMP DEFAULT GETDATE(),
    updated_at TIMESTAMP DEFAULT GETDATE(),
    
    PRIMARY KEY (consumer_group_id, topic_name, partition_id)
);
```

**Why each column?**

| Column | Why |
|--------|-----|
| **consumer_group_id** | Which consumer? 'redshift-writer' or 'blob-archiver'? |
| **topic_name, partition_id** | Which topic/partition? |
| **last_committed_offset** | Last offset successfully processed. If consumer crashes, resume from here. |
| **lag_events** | How many unprocessed events? If lag > 1000, alerting system should trigger. |
| **consumer_instance** | Which server in consumer group processed this? For debugging. |

**Example scenario:**
```
Redshift consumer group processes partition 0
↓
Processes offsets 0-1000 → Commits offset 1001
↓
Consumer crashes
↓
New consumer instance starts
↓
Queries kafka_consumer_offsets: Last committed offset = 1001
↓
Resumes from offset 1001 (no duplicate processing!)
```

**Indexes:**
```sql
CREATE INDEX idx_consumer_lag ON telemetry.kafka_consumer_offsets (consumer_group_id, lag_events);
-- "Which consumer groups are falling behind?" → Alerting
```

---

### TABLE 8: event_processing_status (Pipeline Tracking)

**Purpose:** Track event's journey through entire pipeline. Debugging & observability.

```sql
CREATE TABLE telemetry.event_processing_status (
    event_tracking_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    event_id BIGINT,                            -- FK to user_events
    dedup_id VARCHAR(255),                      -- FK to kafka_event_tracking
    
    -- Pipeline stages
    stage VARCHAR(50),                          -- 'received', 'validated', 'stored', 'aggregated', 'archived'
    stage_status VARCHAR(50),                   -- 'in_progress', 'completed', 'failed'
    
    timestamp_received TIMESTAMP,               -- When received from Kafka
    timestamp_validated TIMESTAMP,              -- When validation passed
    timestamp_stored TIMESTAMP,                 -- When stored to Redshift
    timestamp_aggregated TIMESTAMP,             -- When included in aggregates
    timestamp_archived TIMESTAMP,               -- When archived to blob
    
    processing_duration_ms INT,                 -- Total time in pipeline
    error_details VARCHAR(1000),                -- If any stage failed
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

**Why each column?**

| Column | Why |
|--------|-----|
| **stage** | Where in pipeline? Frontend → Kafka → Redshift → Blob |
| **stage_status** | Each stage: in_progress, completed, or failed |
| **timestamp_* columns** | Track latency per stage. "validation took 50ms, storage took 200ms" |
| **processing_duration_ms** | Total end-to-end latency. Target: <5 seconds |
| **error_details** | If failed at any stage, what was error? |

**Example tracking:**
```
Event "evt-abc-123" flows through pipeline:

1. timestamp_received: 10:00:00.000
   stage: 'received'
   
2. timestamp_validated: 10:00:00.050
   stage: 'validated'
   
3. timestamp_stored: 10:00:00.250
   stage: 'stored' (to user_events table)
   
4. timestamp_aggregated: 10:00:30.000
   stage: 'aggregated' (included in session summary)
   
5. timestamp_archived: 10:00:31.000
   stage: 'archived' (to blob storage)
   
Total processing: 31 seconds (acceptable)
```

**Indexes:**
```sql
CREATE INDEX idx_event_stage ON telemetry.event_processing_status (stage, stage_status);
-- "Show all events stuck in 'aggregation' stage" → Debug

CREATE INDEX idx_processing_duration ON telemetry.event_processing_status (processing_duration_ms DESC);
-- "Which events took longest?" → Performance analysis
```

---

## DATA FLOW WITH KAFKA

```
STEP 1: Frontend sends events
────────────────────────────
Frontend batches 10 events
POST /api/telemetry
    ↓
Backend receives
Backend validates: All 10 valid ✓
Backend publishes to Kafka topic "telemetry-events"
    ├─ Partition 0 (hash(user_id % 3))
    ├─ Offset 45,000-45,009
    └─ Timestamp: 2026-08-19T10:00:00Z
    ↓
Backend responds: 202 Accepted
    ↓
-- STEP 2: Kafka Consumer (redshift-writer) processes
────────────────────────────────────────────────────────
Consumer group "redshift-writer" subscribes to topic
Consumes messages from offset 45,000-45,009
    ↓
FOR EACH event:
    1. Check kafka_event_tracking: dedup_id exists?
       ├─ NO: Continue
       └─ YES: Skip (duplicate)
    
    2. Validate event again
    
    3. Insert into user_events (with kafka_topic, partition, offset)
    
    4. Insert into event_processing_status (timestamp_stored)
    
    5. Insert into kafka_event_tracking (processing_status='processed')
    ↓
Commit offset to kafka_consumer_offsets:
    last_committed_offset = 45,009
    consumer_group_id = 'redshift-writer'
    ↓

-- STEP 3: Aggregation (same as before, every 30 min)
────────────────────────────────────────────
Aggregation job runs:
    Aggregate user_events → user_sessions
    Aggregate user_events → page_analytics
    Aggregate user_events → button_analytics
    Update event_processing_status (timestamp_aggregated)
    ↓

-- STEP 4: Daily summary (same as before)
────────────────────────────────
Daily job:
    Aggregate daily stats → daily_usage_summary
    ↓

-- STEP 5: Blob archival (NEW: Can be separate consumer)
────────────────────────────────
Consumer group "blob-archiver" consumes same topic
For each event:
    If timestamp > 90 days old:
        Compress
        Upload to blob storage
        Update event_processing_status (timestamp_archived)
        Delete from Redshift (optional)
    ↓
```

---

## KAFKA CONFIGURATION (Topic Design)

```properties
Topic: telemetry-events
├─ Partitions: 3
│  ├─ Partition 0: hash(user_id) % 3 == 0
│  ├─ Partition 1: hash(user_id) % 3 == 1
│  └─ Partition 2: hash(user_id) % 3 == 2
│
├─ Replication Factor: 2 (HA)
├─ Retention: 3 days (enough to recover if consumer down)
├─ Compression: snappy (saves storage)
│
└─ Consumer Groups:
    ├─ redshift-writer (1 instance × 3 partitions)
    ├─ blob-archiver (1 instance × 3 partitions)
    └─ real-time-dashboard (future, 1 instance × 3 partitions)
```

---

## SCHEMA CHANGES SUMMARY

| Table | Change | Why |
|-------|--------|-----|
| **user_events** | +3 columns (kafka_topic, partition, offset) | Track Kafka source for replay |
| **NEW: kafka_event_tracking** | 8 columns | Deduplication & idempotency |
| **NEW: kafka_consumer_offsets** | 8 columns | Consumer group state & recovery |
| **NEW: event_processing_status** | 10 columns | Pipeline observability |
| **user_sessions** | None | Same aggregation |
| **daily_usage_summary** | None | Same aggregation |
| **page_analytics** | None | Same aggregation |
| **button_analytics** | None | Same aggregation |

**Total tables:** 8 (5 original + 3 Kafka-specific)

---

## BENEFITS OF KAFKA ARCHITECTURE

### ✅ Scalability
- Partitioning: 3 partitions = up to 3 consumers in parallel
- Can scale to 30 partitions if throughput grows 10x
- Each consumer instance processes independent partitions

### ✅ Reliability
- Deduplication via kafka_event_tracking
- Consumer group offsets enable recovery
- Exactly-once processing semantics

### ✅ Flexibility
- Multiple consumers from same topic (redshift-writer + blob-archiver today)
- Easy to add real-time dashboard consumer later
- Easy to add alerting consumer later

### ✅ Observability
- event_processing_status tracks full pipeline
- kafka_consumer_offsets shows consumer lag
- Can detect bottlenecks per stage

### ✅ Future-proof
- Today: 5K events/day (1 consumer sufficient)
- Tomorrow: 100K events/day (scale to 5 consumers)
- No code changes needed, just add partitions

---

## COST ESTIMATE (WITH KAFKA)

| Component | Cost | Purpose |
|-----------|------|---------|
| Kafka Cluster | $400-600/month | 3 brokers, 2TB storage, managed service |
| Redshift | $250/month | Same as before |
| Blob Storage | $50/month | Archive old events |
| Monitoring | $100/month | Kafka + Redshift observability |
| **TOTAL** | **~$800-1000/month** | |

**Note:** Significant increase vs $250/month without Kafka. Worth it IF you plan to scale.

---

## TIMELINE IMPACT

**Without Kafka:** 4-6 weeks (simple direct API → Redshift)  
**With Kafka:** 6-8 weeks (+2 weeks for Kafka integration & testing)

**Extra effort:**
- Kafka cluster setup: 2-3 days
- Consumer implementation: 3-4 days
- Deduplication logic: 2 days
- Testing & monitoring: 3-4 days

---

## RECOMMENDATION

**Should you include Kafka now?**

| Scenario | Recommendation |
|----------|-----------------|
| **"We need it NOW to scale"** | YES, include Kafka. 6-8 weeks is acceptable. |
| **"We might need it LATER"** | NO, skip for Phase 1. Add in Phase 2 (3 months). |
| **"We want maximum flexibility"** | YES, design for Kafka now. Easy to add, hard to retrofit. |
| **"Cost is critical concern"** | NO, skip. Extra $500/month is significant. |
| **"We're bootstrapped/MVP"** | NO, skip. Ship simple first. |

**My suggestion:** Include Kafka architecture (tables + design) now, but deploy simple API-to-Redshift for Phase 1. Kafka consumer code ready but deactivated. When you hit 50K events/day, activate Kafka in 2-3 days (code already written).

This is **future-proofed but not overbuilt.**

---

## FILE STRUCTURE (With Kafka)

```
src/
├─ services/
│  ├─ telemetryService.js (same as before)
│  ├─ kafkaProducer.js (NEW: publish to Kafka)
│  └─ kafkaConsumer.js (NEW: consume from Kafka)
│
├─ workers/
│  ├─ redshiftWriter.js (NEW: Kafka → Redshift)
│  ├─ blobArchiver.js (NEW: Kafka → Blob)
│  └─ aggregationJob.js (same as before)
│
└─ database/
   └─ schema/
      ├─ user_events.sql (updated)
      ├─ user_sessions.sql (same)
      ├─ daily_usage_summary.sql (same)
      ├─ page_analytics.sql (same)
      ├─ button_analytics.sql (same)
      ├─ kafka_event_tracking.sql (NEW)
      ├─ kafka_consumer_offsets.sql (NEW)
      └─ event_processing_status.sql (NEW)
```

This is your **production-ready Kafka-enabled telemetry schema**. ✅
