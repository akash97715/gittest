# FCR AI - Telemetry Layer Implementation Plan
## Phase-wise Execution Guide

**Document Version:** 1.0  
**Created:** August 17, 2026  
**Target Users:** ~100 concurrent  
**Estimated Timeline:** 4-6 weeks  
**Status:** Strategic Planning Phase

---

## EXECUTIVE SUMMARY

This document outlines a structured, phase-based implementation roadmap for deploying a comprehensive telemetry and user insights system for the FCR AI application. The system will capture user interactions at every level—authentication, navigation, feature usage, and error events—and provide actionable insights through real-time dashboards and analytics.

### Why This Matters
- **User Understanding:** Track how users actually interact with your app
- **Feature Adoption:** Identify which features are used and which are neglected
- **Performance Insights:** Detect bottlenecks and user friction points
- **Data-Driven Decisions:** Make product decisions backed by real usage data

### Key Metrics After Full Implementation
- Real-time user activity dashboard
- Session duration and engagement tracking
- Feature adoption rates
- Page performance analysis
- Error tracking and resolution SLA
- User journey patterns

---

## CURRENT STATE ASSESSMENT

### What's Already in Place ✅
| Component | Status | Location | Details |
|-----------|--------|----------|---------|
| TelemetryService (Frontend) | ✅ Ready | `src/services/telemetryService.js` | 240 lines, event batching, offline support |
| Database Schema | ✅ Documented | `TELEMETRY_DATABASE_SCHEMA.sql` | 5 tables, indexes, aggregations |
| API Endpoints | ✅ Documented | `TELEMETRY_ENDPOINTS.js` | 6 endpoints, validation, error handling |
| Documentation | ✅ Complete | 4 markdown files | 1,500+ lines of guides |

### What's NOT Yet Done ❌
| Component | Priority | Est. Effort | Notes |
|-----------|----------|------------|-------|
| Redshift Schema Deployment | **P0-Critical** | 5 min | SQL execution only |
| Server.js Integration | **P0-Critical** | 30 min | Copy endpoints code |
| App.jsx Telemetry Init | **P0-Critical** | 15 min | Initialize on auth |
| Page View Tracking | **P1-High** | 45 min | 6 pages × 7 min each |
| Button Click Tracking | **P1-High** | 60 min | ~15 buttons across app |
| Error Boundary Setup | **P2-Medium** | 20 min | Error tracking wrapper |
| Analytics Dashboard | **P2-Medium** | 120 min | Visualization component |
| Testing & QA | **P2-Medium** | 45 min | Event validation |

---

## PHASE 1: FOUNDATION & DATABASE (Week 1 - 3 days)

### Objectives
- ✅ Set up Redshift schema and tables
- ✅ Verify database connectivity
- ✅ Create baseline performance baselines

### Deliverables

#### 1.1 Database Schema Setup (30 minutes)
**Location:** `TELEMETRY_DATABASE_SCHEMA.sql`

**Tables to Create:**
1. `telemetry.user_events` - Raw event storage
   - Fields: event_id, session_id, user_id, event_type, event_data (JSONB), timestamp
   - Indexes: user_id, session_id, event_type, timestamp
   - Retention: 90 days rolling window

2. `telemetry.user_sessions` - Session aggregation
   - Fields: session_id, user_id, session_start, session_end, duration_seconds, event_count
   - Indexes: user_id, session_start DESC
   - Auto-aggregated from raw events

3. `telemetry.daily_usage_summary` - Daily rollups
   - Fields: usage_date, active_users, total_events, total_logins, avg_session_duration
   - Purpose: Fast queries for dashboard KPIs

4. `telemetry.page_analytics` - Page-level metrics
   - Fields: page_name, view_count, avg_time_spent_seconds, bounce_rate
   - Materialized view from raw events

5. `telemetry.button_analytics` - Feature adoption tracking
   - Fields: button_name, page, click_count, unique_users, adoption_rate
   - For identifying popular vs. unused features

**Execution Steps:**
```sql
-- Step 1: Create schema
CREATE SCHEMA IF NOT EXISTS telemetry;

-- Step 2: Execute full schema from TELEMETRY_DATABASE_SCHEMA.sql
-- (Provided file, ~250 lines)

-- Step 3: Verify creation
SELECT * FROM information_schema.tables 
WHERE table_schema = 'telemetry';

-- Expected: 5 tables created
```

**Success Criteria:**
- [ ] All 5 tables created without errors
- [ ] All indexes created successfully
- [ ] Schema verified via information_schema query
- [ ] Database user has INSERT permissions

#### 1.2 Connectivity Testing (15 minutes)
**Location:** `server.js` - use existing pool connection

**Test Query:**
```javascript
// Add temporary test in server.js
app.get('/api/telemetry/health', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT COUNT(*) as event_count FROM telemetry.user_events`
    );
    res.json({ 
      status: 'connected', 
      telemetry_events: result.rows[0].event_count 
    });
  } catch (err) {
    res.status(500).json({ status: 'failed', error: err.message });
  }
});
```

**Verification:**
```bash
curl http://localhost:8080/api/telemetry/health
# Expected: { "status": "connected", "telemetry_events": 0 }
```

### SOP Document Elements (Phase 1)
**What to document:**
- [ ] Schema deployment checklist
- [ ] Database connection verification steps
- [ ] Expected table structure screenshot
- [ ] Performance baseline metrics
- [ ] Data retention policy (90-day rolling window)
- [ ] Backup and recovery procedures
- [ ] User permissions required

### Success Metrics
- ✅ Database responds to test queries in < 100ms
- ✅ All telemetry tables exist and have correct schema
- ✅ No permission errors when inserting test data

---

## PHASE 2: BACKEND INTEGRATION (Week 1 - Days 3-4)

### Objectives
- ✅ Deploy API endpoints to server.js
- ✅ Set up event validation
- ✅ Implement error handling

### Deliverables

#### 2.1 Copy Telemetry Endpoints (30 minutes)
**Source:** `TELEMETRY_ENDPOINTS.js`  
**Destination:** `server.js`

**6 Endpoints to Add:**

```javascript
// Endpoint 1: POST /api/telemetry - Main event ingestion
POST /api/telemetry
Request: { events: [...], batchCount: 10, timestamp: "2026-08-17T10:30:00Z" }
Response: { success: true, eventsReceived: 10 }
Purpose: Receive and store event batches

// Endpoint 2: GET /api/telemetry/user-sessions - Session history
GET /api/telemetry/user-sessions?days=7&limit=50
Purpose: Retrieve user session summaries

// Endpoint 3: GET /api/telemetry/user/:userId - User activity
GET /api/telemetry/user/user123?days=30
Purpose: User-level engagement metrics

// Endpoint 4: GET /api/telemetry/page-analytics - Page performance
GET /api/telemetry/page-analytics?days=7
Purpose: Page view counts, time spent, bounce rates

// Endpoint 5: GET /api/telemetry/button-analytics - Feature adoption
GET /api/telemetry/button-analytics?limit=20&sortBy=clicks
Purpose: Most/least used features

// Endpoint 6: GET /api/telemetry/daily-summary - Daily KPIs
GET /api/telemetry/daily-summary?days=30
Purpose: Aggregate daily statistics
```

**Integration Steps:**
1. Open `server.js`
2. Locate existing endpoints (e.g., `/api/summary`, `/api/schema`)
3. Insert telemetry endpoints BEFORE static file serving
4. Update error handling to log to telemetry table
5. Add request validation middleware

**Code Example - Event Ingestion Endpoint:**
```javascript
app.post('/api/telemetry', async (req, res) => {
  try {
    const { events, batchCount, timestamp } = req.body;
    
    // Validation
    if (!events || !Array.isArray(events)) {
      return res.status(400).json({ error: 'Invalid events format' });
    }
    
    // Insert each event
    for (const event of events) {
      try {
        await pool.query(
          `INSERT INTO telemetry.user_events 
            (session_id, user_id, user_name, user_email, event_type, 
             event_data, page, url, timestamp)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [
            event.sessionId,
            event.userId,
            event.userName,
            event.userEmail,
            event.eventType,
            JSON.stringify(event.eventData),
            event.eventData?.page || null,
            event.url,
            event.timestamp || new Date().toISOString(),
          ]
        );
      } catch (err) {
        console.error('Event insert failed:', err);
        // Continue with batch even if single event fails
      }
    }
    
    res.json({
      success: true,
      eventsReceived: events.length,
      message: `Received ${batchCount || events.length} telemetry events`
    });
  } catch (error) {
    console.error('/api/telemetry error:', error);
    res.status(500).json({ error: error.message });
  }
});
```

#### 2.2 Request Validation Middleware (15 minutes)
**Purpose:** Ensure only valid events are stored

```javascript
// Add before telemetry endpoints
const validateTelemetryEvent = (req, res, next) => {
  const validEventTypes = [
    'user_login', 'user_logout', 'page_view', 'page_exit',
    'button_click', 'search', 'data_export', 'api_call',
    'error', 'session_start', 'session_end', 'custom'
  ];
  
  const { events } = req.body;
  
  if (!events || !Array.isArray(events)) {
    return res.status(400).json({ error: 'Events must be an array' });
  }
  
  for (const event of events) {
    if (!event.eventType || !validEventTypes.includes(event.eventType)) {
      return res.status(400).json({ 
        error: `Invalid event type: ${event.eventType}` 
      });
    }
    if (!event.sessionId || !event.userId) {
      return res.status(400).json({ 
        error: 'Missing required fields: sessionId, userId' 
      });
    }
  }
  
  next();
};

// Use middleware
app.post('/api/telemetry', validateTelemetryEvent, async (req, res) => {
  // ... endpoint code
});
```

#### 2.3 Database Insertion with Error Handling (15 minutes)
**Purpose:** Robust event storage with rollback capability

```javascript
// Add helper function
async function insertTelemetryBatch(events) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let insertedCount = 0;
    
    for (const event of events) {
      try {
        await client.query(
          `INSERT INTO telemetry.user_events 
            (session_id, user_id, user_name, user_email, event_type, 
             event_data, page, url, timestamp)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [
            event.sessionId,
            event.userId,
            event.userName,
            event.userEmail,
            event.eventType,
            JSON.stringify(event.eventData),
            event.eventData?.page || null,
            event.url,
            event.timestamp || new Date().toISOString(),
          ]
        );
        insertedCount++;
      } catch (err) {
        console.error('Event insert failed:', err);
      }
    }
    
    await client.query('COMMIT');
    return { success: true, inserted: insertedCount, total: events.length };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
```

### Testing Checklist (Phase 2)

**Manual Testing:**
```bash
# Test 1: Ping telemetry endpoint
curl -X POST http://localhost:8080/api/telemetry \
  -H "Content-Type: application/json" \
  -d '{
    "events": [{
      "sessionId": "test-session-1",
      "userId": "user123",
      "userName": "Test User",
      "userEmail": "test@example.com",
      "eventType": "page_view",
      "eventData": { "page": "activity", "pageTitle": "Activity" },
      "url": "/activity",
      "timestamp": "2026-08-17T10:30:00Z"
    }],
    "batchCount": 1
  }'
# Expected: { "success": true, "eventsReceived": 1 }

# Test 2: Query inserted events
curl http://localhost:8080/api/telemetry/user-sessions?days=1&limit=10
# Expected: Array of session objects

# Test 3: Page analytics query
curl http://localhost:8080/api/telemetry/page-analytics?days=7
# Expected: Array of page analytics
```

**Automated Testing Points:**
- [ ] Invalid event type rejected (400)
- [ ] Missing sessionId rejected (400)
- [ ] Valid event returns success (200)
- [ ] Events persisted to database
- [ ] Query endpoints return proper format
- [ ] Error handling doesn't crash server

### SOP Document Elements (Phase 2)
**What to document:**
- [ ] API endpoint reference guide (6 endpoints)
- [ ] Request/response schema for each endpoint
- [ ] Error codes and meanings
- [ ] Rate limiting policies (if any)
- [ ] Data validation rules
- [ ] Event type definitions and required fields
- [ ] Testing procedures and expected outcomes

### Success Metrics
- ✅ All 6 API endpoints operational
- ✅ Events successfully inserted to database
- ✅ Query endpoints return valid JSON
- ✅ Error handling prevents server crashes

---

## PHASE 3: FRONTEND INITIALIZATION (Week 2 - Days 1-2)

### Objectives
- ✅ Initialize telemetry service on app load
- ✅ Capture user authentication
- ✅ Set up session tracking

### Deliverables

#### 3.1 Update App.jsx - Telemetry Initialization (20 minutes)
**Location:** `App.jsx`

**Current Code:**
```jsx
import { useState } from 'react';
import { useIsAuthenticated } from '@azure/msal-react';
// ... other imports

export default function App() {
  const isAuthenticated = useIsAuthenticated();
  const [hasConsented, setHasConsented] = useState(false);
  const [active, setActive] = useState('activity');
  
  // NO TELEMETRY YET
  if (!isAuthenticated) {
    return <LoginPage />;
  }
  // ... rest of code
}
```

**Updated Code:**
```jsx
import { useState, useEffect } from 'react';
import { useIsAuthenticated } from '@azure/msal-react';
import { useMsal } from '@azure/msal-react';
import { telemetry } from './services/telemetryService';  // ADD THIS
// ... other imports

export default function App() {
  const isAuthenticated = useIsAuthenticated();
  const { accounts } = useMsal();  // GET ACCOUNT INFO
  const [hasConsented, setHasConsented] = useState(false);
  const [active, setActive] = useState('activity');
  
  // INITIALIZE TELEMETRY AFTER AUTH
  useEffect(() => {
    if (isAuthenticated && accounts && accounts.length > 0) {
      const account = accounts[0];
      telemetry.init(
        account.localAccountId || account.homeAccountId,
        account.name || 'Unknown User',
        account.username || 'unknown@company.com'
      );
      console.log('[App] Telemetry initialized for:', account.name);
    }
  }, [isAuthenticated, accounts]);
  
  if (!isAuthenticated) {
    return <LoginPage />;
  }
  
  if (!hasConsented) {
    return <ConsentPage onAccept={() => setHasConsented(true)} />;
  }
  
  const renderPage = () => {
    switch (active) {
      case 'activity':   return <ActivityPage />;
      case 'capability': return <CapabilityPage />;
      case 'askai':      return <AskAIPage />;
      case 'reference':  return <ReferencePage />;
      default:           return <PlaceholderPage title="Coming Soon" />;
    }
  };
  
  return (
    <div className="app-shell">
      <Sidebar active={active} onNavigate={setActive} />
      <div className="main-area">
        <Topbar />
        <main className="page-content" id="main-content" role="main">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
```

**Key Changes:**
1. Import `useMsal` hook
2. Import `telemetry` service
3. Add useEffect to initialize telemetry on auth
4. Capture user info from Azure account

#### 3.2 Update LoginPage.jsx - Track Login Event (10 minutes)
**Location:** `LoginPage.jsx`

**Add After Login:**
```jsx
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../authConfig';
import { telemetry } from '../services/telemetryService';  // ADD THIS

export default function LoginPage() {
  const { instance } = useMsal();

  const handleLogin = () => {
    instance.loginPopup(loginRequest)
      .then(() => {
        // After successful login, telemetry will init in App.jsx
        console.log('[LoginPage] User logged in successfully');
      })
      .catch((e) => {
        console.error('[LoginPage] Login error:', e);
        // Track login failure
        telemetry.trackEvent('login_error', {
          error: e.message,
          errorCode: e.errorCode,
        });
      });
  };
  
  // ... rest of component
}
```

#### 3.3 Update ConsentPage.jsx - Track Consent (5 minutes)
**Location:** `ConsentPage.jsx`

**Add Consent Tracking:**
```jsx
import { telemetry } from '../services/telemetryService';  // ADD THIS

export default function ConsentPage({ onAccept }) {
  const handleAccept = () => {
    // Track consent acceptance
    telemetry.trackButtonClick('consent_accept', {
      consented: true,
      timestamp: new Date().toISOString(),
    });
    onAccept();
  };
  
  const handleDecline = () => {
    // Track consent decline
    telemetry.trackButtonClick('consent_decline', {
      consented: false,
      timestamp: new Date().toISOString(),
    });
    // Could redirect or show message
  };
  
  // ... rest of component
}
```

#### 3.4 Update TelemetryService - Batch Sending Configuration (10 minutes)
**Location:** `src/services/telemetryService.js`

**Review Current Implementation:**
- Batch size: 10 events ✅
- Batch interval: 30 seconds ✅
- Offline storage: localStorage ✅
- Retry logic: Need to verify ✅

**Verify These Methods Exist:**
```javascript
// Should have these methods:
class TelemetryService {
  // Core tracking methods
  trackEvent(eventType, eventData) { }
  trackPageView(pageName, pageTitle) { }
  trackButtonClick(buttonName, context) { }
  trackSearch(searchTerm, filters) { }
  trackDataExport(exportType, dataCount) { }
  trackApiCall(apiName, statusCode, durationMs) { }
  trackError(errorMessage, errorStack, context) { }
  
  // Batch management
  startBatchTimer() { }
  sendBatch() { }
  flush() { }
  
  // Utility
  generateSessionId() { }
  // ... others
}
```

**Add Logging for Debugging:**
```javascript
// Add at top of TelemetryService
static DEBUG = true; // Set to false in production

if (TelemetryService.DEBUG) {
  console.log('[Telemetry] Event:', eventType, eventData);
}
```

### Session Management Implementation

**Session Tracking Flow:**
```
1. User logs in → telemetry.init() called
2. sessionId generated (random UUID)
3. user_login event sent
4. Page navigation tracked
5. Events batched and sent
6. Page unload → final batch sent
7. Session closed

Result: One session record with:
- session_start: initial timestamp
- session_end: last event timestamp
- event_count: total events in session
- duration_seconds: calculated duration
```

### Testing Checklist (Phase 3)

**Manual Testing:**
```bash
# 1. Open app in browser
# 2. Log in with Microsoft account
# 3. Check browser console for telemetry initialization message
# Expected: "[Telemetry] Initialized for user: [Name]"

# 4. Open Network tab in DevTools
# 5. Wait 30 seconds or trigger 10 events
# 6. Look for POST to /api/telemetry
# Expected: Request with 10 events payload

# 7. Check Redshift table
SELECT * FROM telemetry.user_events 
ORDER BY timestamp DESC LIMIT 10;
# Expected: 10+ rows with user_login and other events

# 8. Verify session data
SELECT * FROM telemetry.user_sessions 
ORDER BY session_start DESC LIMIT 1;
# Expected: One session record with event_count >= 10
```

### SOP Document Elements (Phase 3)
**What to document:**
- [ ] Telemetry initialization flow diagram
- [ ] Session ID generation process
- [ ] Event batching mechanism
- [ ] Offline event storage
- [ ] Retry logic with exponential backoff
- [ ] User information capture from Azure MSAL
- [ ] Browser console debugging tips
- [ ] Common troubleshooting (missing events, etc.)

### Success Metrics
- ✅ Telemetry initializes on login
- ✅ Events appear in browser console (DEBUG mode)
- ✅ Events sent to backend via POST /api/telemetry
- ✅ Events visible in Redshift user_events table
- ✅ Session records created in user_sessions table

---

## PHASE 4: PAGE INSTRUMENTATION (Week 2 - Days 3-4)

### Objectives
- ✅ Track page navigation
- ✅ Measure time spent per page
- ✅ Capture page-specific context

### Deliverables

#### 4.1 Page View Tracking Setup (45 minutes)
**Strategy:** Add page tracking to App.jsx route changes

**Current Implementation Issue:**
```jsx
// Current - no tracking
const renderPage = () => {
  switch (active) {
    case 'activity':   return <ActivityPage />;
    case 'capability': return <CapabilityPage />;
    // ... no telemetry
  }
};
```

**Updated Implementation:**
```jsx
import { telemetry } from './services/telemetryService';

// Add effect to track page changes
useEffect(() => {
  if (hasConsented) {
    // Track when active page changes
    const pageMap = {
      'activity': { name: 'activity', title: 'Activity Dashboard' },
      'capability': { name: 'capability', title: 'Capability Analysis' },
      'askai': { name: 'askai', title: 'Ask AI' },
      'reference': { name: 'reference', title: 'Reference' },
    };
    
    const page = pageMap[active];
    if (page) {
      telemetry.trackPageView(page.name, page.title);
    }
  }
}, [active, hasConsented]);

const renderPage = () => {
  switch (active) {
    case 'activity':   return <ActivityPage />;
    case 'capability': return <CapabilityPage />;
    case 'askai':      return <AskAIPage />;
    case 'reference':  return <ReferencePage />;
    default:           return <PlaceholderPage title="Coming Soon" />;
  }
};
```

#### 4.2 Page-Specific Tracking (Each Page ~5 minutes × 6 pages = 30 minutes)

**For Each Page Component:**

**Pattern 1: ActivityPage.jsx**
```jsx
import { useEffect } from 'react';
import { telemetry } from '../services/telemetryService';

export default function ActivityPage() {
  useEffect(() => {
    // Track page view (already done in App.jsx)
    // Optional: Track any page-specific events
    telemetry.trackEvent('page_load_complete', {
      page: 'activity',
      timestamp: new Date().toISOString(),
    });
  }, []);
  
  return (
    <>
      <AlertsBanner />
      <HeroCard />
      {/* ... page content ... */}
    </>
  );
}
```

**Pattern 2: CapabilityPage.jsx**
```jsx
import { useEffect } from 'react';
import { telemetry } from '../services/telemetryService';

export default function CapabilityPage() {
  useEffect(() => {
    telemetry.trackEvent('capability_page_loaded', {
      page: 'capability',
      timestamp: new Date().toISOString(),
    });
  }, []);
  
  return (
    <>
      {/* Page content */}
    </>
  );
}
```

**Pattern 3: AskAIPage.jsx**
```jsx
import { useEffect } from 'react';
import { telemetry } from '../services/telemetryService';

export default function AskAIPage() {
  useEffect(() => {
    telemetry.trackEvent('askai_page_loaded', {
      page: 'askai',
      timestamp: new Date().toISOString(),
    });
  }, []);
  
  return (
    <>
      {/* Page content */}
    </>
  );
}
```

**Pages to Instrument:**
1. ✅ ActivityPage.jsx
2. ✅ CapabilityPage.jsx
3. ✅ AskAIPage.jsx
4. ✅ ReferencePage.jsx
5. ✅ ConsentPage.jsx
6. ✅ LoginPage.jsx

#### 4.3 Measure Time Spent Per Page
**Implementation:** Automatic via TelemetryService.trackPageView()

**How It Works:**
```javascript
// In telemetryService.js - ALREADY IMPLEMENTED
trackPageView(pageName, pageTitle) {
  if (this.currentPage) {
    // Calculate time spent on PREVIOUS page
    const timeSpent = (Date.now() - this.pageStartTime) / 1000;
    this.trackEvent('page_exit', {
      page: this.currentPage,
      timeSpentSeconds: parseFloat(timeSpent.toFixed(2)),
    });
  }
  
  // Track entry to NEW page
  this.currentPage = pageName;
  this.pageStartTime = Date.now();
  this.trackEvent('page_view', {
    page: pageName,
    pageTitle: pageTitle,
    timestamp: new Date().toISOString(),
    url: window.location.pathname,
  });
}
```

**Result in Database:**
```
page_view Event:
- page: "activity"
- pageTitle: "Activity Dashboard"
- timestamp: "2026-08-17T10:30:00Z"

[User navigates to "capability"]

page_exit Event:
- page: "activity"
- timeSpentSeconds: 45.23  ← Calculated automatically
- timestamp: "2026-08-17T10:31:45Z"

page_view Event:
- page: "capability"
- pageTitle: "Capability Analysis"
- timestamp: "2026-08-17T10:31:45Z"
```

### SOP Document Elements (Phase 4)
**What to document:**
- [ ] Page tracking implementation guide
- [ ] Time spent calculation methodology
- [ ] Page navigation flow diagram
- [ ] Expected events per user session example
- [ ] Bounce rate definition (page_view without interactions)
- [ ] Exit page analytics interpretation
- [ ] Page performance targets

### Testing Checklist (Phase 4)

**Manual Testing Steps:**
```bash
# 1. Open app and log in
# 2. Navigate through all pages
# 3. Monitor Network tab for /api/telemetry calls
# 4. Verify each navigation creates page_view + page_exit events

# 5. Query page analytics
SELECT page, COUNT(*) as views, AVG(time_spent_seconds) as avg_time
FROM telemetry.user_events
WHERE event_type IN ('page_view', 'page_exit')
GROUP BY page;

# Expected:
# activity    | 5   | 45.2
# capability  | 3   | 32.1
# askai       | 2   | 28.5
# reference   | 1   | 15.3
```

### Success Metrics
- ✅ All pages tracked with page_view events
- ✅ Time spent calculated for each page
- ✅ Page analytics dashboard queryable
- ✅ No missing page navigation data

---

## PHASE 5: FEATURE TRACKING (Week 3 - Days 1-2)

### Objectives
- ✅ Track button clicks and feature usage
- ✅ Identify most/least used features
- ✅ Monitor feature adoption

### Deliverables

#### 5.1 Button Click Tracking Strategy (30 minutes)
**Approach:** Identify all interactive buttons and add tracking

**Priority Buttons by Impact:**

**High Priority (Must Track):**
| Button | Location | Action | Context |
|--------|----------|--------|---------|
| Export FCR | RecentFCRsTable | Export to PDF/Excel | fcr_id, format |
| View Details | RecentFCRsTable | Navigate to FCR detail | fcr_id, source |
| Filter | CoverageTable | Apply filters | filters_applied, count |
| Search | Any table | Search in data | search_term, results_count |
| Ask AI | AskAIPanel | Submit AI query | query_text, context |

**Medium Priority (Track):**
| Button | Location | Action | Context |
|--------|----------|--------|---------|
| Navigate (sidebar) | Sidebar | Change page | page_target, from_page |
| View Report | ActivityPage | Open report | report_type |
| Refresh Data | Any panel | Refresh metrics | data_source |

**Low Priority (Can Track Later):**
| Button | Location | Action | Context |
|--------|----------|--------|---------|
| Help | Topbar | Open help | help_topic |
| Settings | Topbar | Open settings | setting_section |

#### 5.2 Implementation: Button Click Tracking (60 minutes)
**6 components × 10 minutes each**

**Example 1: RecentFCRsTable.jsx - Export Button**
```jsx
import { telemetry } from '../services/telemetryService';  // ADD

export default function RecentFCRsTable() {
  const handleExportFCR = (fcrId, format = 'pdf') => {
    // Track button click
    telemetry.trackButtonClick('export_fcr', {
      fcr_id: fcrId,
      export_format: format,
      source: 'recent_fcrs_table',
      timestamp: new Date().toISOString(),
    });
    
    // Actual export logic
    console.log(`Exporting FCR ${fcrId} as ${format}`);
    // ... export implementation
  };
  
  const handleViewDetails = (fcrId) => {
    // Track button click
    telemetry.trackButtonClick('view_fcr_details', {
      fcr_id: fcrId,
      source: 'recent_fcrs_table',
      timestamp: new Date().toISOString(),
    });
    
    // Navigate to detail view
    // ... navigation logic
  };
  
  return (
    <table>
      {/* Table content */}
      <button onClick={() => handleViewDetails(row.id)}>View Details</button>
      <button onClick={() => handleExportFCR(row.id, 'pdf')}>Export PDF</button>
    </table>
  );
}
```

**Example 2: CoverageTable.jsx - Filter Button**
```jsx
import { telemetry } from '../services/telemetryService';

export default function CoverageTable() {
  const handleApplyFilters = (filters) => {
    telemetry.trackSearch('coverage_filter', {
      filters_applied: Object.keys(filters).length,
      filter_types: Object.keys(filters),
      results_count: filteredData.length,
      timestamp: new Date().toISOString(),
    });
    
    // Apply filters
    setFilteredData(data.filter(/* ... */));
  };
  
  return (
    <div>
      <button onClick={() => handleApplyFilters(activeFilters)}>
        Apply Filters
      </button>
    </div>
  );
}
```

**Example 3: AskAIPanel.jsx - Submit Query**
```jsx
import { telemetry } from '../services/telemetryService';

export default function AskAIPanel() {
  const handleSubmitQuery = async (query) => {
    telemetry.trackButtonClick('ask_ai_submit', {
      query_length: query.length,
      query_category: categorizeQuery(query),  // e.g., 'trend_analysis'
      timestamp: new Date().toISOString(),
    });
    
    // Call AI API
    const response = await fetch('/api/ask-ai', {
      method: 'POST',
      body: JSON.stringify({ query }),
    });
    
    // Track API call
    telemetry.trackApiCall('ask_ai', response.status, Date.now() - startTime);
    
    // ... handle response
  };
  
  return (
    <div>
      <textarea value={query} onChange={/* ... */} />
      <button onClick={() => handleSubmitQuery(query)}>
        Ask AI
      </button>
    </div>
  );
}
```

**Example 4: Sidebar.jsx - Navigation**
```jsx
import { telemetry } from '../services/telemetryService';

export default function Sidebar({ active, onNavigate }) {
  const handleNavigate = (page) => {
    telemetry.trackButtonClick('sidebar_navigate', {
      target_page: page,
      from_page: active,
      timestamp: new Date().toISOString(),
    });
    
    onNavigate(page);
  };
  
  return (
    <nav>
      <button onClick={() => handleNavigate('activity')}>Activity</button>
      <button onClick={() => handleNavigate('capability')}>Capability</button>
      <button onClick={() => handleNavigate('askai')}>Ask AI</button>
      <button onClick={() => handleNavigate('reference')}>Reference</button>
    </nav>
  );
}
```

**Example 5: Topbar.jsx - Header Actions**
```jsx
import { telemetry } from '../services/telemetryService';
import { useMsal } from '@azure/msal-react';

export default function Topbar() {
  const { instance, accounts } = useMsal();
  
  const handleLogout = () => {
    telemetry.trackButtonClick('logout', {
      user_id: accounts[0].localAccountId,
      timestamp: new Date().toISOString(),
    });
    
    // Flush all pending events before logout
    telemetry.flush();
    
    instance.logoutPopup();
  };
  
  return (
    <header>
      {/* Header content */}
      <button onClick={handleLogout}>Logout</button>
    </header>
  );
}
```

**Example 6: Data Export Tracking**
```jsx
const handleDataExport = (dataType, format) => {
  const recordCount = getRecordCount(dataType);
  
  telemetry.trackDataExport(format, recordCount);
  telemetry.trackButtonClick('data_export', {
    data_type: dataType,
    export_format: format,
    record_count: recordCount,
    file_size_kb: estimateFileSize(dataType, format) / 1024,
    timestamp: new Date().toISOString(),
  });
  
  // Execute export
  downloadData(dataType, format);
};
```

### Search and Filter Tracking (15 minutes)

**Implementation Pattern:**
```jsx
const handleSearch = (searchTerm) => {
  const results = performSearch(searchTerm);
  
  telemetry.trackSearch(searchTerm, {
    source_page: currentPage,
    results_count: results.length,
    search_category: categorizeSearch(searchTerm),
    timestamp: new Date().toISOString(),
  });
  
  setResults(results);
};

const handleFilterChange = (filterName, filterValue) => {
  const filters = { ...activeFilters, [filterName]: filterValue };
  const results = applyFilters(filters);
  
  telemetry.trackSearch(`filter_${filterName}`, {
    filter_value: filterValue,
    results_count: results.length,
    active_filters_count: Object.keys(filters).length,
    timestamp: new Date().toISOString(),
  });
  
  setActiveFilters(filters);
};
```

### SOP Document Elements (Phase 5)
**What to document:**
- [ ] Button tracking checklist (all buttons)
- [ ] Event context data for each button
- [ ] Feature adoption metrics definition
- [ ] Most/least used features query
- [ ] Button click analytics dashboard specs
- [ ] Filter tracking methodology
- [ ] Search term classification system

### Testing Checklist (Phase 5)

**Manual Testing:**
```bash
# 1. For each tracked button:
#    a. Click button
#    b. Check Network tab for /api/telemetry POST
#    c. Verify event includes correct context

# 2. For searches/filters:
#    a. Perform search/filter
#    b. Verify event includes search term and results count

# 3. Query feature adoption
SELECT button, COUNT(*) as clicks, COUNT(DISTINCT user_id) as unique_users
FROM telemetry.user_events
WHERE event_type = 'button_click'
GROUP BY button
ORDER BY clicks DESC;

# Expected: List of all tracked buttons with usage counts
```

### Success Metrics
- ✅ All priority buttons tracked
- ✅ Button context data captured correctly
- ✅ Feature adoption metrics queryable
- ✅ Search/filter tracking functional

---

## PHASE 6: ERROR & PERFORMANCE TRACKING (Week 3 - Days 3-4)

### Objectives
- ✅ Track errors and exceptions
- ✅ Monitor API performance
- ✅ Set up error alerting

### Deliverables

#### 6.1 Error Boundary Setup (20 minutes)
**Location:** Create `src/components/ErrorBoundary.jsx`

```jsx
import { Component } from 'react';
import { telemetry } from '../services/telemetryService';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Log error to telemetry
    telemetry.trackError(error.message, error.stack, {
      componentStack: errorInfo.componentStack,
      errorBoundary: true,
      timestamp: new Date().toISOString(),
    });
    
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
          color: '#666',
        }}>
          <h1>⚠️ Something went wrong</h1>
          <p>{this.state.error?.message}</p>
          <button onClick={() => window.location.reload()}>
            Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
```

**Update App.jsx to Use ErrorBoundary:**
```jsx
import ErrorBoundary from './components/ErrorBoundary';

export default function App() {
  return (
    <ErrorBoundary>
      <div className="app-shell">
        {/* ... existing code ... */}
      </div>
    </ErrorBoundary>
  );
}
```

#### 6.2 Fetch Error Tracking (20 minutes)
**Create global fetch interceptor**

**Add to `main.jsx` after root render:**
```jsx
// Intercept all fetch calls to track API performance
const originalFetch = window.fetch;

window.fetch = function(...args) {
  const [url, config] = args;
  const startTime = Date.now();
  
  return originalFetch.apply(this, args)
    .then(response => {
      const duration = Date.now() - startTime;
      
      // Extract API endpoint name
      const apiName = url.split('/').pop() || url;
      
      // Track API call
      telemetry.trackApiCall(apiName, response.status, duration);
      
      // Track errors (4xx, 5xx)
      if (response.status >= 400) {
        telemetry.trackError(
          `API Error: ${response.status}`,
          `URL: ${url}`,
          {
            api_endpoint: url,
            status_code: response.status,
            duration_ms: duration,
            timestamp: new Date().toISOString(),
          }
        );
      }
      
      return response;
    })
    .catch(error => {
      const duration = Date.now() - startTime;
      
      // Track network errors
      telemetry.trackError(
        'Network Error: ' + error.message,
        error.stack,
        {
          api_endpoint: url,
          duration_ms: duration,
          timestamp: new Date().toISOString(),
        }
      );
      
      throw error;
    });
};
```

#### 6.3 Console Error Tracking (15 minutes)
**Track JavaScript errors logged to console**

**Add to `main.jsx`:**
```jsx
// Track console errors
const originalError = console.error;
console.error = function(...args) {
  const errorMessage = args[0]?.toString?.() || String(args[0]);
  
  // Don't track telemetry errors to avoid infinite loops
  if (!errorMessage.includes('[Telemetry]')) {
    telemetry.trackError(
      'Console Error: ' + errorMessage,
      args[1]?.stack || '',
      {
        error_source: 'console.error',
        full_message: args.join(' '),
        timestamp: new Date().toISOString(),
      }
    );
  }
  
  originalError.apply(console, args);
};

// Track unhandled promise rejections
window.addEventListener('unhandledrejection', event => {
  telemetry.trackError(
    'Unhandled Promise Rejection: ' + event.reason?.message || event.reason,
    event.reason?.stack || '',
    {
      error_source: 'unhandledrejection',
      timestamp: new Date().toISOString(),
    }
  );
});
```

#### 6.4 Performance Metrics Tracking (15 minutes)

**Track key performance indicators:**

```jsx
// Add to App.jsx or main.jsx
useEffect(() => {
  // Track when app becomes interactive
  if (window.performance && window.performance.timing) {
    window.addEventListener('load', () => {
      const perfData = window.performance.timing;
      const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
      
      telemetry.trackEvent('page_performance', {
        page_load_time_ms: pageLoadTime,
        dom_content_loaded_ms: perfData.domContentLoadedEventEnd - perfData.navigationStart,
        time_to_first_byte_ms: perfData.responseStart - perfData.navigationStart,
        resource_load_time_ms: perfData.loadEventEnd - perfData.responseEnd,
        timestamp: new Date().toISOString(),
      });
    });
  }
}, []);
```

### SOP Document Elements (Phase 6)
**What to document:**
- [ ] Error tracking strategy
- [ ] Error categories and severity levels
- [ ] API performance monitoring thresholds
- [ ] Error alerting policies (e.g., notify on 5+ errors)
- [ ] Performance metrics SLA
- [ ] Debugging error telemetry
- [ ] Error resolution workflow

### Testing Checklist (Phase 6)

**Manual Testing:**
```bash
# 1. Trigger intentional error in component
# 2. Check Network tab for error event POST
# 3. Verify error details in Redshift

SELECT * FROM telemetry.user_events
WHERE event_type = 'error'
ORDER BY timestamp DESC
LIMIT 10;

# 4. Test API error tracking
# Make request to invalid endpoint
# Verify error tracked with status code

# 5. Test performance metrics
curl http://localhost:8080/api/telemetry/page-performance?days=1
# Expected: Performance data for tracked pages
```

### Success Metrics
- ✅ Errors caught and logged
- ✅ API latency tracked
- ✅ Error boundary functional
- ✅ Performance metrics queryable

---

## PHASE 7: ANALYTICS DASHBOARD (Week 4 - Days 1-2)

### Objectives
- ✅ Build real-time telemetry dashboard
- ✅ Create visualization components
- ✅ Set up KPI displays

### Deliverables

#### 7.1 Analytics Dashboard Component (120 minutes)
**Create:** `src/pages/TelemetryDashboard.jsx`

**Key Sections:**

**Section 1: Real-Time Metrics**
```jsx
<div className="metrics-grid">
  <MetricCard 
    title="Active Users (24h)"
    value={activeUsers}
    trend={userTrend}
    icon="👥"
  />
  <MetricCard
    title="Total Events"
    value={totalEvents}
    trend={eventTrend}
    icon="📊"
  />
  <MetricCard
    title="Avg Session Duration"
    value={`${avgSessionDuration}m`}
    trend={durationTrend}
    icon="⏱️"
  />
  <MetricCard
    title="Error Rate"
    value={`${errorRate}%`}
    trend={errorTrend}
    icon="⚠️"
  />
</div>
```

**Section 2: Charts**
- User Activity Timeline (line chart)
- Page Views by Page (bar chart)
- Most Used Features (bar chart)
- Session Duration Distribution (histogram)
- Error Frequency (line chart)

**Section 3: Tables**
- Recent User Sessions
- Top Features (by clicks)
- Page Performance Metrics
- Recent Errors

**Section 4: User Journey**
- Session flow diagram
- Page navigation patterns
- Feature adoption funnel

#### 7.2 Query Functions for Dashboard (60 minutes)
**Create:** `src/services/analyticsService.js`

```javascript
/**
 * Analytics Service
 * Provides data fetching functions for telemetry dashboard
 */

export const analyticsService = {
  // Real-time metrics
  async getActiveUsers(days = 1) {
    const res = await fetch(`/api/telemetry/daily-summary?days=${days}`);
    return res.json();
  },
  
  async getUserSessions(limit = 50) {
    const res = await fetch(`/api/telemetry/user-sessions?limit=${limit}`);
    return res.json();
  },
  
  async getPageAnalytics(days = 7) {
    const res = await fetch(`/api/telemetry/page-analytics?days=${days}`);
    return res.json();
  },
  
  async getButtonAnalytics(limit = 20) {
    const res = await fetch(`/api/telemetry/button-analytics?limit=${limit}`);
    return res.json();
  },
  
  // Detailed user analysis
  async getUserActivity(userId, days = 30) {
    const res = await fetch(`/api/telemetry/user/${userId}?days=${days}`);
    return res.json();
  },
  
  // Error tracking
  async getErrors(days = 7, limit = 50) {
    const res = await fetch(`/api/telemetry/errors?days=${days}&limit=${limit}`);
    return res.json();
  },
  
  // Custom query builder
  async queryEvents(filters) {
    const res = await fetch('/api/telemetry/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(filters),
    });
    return res.json();
  },
};
```

#### 7.3 Add Dashboard Route (10 minutes)

**Update App.jsx:**
```jsx
import TelemetryDashboard from './pages/TelemetryDashboard';

export default function App() {
  // ... existing code ...
  
  const renderPage = () => {
    switch (active) {
      case 'activity':   return <ActivityPage />;
      case 'capability': return <CapabilityPage />;
      case 'askai':      return <AskAIPage />;
      case 'reference':  return <ReferencePage />;
      case 'telemetry':  return <TelemetryDashboard />;  // ADD THIS
      default:           return <PlaceholderPage title="Coming Soon" />;
    }
  };
  
  return (
    <div className="app-shell">
      <Sidebar active={active} onNavigate={setActive} />
      {/* ... rest of component ... */}
    </div>
  );
}
```

**Update Sidebar.jsx to include telemetry link:**
```jsx
<nav>
  {/* ... existing nav items ... */}
  <button onClick={() => onNavigate('telemetry')}>
    📊 Telemetry
  </button>
</nav>
```

#### 7.4 Add Query Endpoints for Dashboard (45 minutes)
**Add to server.js:**

```javascript
// GET /api/telemetry/errors — Error tracking
app.get('/api/telemetry/errors', async (req, res) => {
  try {
    const { days = 7, limit = 50 } = req.query;
    
    const result = await pool.query(`
      SELECT 
        event_id,
        user_id,
        user_name,
        page,
        event_data->>'error_message' as error_message,
        timestamp,
        event_data
      FROM telemetry.user_events
      WHERE event_type = 'error'
        AND timestamp >= NOW() - INTERVAL '${days} days'
      ORDER BY timestamp DESC
      LIMIT ${limit}
    `);
    
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/performance — Performance metrics
app.get('/api/telemetry/performance', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    
    const result = await pool.query(`
      SELECT 
        page,
        COUNT(*) as view_count,
        ROUND(AVG(CAST(event_data->>'timeSpentSeconds' AS FLOAT)), 2) as avg_time_spent,
        ROUND(MIN(CAST(event_data->>'timeSpentSeconds' AS FLOAT)), 2) as min_time,
        ROUND(MAX(CAST(event_data->>'timeSpentSeconds' AS FLOAT)), 2) as max_time
      FROM telemetry.user_events
      WHERE event_type = 'page_exit'
        AND timestamp >= NOW() - INTERVAL '${days} days'
      GROUP BY page
      ORDER BY view_count DESC
    `);
    
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/telemetry/feature-adoption — Feature usage
app.get('/api/telemetry/feature-adoption', async (req, res) => {
  try {
    const { days = 30, limit = 20 } = req.query;
    
    const result = await pool.query(`
      SELECT 
        event_data->>'button' as feature,
        COUNT(*) as usage_count,
        COUNT(DISTINCT user_id) as unique_users,
        ROUND(100.0 * COUNT(DISTINCT user_id) / 
          (SELECT COUNT(DISTINCT user_id) FROM telemetry.user_events 
           WHERE timestamp >= NOW() - INTERVAL '${days} days'), 2) as adoption_rate
      FROM telemetry.user_events
      WHERE event_type = 'button_click'
        AND timestamp >= NOW() - INTERVAL '${days} days'
      GROUP BY event_data->>'button'
      ORDER BY usage_count DESC
      LIMIT ${limit}
    `);
    
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

### SOP Document Elements (Phase 7)
**What to document:**
- [ ] Dashboard layout and wireframe
- [ ] Available metrics and their calculations
- [ ] Real-time vs. aggregated data strategy
- [ ] Dashboard refresh intervals
- [ ] Drill-down capabilities
- [ ] Export and reporting features
- [ ] User roles and dashboard access

### Success Metrics
- ✅ Dashboard loads in < 2 seconds
- ✅ Real-time metrics update automatically
- ✅ All charts and tables render correctly
- ✅ Query functions work reliably

---

## PHASE 8: TESTING & QA (Week 4 - Days 3-4)

### Objectives
- ✅ Comprehensive system testing
- ✅ Data validation
- ✅ Performance testing

### Deliverables

#### 8.1 Test Plan (30 minutes)

**Test Coverage:**

| Test Type | Scope | Acceptance Criteria |
|-----------|-------|-------------------|
| Unit Tests | TelemetryService methods | 90%+ code coverage |
| Integration Tests | App.jsx → API → Database | All endpoints respond |
| E2E Tests | Full user journey | Events captured end-to-end |
| Performance Tests | Batch sending, database queries | < 100ms latency |
| Data Validation | Event schema, data types | 100% valid records |
| Dashboard Tests | All charts and metrics render | No broken queries |

#### 8.2 Manual Testing Procedures (90 minutes)

**Test Scenario 1: User Registration & Authentication**
```
1. Open app (not logged in)
2. Click login
3. Complete Microsoft auth flow
4. Verify:
   - user_login event captured
   - User ID matches Azure account
   - Session ID generated
   - Page view for ConsentPage
   - Telemetry initialized message in console
```

**Test Scenario 2: Page Navigation**
```
1. Log in
2. Accept consent
3. Click on each page in sidebar
4. Wait 2 seconds on each page
5. Verify:
   - page_view event for each page
   - page_exit event with time_spent > 2 seconds
   - Page title captured correctly
   - URL recorded
   - Dashboard shows all pages in analytics
```

**Test Scenario 3: Feature Usage**
```
1. Navigate to Activity page
2. Click all major buttons (export, filter, search)
3. Perform searches/filters
4. Verify:
   - button_click event for each button
   - Context data captured (e.g., filter_name)
   - search event for searches with search_term
   - Button analytics show all actions
   - Feature adoption rates calculated
```

**Test Scenario 4: Error Handling**
```
1. Intentionally trigger component error
2. Network tab goes offline
3. Trigger multiple events while offline
4. Go back online
5. Wait 30 seconds
6. Verify:
   - Error captured and logged
   - Events queued in localStorage
   - Events flushed when online
   - No data loss
```

**Test Scenario 5: Dashboard Functionality**
```
1. Log in as multiple users (simulate)
2. Navigate through all pages
3. Trigger various actions
4. Open Telemetry Dashboard
5. Verify:
   - Active users count correct
   - Page views breakdown accurate
   - Feature adoption rates calculated
   - Error rate displays if any errors
   - Charts render without errors
```

#### 8.3 Automated Testing Setup (45 minutes)

**Add test file:** `src/services/__tests__/telemetryService.test.js`

```javascript
import TelemetryService from '../telemetryService';

describe('TelemetryService', () => {
  let service;
  
  beforeEach(() => {
    service = new TelemetryService();
  });
  
  // Test initialization
  test('should initialize with user info', () => {
    service.init('user123', 'John Doe', 'john@company.com');
    expect(service.userId).toBe('user123');
    expect(service.userName).toBe('John Doe');
    expect(service.userEmail).toBe('john@company.com');
  });
  
  // Test event tracking
  test('should queue events', () => {
    service.init('user123', 'John', 'john@example.com');
    service.trackButtonClick('test_button', { data: 'test' });
    expect(service.eventQueue.length).toBeGreaterThan(0);
  });
  
  // Test page view tracking
  test('should track page views and calculate time spent', (done) => {
    service.trackPageView('page1', 'Page 1');
    
    setTimeout(() => {
      service.trackPageView('page2', 'Page 2');
      
      const exitEvent = service.eventQueue.find(
        e => e.eventType === 'page_exit'
      );
      
      expect(exitEvent).toBeDefined();
      expect(exitEvent.eventData.timeSpentSeconds).toBeGreaterThan(0);
      done();
    }, 100);
  });
  
  // Test batch sending
  test('should batch events every 30 seconds or 10 events', (done) => {
    // Track 10 events
    for (let i = 0; i < 10; i++) {
      service.trackButtonClick(`button_${i}`);
    }
    
    // Batch should trigger immediately at 10 events
    setTimeout(() => {
      expect(service.eventQueue.length).toBe(0);
      done();
    }, 1000);
  });
  
  // Test session ID generation
  test('should generate unique session IDs', () => {
    const service1 = new TelemetryService();
    const service2 = new TelemetryService();
    
    expect(service1.sessionId).not.toBe(service2.sessionId);
  });
});
```

**Run tests:**
```bash
npm test src/services/__tests__/telemetryService.test.js
```

#### 8.4 Data Validation Queries (30 minutes)

**Query to validate data integrity:**

```sql
-- Check for required fields
SELECT COUNT(*) as missing_user_id
FROM telemetry.user_events
WHERE user_id IS NULL;
-- Expected: 0

-- Check event type distribution
SELECT event_type, COUNT(*) as count
FROM telemetry.user_events
WHERE timestamp >= NOW() - INTERVAL '1 day'
GROUP BY event_type
ORDER BY count DESC;

-- Verify session consistency
SELECT session_id, COUNT(*) as event_count
FROM telemetry.user_events
WHERE timestamp >= NOW() - INTERVAL '1 day'
GROUP BY session_id
HAVING COUNT(*) = 0;
-- Expected: No results (all sessions have events)

-- Check for orphaned events (no session)
SELECT COUNT(*) as orphaned_events
FROM telemetry.user_events
WHERE session_id NOT IN (SELECT session_id FROM telemetry.user_sessions);
-- Expected: 0 (or minimal)

-- Validate timestamps
SELECT COUNT(*) as invalid_timestamps
FROM telemetry.user_events
WHERE timestamp > NOW() OR timestamp < NOW() - INTERVAL '90 days';
-- Expected: 0
```

### SOP Document Elements (Phase 8)
**What to document:**
- [ ] QA test plan and procedures
- [ ] Test data setup and cleanup
- [ ] Pass/fail criteria for each test
- [ ] Known limitations or issues
- [ ] Testing environment requirements
- [ ] Performance baselines
- [ ] Regression test procedures

### Success Metrics
- ✅ 95%+ test pass rate
- ✅ No data corruption in database
- ✅ All endpoints respond consistently
- ✅ Dashboard queries execute in < 1 second

---

## PHASE 9: MONITORING & OPTIMIZATION (Week 5 - Ongoing)

### Objectives
- ✅ Set up monitoring dashboards
- ✅ Define performance baselines
- ✅ Create alerting rules
- ✅ Plan optimization

### Deliverables

#### 9.1 Monitoring Dashboard Metrics

**Key Metrics to Monitor:**

| Metric | Target | Alert Threshold |
|--------|--------|------------------|
| Event Ingestion Rate | 100-500 events/min | < 10 or > 1000 events/min |
| Database Write Latency | < 50ms p95 | > 100ms |
| API Response Time | < 200ms p95 | > 500ms |
| Error Rate | < 1% | > 5% |
| Active Users | Baseline dependent | Drop > 50% |
| Event Queue Size | < 100 | > 1000 (indicates network issue) |

#### 9.2 Performance Optimization Strategy

**Database Optimization:**
- Add table partitioning by date (daily partitions)
- Configure Redshift auto-vacuum
- Set up materialized views for dashboard queries
- Establish 90-day data retention with automatic purge

**Frontend Optimization:**
- Adjust batch size based on network speed
- Implement exponential backoff for retries
- Compress event data (optional)
- Cache dashboard queries

**API Optimization:**
- Add connection pooling (already in db.js)
- Implement query result caching
- Add request rate limiting
- Optimize Redshift queries with DISTKEY/SORTKEY

#### 9.3 Alerting Rules

**Set up alerts for:**
1. Error rate exceeds 5% in last 15 minutes
2. Event ingestion fails for > 5 consecutive batches
3. Database query latency > 1 second
4. API endpoint 5xx errors
5. Telemetry dashboard unavailable

### SOP Document Elements (Phase 9)
**What to document:**
- [ ] Monitoring dashboard setup
- [ ] Alert definitions and escalation
- [ ] Performance baseline metrics
- [ ] Optimization recommendations
- [ ] Capacity planning (for 200, 500, 1000 users)
- [ ] Data cleanup policies
- [ ] On-call rotation procedures

---

## PHASE 10: DEPLOYMENT & ROLLOUT (Week 5-6)

### Objectives
- ✅ Staged production deployment
- ✅ User communication
- ✅ Monitor production systems

### Deployment Strategy

#### 10.1 Staged Rollout (Recommended)

**Stage 1: Internal Testing (Week 5)**
- Deploy to staging environment
- Run complete test suite
- Gather feedback from team
- Expected duration: 3-5 days

**Stage 2: Limited Production (Week 5-6)**
- Deploy to 10% of users
- Monitor telemetry system health
- Verify data quality
- Expected duration: 2-3 days

**Stage 3: Full Production (Week 6)**
- Deploy to 100% of users
- Continue monitoring
- Prepare support procedures
- Expected duration: Ongoing

#### 10.2 Deployment Checklist

Before deploying each phase:
- [ ] Code reviewed and tested
- [ ] Database schema applied
- [ ] API endpoints tested
- [ ] Frontend components tested
- [ ] Error handling verified
- [ ] Documentation updated
- [ ] Team trained on new features
- [ ] Support plan in place

#### 10.3 Production Monitoring

**First Week:**
- Monitor event ingestion rate (expect 100-500 events/min)
- Check database disk usage (expect ~1-5 GB/day)
- Verify telemetry doesn't impact app performance
- Collect feedback from users

**Ongoing:**
- Weekly metrics review
- Monthly optimization review
- Quarterly capacity planning

### SOP Document Elements (Phase 10)
**What to document:**
- [ ] Deployment procedures (staging and production)
- [ ] Rollback procedures
- [ ] Production monitoring checklist
- [ ] User communication templates
- [ ] Incident response procedures
- [ ] Support troubleshooting guide
- [ ] Success criteria for rollout

---

## SUMMARY: PHASED IMPLEMENTATION ROADMAP

### Timeline Overview

```
Week 1 (3 days)
├── Phase 1: Database Schema [5 min + 15 min testing]
├── Phase 2: Backend Integration [30 min + testing]
└── Status: Production-ready

Week 2 (5 days)
├── Phase 3: Frontend Init [25 min + testing]
├── Phase 4: Page Tracking [45 min + testing]
└── Status: Data collection active

Week 3 (5 days)
├── Phase 5: Feature Tracking [60 min + testing]
├── Phase 6: Error Tracking [50 min + testing]
└── Status: Comprehensive tracking

Week 4 (5 days)
├── Phase 7: Analytics Dashboard [120 min + testing]
├── Phase 8: Testing & QA [90 min + testing]
└── Status: Full system operational

Week 5-6 (10 days)
├── Phase 9: Monitoring & Optimization [Ongoing]
├── Phase 10: Production Deployment [3-5 days]
└── Status: Live in production
```

### Effort Summary

| Phase | Effort | Duration | Status |
|-------|--------|----------|--------|
| 1. Database | 20 min | 1 day | Low risk |
| 2. Backend | 45 min | 1 day | Low risk |
| 3. Frontend Init | 25 min | 1 day | Low risk |
| 4. Page Tracking | 45 min | 1 day | Medium risk |
| 5. Feature Tracking | 75 min | 1 day | Medium risk |
| 6. Error Tracking | 50 min | 1 day | Low risk |
| 7. Analytics | 120 min | 2 days | High risk |
| 8. Testing | 90 min | 1 day | Medium risk |
| 9. Monitoring | Ongoing | 1 week | Low risk |
| 10. Deployment | 15 min | 1-2 weeks | Low risk |
| **TOTAL** | **485 min** | **4-6 weeks** | ✅ Ready |

---

## SOP DOCUMENT STRUCTURE

For the final SOP document (standalone reference), include:

### Part 1: Planning Level
✅ Current architecture overview  
✅ Phased implementation roadmap  
✅ Resource requirements  
✅ Risk assessment  
✅ Success metrics  

### Part 2: Phase-Specific Runbooks
✅ Phase 1: Database Setup  
✅ Phase 2: API Integration  
✅ Phase 3: Frontend Init  
✅ Phase 4: Page Tracking  
✅ Phase 5: Feature Tracking  
✅ Phase 6: Error Tracking  
✅ Phase 7: Dashboard  
✅ Phase 8: QA  
✅ Phase 9: Monitoring  
✅ Phase 10: Deployment  

### Part 3: Operational Procedures
✅ Daily monitoring checklist  
✅ Incident response procedures  
✅ User support guide  
✅ Troubleshooting guide  
✅ Escalation procedures  

### Part 4: Appendices
✅ SQL queries reference  
✅ API endpoint reference  
✅ Event type definitions  
✅ Metrics glossary  
✅ Known issues & limitations  

---

## TECHNICAL ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────────┐
│                        USER BROWSER                         │
│  React App (Vite)                                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Pages (Activity, Capability, Ask AI, Reference)      │  │
│  │ ↓                                                     │  │
│  │ TelemetryService (batching, offline queue)           │  │
│  │ - Tracks: page views, button clicks, searches        │  │
│  │ - Batches: 10 events or 30 seconds                   │  │
│  │ - Stores: localStorage for offline                   │  │
│  │ ↓                                                     │  │
│  │ POST /api/telemetry (JSON batch)                     │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────────┬────────────────────────────────────┘
                         │
                    HTTP/HTTPS
                         │
┌────────────────────────▼────────────────────────────────────┐
│              EXPRESS BACKEND (Node.js)                      │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ POST /api/telemetry                                 │  │
│  │ - Validates event schema                            │  │
│  │ - Transforms data                                   │  │
│  │ - Inserts to Redshift                               │  │
│  │ - Returns success/error                             │  │
│  │                                                     │  │
│  │ GET endpoints (analytics queries):                  │  │
│  │ - /api/telemetry/user-sessions                      │  │
│  │ - /api/telemetry/page-analytics                     │  │
│  │ - /api/telemetry/button-analytics                   │  │
│  │ - /api/telemetry/errors                             │  │
│  │ - /api/telemetry/performance                        │  │
│  └──────────────────────────────────────────────────────┘  │
│              Connection Pool (pg)                           │
│                     ↓                                       │
└────────────────────────┬──────────────────────────────────┘
                         │
                     TCP 5439
                         │
┌────────────────────────▼──────────────────────────────────┐
│         AMAZON REDSHIFT (Data Warehouse)                  │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ telemetry schema                                     │ │
│  │ ├── user_events (raw data, 90-day retention)        │ │
│  │ ├── user_sessions (session aggregation)             │ │
│  │ ├── daily_usage_summary (daily KPIs)                │ │
│  │ ├── page_analytics (page metrics)                   │ │
│  │ └── button_analytics (feature adoption)             │ │
│  │                                                     │ │
│  │ Indexes: user_id, session_id, event_type, timestamp │ │
│  └──────────────────────────────────────────────────────┘ │
│              ↑                                             │
│              │ Materialized Views                         │
│              ↓                                             │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ Analytics Views (for dashboard queries)              │ │
│  │ - top_features_view                                  │ │
│  │ - user_engagement_view                               │ │
│  │ - error_summary_view                                 │ │
│  └──────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
        ↑
        │ Dashboard queries via backend
        │
┌───────┴──────────────────────────────────────────────────────┐
│    TELEMETRY DASHBOARD (React Component)                    │
│  - Real-time metrics                                        │
│  - Charts and visualizations                                │
│  - User sessions table                                      │
│  - Feature adoption metrics                                 │
│  - Error tracking                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## RISK MITIGATION

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| High event volume overwhelming API | Medium | High | Implement rate limiting, queue management |
| Redshift storage costs | Medium | Medium | Set 90-day retention, auto-purge old data |
| Performance impact on frontend | Low | High | Test batch sizes, use localStorage queue |
| Data privacy concerns | Medium | High | Anonymize sensitive data, document retention |
| Database schema changes | Low | Medium | Version migrations, test before deploy |
| Event data loss | Low | High | localStorage fallback, retry with backoff |
| Telemetry service errors | Medium | Low | Error boundaries, graceful degradation |
| Dashboard performance | Medium | Medium | Materialized views, query optimization |

---

## SUCCESS CRITERIA

✅ **Phase 1 Success:**
- Database schema created without errors
- All tables queryable
- Connectivity verified

✅ **Phase 2 Success:**
- All 6 API endpoints operational
- Events insert to database
- No API errors in production

✅ **Phase 3 Success:**
- Telemetry initializes on login
- Sessions created automatically
- First events captured

✅ **Phase 4 Success:**
- Page views tracked for all pages
- Time spent calculated
- Page analytics queryable

✅ **Phase 5 Success:**
- All major buttons tracked
- Feature adoption metrics available
- Searches/filters captured

✅ **Phase 6 Success:**
- Errors caught and logged
- API latency tracked
- Performance metrics available

✅ **Phase 7 Success:**
- Dashboard renders all KPIs
- Charts update in real-time
- Query performance < 1 second

✅ **Phase 8 Success:**
- Test pass rate > 95%
- Data integrity verified
- No data corruption

✅ **Phase 9 Success:**
- Monitoring dashboards operational
- Alerts configured and tested
- Performance baselines established

✅ **Phase 10 Success:**
- Production deployment successful
- Zero data loss observed
- User adoption tracking confirmed

---

## NEXT STEPS

1. **Review** this plan with stakeholders (15 min)
2. **Schedule** Phase 1 kick-off (Database setup)
3. **Allocate** resources (1 engineer, 4-6 weeks)
4. **Prepare** Redshift environment (access verification)
5. **Brief** frontend team on upcoming changes
6. **Start** Phase 1 when ready

**Estimated ROI:**
- Week 1-2: Understanding user behavior
- Week 3-4: Identifying low-adoption features
- Week 5+: Data-driven product decisions

---

**Document Version:** 1.0  
**Last Updated:** August 17, 2026  
**Next Review:** September 1, 2026  
**Owner:** Engineering Team  
**Status:** Ready for Implementation  

