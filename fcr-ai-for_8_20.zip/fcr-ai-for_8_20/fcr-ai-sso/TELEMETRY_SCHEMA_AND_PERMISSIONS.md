# Telemetry System - Table Schema & Permission Testing Guide

**Database Connection Details (from .env):**
```
REDSHIFT_HOST: itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com
REDSHIFT_PORT: 5439
REDSHIFT_DB: awprdrsdb
REDSHIFT_USER: dmp_fcr_ai_development_prod_read
REDSHIFT_PASSWORD: fPmzkv-12rfF
```

**Test User:** `dmp_fcr_ai_development_prod_read`  
**Target Database:** `awprdrsdb`  
**Target Schema:** `telemetry`

---

## 📋 ALL TABLES - Complete Schema Reference

### Table 1: telemetry.user_events
**Purpose:** Raw event storage (all user interactions)  
**Retention:** 90 days  
**Row Count:** ~150,000 per month (100 users)  

#### Schema (Complete)
```sql
CREATE TABLE telemetry.user_events (
    event_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    session_id VARCHAR(100) NOT NULL,
    user_id VARCHAR(100),
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    event_type VARCHAR(50) NOT NULL,
    event_data VARCHAR(MAX),
    page VARCHAR(100),
    url VARCHAR(2048),
    
    timestamp TIMESTAMP DEFAULT GETDATE(),
    
    CONSTRAINT event_type_check CHECK (event_type IN (
        'user_login', 'user_logout', 'page_view', 'page_exit',
        'button_click', 'search', 'data_export', 'api_call',
        'error', 'session_start', 'session_end', 'custom'
    ))
)
DISTKEY (user_id)
SORTKEY (timestamp DESC);
```

#### Column Details
| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| event_id | BIGINT | NO | IDENTITY | Auto-incrementing primary key |
| session_id | VARCHAR(100) | NO | - | Unique session identifier |
| user_id | VARCHAR(100) | YES | - | User identifier (hashed Azure AD ID) |
| user_name | VARCHAR(255) | YES | - | User display name |
| user_email | VARCHAR(255) | YES | - | Corporate email |
| event_type | VARCHAR(50) | NO | - | Type of event (11 types) |
| event_data | VARCHAR(MAX) | YES | - | JSON payload of event details |
| page | VARCHAR(100) | YES | - | Page/route name |
| url | VARCHAR(2048) | YES | - | Full URL where event occurred |
| timestamp | TIMESTAMP | YES | GETDATE() | When event occurred |

#### Indexes (6 total)
```sql
CREATE INDEX idx_user_events_user_id ON telemetry.user_events (user_id);
CREATE INDEX idx_user_events_session_id ON telemetry.user_events (session_id);
CREATE INDEX idx_user_events_event_type ON telemetry.user_events (event_type);
CREATE INDEX idx_user_events_timestamp ON telemetry.user_events (timestamp);
CREATE INDEX idx_user_events_page ON telemetry.user_events (page);
CREATE INDEX idx_user_events_user_timestamp ON telemetry.user_events (user_id, timestamp DESC);
```

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on table `telemetry.user_events`
- `INSERT` on table `telemetry.user_events` (for backend to write events)

---

### Table 2: telemetry.user_sessions
**Purpose:** Aggregated session-level data  
**Retention:** 1 year  
**Row Count:** ~3,000 per month (100 users, ~30 sessions/user)  

#### Schema (Complete)
```sql
CREATE TABLE telemetry.user_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(255),
    user_email VARCHAR(255),
    
    session_start TIMESTAMP,
    session_end TIMESTAMP,
    duration_seconds INT,
    
    event_count INT DEFAULT 0,
    page_views INT DEFAULT 0,
    button_clicks INT DEFAULT 0,
    errors_count INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

#### Column Details
| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| session_id | VARCHAR(100) | NO | - | Unique session ID (PK) |
| user_id | VARCHAR(100) | NO | - | User identifier |
| user_name | VARCHAR(255) | YES | - | User name |
| user_email | VARCHAR(255) | YES | - | User email |
| session_start | TIMESTAMP | YES | - | Session start time |
| session_end | TIMESTAMP | YES | - | Session end time |
| duration_seconds | INT | YES | - | Total session duration in seconds |
| event_count | INT | YES | 0 | Total events in session |
| page_views | INT | YES | 0 | Page view count |
| button_clicks | INT | YES | 0 | Button click count |
| errors_count | INT | YES | 0 | Error count |
| created_at | TIMESTAMP | YES | GETDATE() | Record creation time |

#### Indexes (2 total)
```sql
CREATE INDEX idx_user_sessions_user_id ON telemetry.user_sessions (user_id);
CREATE INDEX idx_user_sessions_session_start ON telemetry.user_sessions (session_start DESC);
```

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on table `telemetry.user_sessions`
- `INSERT` on table `telemetry.user_sessions` (for aggregation)
- `UPDATE` on table `telemetry.user_sessions` (for aggregation updates)

---

### Table 3: telemetry.daily_usage_summary
**Purpose:** Daily aggregated usage statistics  
**Retention:** 1 year  
**Row Count:** ~365 rows per year  

#### Schema (Complete)
```sql
CREATE TABLE telemetry.daily_usage_summary (
    usage_date DATE PRIMARY KEY,
    
    active_users INT,
    total_sessions INT,
    total_events INT,
    total_page_views INT,
    total_button_clicks INT,
    total_logins INT,
    total_errors INT,
    
    avg_session_duration_seconds DECIMAL(10, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

#### Column Details
| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| usage_date | DATE | NO | - | Date of statistics (PK) |
| active_users | INT | YES | - | Count of unique active users |
| total_sessions | INT | YES | - | Total sessions for day |
| total_events | INT | YES | - | Total events for day |
| total_page_views | INT | YES | - | Page views for day |
| total_button_clicks | INT | YES | - | Button clicks for day |
| total_logins | INT | YES | - | Login events for day |
| total_errors | INT | YES | - | Errors for day |
| avg_session_duration_seconds | DECIMAL(10,2) | YES | - | Average session duration |
| created_at | TIMESTAMP | YES | GETDATE() | Record creation time |

#### Indexes (0 - PK only)
```sql
-- Primary key (usage_date) serves as index
```

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on table `telemetry.daily_usage_summary`
- `INSERT` on table `telemetry.daily_usage_summary` (for daily aggregation)
- `UPDATE` on table `telemetry.daily_usage_summary` (for daily updates)

---

### Table 4: telemetry.page_analytics
**Purpose:** Page-level analytics  
**Retention:** 1 year  
**Row Count:** ~7 pages × 365 days = ~2,555 rows/year  

#### Schema (Complete)
```sql
CREATE TABLE telemetry.page_analytics (
    page_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    page_name VARCHAR(100),
    analytics_date DATE,
    
    view_count INT DEFAULT 0,
    unique_visitors INT DEFAULT 0,
    avg_time_spent_seconds DECIMAL(10, 2),
    bounce_rate DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

#### Column Details
| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| page_id | BIGINT | NO | IDENTITY | Auto-incrementing ID |
| page_name | VARCHAR(100) | YES | - | Page name (dashboard, fcrs, etc) |
| analytics_date | DATE | YES | - | Date of analytics |
| view_count | INT | YES | 0 | Total page views |
| unique_visitors | INT | YES | 0 | Unique user count |
| avg_time_spent_seconds | DECIMAL(10,2) | YES | - | Average time per visit |
| bounce_rate | DECIMAL(5,2) | YES | - | Bounce rate percentage |
| created_at | TIMESTAMP | YES | GETDATE() | Record creation time |

#### Indexes (1 total)
```sql
CREATE INDEX idx_page_analytics_page_date ON telemetry.page_analytics (page_name, analytics_date DESC);
```

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on table `telemetry.page_analytics`
- `INSERT` on table `telemetry.page_analytics` (for daily aggregation)
- `UPDATE` on table `telemetry.page_analytics` (for daily updates)

---

### Table 5: telemetry.button_analytics
**Purpose:** Button/feature usage analytics  
**Retention:** 1 year  
**Row Count:** ~30 buttons × 365 days = ~10,950 rows/year  

#### Schema (Complete)
```sql
CREATE TABLE telemetry.button_analytics (
    button_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    button_name VARCHAR(255),
    page_name VARCHAR(100),
    analytics_date DATE,
    
    click_count INT DEFAULT 0,
    unique_users INT DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

#### Column Details
| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| button_id | BIGINT | NO | IDENTITY | Auto-incrementing ID |
| button_name | VARCHAR(255) | YES | - | Button/feature name |
| page_name | VARCHAR(100) | YES | - | Page where button is located |
| analytics_date | DATE | YES | - | Date of analytics |
| click_count | INT | YES | 0 | Total clicks for day |
| unique_users | INT | YES | 0 | Unique users who clicked |
| created_at | TIMESTAMP | YES | GETDATE() | Record creation time |

#### Indexes (1 total)
```sql
CREATE INDEX idx_button_analytics_button_page_date ON telemetry.button_analytics (button_name, page_name, analytics_date DESC);
```

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on table `telemetry.button_analytics`
- `INSERT` on table `telemetry.button_analytics` (for daily aggregation)
- `UPDATE` on table `telemetry.button_analytics` (for daily updates)

---

## 👁️ ALL VIEWS - Complete Schema Reference

### View 1: telemetry.v_user_activity
**Purpose:** User activity summary (last 30 days)  
**Type:** Materialized view (for fast dashboard queries)  

#### Schema
```sql
CREATE OR REPLACE VIEW telemetry.v_user_activity AS
SELECT 
    user_id,
    user_name,
    user_email,
    COUNT(DISTINCT session_id) as session_count,
    COUNT(*) as event_count,
    COUNT(DISTINCT DATE(timestamp)) as active_days,
    MAX(timestamp) as last_activity,
    COUNT(CASE WHEN event_type = 'button_click' THEN 1 END) as total_clicks,
    COUNT(CASE WHEN event_type = 'page_view' THEN 1 END) as total_pages,
    COUNT(CASE WHEN event_type = 'error' THEN 1 END) as total_errors
FROM telemetry.user_events
WHERE timestamp >= DATEADD(day, -30, GETDATE())
GROUP BY user_id, user_name, user_email;
```

#### Columns Returned
| Column | Type | Description |
|--------|------|-------------|
| user_id | VARCHAR(100) | User identifier |
| user_name | VARCHAR(255) | User display name |
| user_email | VARCHAR(255) | User email |
| session_count | BIGINT | Total sessions (30 days) |
| event_count | BIGINT | Total events (30 days) |
| active_days | BIGINT | Unique days with activity |
| last_activity | TIMESTAMP | Last event timestamp |
| total_clicks | BIGINT | Button click count |
| total_pages | BIGINT | Page view count |
| total_errors | BIGINT | Error count |

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on view `telemetry.v_user_activity`
- `SELECT` on underlying table `telemetry.user_events`

---

### View 2: telemetry.v_page_performance
**Purpose:** Page performance metrics (last 7 days)  

#### Schema
```sql
CREATE OR REPLACE VIEW telemetry.v_page_performance AS
SELECT 
    page,
    COUNT(*) as page_views,
    COUNT(DISTINCT session_id) as unique_sessions,
    COUNT(DISTINCT user_id) as unique_users,
    ROUND(AVG(CAST(event_data->>'timeSpentSeconds' AS FLOAT)), 2) as avg_time_seconds,
    MIN(timestamp) as first_view,
    MAX(timestamp) as last_view
FROM telemetry.user_events
WHERE event_type = 'page_view'
    AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY page;
```

#### Columns Returned
| Column | Type | Description |
|--------|------|-------------|
| page | VARCHAR(100) | Page name |
| page_views | BIGINT | Total page views |
| unique_sessions | BIGINT | Unique sessions |
| unique_users | BIGINT | Unique users |
| avg_time_seconds | NUMERIC | Average time spent |
| first_view | TIMESTAMP | First view timestamp |
| last_view | TIMESTAMP | Last view timestamp |

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on view `telemetry.v_page_performance`
- `SELECT` on underlying table `telemetry.user_events`

---

### View 3: telemetry.v_most_used_features
**Purpose:** Most used features ranking (last 7 days)  

#### Schema
```sql
CREATE OR REPLACE VIEW telemetry.v_most_used_features AS
SELECT 
    CAST(event_data->>'button' AS VARCHAR) as feature_name,
    CAST(event_data->>'page' AS VARCHAR) as page,
    COUNT(*) as usage_count,
    COUNT(DISTINCT user_id) as unique_users,
    MAX(timestamp) as last_used
FROM telemetry.user_events
WHERE event_type = 'button_click'
    AND timestamp >= DATEADD(day, -7, GETDATE())
GROUP BY CAST(event_data->>'button' AS VARCHAR), CAST(event_data->>'page' AS VARCHAR)
ORDER BY usage_count DESC;
```

#### Columns Returned
| Column | Type | Description |
|--------|------|-------------|
| feature_name | VARCHAR | Feature/button name |
| page | VARCHAR | Page where feature is |
| usage_count | BIGINT | Total uses |
| unique_users | BIGINT | Users who used it |
| last_used | TIMESTAMP | Last usage timestamp |

#### Permissions Needed
- `USAGE` on schema `telemetry`
- `SELECT` on view `telemetry.v_most_used_features`
- `SELECT` on underlying table `telemetry.user_events`

---

## 🔐 COMPLETE PERMISSION MATRIX

### Schema Level
```
Schema: telemetry
├─ Permission: USAGE
├─ Grantee: dmp_fcr_ai_development_prod_read
└─ Status: REQUIRED ✓
```

### Table Level - Permissions Required

| Table | SELECT | INSERT | UPDATE | DELETE | TRUNCATE |
|-------|--------|--------|--------|--------|----------|
| user_events | ✓ YES | ✓ YES | NO | NO | NO |
| user_sessions | ✓ YES | ✓ YES | ✓ YES | NO | NO |
| daily_usage_summary | ✓ YES | ✓ YES | ✓ YES | NO | NO |
| page_analytics | ✓ YES | ✓ YES | ✓ YES | NO | NO |
| button_analytics | ✓ YES | ✓ YES | ✓ YES | NO | NO |

### View Level - Permissions Required

| View | SELECT |
|------|--------|
| v_user_activity | ✓ YES |
| v_page_performance | ✓ YES |
| v_most_used_features | ✓ YES |

---

## 🧪 PERMISSION TESTING QUERIES

### Test 1: Schema Access
```sql
-- Should succeed if USAGE granted
SELECT nspname FROM pg_namespace 
WHERE nspname = 'telemetry';
```
✅ **Expected:** Returns 1 row with "telemetry"

---

### Test 2: User Events - SELECT
```sql
-- Should succeed if SELECT granted
SELECT COUNT(*) FROM telemetry.user_events LIMIT 1;
```
✅ **Expected:** Returns count (may be 0 if table empty)

---

### Test 3: User Events - INSERT
```sql
-- Should succeed if INSERT granted
INSERT INTO telemetry.user_events 
  (session_id, user_id, user_name, user_email, event_type, timestamp)
VALUES 
  ('test_session_123', 'test_user', 'Test User', 'test@example.com', 'custom', GETDATE());
```
✅ **Expected:** INSERT 0 1 (1 row inserted)

---

### Test 4: User Sessions - SELECT
```sql
-- Should succeed if SELECT granted
SELECT COUNT(*) FROM telemetry.user_sessions LIMIT 1;
```
✅ **Expected:** Returns count

---

### Test 5: User Sessions - INSERT
```sql
-- Should succeed if INSERT granted
INSERT INTO telemetry.user_sessions 
  (session_id, user_id, user_name, user_email, session_start, duration_seconds)
VALUES 
  ('test_session_123', 'test_user', 'Test User', 'test@example.com', GETDATE(), 100);
```
✅ **Expected:** INSERT 0 1

---

### Test 6: User Sessions - UPDATE
```sql
-- Should succeed if UPDATE granted
UPDATE telemetry.user_sessions 
SET duration_seconds = 200 
WHERE session_id = 'test_session_123';
```
✅ **Expected:** UPDATE 1 (updates 1 row)

---

### Test 7: Daily Usage Summary - SELECT
```sql
-- Should succeed if SELECT granted
SELECT COUNT(*) FROM telemetry.daily_usage_summary LIMIT 1;
```
✅ **Expected:** Returns count

---

### Test 8: Daily Usage Summary - INSERT
```sql
-- Should succeed if INSERT granted
INSERT INTO telemetry.daily_usage_summary 
  (usage_date, active_users, total_sessions, total_events)
VALUES 
  (CURRENT_DATE, 10, 50, 500);
```
✅ **Expected:** INSERT 0 1

---

### Test 9: Daily Usage Summary - UPDATE
```sql
-- Should succeed if UPDATE granted
UPDATE telemetry.daily_usage_summary 
SET active_users = 15 
WHERE usage_date = CURRENT_DATE;
```
✅ **Expected:** UPDATE 1

---

### Test 10: Page Analytics - SELECT
```sql
-- Should succeed if SELECT granted
SELECT COUNT(*) FROM telemetry.page_analytics LIMIT 1;
```
✅ **Expected:** Returns count

---

### Test 11: Page Analytics - INSERT
```sql
-- Should succeed if INSERT granted
INSERT INTO telemetry.page_analytics 
  (page_name, analytics_date, view_count, unique_visitors)
VALUES 
  ('dashboard', CURRENT_DATE, 100, 25);
```
✅ **Expected:** INSERT 0 1

---

### Test 12: Button Analytics - SELECT
```sql
-- Should succeed if SELECT granted
SELECT COUNT(*) FROM telemetry.button_analytics LIMIT 1;
```
✅ **Expected:** Returns count

---

### Test 13: Button Analytics - INSERT
```sql
-- Should succeed if INSERT granted
INSERT INTO telemetry.button_analytics 
  (button_name, page_name, analytics_date, click_count)
VALUES 
  ('export_pdf', 'fcrs', CURRENT_DATE, 50);
```
✅ **Expected:** INSERT 0 1

---

### Test 14: View - v_user_activity
```sql
-- Should succeed if SELECT on view granted
SELECT COUNT(*) FROM telemetry.v_user_activity;
```
✅ **Expected:** Returns count

---

### Test 15: View - v_page_performance
```sql
-- Should succeed if SELECT on view granted
SELECT COUNT(*) FROM telemetry.v_page_performance;
```
✅ **Expected:** Returns count

---

### Test 16: View - v_most_used_features
```sql
-- Should succeed if SELECT on view granted
SELECT COUNT(*) FROM telemetry.v_most_used_features;
```
✅ **Expected:** Returns count

---

### Test 17: Index Access - user_id
```sql
-- Should use index for fast lookup
EXPLAIN SELECT * FROM telemetry.user_events 
WHERE user_id = 'user-123';
```
✅ **Expected:** Query plan shows index scan

---

### Test 18: Index Access - timestamp
```sql
-- Should use index for time-range queries
EXPLAIN SELECT * FROM telemetry.user_events 
WHERE timestamp >= DATEADD(day, -7, GETDATE());
```
✅ **Expected:** Query plan shows index scan

---

## 🚀 COMPLETE GRANT STATEMENTS (For Redshift Admin)

**Run these commands to grant all required permissions:**

```sql
-- 1. Grant USAGE on schema
GRANT USAGE ON SCHEMA telemetry 
TO dmp_fcr_ai_development_prod_read;

-- 2. Grant SELECT on all tables
GRANT SELECT ON telemetry.user_events 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.user_sessions 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.daily_usage_summary 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.page_analytics 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.button_analytics 
TO dmp_fcr_ai_development_prod_read;

-- 3. Grant INSERT on tables (for backend event ingestion)
GRANT INSERT ON telemetry.user_events 
TO dmp_fcr_ai_development_prod_read;

GRANT INSERT ON telemetry.user_sessions 
TO dmp_fcr_ai_development_prod_read;

GRANT INSERT ON telemetry.daily_usage_summary 
TO dmp_fcr_ai_development_prod_read;

GRANT INSERT ON telemetry.page_analytics 
TO dmp_fcr_ai_development_prod_read;

GRANT INSERT ON telemetry.button_analytics 
TO dmp_fcr_ai_development_prod_read;

-- 4. Grant UPDATE on aggregation tables (for daily rollups)
GRANT UPDATE ON telemetry.user_sessions 
TO dmp_fcr_ai_development_prod_read;

GRANT UPDATE ON telemetry.daily_usage_summary 
TO dmp_fcr_ai_development_prod_read;

GRANT UPDATE ON telemetry.page_analytics 
TO dmp_fcr_ai_development_prod_read;

GRANT UPDATE ON telemetry.button_analytics 
TO dmp_fcr_ai_development_prod_read;

-- 5. Grant SELECT on all views
GRANT SELECT ON telemetry.v_user_activity 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.v_page_performance 
TO dmp_fcr_ai_development_prod_read;

GRANT SELECT ON telemetry.v_most_used_features 
TO dmp_fcr_ai_development_prod_read;

-- 6. (Optional) Grant default for future objects
ALTER DEFAULT PRIVILEGES IN SCHEMA telemetry 
GRANT SELECT ON TABLES TO dmp_fcr_ai_development_prod_read;
```

---

## 📝 PERMISSION TEST SCRIPT (Python)

**Use this to test all permissions at once:**

```python
import psycopg2
from psycopg2 import sql

# Connection details from .env
conn_config = {
    'host': 'itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com',
    'port': 5439,
    'database': 'awprdrsdb',
    'user': 'dmp_fcr_ai_development_prod_read',
    'password': 'fPmzkv-12rfF'
}

tests = [
    ("Schema Access", "SELECT nspname FROM pg_namespace WHERE nspname = 'telemetry'"),
    ("user_events SELECT", "SELECT COUNT(*) FROM telemetry.user_events LIMIT 1"),
    ("user_events INSERT", "INSERT INTO telemetry.user_events (session_id, user_id, event_type) VALUES ('test', 'test', 'custom')"),
    ("user_sessions SELECT", "SELECT COUNT(*) FROM telemetry.user_sessions LIMIT 1"),
    ("user_sessions INSERT", "INSERT INTO telemetry.user_sessions (session_id, user_id) VALUES ('test', 'test')"),
    ("user_sessions UPDATE", "UPDATE telemetry.user_sessions SET duration_seconds = 0 WHERE session_id = 'test'"),
    ("daily_usage_summary SELECT", "SELECT COUNT(*) FROM telemetry.daily_usage_summary LIMIT 1"),
    ("daily_usage_summary INSERT", "INSERT INTO telemetry.daily_usage_summary (usage_date, active_users) VALUES (CURRENT_DATE, 0)"),
    ("daily_usage_summary UPDATE", "UPDATE telemetry.daily_usage_summary SET active_users = 0 WHERE usage_date = CURRENT_DATE"),
    ("page_analytics SELECT", "SELECT COUNT(*) FROM telemetry.page_analytics LIMIT 1"),
    ("page_analytics INSERT", "INSERT INTO telemetry.page_analytics (page_name, view_count) VALUES ('test', 0)"),
    ("button_analytics SELECT", "SELECT COUNT(*) FROM telemetry.button_analytics LIMIT 1"),
    ("button_analytics INSERT", "INSERT INTO telemetry.button_analytics (button_name, click_count) VALUES ('test', 0)"),
    ("v_user_activity SELECT", "SELECT COUNT(*) FROM telemetry.v_user_activity"),
    ("v_page_performance SELECT", "SELECT COUNT(*) FROM telemetry.v_page_performance"),
    ("v_most_used_features SELECT", "SELECT COUNT(*) FROM telemetry.v_most_used_features"),
]

try:
    conn = psycopg2.connect(**conn_config)
    cursor = conn.cursor()
    
    print("=" * 60)
    print("TELEMETRY PERMISSION TEST RESULTS")
    print("=" * 60)
    
    passed = 0
    failed = 0
    
    for test_name, query in tests:
        try:
            cursor.execute(query)
            if "INSERT" in query or "UPDATE" in query:
                conn.rollback()  # Don't persist test inserts
            else:
                conn.commit()
            print(f"✅ PASS: {test_name}")
            passed += 1
        except Exception as e:
            print(f"❌ FAIL: {test_name}")
            print(f"   Error: {str(e)[:100]}")
            failed += 1
            conn.rollback()
    
    print("=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    cursor.close()
    conn.close()

except Exception as e:
    print(f"Connection Error: {e}")
```

---

## 📊 SUMMARY - All Permissions Required

### By User: `dmp_fcr_ai_development_prod_read`

**Schema Level:**
- ✅ USAGE on `telemetry`

**Table Level (5 tables):**
- ✅ SELECT on: `user_events`, `user_sessions`, `daily_usage_summary`, `page_analytics`, `button_analytics`
- ✅ INSERT on: `user_events`, `user_sessions`, `daily_usage_summary`, `page_analytics`, `button_analytics`
- ✅ UPDATE on: `user_sessions`, `daily_usage_summary`, `page_analytics`, `button_analytics`

**View Level (3 views):**
- ✅ SELECT on: `v_user_activity`, `v_page_performance`, `v_most_used_features`

**Total Permissions:** 
- 1 SCHEMA permission
- 10 TABLE SELECT permissions
- 5 TABLE INSERT permissions
- 4 TABLE UPDATE permissions
- 3 VIEW SELECT permissions
- **= 23 total permissions**

---

## 📞 NEXT STEPS

1. **Run Test Script** - Use Python script above to test all permissions
2. **Identify Failures** - Note which tests fail
3. **Request Grants** - Send failing permission list to Redshift admin
4. **Re-test** - Verify permissions after admin grants them
5. **Proceed** - Once all tests pass, telemetry system can go live

---

**Status:** ✅ Complete schema reference ready for testing  
**Connection String:** See .env file (already configured)
