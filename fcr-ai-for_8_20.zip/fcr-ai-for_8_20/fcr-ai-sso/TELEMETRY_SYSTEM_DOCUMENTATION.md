# FCR AI - User Telemetry & Tracking System

**Version:** 1.0  
**Date:** August 13, 2026  
**Scope:** ~100 concurrent users  
**Purpose:** Track user interactions, engagement, and system performance

---

## Executive Summary

A comprehensive user tracking system has been implemented for the FCR AI application to monitor:

✅ **User Activity**
- Login events and session tracking
- Page navigation and time spent per page
- Button clicks and feature usage

✅ **Engagement Metrics**
- Session duration and frequency
- Page view patterns
- Most used features

✅ **System Health**
- Application errors and exceptions
- API performance metrics
- User experience bottlenecks

✅ **Analytics Dashboard**
- Real-time user activity monitoring
- Engagement trends and patterns
- Error tracking and alerting

---

## Architecture

```
┌─────────────────────────┐
│   React Frontend        │
│   (100 users)           │
└────────────┬────────────┘
             │
             │ Events batch every 30s
             │ or 10 events queued
             ▼
┌─────────────────────────┐
│  TelemetryService       │
│  (Client-side)          │
│  - Tracks interactions  │
│  - Queues events        │
│  - Batches & sends      │
└────────────┬────────────┘
             │
             │ POST /api/telemetry
             │ JSON batch
             ▼
┌─────────────────────────┐
│  Express Backend        │
│  - Receives events      │
│  - Validates data       │
│  - Inserts to DB        │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│  Amazon Redshift        │
│  - telemetry.user_events│
│  - telemetry.daily_...  │
│  - Views & reporting    │
└─────────────────────────┘
```

---

## Events Tracked

### User Session Events
| Event | Purpose | Data Captured |
|-------|---------|---------------|
| `user_login` | Track login | userId, userName, timestamp |
| `session_start` | Session begins | sessionId, timestamp |
| `session_end` | Session ends | duration, eventCount |

### Page Navigation
| Event | Purpose | Data Captured |
|-------|---------|---------------|
| `page_view` | Page load | pageName, timestamp, url |
| `page_exit` | Page leave | timeSpentSeconds |

### User Interactions
| Event | Purpose | Data Captured |
|-------|---------|---------------|
| `button_click` | Feature usage | buttonName, page, context |
| `search` | Search/filter | searchTerm, filters applied |
| `data_export` | Export action | exportType, dataCount |

### System Metrics
| Event | Purpose | Data Captured |
|-------|---------|---------------|
| `api_call` | Backend performance | endpoint, method, statusCode, responseTime |
| `error` | Exceptions | message, stack, page, context |

---

## Files Included

### Frontend
1. **`src/services/telemetryService.js`**
   - Main telemetry client
   - Tracks events and batches them
   - Sends to backend API
   - 240+ lines, well-documented

2. **`src/components/TelemetryDashboard.jsx`**
   - React component for analytics dashboard
   - Charts, tables, KPIs
   - Real-time metric display

3. **`src/components/TelemetryDashboard.css`**
   - Dashboard styling
   - Responsive design
   - Animation & interactions

### Backend
1. **`TELEMETRY_ENDPOINTS.js`**
   - 6 Express API endpoints
   - Event ingestion
   - Analytics queries
   - Copy content to `server.js`

### Database
1. **`TELEMETRY_DATABASE_SCHEMA.sql`**
   - 5 main tables
   - 3 reporting views
   - Indexes for performance
   - Data retention policy

### Documentation
1. **`TELEMETRY_IMPLEMENTATION_GUIDE.md`** (This file)
   - Step-by-step integration
   - Usage examples
   - Best practices
   - Troubleshooting

---

## Quick Start (5 Steps)

### Step 1: Create Services Directory
```bash
mkdir -p src/services
```

### Step 2: Add Telemetry Service to Frontend
File is already created: `src/services/telemetryService.js`

### Step 3: Create Database Tables
Run SQL from `TELEMETRY_DATABASE_SCHEMA.sql`:
```bash
psql -h <redshift-host> -U <username> -d awprdrsdb < TELEMETRY_DATABASE_SCHEMA.sql
```

### Step 4: Add Backend Endpoints to server.js
Copy endpoints from `TELEMETRY_ENDPOINTS.js` into `server.js`

### Step 5: Initialize Telemetry in App.jsx
```jsx
import { telemetry } from './services/telemetryService';
import { useEffect } from 'react';
import { useMsal } from '@azure/msal-react';

export default function App() {
  const { accounts } = useMsal();
  
  useEffect(() => {
    if (accounts && accounts.length > 0) {
      const account = accounts[0];
      telemetry.init(
        account.localAccountId || account.homeAccountId,
        account.name || 'Unknown',
        account.username || account.homeAccountId
      );
    }
  }, [accounts]);
  
  return (/* your app */);
}
```

---

## Integration Points

### 1. Track Page Views
```jsx
import { telemetry } from '../services/telemetryService';

export default function DashboardPage() {
  useEffect(() => {
    telemetry.trackPageView('dashboard', 'Dashboard');
  }, []);
}
```

### 2. Track Button Clicks
```jsx
const handleExport = () => {
  telemetry.trackButtonClick('export_pdf', { fcr_id: 'a2z...' });
  // ... export logic
};
```

### 3. Track Searches/Filters
```jsx
const handleFilter = (filters) => {
  telemetry.trackSearch(searchTerm, {
    ta: filters.ta,
    status: filters.status
  });
  // ... fetch data
};
```

### 4. Track API Calls
```jsx
const startTime = performance.now();
const response = await fetch('/api/fcrs');
const duration = performance.now() - startTime;
telemetry.trackApiCall('/api/fcrs', 'GET', response.status, duration);
```

### 5. Track Errors
```jsx
try {
  // some code
} catch (error) {
  telemetry.trackError(error.message, error.stack, { feature: 'fcr' });
}
```

---

## API Endpoints

### Analytics Endpoints

#### `GET /api/telemetry/usage-summary`
Returns overall usage statistics.

**Query Params:**
- `days` (default: 30) - Time period in days

**Response:**
```json
{
  "timeframe": "Last 30 days",
  "active_users": 45,
  "total_sessions": 287,
  "total_events": 5234,
  "avg_session_duration_seconds": 1245.50,
  "total_errors": 12
}
```

---

#### `GET /api/telemetry/user-sessions`
Get list of recent user sessions.

**Query Params:**
- `days` (default: 7)
- `limit` (default: 50)

**Response:**
```json
[
  {
    "session_id": "session_1234567890_abc123",
    "user_id": "user-123",
    "user_name": "John Doe",
    "user_email": "john@jnj.com",
    "session_start": "2026-08-13T10:30:00Z",
    "session_end": "2026-08-13T11:15:00Z",
    "event_count": 42,
    "event_types": 8,
    "duration_seconds": 2700
  }
]
```

---

#### `GET /api/telemetry/user/:userId`
Get individual user activity summary.

**Response:**
```json
{
  "user_id": "user-123",
  "user_name": "Jane Smith",
  "user_email": "jane@jnj.com",
  "total_sessions": 23,
  "total_events": 1024,
  "active_days": 18,
  "login_count": 23,
  "page_views": 234,
  "button_clicks": 567,
  "error_count": 3
}
```

---

#### `GET /api/telemetry/page-analytics`
Get page-level analytics.

**Query Params:**
- `days` (default: 7)

**Response:**
```json
[
  {
    "page_name": "dashboard",
    "page_views": 234,
    "unique_sessions": 45,
    "unique_users": 23,
    "avg_time_spent_seconds": 125.50
  }
]
```

---

#### `GET /api/telemetry/button-clicks`
Get most-used features/buttons.

**Query Params:**
- `days` (default: 7)
- `limit` (default: 20)

**Response:**
```json
[
  {
    "button_name": "export_pdf",
    "page": "fcrs",
    "click_count": 234,
    "unique_users": 45
  }
]
```

---

#### `GET /api/telemetry/errors`
Get application errors.

**Query Params:**
- `days` (default: 7)
- `limit` (default: 50)

**Response:**
```json
[
  {
    "timestamp": "2026-08-13T10:30:00Z",
    "user_id": "user-123",
    "user_name": "John Doe",
    "page": "fcrs",
    "error_message": "Cannot read property 'id' of undefined",
    "occurrence_count": 3
  }
]
```

---

#### `POST /api/telemetry`
Send telemetry events (called automatically by TelemetryService).

**Request:**
```json
{
  "events": [
    {
      "sessionId": "session_1234567890_abc123",
      "userId": "user-123",
      "userName": "John Doe",
      "userEmail": "john@jnj.com",
      "eventType": "button_click",
      "eventData": { "button": "export_pdf", "page": "fcrs" },
      "timestamp": "2026-08-13T10:30:00Z"
    }
  ],
  "batchCount": 1
}
```

**Response:**
```json
{
  "success": true,
  "eventsReceived": 1,
  "message": "Received 1 telemetry events"
}
```

---

## Database Schema

### Main Table: `telemetry.user_events`
Stores all user interaction events.

```sql
Columns:
- event_id (BIGINT, PRIMARY KEY)
- session_id (VARCHAR)
- user_id (VARCHAR)
- user_name (VARCHAR)
- user_email (VARCHAR)
- event_type (VARCHAR)
- event_data (VARCHAR/JSON)
- page (VARCHAR)
- url (VARCHAR)
- timestamp (TIMESTAMP)
```

**Indexes:**
- `user_id` - Query by user
- `session_id` - Query by session
- `event_type` - Query by event
- `timestamp` - Query by time
- `page` - Query by page

---

### Supporting Tables
- `telemetry.user_sessions` - Aggregated session data
- `telemetry.daily_usage_summary` - Daily stats
- `telemetry.page_analytics` - Page-level analytics
- `telemetry.button_analytics` - Button click stats

---

### Reporting Views
- `telemetry.v_user_activity` - User activity summary
- `telemetry.v_page_performance` - Page performance metrics
- `telemetry.v_most_used_features` - Feature usage ranking

---

## Performance Impact

### For 100 Users
**Event Volume:**
- ~50 events per user per day
- ~5,000 total events/day
- ~150,000 events/month

**Storage:**
- ~5-10 MB/month (raw events)
- ~500 MB/quarter (with archives)

**Network:**
- ~5-10 KB per batch (10 events)
- ~500 batches/day
- ~5-10 MB/day bandwidth

**Server Impact:**
- < 1% CPU overhead
- Minimal database load
- Events batched and async

---

## Data Retention & Privacy

### Default Policy
- **Raw Events:** 90 days (in `user_events`)
- **Aggregated Data:** 1 year (in summary tables)
- **Archive:** S3 or cold storage

### GDPR Compliance
- User data is identified by user ID, name, email
- Event data is pseudonymous (no PII beyond user email)
- Users can request data export via `/api/telemetry/user/:userId`
- Users can request deletion (implement archival)

### Cleanup Script
```sql
-- Run monthly
DELETE FROM telemetry.user_events 
WHERE timestamp < DATEADD(day, -90, GETDATE());
```

---

## Analytics Dashboard

### Access Point
Add to App.jsx routing:
```jsx
case 'analytics':
  telemetry.trackPageView('analytics', 'Analytics');
  return <TelemetryDashboard />;
```

### Displays
- 6 KPI cards (active users, sessions, duration, errors)
- Page performance chart
- Button usage chart
- Recent user sessions table
- Error log table
- Engagement metrics

### Features
- Timeframe selector (1d, 7d, 30d, 90d)
- Real-time refresh
- Sortable tables
- Charts with legend
- Error highlighting

---

## Best Practices

### DO ✅
- Track meaningful user actions
- Use consistent event naming
- Include page context in events
- Batch events for efficiency
- Monitor error rates
- Archive old data
- Use timeframe filters in queries

### DON'T ❌
- Track passwords or sensitive data
- Send events for every keystroke
- Store PII in event_data
- Query all 90 days of data without filtering
- Allow unbounded event queues
- Expose telemetry data to non-admin users

---

## Troubleshooting

### Issue: Events not being sent
**Causes:**
- Network connectivity
- Invalid `/api/telemetry` endpoint
- CORS issues

**Solution:**
1. Check browser DevTools Network tab
2. Verify endpoint is working: `curl http://localhost:8080/api/telemetry`
3. Check server logs

---

### Issue: Database connection errors
**Cause:** Redshift permissions

**Solution:**
1. Verify table exists: `SELECT COUNT(*) FROM telemetry.user_events;`
2. Check user permissions (refer to REDSHIFT_CONNECTION_REPORT.md)
3. Run schema script again

---

### Issue: Slow queries
**Cause:** Missing indexes or large time range

**Solution:**
1. Use date filters
2. Verify indexes exist
3. Archive older data
4. Use materialized views for reports

---

## Monitoring & Alerts

### Key Metrics to Monitor
1. **Active Users** - Track growth/churn
2. **Error Rate** - % of events that are errors
3. **Page Load Time** - API response times
4. **Session Duration** - Engagement metric
5. **Feature Usage** - Which features are used

### Alert Thresholds (suggested)
- Error rate > 5% → Investigate
- Response time > 2s → Performance issue
- Session drop > 20% → Churn alert
- Feature unused for 2 weeks → Deprecation warning

---

## File Checklist

- [x] `src/services/telemetryService.js` - Frontend service (240 lines)
- [x] `src/components/TelemetryDashboard.jsx` - Dashboard component (350 lines)
- [x] `src/components/TelemetryDashboard.css` - Dashboard styling (300 lines)
- [x] `TELEMETRY_ENDPOINTS.js` - Backend API endpoints
- [x] `TELEMETRY_DATABASE_SCHEMA.sql` - Database schema & views
- [x] `TELEMETRY_IMPLEMENTATION_GUIDE.md` - Integration guide
- [ ] Update `src/App.jsx` - Initialize telemetry
- [ ] Update components - Add tracking calls
- [ ] Run database schema
- [ ] Deploy backend changes

---

## Support & Questions

### Documentation
- `TELEMETRY_IMPLEMENTATION_GUIDE.md` - Step-by-step integration
- `TELEMETRY_ENDPOINTS.js` - API reference
- `TELEMETRY_DATABASE_SCHEMA.sql` - Database reference
- `telemetryService.js` - Comments & JSDoc

### Debugging
1. Browser DevTools Console - Check for telemetry errors
2. Network Tab - Verify /api/telemetry requests
3. Database Queries - Check telemetry tables
4. Server Logs - Backend errors

### Enhancement Ideas
- User segmentation (by TA, role, region)
- Cohort analysis (new vs returning users)
- Funnel analysis (page flow patterns)
- Session replay (store page state)
- Real-time alerting (email on high error rate)
- Integration with BI tools (Tableau, PowerBI)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-08-13 | Initial implementation |
| | | - User login tracking |
| | | - Page view & time spent |
| | | - Button click tracking |
| | | - Error tracking |
| | | - Analytics dashboard |
| | | - 6 API endpoints |
| | | - Redshift integration |

---

**Status:** ✅ Ready for Integration  
**Next Steps:** Follow TELEMETRY_IMPLEMENTATION_GUIDE.md to get started
