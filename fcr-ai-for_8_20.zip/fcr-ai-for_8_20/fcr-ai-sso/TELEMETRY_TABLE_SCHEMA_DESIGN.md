# TELEMETRY DATABASE SCHEMA DESIGN
## Complete Table Architecture with Reasoning

**Date:** August 19, 2026  
**Database:** Amazon Redshift  
**Approach:** 5 core tables + Views for reporting

---

## SCHEMA OVERVIEW

```
TELEMETRY SCHEMA (5 Tables)
├─ user_events          (Raw data - all user actions)
├─ user_sessions        (Aggregated - one row per session)
├─ daily_usage_summary  (Daily rollups - fast dashboards)
├─ page_analytics       (Page performance - by date)
└─ button_analytics     (Feature adoption - by date)
```

---

## TABLE 1: user_events (Raw Event Log)

### Purpose
**Single source of truth.** Every user action gets one row here. This is your audit log.

### Columns & Data Types

```sql
CREATE TABLE telemetry.user_events (
    event_id BIGINT IDENTITY(1,1),          -- Unique per event, auto-increment
    
    -- ═══ IDENTIFIERS (Who did it?) ═══
    session_id VARCHAR(100) NOT NULL,       -- Groups events into sessions
    user_id VARCHAR(100) NOT NULL,          -- Azure user ID
    user_name VARCHAR(255),                 -- "John Smith" for readability
    user_email VARCHAR(255),                -- "john@company.com" for contact/audit
    
    -- ═══ EVENT DETAILS (What happened?) ═══
    event_type VARCHAR(50) NOT NULL,        -- 'page_view', 'button_click', 'error', etc.
    event_data SUPER,                       -- JSON payload (flexible schema)
    page VARCHAR(100),                      -- Current page: 'activity', 'capability'
    url VARCHAR(2048),                      -- Full URL for debugging
    
    -- ═══ TIMESTAMP (When?) ═══
    timestamp TIMESTAMP DEFAULT GETDATE(),  -- Event occurred here
    
    -- ═══ CONSTRAINTS ═══
    PRIMARY KEY (event_id),
    CONSTRAINT valid_event_type CHECK (event_type IN (
        'user_login', 'user_logout', 'page_view', 'page_exit',
        'button_click', 'search', 'data_export', 'api_call',
        'error', 'session_start', 'session_end', 'custom'
    ))
);
```

### Why Each Column?

| Column | Why |
|--------|-----|
| **event_id** | Unique identifier for every event. Redshift IDENTITY creates auto-increment. Needed for deduplication (if events arrive twice). |
| **session_id** | Groups related events. "abc-123" session has 50 events → 1 user visit. Without this, can't calculate session duration. |
| **user_id** | Enables user-level analysis: "How many times did John log in?" Without it, can't segment by user. |
| **user_name** | Read friendly name instead of UUID. Easier for debugging. |
| **user_email** | For compliance/audit: "Who is this user?" Also useful for contact info if needed. |
| **event_type** | Categorizes event. Dashboard query: `WHERE event_type = 'page_view'` to count page visits. |
| **event_data** | JSON blob for flexible metadata. E.g., `{"button": "export", "format": "pdf"}`. Don't need to pre-define all fields. |
| **page** | Which page user was on? Quick filter: "Activity page views = 156". |
| **url** | Full URL for debugging. "Was this /activity or /activity?filter=active?" |
| **timestamp** | WHEN did event happen? Essential for: session duration, time trends, daily aggregates. |

### Indexes (Why They Matter)

```sql
CREATE INDEX idx_user_events_user_id ON telemetry.user_events (user_id);
-- Query: "Show me all events from John" — 10x faster with index

CREATE INDEX idx_user_events_session_id ON telemetry.user_events (session_id);
-- Query: "Get all events in session abc-123" — Fast lookup

CREATE INDEX idx_user_events_event_type ON telemetry.user_events (event_type);
-- Query: "Count all button_clicks" — Filter by type instantly

CREATE INDEX idx_user_events_timestamp ON telemetry.user_events (timestamp);
-- Query: "Events from last 7 days" — Range query on timestamp fast

CREATE INDEX idx_user_events_page ON telemetry.user_events (page);
-- Query: "Activity page views" — Filter by page name

CREATE INDEX idx_user_events_user_timestamp ON telemetry.user_events (user_id, timestamp DESC);
-- Query: "Last 10 actions by John" — Composite index, ordered
```

### Storage & Retention

- **Size:** ~450K events after 90 days = ~3GB compressed (Redshift columnar)
- **Retention:** 90 days in hot storage (queryable)
- **After 90 days:** Archive to blob storage, delete from Redshift

---

## TABLE 2: user_sessions (Aggregated View)

### Purpose
**Speed up session queries.** Instead of: "Scan 450K events, group by session_id, calculate duration," just: "SELECT * FROM user_sessions WHERE date = '2026-08-18'."

### Columns & Data Types

```sql
CREATE TABLE telemetry.user_sessions (
    session_id VARCHAR(100),                -- PK: "abc-123-xyz"
    user_id VARCHAR(100) NOT NULL,          -- Which user?
    user_name VARCHAR(255),                 -- Display name
    user_email VARCHAR(255),                -- Email for audit
    
    session_start TIMESTAMP,                -- When login happened
    session_end TIMESTAMP,                  -- When logout happened
    duration_seconds INT,                   -- session_end - session_start
    
    event_count INT DEFAULT 0,              -- Total events in session
    page_views INT DEFAULT 0,               -- page_view events only
    button_clicks INT DEFAULT 0,            -- button_click events only
    errors_count INT DEFAULT 0,             -- error events only
    
    created_at TIMESTAMP DEFAULT GETDATE()  -- When we wrote this row
);
```

### Why Each Column?

| Column | Why |
|--------|-----|
| **session_id** | Primary key. One row = one session. Unique identifier. |
| **user_id** | Which user? Enables "Show me all sessions from John." |
| **user_name, user_email** | For readability and audit trail. |
| **session_start, session_end** | Timestamps bounding the session. Enables "When was John working?" |
| **duration_seconds** | PRE-CALCULATED. `session_end - session_start` in seconds. Faster than calculating in queries. |
| **event_count** | How many total events? "John had 234 events in this session" = very engaged. |
| **page_views, button_clicks, errors_count** | Break down event types. "234 events: 12 page views, 200 clicks, 22 errors." |
| **created_at** | When we created this aggregate. For audit purposes. |

### How It's Populated

**Automatic aggregation** (run after each event batch):

```sql
INSERT INTO telemetry.user_sessions (session_id, user_id, ...)
SELECT 
    session_id,
    user_id,
    user_name,
    user_email,
    MIN(timestamp) as session_start,
    MAX(timestamp) as session_end,
    DATEDIFF(second, MIN(timestamp), MAX(timestamp)) as duration_seconds,
    COUNT(*) as event_count,
    COUNT(CASE WHEN event_type = 'page_view' THEN 1 END) as page_views,
    COUNT(CASE WHEN event_type = 'button_click' THEN 1 END) as button_clicks,
    COUNT(CASE WHEN event_type = 'error' THEN 1 END) as errors_count
FROM telemetry.user_events
WHERE session_id NOT IN (SELECT session_id FROM telemetry.user_sessions)
GROUP BY session_id, user_id, user_name, user_email;
```

### Indexes

```sql
CREATE INDEX idx_user_sessions_user_id ON telemetry.user_sessions (user_id);
-- "Show all sessions by John"

CREATE INDEX idx_user_sessions_session_start ON telemetry.user_sessions (session_start DESC);
-- "Sessions from last 7 days" (ordered by date)
```

---

## TABLE 3: daily_usage_summary (KPI Rollups)

### Purpose
**Dashboard speed.** Manager asks: "How many users today?" Answer in <100ms from this table, not from scanning 450K events.

### Columns & Data Types

```sql
CREATE TABLE telemetry.daily_usage_summary (
    usage_date DATE,                        -- PK: '2026-08-18'
    
    active_users INT,                       -- Distinct users who logged in
    total_sessions INT,                     -- Total sessions that day
    total_events INT,                       -- Sum of all events
    total_page_views INT,                   -- Count where event_type = 'page_view'
    total_button_clicks INT,                -- Count where event_type = 'button_click'
    total_logins INT,                       -- Count where event_type = 'user_login'
    total_errors INT,                       -- Count where event_type = 'error'
    
    avg_session_duration_seconds DECIMAL,   -- Average seconds per session that day
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

### Why Each Column?

| Column | Why |
|--------|-----|
| **usage_date** | Primary key. One row per day. "Give me metrics for 2026-08-18." |
| **active_users** | Critical KPI. "42 users used app today." Compare to yesterday/week. |
| **total_sessions** | "42 users had 58 sessions today" (some users logged in twice). |
| **total_events** | Volume metric. "7,800 total events = high activity day." |
| **total_page_views** | Engagement: "156 page views" = users navigating. |
| **total_button_clicks** | Feature usage: "234 button clicks" = features being used. |
| **total_logins** | Security/adoption: "42 logins" = usage frequency. |
| **total_errors** | Quality: "12 errors" = system working well. If errors spike to 100, problem! |
| **avg_session_duration_seconds** | Engagement: "Avg session 28 min = high engagement." |

### How It's Populated

**Scheduled aggregation** (run once per day at midnight):

```sql
INSERT INTO telemetry.daily_usage_summary
SELECT 
    DATE(timestamp) as usage_date,
    COUNT(DISTINCT user_id) as active_users,
    COUNT(DISTINCT session_id) as total_sessions,
    COUNT(*) as total_events,
    COUNT(CASE WHEN event_type = 'page_view' THEN 1 END) as total_page_views,
    COUNT(CASE WHEN event_type = 'button_click' THEN 1 END) as total_button_clicks,
    COUNT(CASE WHEN event_type = 'user_login' THEN 1 END) as total_logins,
    COUNT(CASE WHEN event_type = 'error' THEN 1 END) as total_errors,
    AVG(CAST(duration_seconds AS FLOAT)) as avg_session_duration_seconds
FROM telemetry.user_events
WHERE DATE(timestamp) = DATEADD(day, -1, GETDATE())
GROUP BY DATE(timestamp);
```

### Why Pre-aggregate?

**Without pre-aggregation:**
```
Dashboard query: "Show me active users last 30 days"
Engine: Scan 30 × 450K events, group by date, count distinct users
Time: 15-30 seconds ❌
```

**With pre-aggregation:**
```
Dashboard query: "Show me active users last 30 days"
Engine: 30 rows from daily_usage_summary, sum active_users
Time: <100ms ✅
```

**30x speed improvement for dashboards.**

---

## TABLE 4: page_analytics (Page Performance)

### Purpose
Track which pages are engaging. "Activity page: 156 views, avg 45 seconds on page."

### Columns & Data Types

```sql
CREATE TABLE telemetry.page_analytics (
    page_id BIGINT IDENTITY(1,1),           -- Unique row ID
    
    page_name VARCHAR(100),                 -- 'activity', 'capability', 'askai'
    analytics_date DATE,                    -- Which day? '2026-08-18'
    
    view_count INT DEFAULT 0,               -- Total page_view events
    unique_visitors INT DEFAULT 0,          -- Distinct users who viewed
    avg_time_spent_seconds DECIMAL(10, 2), -- Avg seconds on page
    bounce_rate DECIMAL(5, 2),              -- % who left without action
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

### Why Each Column?

| Column | Why |
|--------|-----|
| **page_name** | Which page? "activity" or "capability"? |
| **analytics_date** | Which day? Track trends day-over-day. |
| **view_count** | Total views. "Activity: 156 views." |
| **unique_visitors** | Distinct users. "156 views by 80 unique users" = repeat visitors. |
| **avg_time_spent_seconds** | Engagement proxy. "45 sec avg = high engagement." "12 sec = low." |
| **bounce_rate** | "67% bounce from Reference page" = users leaving immediately = bad UX. |

### How It's Populated

**Aggregated from events** (run hourly):

```sql
INSERT INTO telemetry.page_analytics
SELECT 
    page,
    DATE(timestamp) as analytics_date,
    COUNT(*) as view_count,
    COUNT(DISTINCT user_id) as unique_visitors,
    AVG(CAST(event_data->>'timeSpentSeconds' AS FLOAT)) as avg_time_spent_seconds,
    COUNT(CASE WHEN bounce = 1 THEN 1 END) * 100.0 / COUNT(*) as bounce_rate
FROM (
    SELECT 
        *,
        CASE WHEN LEAD(page) OVER (PARTITION BY session_id ORDER BY timestamp) IS NULL 
             OR LEAD(page) OVER (PARTITION BY session_id ORDER BY timestamp) != page
        THEN 1 ELSE 0 END as bounce
    FROM telemetry.user_events
    WHERE event_type = 'page_view'
)
WHERE DATE(timestamp) = DATEADD(day, -1, GETDATE())
GROUP BY page, DATE(timestamp);
```

### Indexes

```sql
CREATE INDEX idx_page_analytics_page_date ON telemetry.page_analytics (page_name, analytics_date DESC);
-- "Get Activity page metrics for last 7 days" — Fast
```

---

## TABLE 5: button_analytics (Feature Adoption)

### Purpose
Track which features users actually click. "Download: 89% adoption, Email: 12% adoption."

### Columns & Data Types

```sql
CREATE TABLE telemetry.button_analytics (
    button_id BIGINT IDENTITY(1,1),         -- Unique row ID
    
    button_name VARCHAR(255),               -- 'export_button', 'download_report'
    page_name VARCHAR(100),                 -- 'activity', 'capability'
    analytics_date DATE,                    -- '2026-08-18'
    
    click_count INT DEFAULT 0,              -- Total clicks on this button
    unique_users INT DEFAULT 0,             -- Distinct users who clicked
    adoption_rate DECIMAL(5, 2),            -- % of active users who clicked
    
    created_at TIMESTAMP DEFAULT GETDATE()
);
```

### Why Each Column?

| Column | Why |
|--------|-----|
| **button_name** | Which button? "download_report" or "email_report"? |
| **page_name** | Where was the button? "Export button on Activity page." |
| **analytics_date** | Which day? Track if adoption growing or declining. |
| **click_count** | Total clicks. "234 clicks on Download." |
| **unique_users** | Distinct users. "89 users clicked Download = 89% adoption (out of 100 active users)." |
| **adoption_rate** | KEY METRIC. "89% adoption" = feature succeeds. "12% adoption" = feature unused. |

### How It's Populated

**Aggregated from button_click events** (run hourly):

```sql
INSERT INTO telemetry.button_analytics
SELECT 
    event_data->>'button' as button_name,
    event_data->>'page' as page_name,
    DATE(timestamp) as analytics_date,
    COUNT(*) as click_count,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT user_id) * 100.0 / 
        (SELECT COUNT(DISTINCT user_id) FROM telemetry.user_events 
         WHERE DATE(timestamp) = DATE(timestamp) AND event_type != 'error')
        as adoption_rate
FROM telemetry.user_events
WHERE event_type = 'button_click'
    AND DATE(timestamp) = DATEADD(day, -1, GETDATE())
GROUP BY event_data->>'button', event_data->>'page', DATE(timestamp);
```

### Indexes

```sql
CREATE INDEX idx_button_analytics_button_page_date 
    ON telemetry.button_analytics (button_name, page_name, analytics_date DESC);
-- "Show Download button adoption over last 30 days" — Fast
```

---

## QUERY PATTERNS: Why This Schema Works

### Query 1: "How many users logged in today?"
```sql
SELECT active_users FROM telemetry.daily_usage_summary 
WHERE usage_date = '2026-08-18';
-- Result: 42
-- Speed: <10ms (1 row lookup)
```

### Query 2: "What's John's session history?"
```sql
SELECT * FROM telemetry.user_sessions 
WHERE user_id = 'john123' AND session_start >= DATEADD(day, -7, GETDATE())
ORDER BY session_start DESC;
-- Result: 8 sessions, each with duration, event counts
-- Speed: <100ms (index on user_id)
```

### Query 3: "Which pages get most engagement?"
```sql
SELECT page_name, AVG(avg_time_spent_seconds) as avg_engagement, SUM(view_count) as total_views
FROM telemetry.page_analytics 
WHERE analytics_date >= DATEADD(day, -7, GETDATE())
GROUP BY page_name
ORDER BY avg_engagement DESC;
-- Result: Activity=45s, Ask AI=58s, Capability=23s
-- Speed: <100ms (pre-aggregated data)
```

### Query 4: "Which features are users ignoring?"
```sql
SELECT button_name, adoption_rate, click_count
FROM telemetry.button_analytics 
WHERE analytics_date = '2026-08-18'
ORDER BY adoption_rate ASC
LIMIT 10;
-- Result: Email (12%), Share (8%), Search (5%)
-- Speed: <50ms (simple table scan)
```

---

## DATA FLOW: How Tables Are Populated

```
PHASE 1-2: Events arrive via API
    ↓
Frontend sends: POST /api/telemetry
    { events: [
        { sessionId: "abc", userId: "john", eventType: "button_click", ... }
    ]}
    ↓
Backend inserts: 1 row into user_events
    ↓

PHASE 3-4: Aggregation runs (Every 30 min)
    ↓
SQL job: Aggregate events → user_sessions
SQL job: Aggregate events → page_analytics
SQL job: Aggregate events → button_analytics
    ↓

PHASE 5: End of day aggregation
    ↓
SQL job: Aggregate all daily metrics → daily_usage_summary
    ↓

RESULT: Tables ready for queries
    Dashboard queries tables 3-5 (pre-aggregated)
    Detailed queries use table 1 (raw events)
```

---

## STORAGE & COST ESTIMATION

| Table | Rows (90 days) | Size | Purpose |
|-------|----------------|------|---------|
| **user_events** | 450K | ~2.5GB | Raw data (audit log) |
| **user_sessions** | 15K | ~50MB | Aggregated sessions |
| **daily_usage_summary** | 90 | ~1MB | Daily KPIs |
| **page_analytics** | 360 (4 pages × 90 days) | ~5MB | Page performance |
| **button_analytics** | 1,800 (20 buttons × 90 days) | ~15MB | Feature adoption |
| | **TOTAL** | | **~2.6GB** |

**Cost in Redshift:** ~$0.25/day (negligible)

---

## SUMMARY: Why This Schema Design?

| Table | Why | Trade-off |
|-------|-----|-----------|
| **user_events** | Single source of truth, audit log | Lots of rows (450K), but compressed in Redshift |
| **user_sessions** | Speed up session queries | Denormalized (duplicate data), but 10x faster |
| **daily_usage_summary** | Sub-100ms dashboard queries | Pre-aggregated (less detail), but instant |
| **page_analytics** | Know page engagement | Aggregated by day (can't do intra-day), but sufficient |
| **button_analytics** | Track feature adoption | Aggregated by day, but shows adoption trends |

**Design Philosophy:**
- **Layer 1:** Raw events (user_events) — Complete detail, searchable
- **Layer 2:** Sessions & aggregates — Denormalized for speed
- **Layer 3:** Daily rollups — Pre-aggregated for dashboards

This design enables:
✅ Real-time feature adoption tracking
✅ Sub-second dashboard queries
✅ User journey analysis
✅ Trend detection
✅ Compliance audit trail (raw events)
✅ Cost efficiency (compression + lifecycle)
