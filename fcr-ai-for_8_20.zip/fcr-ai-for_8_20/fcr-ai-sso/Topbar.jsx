import { Search, Bell, Download } from 'lucide-react';

export default function Topbar() {
  return (
    <header className="topbar">
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, flexShrink: 0 }}>
        <span className="topbar-logo">FCR Insights</span>
        <span style={{ fontSize: 9, color: '#ef4444', fontWeight: 700, border: '1px solid #fecaca', borderRadius: 4, padding: '1px 5px', background: '#fef2f2' }}>
          ⚡ AI Powered
        </span>
      </div>

      {/* Centered AI search */}
      <div className="topbar-search-wrap">
        <Search className="si" />
        <input
          id="global-search"
          type="text"
          placeholder="Ask anything, search MSLs, medical reports, scientific insights..."
          aria-label="AI Search"
        />
        <button className="topbar-search-btn" id="btn-ai-search">AI Search</button>
      </div>

      <div className="topbar-right">
        <div className="topbar-icon" id="btn-notifications" title="Notifications">
          <Bell size={17} />
          <span className="dot" />
        </div>
        <div className="topbar-avatar" id="user-avatar" title="Timothy Mauri">TM</div>
      </div>
    </header>
  );
}
