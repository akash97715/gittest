/**
 * Telemetry Constants - Shared between Frontend & Backend
 * Single source of truth for event types and telemetry configuration
 */

export const VALID_EVENT_TYPES = [
  'user_login',
  'user_logout',
  'browser_closed',
  'session_start',
  'session_end',
  'page_view',
  'page_exit',
  'button_click',
  'search',
  'data_export',
  'api_call',
  'error',
  'custom'
];

/**
 * Create a standardized event payload
 */
export function createEventPayload(type, data = {}) {
  if (!VALID_EVENT_TYPES.includes(type)) {
    throw new Error(`Invalid event type: ${type}`);
  }
  return {
    event_type: type,
    event_data: data,
    timestamp: new Date().toISOString()
  };
}

/**
 * Telemetry configuration from environment
 */
export const TELEMETRY_CONFIG = {
  ENABLED: process.env.TELEMETRY_ENABLED === 'true',
  TRANSPORT: process.env.TELEMETRY_TRANSPORT || 'direct', // 'direct' or 'kafka'
  BATCH_SIZE: parseInt(process.env.TELEMETRY_BATCH_SIZE || '10'),
  FLUSH_INTERVAL_MS: parseInt(process.env.TELEMETRY_FLUSH_INTERVAL_MS || '30000'),
  
  // Kafka config (for future use)
  KAFKA_BROKERS: process.env.KAFKA_BROKERS || '',
  KAFKA_TOPIC: process.env.KAFKA_TOPIC || 'telemetry_events',
  KAFKA_CLIENT_ID: process.env.KAFKA_CLIENT_ID || 'fcrai-telemetry-producer'
};

/**
 * Database schema and table names
 */
export const DB_SCHEMA = {
  SCHEMA: process.env.TELEMETRY_DB_SCHEMA || 'telemetry',
  USER_EVENTS: 'user_events',
  USER_SESSIONS: 'user_sessions',
  KAFKA_EVENT_TRACKING: 'kafka_event_tracking',
  EVENT_PROCESSING_STATUS: 'event_processing_status'
};
