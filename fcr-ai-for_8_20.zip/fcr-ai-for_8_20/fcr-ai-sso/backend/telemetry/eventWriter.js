import crypto from 'crypto';
import telemetryPool from '../../telemetryDb.js';
import { DB_SCHEMA, VALID_EVENT_TYPES, TELEMETRY_CONFIG } from './constants.js';

/**
 * Generate deterministic dedup ID from event components
 * Format: SHA256(userId|sessionId|timestamp|eventType)
 * Used for deduplication in kafka_event_tracking table
 */
export function generateDedupId(userId, sessionId, timestamp, eventType) {
  const combined = `${userId}|${sessionId}|${timestamp}|${eventType}`;
  return crypto.createHash('sha256').update(combined).digest('hex');
}

/**
 * Validate event structure and types
 */
function validateEvent(event) {
  if (!event.event_type) throw new Error('Missing event_type');
  if (!VALID_EVENT_TYPES.includes(event.event_type)) {
    throw new Error(`Invalid event_type: ${event.event_type}`);
  }
  return true;
}

/**
 * Write events to telemetry database in batch
 * 
 * Process:
 * 1. Generate dedup_id for each event
 * 2. Dedup check against kafka_event_tracking (INSERT ... ON CONFLICT DO NOTHING)
 * 3. Insert deduplicated events into user_events
 * 4. Write to event_processing_status for each event
 * 
 * @param {Array} events - Array of event objects
 * @param {string} [sessionId] - Optional session ID override
 * @param {string} [userId] - Optional user ID override
 * @returns {Object} { inserted: number, skipped: number, errors: array }
 */
export async function writeEvents(events, { sessionId, userId } = {}) {
  console.log('[EVENT_WRITER] writeEvents() called with', events.length, 'events');
  if (!events || events.length === 0) {
    console.log('[EVENT_WRITER] No events, returning');
    return { inserted: 0, skipped: 0, errors: [] };
  }

  console.log('[EVENT_WRITER] Getting telemetryPool connection...');
  const client = await telemetryPool.connect();
  console.log('[EVENT_WRITER] Connected to database');
  const results = { inserted: 0, skipped: 0, errors: [] };

  try {
    console.log('[EVENT_WRITER] Starting transaction (BEGIN)');
    await client.query('BEGIN');

    // Validate all events first
    events.forEach((e, i) => {
      try {
        validateEvent(e);
      } catch (err) {
        results.errors.push({
          index: i,
          error: err.message,
          event: e
        });
      }
    });

    // Filter out invalid events
    const validEvents = events.filter((e, i) => 
      !results.errors.some(er => er.index === i)
    );

    if (validEvents.length === 0) {
      await client.query('ROLLBACK');
      return results;
    }

    // ─── Step 1: Dedup check in kafka_event_tracking ───────────────────
    const dedupIds = validEvents.map(e => 
      generateDedupId(
        e.user_id || userId || 'anonymous',
        e.session_id || sessionId,
        e.timestamp || e.event_timestamp || new Date().toISOString(),
        e.event_type
      )
    );

    const dedupCheckQuery = `
      SELECT dedup_id FROM "${DB_SCHEMA.SCHEMA}"."${DB_SCHEMA.KAFKA_EVENT_TRACKING}"
      WHERE dedup_id = ANY($1::text[])
    `;
    const dedupCheckResult = await client.query(dedupCheckQuery, [dedupIds]);
    const existingDedupIds = new Set(dedupCheckResult.rows.map(r => r.dedup_id));

    // Filter for new events only
    const newEvents = validEvents.filter((e, i) => 
      !existingDedupIds.has(dedupIds[i])
    );

    if (newEvents.length === 0) {
      results.skipped = validEvents.length;
      await client.query('COMMIT');
      return results;
    }

    // ─── Step 2: Skip Kafka tracking for direct transport ─────────────────
    // For direct transport, we go straight to user_events
    // For Kafka transport, this would reserve the dedup_id
    console.log('[EVENT_WRITER] TELEMETRY_CONFIG.TRANSPORT:', TELEMETRY_CONFIG.TRANSPORT);
    let userEventInserts = newEvents;
    
    if (TELEMETRY_CONFIG.TRANSPORT === 'kafka') {
      console.log('[EVENT_WRITER] Using Kafka transport path');
      // Kafka path: Insert into kafka_event_tracking first
      const kafkaTopic = process.env.KAFKA_TOPIC || 'telemetry_events';
      const kafkaTrackingInserts = newEvents.map((e, i) => ({
        dedup_id: dedupIds[validEvents.indexOf(e)],
        kafka_topic: kafkaTopic,
        kafka_partition: 0,
        kafka_offset: -1,
        session_id: e.session_id || sessionId,
        user_id: e.user_id || userId || 'anonymous',
        processing_status: 'processed',
        created_at: new Date().toISOString()
      }));

      const kafkaTrackingPlaceholders = kafkaTrackingInserts
        .map((_, i) => {
          const offset = i * 7;
          return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7})`;
        })
        .join(',');

      const kafkaTrackingValues = kafkaTrackingInserts.flatMap(row => [
        row.dedup_id,
        row.kafka_topic,
        row.kafka_partition,
        row.kafka_offset,
        row.session_id,
        row.user_id,
        row.processing_status
      ]);

      const kafkaInsertQuery = `
        INSERT INTO "${DB_SCHEMA.SCHEMA}"."${DB_SCHEMA.KAFKA_EVENT_TRACKING}"
          (dedup_id, kafka_topic, kafka_partition, kafka_offset, session_id, user_id, processing_status)
        VALUES ${kafkaTrackingPlaceholders}
        ON CONFLICT (dedup_id) DO NOTHING
        RETURNING dedup_id
      `;

      const kafkaInsertResult = await client.query(kafkaInsertQuery, kafkaTrackingValues);
      const insertedDedupIds = new Set(kafkaInsertResult.rows.map(r => r.dedup_id));
      userEventInserts = newEvents.filter((e, i) =>
        insertedDedupIds.has(dedupIds[validEvents.indexOf(e)])
      );
    } else {
      console.log('[EVENT_WRITER] Using direct transport, skipping kafka_event_tracking');
    }

    // ─── Step 3: Batch insert into user_events ──────────────────────────
    const finalEventInserts = userEventInserts.filter((e, i) => 
      !results.errors.some(er => er.index === validEvents.indexOf(e))
    );

    if (finalEventInserts.length === 0) {
      results.skipped = validEvents.length;
      await client.query('COMMIT');
      return results;
    }

    const userEventPlaceholders = finalEventInserts
      .map((_, i) => {
        const offset = i * 8;
        return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6}, $${offset + 7}, $${offset + 8})`;
      })
      .join(',');

    const userEventValues = finalEventInserts.flatMap(e => [
      e.session_id || sessionId,
      e.user_id || userId || 'anonymous',
      e.user_name || null,
      e.user_email || null,
      e.event_type,
      JSON.stringify(e.event_data || {}),
      e.page || null,
      e.event_timestamp || new Date().toISOString()
    ]);

    const userEventsQuery = `
      INSERT INTO "${DB_SCHEMA.SCHEMA}"."${DB_SCHEMA.USER_EVENTS}"
        (session_id, user_id, user_name, user_email, event_type, event_data, page, event_timestamp)
      VALUES ${userEventPlaceholders}
      RETURNING event_id, session_id, user_id, event_type, event_timestamp
    `;

    const userEventsResult = await client.query(userEventsQuery, userEventValues);
    results.inserted = userEventsResult.rows.length;

    // ─── Step 4: Write to event_processing_status ───────────────────────
    const processingStatusInserts = userEventsResult.rows.map(row => {
      const dedupIndex = finalEventInserts.findIndex(
        e => e.session_id === row.session_id && e.user_id === row.user_id
      );
      const dedupId = dedupIds[validEvents.indexOf(finalEventInserts[dedupIndex])];
      
      return {
        event_id: row.event_id,
        dedup_id: dedupId,
        stage: 'stored',  // Valid stages: 'received', 'validated', 'stored', 'aggregated', 'archived'
        stage_status: 'completed',  // Valid statuses: 'in_progress', 'completed', 'failed'
        timestamp_received: new Date().toISOString(),
        processing_duration_ms: 0,
        created_at: new Date().toISOString()
      };
    });

    const statusPlaceholders = processingStatusInserts
      .map((_, i) => {
        const offset = i * 6;
        return `($${offset + 1}, $${offset + 2}, $${offset + 3}, $${offset + 4}, $${offset + 5}, $${offset + 6})`;
      })
      .join(',');

    const statusValues = processingStatusInserts.flatMap(row => [
      row.event_id,
      row.dedup_id,
      row.stage,
      row.stage_status,
      row.timestamp_received,
      row.created_at
    ]);

    const statusQuery = `
      INSERT INTO "${DB_SCHEMA.SCHEMA}"."${DB_SCHEMA.EVENT_PROCESSING_STATUS}"
        (event_id, dedup_id, stage, stage_status, timestamp_received, created_at)
      VALUES ${statusPlaceholders}
      ON CONFLICT DO NOTHING
    `;

    // Only write event_processing_status for Kafka transport
    if (TELEMETRY_CONFIG.TRANSPORT === 'kafka' && statusValues.length > 0) {
      await client.query(statusQuery, statusValues);
      console.log('[EVENT_WRITER] Kafka mode: event_processing_status written');
    } else {
      console.log('[EVENT_WRITER] Direct mode: skipping event_processing_status');
    }

    results.skipped = validEvents.length - results.inserted;
    console.log('[EVENT_WRITER] Transaction COMMIT. Results:', results);
    await client.query('COMMIT');

  } catch (err) {
    console.error('[EVENT_WRITER] ERROR:', err.message, err.stack);
    await client.query('ROLLBACK');
    console.error('Error writing telemetry events:', err.message);
    results.errors.push({
      type: 'write_error',
      error: err.message
    });
  } finally {
    console.log('[EVENT_WRITER] Releasing database connection');
    client.release();
  }

  console.log('[EVENT_WRITER] Returning results:', results);
  return results;
}
