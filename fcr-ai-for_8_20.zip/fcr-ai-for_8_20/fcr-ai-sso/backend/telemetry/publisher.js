import { TELEMETRY_CONFIG } from './constants.js';
import { writeEvents } from './eventWriter.js';

/**
 * Telemetry Publisher - Transport Abstraction Layer
 * 
 * Routes events to the configured transport:
 * - 'direct': Write directly to PostgreSQL (current)
 * - 'kafka': Send to Kafka producer (future implementation)
 * 
 * The API route and frontend never reference transport directly.
 * This enables zero-code-change migration to Kafka later.
 */

/**
 * Publish events to telemetry system
 * Fire-and-forget: Returns immediately, never blocks caller
 * 
 * @param {Array} events - Array of event objects
 * @param {Object} context - Optional context { sessionId, userId, userName, userEmail }
 * @returns {Promise<void>}
 */
export async function publish(events, context = {}) {
  console.log('[PUBLISHER] publish() called with', events.length, 'events');
  console.log('[PUBLISHER] TELEMETRY_CONFIG.ENABLED:', TELEMETRY_CONFIG.ENABLED);
  console.log('[PUBLISHER] TELEMETRY_CONFIG.TRANSPORT:', TELEMETRY_CONFIG.TRANSPORT);
  
  if (!TELEMETRY_CONFIG.ENABLED) {
    console.log('[PUBLISHER] Telemetry disabled, returning');
    return;
  }

  if (!events || events.length === 0) {
    console.log('[PUBLISHER] No events to publish, returning');
    return;
  }

  try {
    if (TELEMETRY_CONFIG.TRANSPORT === 'kafka') {
      console.log('[PUBLISHER] Using Kafka transport (not yet implemented)');
      // Future: Send to Kafka producer
      console.warn('Kafka transport not yet implemented');
    } else {
      console.log('[PUBLISHER] Using direct transport, calling writeEvents()');
      // Direct to PostgreSQL (current)
      const result = await writeEvents(events, {
        sessionId: context.sessionId,
        userId: context.userId,
        userName: context.userName,
        userEmail: context.userEmail
      });
      console.log('[PUBLISHER] writeEvents result:', result);
    }
  } catch (err) {
    // Never throw — telemetry failures must never affect user requests
    console.error('[PUBLISHER] Telemetry publish error:', err.message, err.stack);
  }
}

/**
 * Publish a single event (convenience wrapper)
 */
export async function publishEvent(eventType, eventData = {}, context = {}) {
  const event = {
    event_type: eventType,
    event_data: eventData,
    event_timestamp: new Date().toISOString(),
    ...context
  };
  return publish([event], context);
}

export default {
  publish,
  publishEvent
};
