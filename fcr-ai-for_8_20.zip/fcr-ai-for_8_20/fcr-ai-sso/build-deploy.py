"""
build-deploy.py
Creates a clean deployment ZIP for Azure App Service.

Approach: NO node_modules bundled.
Azure (Oryx) runs npm install DURING DEPLOYMENT (not at startup),
so the container starts in seconds with dependencies already installed.

REQUIRED Azure App Setting: SCM_DO_BUILD_DURING_DEPLOYMENT = true
"""

import os
import shutil
import zipfile
import json

ROOT       = os.path.dirname(os.path.abspath(__file__))
STAGING    = os.path.join(ROOT, "deploy-staging")
OUTPUT_ZIP = os.path.join(ROOT, "fcr-ai-deploy.zip")

# Slim package.json - only express is needed at runtime.
# React/recharts/etc. are already compiled into dist/ by Vite.
SLIM_PKG = {
    "name": "fcr-ai",
    "version": "1.0.0",
    "private": True,
    "type": "module",
    "scripts": {
        "start": "node server.js"
    },
    "engines": {
        "node": ">=20.0.0"
    },
    "dependencies": {
        "express": "^4.21.2"
    }
}

# Step 1: Clean staging
print("[*] Cleaning staging directory...")
import stat

def force_remove(path):
    """Remove directory tree, handling read-only files (OneDrive/Windows)."""
    def onerror(func, path, exc_info):
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass
    shutil.rmtree(path, onerror=onerror)

if os.path.exists(STAGING):
    force_remove(STAGING)
os.makedirs(STAGING)

# Step 2: Copy server.js
print("[*] Copying server.js...")
shutil.copy(os.path.join(ROOT, "server.js"), os.path.join(STAGING, "server.js"))

# Step 3: Copy dist/
print("[*] Copying dist/ folder...")
shutil.copytree(
    os.path.join(ROOT, "dist"),
    os.path.join(STAGING, "dist")
)

# Step 4: Write slim package.json
print("[*] Writing slim package.json (express only)...")
with open(os.path.join(STAGING, "package.json"), "w") as f:
    json.dump(SLIM_PKG, f, indent=2)

# Step 5: Build ZIP with forward slashes (Linux-compatible)
print(f"[*] Building ZIP -> {OUTPUT_ZIP}")
if os.path.exists(OUTPUT_ZIP):
    os.remove(OUTPUT_ZIP)

with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for dirpath, dirnames, filenames in os.walk(STAGING):
        for filename in filenames:
            abs_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(abs_path, STAGING).replace("\\", "/")
            zf.write(abs_path, rel_path)

size_kb = os.path.getsize(OUTPUT_ZIP) / 1024
print(f"\n[OK] fcr-ai-deploy.zip created ({size_kb:.0f} KB)")
print("   Contains: server.js | package.json (express only) | dist/")
print("   No node_modules - Azure will run npm install during deployment")
print("\n   REQUIRED App Setting: SCM_DO_BUILD_DURING_DEPLOYMENT = true")
print("   Then upload this ZIP via Kudu or Azure Portal ZIP Deploy.")

# Cleanup
print("\n[*] Cleaning up staging directory...")
shutil.rmtree(STAGING)
print("[*] Done.")
