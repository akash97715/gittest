// build-zip.cjs — Creates Linux-compatible ZIP for Azure (forward slashes only)
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');

const OUTPUT = 'fcr-ai-deploy.zip';

function addFolderRecursive(zip, folderPath, zipPrefix) {
  const items = fs.readdirSync(folderPath);
  for (const item of items) {
    const fullPath = path.join(folderPath, item);
    // Always use forward slash for ZIP entry name (Linux-compatible)
    const zipPath = zipPrefix + '/' + item;
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      addFolderRecursive(zip, fullPath, zipPath);
    } else {
      zip.addFile(zipPath, fs.readFileSync(fullPath));
    }
  }
}

const zip = new AdmZip();

// Add individual root files
zip.addFile('server.js',         fs.readFileSync('server.js'));
zip.addFile('package.json',      fs.readFileSync('package.json'));
zip.addFile('package-lock.json', fs.readFileSync('package-lock.json'));

// Add dist/ folder recursively with forward slashes
addFolderRecursive(zip, 'dist', 'dist');

zip.writeZip(OUTPUT);

// Verify entries
const entries = zip.getEntries().map(e => e.entryName);
const sizeMB = (fs.statSync(OUTPUT).size / 1024 / 1024).toFixed(2);

console.log('\n✅ ZIP created: ' + OUTPUT + ' (' + sizeMB + ' MB)');
console.log('\nEntries (' + entries.length + ' files):');
entries.forEach(e => console.log('  ' + e));
console.log('\n✅ Ready to upload to Azure Web App via ZIP Deploy!');
