// build-zip.mjs — Creates a Linux-compatible ZIP for Azure Web App deployment
// Uses forward slashes in all paths (fixes rsync Invalid argument error on Azure)

import fs from 'fs';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { ZipArchive } = require('archiver');

const OUTPUT = 'fcr-ai-deploy.zip';

// Remove old ZIP if it exists
if (fs.existsSync(OUTPUT)) {
  fs.unlinkSync(OUTPUT);
  console.log(`Removed old ${OUTPUT}`);
}

// Verify dist/ exists
if (!fs.existsSync('dist')) {
  console.error('\n❌  dist/ folder not found. Run "npm run build" first.\n');
  process.exit(1);
}

const output = fs.createWriteStream(OUTPUT);
const archive = new ZipArchive({ zlib: { level: 9 } });

archive.on('finish', () => {
  const sizeMB = (fs.statSync(OUTPUT).size / 1024 / 1024).toFixed(2);
  console.log(`\n✅  ZIP created: ${OUTPUT} (${sizeMB} MB)`);
  console.log('\n📦  Contents included:');
  console.log('  server.js        ← Express API + static file server');
  console.log('  db.js            ← Redshift/PostgreSQL connection');
  console.log('  package.json     ← npm start = node server.js');
  console.log('  package-lock.json');
  console.log('  web.config       ← Azure IIS/iisnode routing');
  console.log('  dist/            ← Pre-built React frontend');
  console.log('\n🚀  Deploy with:');
  console.log('  az webapp deploy --resource-group <rg> --name <app-name> --src-path fcr-ai-deploy.zip --type zip');
  console.log('\n⚙️   Remember to set these in Azure Portal → Web App → Environment variables:');
  console.log('  PORT, PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD');
  console.log('  AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_API_KEY');
  console.log('  VITE_AZURE_CLIENT_ID, VITE_AZURE_TENANT_ID');
});

archive.on('error', (err) => { throw err; });

archive.pipe(output);

// ── Root server files ─────────────────────────────────────────
const rootFiles = [
  'server.js',
  'db.js',
  'package.json',
  'package-lock.json',
  'web.config',
];
for (const f of rootFiles) {
  if (fs.existsSync(f)) {
    archive.file(f, { name: f });
  } else {
    console.warn(`⚠️  Warning: ${f} not found, skipping`);
  }
}

// ── Pre-built React frontend ──────────────────────────────────
archive.directory('dist/', 'dist');

archive.finalize();
