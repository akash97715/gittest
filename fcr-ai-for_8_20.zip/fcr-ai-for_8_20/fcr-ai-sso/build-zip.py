"""
build-zip.py — Azure Web App deployment ZIP builder
Uses Python's built-in zipfile module (no PowerShell, no archiver issues)
Run: python build-zip.py
"""

import zipfile
import os
import sys

OUTPUT = 'fcr-ai-deploy.zip'

# Files to include at the root of the ZIP
ROOT_FILES = [
    'server.js',
    'db.js',
    'package.json',
    'package-lock.json',
    'web.config',
]

# Folders to include recursively
FOLDERS = [
    'dist',   # pre-built React frontend (run npm run build first)
]

# ── Checks ──────────────────────────────────────────────────────
if not os.path.isdir('dist'):
    print('\n❌  dist/ not found. Run "npm run build" first.\n')
    sys.exit(1)

missing = [f for f in ROOT_FILES if not os.path.isfile(f)]
if missing:
    print(f'⚠️  Warning: these files not found and will be skipped: {missing}')
    ROOT_FILES_EXIST = [f for f in ROOT_FILES if os.path.isfile(f)]
else:
    ROOT_FILES_EXIST = ROOT_FILES

# Remove old zip
if os.path.exists(OUTPUT):
    os.remove(OUTPUT)
    print(f'Removed old {OUTPUT}')

# ── Build ZIP ────────────────────────────────────────────────────
file_count = 0
with zipfile.ZipFile(OUTPUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:

    # Root files
    for f in ROOT_FILES_EXIST:
        zf.write(f, arcname=f)
        print(f'  + {f}')
        file_count += 1

    # Folders (use forward slashes for Linux compatibility)
    for folder in FOLDERS:
        for root, dirs, files in os.walk(folder):
            # Skip node_modules if accidentally inside dist
            dirs[:] = [d for d in dirs if d != 'node_modules']
            for file in files:
                full_path = os.path.join(root, file)
                # Always use forward slashes in the archive path
                arc_name = full_path.replace('\\', '/')
                zf.write(full_path, arcname=arc_name)
                file_count += 1

size_mb = os.path.getsize(OUTPUT) / 1024 / 1024
print(f'\n✅  {OUTPUT} created  ({size_mb:.2f} MB, {file_count} files)')
print('\n🚀  Deploy command:')
print('    az webapp deploy --resource-group <rg> --name <app-name> --src-path fcr-ai-deploy.zip --type zip')
print('\n⚙️   Azure Portal → Web App → Environment variables → add:')
print('    PORT=8080')
print('    PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD')
print('    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_API_KEY')
print('    VITE_AZURE_CLIENT_ID, VITE_AZURE_TENANT_ID')
