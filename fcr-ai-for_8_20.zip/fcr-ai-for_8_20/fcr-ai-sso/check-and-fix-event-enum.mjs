#!/usr/bin/env node
/**
 * Check Database Event Type ENUM and Add browser_closed if needed
 */

import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const telemetryPool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

console.log('\n' + '='.repeat(80));
console.log('DATABASE EVENT TYPE ENUM CHECK');
console.log('='.repeat(80));

try {
  const client = await telemetryPool.connect();
  
  // Step 1: Check if event_type is an ENUM
  console.log('\n✓ Step 1: Checking if event_type column is an ENUM...');
  
  const typeQuery = `
    SELECT 
      column_name,
      data_type,
      udt_name
    FROM information_schema.columns
    WHERE table_schema = 'telemetry' 
      AND table_name = 'user_events'
      AND column_name = 'event_type'
  `;
  
  const typeResult = await client.query(typeQuery);
  
  if (typeResult.rows.length === 0) {
    console.log('  ⚠️  event_type column not found!');
    client.release();
    process.exit(1);
  }
  
  const column = typeResult.rows[0];
  console.log('  Column Details:');
  console.log('    - Column Name:', column.column_name);
  console.log('    - Data Type:', column.data_type);
  console.log('    - UDT Name (Underlying Type):', column.udt_name);
  
  if (column.data_type !== 'USER-DEFINED' || !column.udt_name.includes('event_type')) {
    console.log('\n  ⚠️  event_type is NOT an ENUM! It\'s a regular column.');
    console.log('     Type:', column.data_type);
    console.log('     No need to update enum values.');
    client.release();
    process.exit(0);
  }
  
  // Step 2: Get current ENUM values
  console.log('\n✓ Step 2: Fetching current ENUM values...');
  
  const enumQuery = `
    SELECT enum_range(NULL::${column.udt_name}) AS enum_values
  `;
  
  const enumResult = await client.query(enumQuery);
  const currentValues = enumResult.rows[0]?.enum_values || [];
  
  console.log('  Current ENUM values:');
  currentValues.forEach((val, idx) => {
    console.log(`    ${idx + 1}. '${val}'`);
  });
  
  // Step 3: Check if browser_closed is already there
  console.log('\n✓ Step 3: Checking if browser_closed exists...');
  
  if (currentValues.includes('browser_closed')) {
    console.log('  ✅ browser_closed already exists in the enum!');
    client.release();
    process.exit(0);
  }
  
  console.log('  ❌ browser_closed NOT found in enum values!');
  console.log('  Action: Adding browser_closed to the enum...');
  
  // Step 4: Add browser_closed to ENUM
  console.log('\n✓ Step 4: Adding browser_closed to ENUM...');
  
  const alterQuery = `
    ALTER TYPE ${column.udt_name} ADD VALUE 'browser_closed' BEFORE 'session_start'
  `;
  
  console.log('  SQL:', alterQuery);
  
  await client.query(alterQuery);
  
  console.log('  ✅ Successfully added browser_closed to ENUM!');
  
  // Step 5: Verify the change
  console.log('\n✓ Step 5: Verifying the change...');
  
  const verifyResult = await client.query(enumQuery);
  const updatedValues = verifyResult.rows[0]?.enum_values || [];
  
  console.log('  Updated ENUM values:');
  updatedValues.forEach((val, idx) => {
    const marker = val === 'browser_closed' ? ' ← NEWLY ADDED' : '';
    console.log(`    ${idx + 1}. '${val}'${marker}`);
  });
  
  client.release();
  
  console.log('\n' + '='.repeat(80));
  console.log('✅ SUCCESS! database ENUM updated with browser_closed');
  console.log('='.repeat(80) + '\n');
  
  process.exit(0);
  
} catch (err) {
  console.error('\n❌ ERROR:', err.message);
  console.error('\nFull error details:');
  console.error(err);
  process.exit(1);
}
