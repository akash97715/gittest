import pool from './db.js';

// Check real competency-rated question counts and sample names
const r = await pool.query(`
  SELECT
    CASE
      WHEN LOWER(survey_question_text) LIKE '%selling skill%'                                               THEN 'Selling Skills'
      WHEN LOWER(survey_question_text) LIKE '%healthcare marketplace%'                                      THEN 'Healthcare Marketplace'
      WHEN LOWER(survey_question_text) LIKE '%analytics%' AND LOWER(survey_question_text) LIKE '%insight%'  THEN 'Analytics & Insights'
      WHEN LOWER(survey_question_text) LIKE '%internal partner%'                                            THEN 'Internal Partnerships'
      WHEN LOWER(survey_question_text) LIKE '%account management%'                                          THEN 'Account Management'
      WHEN LOWER(survey_question_text) LIKE '%market%plan%' AND LOWER(survey_question_text) LIKE '%business%' THEN 'Business Planning'
      WHEN LOWER(survey_question_text) LIKE '%pre-call%' OR LOWER(survey_question_text) LIKE '%pre call%'   THEN 'Pre-Call Planning'
      WHEN LOWER(survey_question_text) LIKE 'advance%'                                                      THEN 'Advance'
      WHEN LOWER(survey_question_text) LIKE 'learn%' AND LOWER(survey_question_text) LIKE '%customer%'      THEN 'Learn'
      WHEN LOWER(survey_question_text) LIKE 'deliver%'                                                      THEN 'Deliver'
      WHEN LOWER(survey_question_text) LIKE 'engage%'                                                       THEN 'Engage'
      WHEN LOWER(survey_question_text) LIKE '%stakeholder%'                                                 THEN 'Stakeholder Mapping'
      ELSE 'OTHER'
    END AS competency,
    survey_question_response,
    COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND survey_question_response IN ('Clear Strength','Emerging Strength','Development Need','Clear Development Need')
  GROUP BY 1, 2
  ORDER BY competency, survey_question_response
`);
r.rows.forEach(x => console.log(JSON.stringify(x)));
process.exit(0);

