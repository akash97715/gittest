import pool from './db.js';

// Example: Danny Mcnatty's FCR ID from the UI
const fcrId = 'a2zWQ0000041VsHYAU'; // Change this to any FCR ID

const res = await pool.query(`
  SELECT
    survey_target_id,
    rep_first_nm,
    rep_last_nm,
    survey_question_order,
    survey_question_name,
    survey_question_text,
    survey_question_response,
    survey_question_response_text
  FROM odp.dp_cust_pers_engagement_dly
  WHERE survey_target_id = $1
    AND chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
  ORDER BY survey_question_order
  LIMIT 50
`, [fcrId]);

console.log(`\nFCR: ${fcrId}`);
console.log(`Person: ${res.rows[0]?.rep_first_nm} ${res.rows[0]?.rep_last_nm}\n`);

// Filter only FBMS behavior ratings
const FBMS_SCORE = { Expert: 4, Advanced: 3, Skilled: 2, Awareness: 1 };
const rated = res.rows.filter(r => FBMS_SCORE[r.survey_question_response]);

console.log('FBMS Behavior Ratings:');
console.table(rated.map(r => ({
  'Question': r.survey_question_order,
  'Rating': r.survey_question_response,
  'Points': FBMS_SCORE[r.survey_question_response]
})));

const totalPoints = rated.reduce((s, r) => s + FBMS_SCORE[r.survey_question_response], 0);
const avgScore = totalPoints / rated.length;
const label = avgScore >= 3.5 ? 'Expert' : avgScore >= 3.0 ? 'Advanced' : avgScore >= 2.0 ? 'Skilled' : 'Awareness';

console.log(`\n✅ Total rated: ${rated.length} behaviors`);
console.log(`✅ Total points: ${totalPoints}`);
console.log(`✅ Average score: ${avgScore.toFixed(1)}`);
console.log(`✅ Label: ${label}\n`);

await pool.end();
