import pool from './db.js';

// 1. All distinct response values
const r1 = await pool.query(`
  SELECT DISTINCT survey_question_response, COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND survey_question_response IS NOT NULL AND survey_question_response != ''
  GROUP BY 1 ORDER BY cnt DESC LIMIT 30
`);
console.log('\n=== RESPONSE VALUES ===');
r1.rows.forEach(x => console.log(JSON.stringify(x)));

// 2. Sample question texts that mention PINS keywords
const r2 = await pool.query(`
  SELECT DISTINCT survey_question_text, survey_question_response, COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND (
      LOWER(survey_question_text) LIKE '%planning%'
      OR LOWER(survey_question_text) LIKE '%investigate%'
      OR LOWER(survey_question_text) LIKE '%navigate%'
      OR LOWER(survey_question_text) LIKE '%secure%'
      OR LOWER(survey_question_text) LIKE '%pins%'
      OR LOWER(survey_question_text) LIKE '%training needed%'
      OR LOWER(survey_question_text) LIKE '%impressions%'
      OR LOWER(survey_question_text) LIKE '%fbms%'
    )
  GROUP BY 1, 2 ORDER BY cnt DESC LIMIT 40
`);
console.log('\n=== PINS-RELATED QUESTIONS ===');
r2.rows.forEach(x => console.log(JSON.stringify(x)));

process.exit(0);
