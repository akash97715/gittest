import pool from './db.js';

console.log('\n=== Redshift Diagnostics ===\n');

try {
  // 1. Check STV_RECENTS column names
  const cols = await pool.query('SELECT * FROM STV_RECENTS LIMIT 0');
  console.log('STV_RECENTS columns:', cols.fields.map(f => f.name).join(', '));
} catch(e) { console.log('STV_RECENTS error:', e.message); }

try {
  // 2. Running queries
  const running = await pool.query(`
    SELECT pid, user_name, status,
           ROUND(duration/1000000.0,1) AS elapsed_secs,
           SUBSTRING(query, 1, 120) AS query_preview
    FROM STV_RECENTS
    WHERE status = 'Running'
    ORDER BY duration DESC
    LIMIT 10
  `);
  console.log('\n--- Running Queries ---');
  if (running.rows.length === 0) console.log('None currently running');
  else running.rows.forEach(r => console.log(JSON.stringify(r)));
} catch(e) {
  // Try alternate column name
  try {
    const running2 = await pool.query(`
      SELECT pid, user_name, status,
             SUBSTRING(query, 1, 120) AS query_preview
      FROM STV_RECENTS
      WHERE status = 'Running'
      LIMIT 10
    `);
    console.log('\n--- Running Queries ---');
    running2.rows.forEach(r => console.log(JSON.stringify(r)));
  } catch(e2) { console.log('Running query error:', e2.message); }
}

try {
  // 3. Table health
  const health = await pool.query(`
    SELECT schema_name, table_name, 
           size_in_mb, tbl_rows,
           unsorted_rows, stats_off, rows_modified
    FROM SVV_TABLE_INFO
    WHERE table_name = 'dp_cust_pers_engagement_dly'
  `);
  console.log('\n--- Table Health ---');
  health.rows.forEach(r => console.log(JSON.stringify(r)));
} catch(e) { console.log('Table health error:', e.message); }

try {
  // 4. WLM concurrency slots
  const wlm = await pool.query(`
    SELECT service_class, num_query_tasks
    FROM STV_WLM_SERVICE_CLASS_CONFIG
    WHERE service_class > 4
    ORDER BY service_class
  `);
  console.log('\n--- WLM Slots ---');
  wlm.rows.forEach(r => console.log(JSON.stringify(r)));
} catch(e) { console.log('WLM error:', e.message); }

try {
  // 5. Sort keys on the table
  const sk = await pool.query(`
    SELECT columnname, sortkey, distkey
    FROM PG_TABLE_DEF
    WHERE schemaname = 'odp'
      AND tablename = 'dp_cust_pers_engagement_dly'
      AND (sortkey > 0 OR distkey = true)
    ORDER BY sortkey
  `);
  console.log('\n--- Sort / Dist Keys ---');
  if (sk.rows.length === 0) console.log('NO sort keys defined (full table scan on every query)');
  else sk.rows.forEach(r => console.log(JSON.stringify(r)));
} catch(e) { console.log('Sort key error:', e.message); }

try {
  // 6. Quick timing test on a simple count
  const t0 = Date.now();
  const ct = await pool.query(`SELECT COUNT(*) FROM odp.dp_cust_pers_engagement_dly`);
  const elapsed = Date.now() - t0;
  console.log(`\n--- Simple COUNT(*) ---`);
  console.log(`Rows: ${ct.rows[0].count}, Time: ${elapsed}ms`);
} catch(e) { console.log('Count error:', e.message); }

await pool.end();
console.log('\n=== Done ===');
