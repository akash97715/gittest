#!/usr/bin/env node
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;
const pool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

const client = await pool.connect();
const result = await client.query(`
  SELECT column_name, data_type 
  FROM information_schema.columns
  WHERE table_schema = 'telemetry' AND table_name = 'user_events'
  ORDER BY ordinal_position
`);
console.log('\nColumns in telemetry.user_events:');
result.rows.forEach((col, idx) => {
  console.log(`  ${idx + 1}. ${col.column_name.padEnd(20)} : ${col.data_type}`);
});

// Also check for recent browser_closed events
console.log('\n\nRecent browser_closed events:');
const eventsResult = await client.query(`
  SELECT session_id, user_id, event_type, event_timestamp 
  FROM telemetry.user_events 
  WHERE event_type = 'browser_closed'
  ORDER BY event_timestamp DESC
  LIMIT 5
`);

console.log('Found:', eventsResult.rows.length, 'events');
if (eventsResult.rows.length === 0) {
  console.log('  ⚠️  No browser_closed events found yet');
} else {
  eventsResult.rows.forEach((row, idx) => {
    console.log(`  ${idx + 1}. Session: ${row.session_id}, User: ${row.user_id}, Type: ${row.event_type}, Timestamp: ${row.event_timestamp}`);
  });
}

client.release();
pool.end();
