import pool from './db.js';

const cutoff = new Date();
cutoff.setDate(cutoff.getDate() - 180);
const cutoffStr = cutoff.toISOString().slice(0, 10);

console.log('6-month cutoff:', cutoffStr);

const sql = `
  SELECT
    COUNT(DISTINCT survey_target_id) AS flagged_fcrs_awareness,
    COUNT(DISTINCT rep_wwid) AS reps_needing_training_awareness
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
    AND acty_dt >= $1::date
    AND survey_question_response = 'Awareness'
`;

try {
  const result = await pool.query(sql, [cutoffStr]);
  console.log('Awareness only (6 months):', result.rows[0]);
  
  // Also check other values
  const sql2 = `
    SELECT
      survey_question_response,
      COUNT(DISTINCT survey_target_id) AS fcrs_count,
      COUNT(DISTINCT rep_wwid) AS reps_count
    FROM odp.dp_cust_pers_engagement_dly
    WHERE chnl = 'SURVEY'
      AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
      AND survey_target_id IS NOT NULL
      AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
      AND acty_dt >= $1::date
    GROUP BY survey_question_response
    ORDER BY fcrs_count DESC
  `;
  const result2 = await pool.query(sql2, [cutoffStr]);
  console.log('\nAll response values (6 months):');
  result2.rows.forEach(r => console.log(r));
  
  process.exit(0);
} catch (err) {
  console.error('Error:', err.message);
  process.exit(1);
}
