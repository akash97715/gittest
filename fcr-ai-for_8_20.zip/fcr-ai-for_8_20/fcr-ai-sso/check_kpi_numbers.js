import 'dotenv/config';
import pool from './db.js';

const MSL_FILTER = `(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`;

const conditions = [
  `chnl = 'SURVEY'`,
  `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
  `survey_target_id IS NOT NULL`,
  MSL_FILTER,
];

const where = conditions.join(' AND ');

async function test() {
  try {
    // Query 1: Original query - total FCRs, total reps, etc.
    const sql = `
      SELECT
        COUNT(DISTINCT survey_target_id) AS total_fcrs,
        COUNT(DISTINCT rep_wwid) AS total_reps,
        ROUND(1.0 * COUNT(DISTINCT survey_target_id) / NULLIF(COUNT(DISTINCT rep_wwid), 0), 1) AS fcrs_per_rep,
        COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END) AS submitted_fcrs,
        COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%' THEN survey_target_id END) AS draft_fcrs
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
    `;

    console.log('\n=== QUERY 1: Base KPIs (Original Code) ===');
    const result = await pool.query(sql, []);
    console.log(JSON.stringify(result.rows[0], null, 2));

    // Query 2: Survey responses distribution
    const q2 = `
      SELECT
        survey_question_response,
        COUNT(DISTINCT survey_target_id) AS fcr_count,
        COUNT(DISTINCT rep_wwid) AS rep_count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response IS NOT NULL
      GROUP BY survey_question_response
      ORDER BY fcr_count DESC
    `;

    console.log('\n=== QUERY 2: Survey Response Distribution ===');
    const result2 = await pool.query(q2, []);
    console.log(JSON.stringify(result2.rows, null, 2));

    // Query 3: Count specific training need responses
    const q3 = `
      SELECT
        'Clear Development Need' as response_type,
        COUNT(DISTINCT survey_target_id) AS fcr_count,
        COUNT(DISTINCT rep_wwid) AS rep_count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response = 'Clear Development Need'
      UNION ALL
      SELECT
        'Development Need' as response_type,
        COUNT(DISTINCT survey_target_id) AS fcr_count,
        COUNT(DISTINCT rep_wwid) AS rep_count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response = 'Development Need'
      UNION ALL
      SELECT
        'Awareness' as response_type,
        COUNT(DISTINCT survey_target_id) AS fcr_count,
        COUNT(DISTINCT rep_wwid) AS rep_count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response = 'Awareness'
    `;

    console.log('\n=== QUERY 3: Specific Training Need Responses ===');
    const result3 = await pool.query(q3, []);
    console.log(JSON.stringify(result3.rows, null, 2));

    await pool.end();
    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

test();
