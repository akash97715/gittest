import 'dotenv/config';
import pool from './db.js';

const MSL_FILTER = `(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`;

const baseConds = [
  `chnl = 'SURVEY'`,
  `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
  `survey_target_id IS NOT NULL`,
  MSL_FILTER,
];

async function test() {
  try {
    // Test different timeframes
    const timeframes = [
      { label: 'All time', days: null },
      { label: 'Past 30 days', days: 30 },
      { label: 'Past 90 days', days: 90 },
      { label: 'Past 6 months', days: 180 },
      { label: 'Past year', days: 365 },
    ];

    for (const { label, days } of timeframes) {
      const conditions = [...baseConds];
      
      if (days) {
        const d = new Date();
        d.setDate(d.getDate() - days);
        const dateStr = d.toISOString().slice(0, 10);
        conditions.push(`acty_dt >= '${dateStr}'::date`);
      }

      const where = conditions.join(' AND ');

      const sql = `
        SELECT
          COUNT(DISTINCT survey_target_id) AS total_fcrs,
          COUNT(DISTINCT rep_wwid) AS total_reps,
          COUNT(DISTINCT CASE WHEN survey_question_response = 'Awareness' THEN survey_target_id END) AS awareness_fcrs,
          COUNT(DISTINCT CASE WHEN survey_question_response = 'Awareness' THEN rep_wwid END) AS awareness_reps
        FROM odp.dp_cust_pers_engagement_dly
        WHERE ${where}
      `;

      const result = await pool.query(sql, []);
      const row = result.rows[0];
      
      console.log(`\n${label}:`);
      console.log(`  Total FCRs: ${row.total_fcrs}`);
      console.log(`  Total Reps: ${row.total_reps}`);
      console.log(`  Awareness FCRs (flagging): ${row.awareness_fcrs}`);
      console.log(`  Awareness Reps (needing): ${row.awareness_reps}`);
    }

    await pool.end();
    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

test();
