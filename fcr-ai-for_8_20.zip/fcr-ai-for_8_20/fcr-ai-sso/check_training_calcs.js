import 'dotenv/config';
import pool from './db.js';

const MSL_FILTER = `(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`;

const baseConds = [
  `chnl = 'SURVEY'`,
  `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
  `survey_target_id IS NOT NULL`,
  MSL_FILTER,
];

async function test() {
  try {
    // Apply 6-month filter
    const d = new Date();
    d.setDate(d.getDate() - 180);
    const dateStr = d.toISOString().slice(0, 10);
    
    const conditions = [...baseConds, `acty_dt >= '${dateStr}'::date`];
    const where = conditions.join(' AND ');

    console.log('\n=== Testing different training flag combinations (6-month timeframe) ===');

    // Test 1: Just "Awareness"
    let sql = `
      SELECT
        'Awareness only' as test_name,
        COUNT(DISTINCT CASE WHEN survey_question_response = 'Awareness' THEN survey_target_id END) AS flagged_fcrs,
        COUNT(DISTINCT CASE WHEN survey_question_response = 'Awareness' THEN rep_wwid END) AS flagged_reps
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
    `;
    let result = await pool.query(sql, []);
    console.log('\nTest 1: Awareness only');
    console.log(JSON.stringify(result.rows[0], null, 2));

    // Test 2: "Awareness" + "Area of development"
    sql = `
      SELECT
        'Awareness + Area of development' as test_name,
        COUNT(DISTINCT CASE WHEN survey_question_response IN ('Awareness', 'Area of development') THEN survey_target_id END) AS flagged_fcrs,
        COUNT(DISTINCT CASE WHEN survey_question_response IN ('Awareness', 'Area of development') THEN rep_wwid END) AS flagged_reps
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
    `;
    result = await pool.query(sql, []);
    console.log('\nTest 2: Awareness + Area of development');
    console.log(JSON.stringify(result.rows[0], null, 2));

    // Test 3: Check what responses are marked as "Area of development"
    sql = `
      SELECT survey_question_response, COUNT(*) as count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response LIKE '%development%'
      GROUP BY survey_question_response
    `;
    result = await pool.query(sql, []);
    console.log('\nTest 3: Responses containing "development"');
    console.log(JSON.stringify(result.rows, null, 2));

    // Test 4: Count records per FCR to understand duplicates
    sql = `
      SELECT
        survey_target_id,
        COUNT(DISTINCT survey_question_response) as unique_responses,
        COUNT(*) as total_rows
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      AND survey_question_response = 'Awareness'
      LIMIT 5
    `;
    result = await pool.query(sql, []);
    console.log('\nTest 4: Sample FCRs with Awareness responses');
    console.log(JSON.stringify(result.rows, null, 2));

    await pool.end();
    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}

test();
