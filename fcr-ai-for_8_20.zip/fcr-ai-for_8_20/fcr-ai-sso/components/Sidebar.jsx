import { LayoutDashboard, BarChart2, Bot, BookOpen, Settings, LogOut } from 'lucide-react';
import { telemetryService } from '../services/telemetryService';

const NAV = [
  { id: 'activity',    icon: LayoutDashboard, label: 'Activity' },
  { id: 'capability', icon: BarChart2,        label: 'Capability & Quality' },
  { id: 'askai',      icon: Bot,              label: 'Ask AI' },
  { id: 'reference',  icon: BookOpen,         label: 'Reference' },
];

export default function Sidebar({ active, onNavigate }) {
  const handleNavigation = (itemId) => {
    // Track button click in telemetry
    telemetryService.trackButtonClick(`nav_${itemId}`, 'sidebar');
    onNavigate(itemId);
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="jnj">Johnson&amp;Johnson</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
          <div className="brand">FCR Insights</div>
          <span className="ai-badge">⚡ AI Powered</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {NAV.map(item => (
          <div
            key={item.id}
            id={`nav-${item.id}`}
            className={`nav-item ${active === item.id ? 'active' : ''}`}
            onClick={() => handleNavigation(item.id)}
          >
            <item.icon size={14} />
            {item.label}
          </div>
        ))}
      </nav>

      <div className="sidebar-user">
        <div className="user-info">
          <div className="avatar">TM</div>
          <div>
            <div className="name">Timothy Mauri</div>
            <div className="role">Regional Director</div>
          </div>
        </div>
        <div className="sidebar-user-links">
          <div className="sidebar-user-link" onClick={() => telemetryService.trackButtonClick('settings', 'sidebar')}><Settings size={11} /> Settings</div>
          <div className="sidebar-user-link" onClick={() => telemetryService.trackButtonClick('logout', 'sidebar')}><LogOut size={11} /> Log out</div>
        </div>
      </div>
    </aside>
  );
}
