#!/usr/bin/env node

import { Document, Packer, Paragraph, TextRun, convertInchesToTwip, AlignmentType } from 'docx';
import fs from 'fs';

const files = [
  {
    input: './MANAGER_TELEMETRY_01_EXECUTIVE_OVERVIEW.md',
    output: './MANAGER_TELEMETRY_01_EXECUTIVE_OVERVIEW.docx'
  },
  {
    input: './MANAGER_TELEMETRY_02_INFRA_AND_BACKEND.md',
    output: './MANAGER_TELEMETRY_02_INFRA_AND_BACKEND.docx'
  },
  {
    input: './MANAGER_TELEMETRY_03_USER_TRACKING.md',
    output: './MANAGER_TELEMETRY_03_USER_TRACKING.docx'
  },
  {
    input: './MANAGER_TELEMETRY_04_FEATURES_AND_DASHBOARD.md',
    output: './MANAGER_TELEMETRY_04_FEATURES_AND_DASHBOARD.docx'
  }
];

function convertMarkdownToDocx(mdContent) {
  const lines = mdContent.split('\n');
  const docElements = [];
  let inCodeBlock = false;
  let codeLines = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Code blocks
    if (line.startsWith('```')) {
      if (inCodeBlock) {
        docElements.push(
          new Paragraph({
            text: codeLines.join('\n'),
            spacing: { before: 100, after: 100 }
          })
        );
        codeLines = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      continue;
    }

    if (inCodeBlock) {
      codeLines.push(line);
      continue;
    }

    // Headings
    if (line.startsWith('# ')) {
      docElements.push(
        new Paragraph({
          text: line.substring(2),
          bold: true,
          size: 32,
          spacing: { before: 200, after: 100 }
        })
      );
      continue;
    }

    if (line.startsWith('## ')) {
      docElements.push(
        new Paragraph({
          text: line.substring(3),
          bold: true,
          size: 28,
          spacing: { before: 150, after: 80 }
        })
      );
      continue;
    }

    if (line.startsWith('### ')) {
      docElements.push(
        new Paragraph({
          text: line.substring(4),
          bold: true,
          size: 24,
          spacing: { before: 120, after: 60 }
        })
      );
      continue;
    }

    // Bold markdown
    if (line.includes('**')) {
      const parts = line.split(/\*\*(.*?)\*\*/g);
      const runs = [];
      for (let j = 0; j < parts.length; j++) {
        if (j % 2 === 0) {
          if (parts[j]) runs.push(new TextRun(parts[j]));
        } else {
          runs.push(new TextRun({ text: parts[j], bold: true }));
        }
      }
      if (runs.length > 0) {
        docElements.push(
          new Paragraph({
            children: runs,
            spacing: { after: 80 }
          })
        );
      }
      continue;
    }

    // Regular text
    if (line.trim()) {
      docElements.push(
        new Paragraph({
          text: line,
          spacing: { after: 80 }
        })
      );
    } else {
      docElements.push(new Paragraph(''));
    }
  }

  return docElements;
}

async function convertFile(inputFile, outputFile) {
  try {
    console.log(`Converting ${inputFile}...`);
    const mdContent = fs.readFileSync(inputFile, 'utf-8');
    const docElements = convertMarkdownToDocx(mdContent);

    const doc = new Document({
      sections: [
        {
          children: docElements,
          properties: {
            page: {
              margins: {
                top: convertInchesToTwip(1),
                right: convertInchesToTwip(1),
                bottom: convertInchesToTwip(1),
                left: convertInchesToTwip(1)
              }
            }
          }
        }
      ]
    });

    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync(outputFile, buffer);
    console.log(`✅ Created ${outputFile}`);
  } catch (error) {
    console.error(`❌ Error converting ${inputFile}:`, error.message);
  }
}

async function convertAll() {
  console.log('Starting Manager Telemetry Documents Conversion...\n');
  for (const file of files) {
    await convertFile(file.input, file.output);
  }
  console.log('\n✅ All conversions complete!');
  console.log('\n📄 Generated Files:');
  files.forEach(f => console.log(`   - ${f.output}`));
}

convertAll();
