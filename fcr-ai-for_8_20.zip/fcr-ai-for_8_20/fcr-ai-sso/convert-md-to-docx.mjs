import fs from 'fs';
import path from 'path';
import { Document, Packer, Paragraph, HeadingLevel, Table, TableRow, TableCell, WidthType, BorderStyle, convertInchesToTwip } from 'docx';

const mdFile = './REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.md';
const docxFile = './REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.docx';

try {
  const markdown = fs.readFileSync(mdFile, 'utf-8');
  
  // Split into lines and parse
  const lines = markdown.split('\n');
  const sections = [];
  let currentSection = [];
  
  lines.forEach(line => {
    if (line.startsWith('# ')) {
      if (currentSection.length > 0) sections.push(currentSection);
      currentSection = [line];
    } else {
      currentSection.push(line);
    }
  });
  if (currentSection.length > 0) sections.push(currentSection);
  
  // Convert markdown to docx structure
  const docElements = [];
  
  sections.forEach(section => {
    section.forEach(line => {
      if (line.startsWith('# ')) {
        docElements.push(new Paragraph({
          text: line.replace(/^# /, ''),
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 240, after: 120 }
        }));
      } else if (line.startsWith('## ')) {
        docElements.push(new Paragraph({
          text: line.replace(/^## /, ''),
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }));
      } else if (line.startsWith('### ')) {
        docElements.push(new Paragraph({
          text: line.replace(/^### /, ''),
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 160, after: 80 }
        }));
      } else if (line.startsWith('```')) {
        // Code block - add as monospace paragraph
        docElements.push(new Paragraph({
          text: '--- CODE BLOCK ---',
          style: 'code'
        }));
      } else if (line.trim().length > 0) {
        docElements.push(new Paragraph({
          text: line,
          spacing: { line: 360 }
        }));
      }
    });
  });
  
  const doc = new Document({ sections: [{ children: docElements }] });
  
  Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync(docxFile, buffer);
    console.log(`✓ DOCX file created: ${docxFile}`);
  }).catch(err => {
    console.error('Error creating DOCX:', err.message);
    process.exit(1);
  });
  
} catch (error) {
  console.error('Error:', error.message);
  process.exit(1);
}
