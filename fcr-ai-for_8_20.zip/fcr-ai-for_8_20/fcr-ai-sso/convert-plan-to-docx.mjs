#!/usr/bin/env node

/**
 * Convert Telemetry Implementation Plan Markdown to DOCX
 * Using docx library to create a professionally formatted Word document
 */

import { Document, Packer, Paragraph, TextRun, HeadingLevel, PageBreak, Table, TableCell, TableRow, BorderStyle, convertInchesToTwip, AlignmentType, UnorderedList, OrderedList } from 'docx';
import fs from 'fs';
import path from 'path';

const mdContent = fs.readFileSync('./TELEMETRY_PHASED_IMPLEMENTATION_PLAN.md', 'utf-8');

// Parse markdown into sections
const sections = mdContent.split('\n## ').map((section, idx) => {
  if (idx === 0) {
    return { title: 'Title', content: section };
  }
  const lines = section.split('\n');
  const title = lines[0];
  const content = lines.slice(1).join('\n');
  return { title, content };
});

// Helper to convert markdown text to TextRun
function parseMarkdownText(text) {
  const parts = [];
  let remaining = text;
  
  // Handle inline formatting
  while (remaining.length > 0) {
    // Bold: **text**
    const boldMatch = remaining.match(/\*\*(.*?)\*\*/);
    if (boldMatch) {
      const beforeBold = remaining.substring(0, boldMatch.index);
      if (beforeBold) parts.push(new TextRun(beforeBold));
      parts.push(new TextRun({ text: boldMatch[1], bold: true }));
      remaining = remaining.substring(boldMatch.index + boldMatch[0].length);
    }
    // Code: `text`
    else if ((remaining.match(/`(.*?)`/))) {
      const codeMatch = remaining.match(/`(.*?)`/);
      const beforeCode = remaining.substring(0, codeMatch.index);
      if (beforeCode) parts.push(new TextRun(beforeCode));
      parts.push(new TextRun({ 
        text: codeMatch[1], 
        bold: true,
        color: '0070C0'
      }));
      remaining = remaining.substring(codeMatch.index + codeMatch[0].length);
    }
    else {
      parts.push(new TextRun(remaining));
      break;
    }
  }
  
  return parts.length > 0 ? parts : [new TextRun(text)];
}

// Build document
const docElements = [];

// Title page
docElements.push(
  new Paragraph({
    text: 'FCR AI - Telemetry Layer',
    style: 'Heading1',
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
  }),
  new Paragraph({
    text: 'Phase-wise Implementation Plan',
    style: 'Heading2',
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),
  new Paragraph({
    text: 'Document Version: 1.0 | August 17, 2026',
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
  }),
  new PageBreak()
);

// Table of contents
docElements.push(
  new Paragraph({
    text: 'Table of Contents',
    style: 'Heading1',
  }),
  new Paragraph(''),
  new OrderedList({
    levels: [
      {
        level: 0,
        format: 'decimal',
        text: 'Executive Summary',
        alignment: AlignmentType.LEFT,
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Current State Assessment',
        alignment: AlignmentType.LEFT,
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Phase 1-10 Detailed Plans',
        alignment: AlignmentType.LEFT,
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Implementation Timeline',
        alignment: AlignmentType.LEFT,
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Architecture & Risks',
        alignment: AlignmentType.LEFT,
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Next Steps',
        alignment: AlignmentType.LEFT,
      },
    ],
  }),
  new PageBreak()
);

// Executive summary section
docElements.push(
  new Paragraph({ text: 'Executive Summary', style: 'Heading1' }),
  new Paragraph('A comprehensive user tracking system for FCR AI application that monitors user interactions, engagement, and system performance.'),
  new Paragraph(''),
  new Paragraph({ text: 'Key Objectives', style: 'Heading2' }),
  new UnorderedList({
    levels: [
      {
        level: 0,
        format: 'bullet',
        text: 'User Understanding: Track how users interact with the app',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Feature Adoption: Identify used vs. neglected features',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Performance Insights: Detect bottlenecks and friction points',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Data-Driven Decisions: Make product decisions with real data',
      },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Timeline & Resources' }),
  new Paragraph('Estimated Duration: 4-6 weeks'),
  new Paragraph('Estimated Effort: 485 minutes (~8 hours)'),
  new Paragraph('Resource Required: 1 full-stack engineer'),
  new PageBreak()
);

// Current state section
docElements.push(
  new Heading({ level: 1, text: 'Current State Assessment' }),
  new Heading({ level: 2, text: 'What\'s Already in Place ✅' }),
  new Paragraph('The codebase already has substantial telemetry infrastructure:'),
  new UnorderedList({
    levels: [
      {
        level: 0,
        format: 'bullet',
        text: 'TelemetryService (Frontend) - 240 lines, ready to use',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Database Schema - Fully documented and designed',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'API Endpoints - 6 endpoints designed and ready to implement',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Documentation - 1,500+ lines of guides and reference',
      },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'What Needs to Be Done ❌' }),
  new UnorderedList({
    levels: [
      {
        level: 0,
        format: 'bullet',
        text: 'Deploy Redshift schema (5 minutes)',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Integrate API endpoints into server.js (30 minutes)',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Initialize telemetry in App.jsx (15 minutes)',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Add page and button tracking (105 minutes)',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Build analytics dashboard (120 minutes)',
      },
      {
        level: 0,
        format: 'bullet',
        text: 'Testing and QA (90 minutes)',
      },
    ],
  }),
  new PageBreak()
);

// Phase summaries
const phaseSummaries = [
  { num: 1, title: 'Foundation & Database', duration: '3 days', effort: '20 min', risk: 'Low' },
  { num: 2, title: 'Backend Integration', duration: '1 day', effort: '45 min', risk: 'Low' },
  { num: 3, title: 'Frontend Initialization', duration: '1 day', effort: '25 min', risk: 'Low' },
  { num: 4, title: 'Page Instrumentation', duration: '1 day', effort: '45 min', risk: 'Medium' },
  { num: 5, title: 'Feature Tracking', duration: '1 day', effort: '75 min', risk: 'Medium' },
  { num: 6, title: 'Error & Performance', duration: '1 day', effort: '50 min', risk: 'Low' },
  { num: 7, title: 'Analytics Dashboard', duration: '2 days', effort: '120 min', risk: 'High' },
  { num: 8, title: 'Testing & QA', duration: '1 day', effort: '90 min', risk: 'Medium' },
  { num: 9, title: 'Monitoring & Optimization', duration: '1 week', effort: 'Ongoing', risk: 'Low' },
  { num: 10, title: 'Deployment & Rollout', duration: '1-2 weeks', effort: '15 min', risk: 'Low' },
];

docElements.push(
  new Heading({ level: 1, text: '10-Phase Implementation Roadmap' }),
  new Paragraph('The implementation is divided into 10 strategic phases:'),
  new Paragraph('')
);

phaseSummaries.forEach((phase) => {
  docElements.push(
    new Heading({ 
      level: 2, 
      text: `Phase ${phase.num}: ${phase.title}` 
    }),
    new Paragraph(`Duration: ${phase.duration} | Effort: ${phase.effort} | Risk: ${phase.risk}`),
    new Paragraph('')
  );
});

docElements.push(new PageBreak());

// Implementation timeline
docElements.push(
  new Heading({ level: 1, text: 'Implementation Timeline' }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Week 1: Foundation (3 days)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Day 1: Database Schema Setup' },
      { level: 0, format: 'bullet', text: 'Day 2-3: Backend API Integration' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Week 2: Data Collection (5 days)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Day 1: Frontend Initialization' },
      { level: 0, format: 'bullet', text: 'Day 2-3: Page View Tracking' },
      { level: 0, format: 'bullet', text: 'Day 4-5: Button Click & Feature Tracking' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Week 3: Advanced Tracking (5 days)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Day 1-2: Error & Performance Tracking' },
      { level: 0, format: 'bullet', text: 'Day 3-5: Analytics Dashboard Development' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Week 4: Testing & Optimization (5 days)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Day 1-2: QA Testing' },
      { level: 0, format: 'bullet', text: 'Day 3-5: Monitoring Setup & Performance Tuning' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Week 5-6: Deployment (2 weeks)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Stage 1: Internal Testing (3-5 days)' },
      { level: 0, format: 'bullet', text: 'Stage 2: Limited Production (2-3 days, 10% users)' },
      { level: 0, format: 'bullet', text: 'Stage 3: Full Production (100% users)' },
    ],
  }),
  new PageBreak()
);

// Success criteria
docElements.push(
  new Heading({ level: 1, text: 'Success Criteria' }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Phase 1-3: Foundation Ready' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Database schema created and tested' },
      { level: 0, format: 'bullet', text: 'API endpoints operational' },
      { level: 0, format: 'bullet', text: 'Telemetry service initialized on login' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Phase 4-6: Data Collection Active' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Page views tracked for all pages' },
      { level: 0, format: 'bullet', text: 'Feature usage captured' },
      { level: 0, format: 'bullet', text: 'Error and performance metrics available' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Phase 7-8: System Complete' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Analytics dashboard operational' },
      { level: 0, format: 'bullet', text: '95%+ test pass rate' },
      { level: 0, format: 'bullet', text: 'Dashboard queries < 1 second' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Phase 9-10: Production Ready' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Monitoring dashboards operational' },
      { level: 0, format: 'bullet', text: 'Alerts configured and tested' },
      { level: 0, format: 'bullet', text: 'Zero data loss in production' },
    ],
  }),
  new PageBreak()
);

// Key technical components
docElements.push(
  new Heading({ level: 1, text: 'Key Technical Components' }),
  new Heading({ level: 2, text: 'Frontend (React)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'TelemetryService: Event tracking and batching' },
      { level: 0, format: 'bullet', text: 'ErrorBoundary: Error capture and logging' },
      { level: 0, format: 'bullet', text: 'TelemetryDashboard: Analytics visualization' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Backend (Express + Redshift)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'POST /api/telemetry: Event ingestion (1000s events/min)' },
      { level: 0, format: 'bullet', text: 'GET endpoints: Analytics queries' },
      { level: 0, format: 'bullet', text: 'Event validation: Schema checking' },
      { level: 0, format: 'bullet', text: 'Error handling: Resilience & retry logic' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Database (Redshift)' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'telemetry.user_events: Raw event storage' },
      { level: 0, format: 'bullet', text: 'telemetry.user_sessions: Session aggregation' },
      { level: 0, format: 'bullet', text: 'telemetry.daily_usage_summary: Daily KPIs' },
      { level: 0, format: 'bullet', text: 'Materialized views: Fast dashboard queries' },
    ],
  }),
  new PageBreak()
);

// Events tracked
docElements.push(
  new Heading({ level: 1, text: 'Events Tracked' }),
  new Paragraph('11 event types capture complete user behavior:'),
  new Paragraph(''),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'user_login: Authentication events' },
      { level: 0, format: 'bullet', text: 'page_view: Page navigation' },
      { level: 0, format: 'bullet', text: 'page_exit: Time spent on page' },
      { level: 0, format: 'bullet', text: 'button_click: Feature usage' },
      { level: 0, format: 'bullet', text: 'search: Queries and filters' },
      { level: 0, format: 'bullet', text: 'data_export: Data downloads' },
      { level: 0, format: 'bullet', text: 'api_call: API performance metrics' },
      { level: 0, format: 'bullet', text: 'error: Exceptions and errors' },
      { level: 0, format: 'bullet', text: 'session_start/end: Session tracking' },
      { level: 0, format: 'bullet', text: 'custom: App-specific events' },
    ],
  }),
  new PageBreak()
);

// Risk mitigation
docElements.push(
  new Heading({ level: 1, text: 'Risk Mitigation' }),
  new Paragraph('Key risks identified and mitigation strategies:'),
  new Paragraph(''),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'High event volume: Implement rate limiting and queue management' },
      { level: 0, format: 'bullet', text: 'Frontend performance impact: Use localStorage queue, test batch sizes' },
      { level: 0, format: 'bullet', text: 'Data privacy: Anonymize sensitive data, document retention policy' },
      { level: 0, format: 'bullet', text: 'Database costs: Set 90-day retention with auto-purge' },
      { level: 0, format: 'bullet', text: 'Event loss: localStorage fallback with exponential backoff retry' },
    ],
  }),
  new PageBreak()
);

// Next steps
docElements.push(
  new Heading({ level: 1, text: 'Next Steps' }),
  new OrderedList({
    levels: [
      {
        level: 0,
        format: 'decimal',
        text: 'Review this plan with stakeholders (15 min)',
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Schedule Phase 1 kick-off (Database setup)',
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Allocate resources (1 engineer, 4-6 weeks)',
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Verify Redshift environment access',
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Brief development team on changes',
      },
      {
        level: 0,
        format: 'decimal',
        text: 'Begin Phase 1 when ready',
      },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Expected ROI Timeline' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Week 1-2: Understanding user behavior' },
      { level: 0, format: 'bullet', text: 'Week 3-4: Identifying feature adoption patterns' },
      { level: 0, format: 'bullet', text: 'Week 5+: Making data-driven product decisions' },
    ],
  }),
  new PageBreak()
);

// Appendix
docElements.push(
  new Heading({ level: 1, text: 'Appendix: Technical Details' }),
  new Heading({ level: 2, text: 'Technology Stack' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Frontend: React 19 with Vite' },
      { level: 0, format: 'bullet', text: 'Auth: Azure MSAL (Microsoft SSO)' },
      { level: 0, format: 'bullet', text: 'Backend: Express.js 5.2' },
      { level: 0, format: 'bullet', text: 'Database: Amazon Redshift' },
      { level: 0, format: 'bullet', text: 'Driver: pg (Node.js PostgreSQL client)' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Event Batching Strategy' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Batch Trigger: 10 events OR 30 seconds' },
      { level: 0, format: 'bullet', text: 'Offline Storage: localStorage queue' },
      { level: 0, format: 'bullet', text: 'Retry Logic: Exponential backoff' },
      { level: 0, format: 'bullet', text: 'Expected Volume: 100-500 events/minute (100 users)' },
    ],
  }),
  new Paragraph(''),
  new Heading({ level: 2, text: 'Database Performance Targets' }),
  new UnorderedList({
    levels: [
      { level: 0, format: 'bullet', text: 'Event Insert: < 50ms p95' },
      { level: 0, format: 'bullet', text: 'Query Latency: < 200ms p95' },
      { level: 0, format: 'bullet', text: 'Dashboard Queries: < 1 second' },
      { level: 0, format: 'bullet', text: 'Event Retention: 90 days rolling window' },
    ],
  }),
  new Paragraph(''),
  new Paragraph(''),
  new Paragraph('Document Version: 1.0 | Status: Ready for Implementation'),
  new Paragraph('For questions or updates, refer to the detailed markdown plan.')
);

// Create document
const doc = new Document({
  sections: [
    {
      children: docElements,
      properties: {
        page: {
          margins: {
            top: convertInchesToTwip(1),
            right: convertInchesToTwip(1),
            bottom: convertInchesToTwip(1),
            left: convertInchesToTwip(1),
          },
        },
      },
    },
  ],
});

// Write to file
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('./TELEMETRY_PHASED_IMPLEMENTATION_PLAN.docx', buffer);
  console.log('✅ DOCX file created: TELEMETRY_PHASED_IMPLEMENTATION_PLAN.docx');
  console.log('');
  console.log('Document Summary:');
  console.log('- Title: FCR AI - Telemetry Layer Phase-wise Implementation Plan');
  console.log('- Sections: 10 phases + appendices');
  console.log('- Total timeline: 4-6 weeks');
  console.log('- Total effort: ~485 minutes (8 hours)');
  console.log('- Status: Ready for implementation');
  console.log('');
  console.log('Next: Review with stakeholders and schedule Phase 1 kick-off');
});
