#!/usr/bin/env python3
"""
Convert Markdown to DOCX format
Preserves formatting, headings, tables, and code blocks
"""

import re
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

def read_markdown(filepath):
    """Read markdown file"""
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

def parse_markdown_to_docx(markdown_text):
    """Parse markdown and convert to DOCX document"""
    doc = Document()
    
    # Add title
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title.add_run('Redshift Query Optimization')
    title_run.font.size = Pt(28)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(25, 25, 46)
    
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle_run = subtitle.add_run('Comprehensive Analysis & Standard Operating Procedure')
    subtitle_run.font.size = Pt(14)
    subtitle_run.font.color.rgb = RGBColor(100, 100, 100)
    
    doc.add_paragraph()  # Spacing
    
    # Add Table of Contents placeholder
    toc = doc.add_paragraph()
    toc_run = toc.add_run('TABLE OF CONTENTS')
    toc_run.font.bold = True
    toc_run.font.size = Pt(12)
    
    doc.add_paragraph()  # Spacing
    
    lines = markdown_text.split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i]
        
        # Headings
        if line.startswith('# ') and not line.startswith('##'):
            heading_text = line.replace('# ', '', 1)
            p = doc.add_heading(heading_text, level=1)
            p.style = 'Heading 1'
            
        elif line.startswith('## '):
            heading_text = line.replace('## ', '', 1)
            p = doc.add_heading(heading_text, level=2)
            p.style = 'Heading 2'
            
        elif line.startswith('### '):
            heading_text = line.replace('### ', '', 1)
            p = doc.add_heading(heading_text, level=3)
            p.style = 'Heading 3'
            
        # Code blocks
        elif line.startswith('```'):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].startswith('```'):
                code_lines.append(lines[i])
                i += 1
            
            code_text = '\n'.join(code_lines).strip()
            if code_text:
                p = doc.add_paragraph(code_text, style='No Spacing')
                for run in p.runs:
                    run.font.name = 'Courier New'
                    run.font.size = Pt(9)
                p.paragraph_format.left_indent = Inches(0.5)
                
        # Tables
        elif '|' in line and i + 1 < len(lines) and '|' in lines[i + 1]:
            table_lines = [line]
            i += 1
            
            # Skip separator row
            if '---' in lines[i]:
                i += 1
                
            # Collect table rows
            while i < len(lines) and '|' in lines[i]:
                table_lines.append(lines[i])
                i += 1
            i -= 1  # Adjust for outer loop increment
            
            # Parse and create table
            headers = [h.strip() for h in table_lines[0].split('|')[1:-1]]
            rows_data = []
            for tl in table_lines[2:]:
                row = [c.strip() for c in tl.split('|')[1:-1]]
                if row:
                    rows_data.append(row)
            
            if headers and rows_data:
                table = doc.add_table(rows=1 + len(rows_data), cols=len(headers))
                table.style = 'Light Grid Accent 1'
                
                # Add headers
                header_cells = table.rows[0].cells
                for i, header in enumerate(headers):
                    header_cells[i].text = header
                    for paragraph in header_cells[i].paragraphs:
                        for run in paragraph.runs:
                            run.font.bold = True
                
                # Add rows
                for row_idx, row_data in enumerate(rows_data, 1):
                    row_cells = table.rows[row_idx].cells
                    for col_idx, cell_data in enumerate(row_data):
                        row_cells[col_idx].text = cell_data
                
        # Bold text
        elif line.strip():
            p = doc.add_paragraph()
            # Process inline formatting
            parts = re.split(r'(\*\*.*?\*\*|\*.*?\*|`.*?`)', line)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                elif part.startswith('*') and part.endswith('*'):
                    run = p.add_run(part[1:-1])
                    run.italic = True
                elif part.startswith('`') and part.endswith('`'):
                    run = p.add_run(part[1:-1])
                    run.font.name = 'Courier New'
                    run.font.size = Pt(10)
                else:
                    p.add_run(part)
        
        i += 1
    
    return doc

def main():
    md_file = 'REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.md'
    docx_file = 'REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.docx'
    
    print(f"📖 Reading markdown file: {md_file}")
    markdown = read_markdown(md_file)
    
    print(f"✍️  Converting to DOCX format...")
    doc = parse_markdown_to_docx(markdown)
    
    print(f"💾 Saving DOCX file: {docx_file}")
    doc.save(docx_file)
    
    print(f"✅ Successfully created: {docx_file}")
    print(f"📏 File size: {round(open(docx_file, 'rb').read().__sizeof__() / 1024, 2)} KB")

if __name__ == '__main__':
    main()
