#!/usr/bin/env python3
"""
Fast Markdown to DOCX converter
Simply copies markdown content with basic formatting
"""

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

md_file = 'REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.md'
docx_file = 'REDSHIFT_OPTIMIZATION_COMPREHENSIVE_SOP.docx'

print(f"📖 Reading {md_file}...")
with open(md_file, 'r', encoding='utf-8') as f:
    content = f.read()

print(f"✍️  Creating DOCX...")
doc = Document()

# Add title page
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title_run = title.add_run('Redshift Query Optimization')
title_run.font.size = Pt(28)
title_run.font.bold = True
title_run.font.color.rgb = RGBColor(25, 25, 46)

subtitle = doc.add_paragraph()
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
sub_run = subtitle.add_run('Comprehensive Analysis & SOP')
sub_run.font.size = Pt(14)
sub_run.font.color.rgb = RGBColor(100, 100, 100)

doc.add_paragraph()  # Blank line

# Add the full content as plain text with basic formatting
lines = content.split('\n')
for line in lines:
    if line.startswith('# '):
        heading = line.replace('# ', '')
        p = doc.add_heading(heading, level=1)
    elif line.startswith('## '):
        heading = line.replace('## ', '')
        p = doc.add_heading(heading, level=2)
    elif line.startswith('### '):
        heading = line.replace('### ', '')
        p = doc.add_heading(heading, level=3)
    elif line.strip():
        p = doc.add_paragraph(line)
        if '**' in line or '*' in line or '`' in line:
            # Keep monospace for code blocks
            if '```' in line:
                for run in p.runs:
                    run.font.name = 'Courier New'
    else:
        doc.add_paragraph()  # Blank line

print(f"💾 Saving {docx_file}...")
doc.save(docx_file)

# Check file size
import os
file_size = os.path.getsize(docx_file)
print(f"✅ Success! Created {docx_file} ({round(file_size / 1024, 2)} KB)")
