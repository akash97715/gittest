#!/usr/bin/env node

/**
 * Simple Telemetry Plan to DOCX Converter
 */

import { Document, Packer, Paragraph, TextRun, convertInchesToTwip, AlignmentType } from 'docx';
import fs from 'fs';

const mdContent = fs.readFileSync('./TELEMETRY_PHASED_IMPLEMENTATION_PLAN.md', 'utf-8');
const lines = mdContent.split('\n');

const docElements = [];
let currentHeadingLevel = 0;

// Add title page
docElements.push(
  new Paragraph({
    text: 'FCR AI - Telemetry Layer Implementation Plan',
    bold: true,
    size: 32,
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
  }),
  new Paragraph({
    text: 'Phase-wise Execution Guide',
    size: 28,
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  }),
  new Paragraph({
    text: 'Document Version: 1.0 | August 17, 2026',
    alignment: AlignmentType.CENTER,
    spacing: { after: 400 },
  }),
  new Paragraph({
    text: 'Status: Strategic Planning & Ready for Implementation',
    bold: true,
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
  })
);

// Add page break
docElements.push(new Paragraph({ text: '', spacing: { after: 600 } }));

// Add content
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  // Skip empty lines
  if (!line.trim()) {
    docElements.push(new Paragraph(''));
    continue;
  }
  
  // Headings
  if (line.startsWith('# ')) {
    docElements.push(
      new Paragraph({
        text: line.substring(2),
        bold: true,
        size: 32,
        spacing: { before: 200, after: 100 },
      })
    );
  } else if (line.startsWith('## ')) {
    docElements.push(
      new Paragraph({
        text: line.substring(3),
        bold: true,
        size: 28,
        spacing: { before: 200, after: 100 },
      })
    );
  } else if (line.startsWith('### ')) {
    docElements.push(
      new Paragraph({
        text: line.substring(4),
        bold: true,
        size: 24,
        spacing: { before: 150, after: 80 },
      })
    );
  }
  // Code blocks
  else if (line.startsWith('```')) {
    // Skip code block markers, content will be handled
    continue;
  }
  // Bold text
  else if (line.includes('**')) {
    const parts = line.split(/\*\*(.*?)\*\*/g);
    const runs = [];
    for (let j = 0; j < parts.length; j++) {
      if (j % 2 === 0) {
        runs.push(new TextRun(parts[j]));
      } else {
        runs.push(new TextRun({ text: parts[j], bold: true }));
      }
    }
    docElements.push(
      new Paragraph({
        children: runs.length > 0 ? runs : [new TextRun(line)],
        spacing: { after: 80 },
      })
    );
  }
  // Regular text
  else if (line.trim()) {
    docElements.push(
      new Paragraph({
        text: line,
        spacing: { after: 80 },
      })
    );
  }
}

// Create document
const doc = new Document({
  sections: [
    {
      children: docElements,
      properties: {
        page: {
          margins: {
            top: convertInchesToTwip(1),
            right: convertInchesToTwip(1),
            bottom: convertInchesToTwip(1),
            left: convertInchesToTwip(1),
          },
        },
      },
    },
  ],
});

// Write to file
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('./TELEMETRY_PHASED_IMPLEMENTATION_PLAN.docx', buffer);
  console.log('✅ SUCCESS: DOCX file created');
  console.log('');
  console.log('📄 File Details:');
  console.log('   Name: TELEMETRY_PHASED_IMPLEMENTATION_PLAN.docx');
  console.log('   Location: c:\\Users\\GReddy51\\Downloads\\fcr-ai-for\\fcr-ai-sso\\');
  console.log('');
  console.log('📋 Document Contents:');
  console.log('   ✓ Executive Summary');
  console.log('   ✓ Current State Assessment');
  console.log('   ✓ 10-Phase Implementation Plan');
  console.log('   ✓ Detailed Phase Deliverables');
  console.log('   ✓ Testing & QA Procedures');
  console.log('   ✓ Monitoring & Optimization Strategy');
  console.log('   ✓ Deployment & Rollout Plan');
  console.log('   ✓ Technical Architecture');
  console.log('   ✓ Risk Mitigation');
  console.log('   ✓ Success Criteria');
  console.log('');
  console.log('⏱️ Timeline: 4-6 weeks total');
  console.log('👤 Resource: 1 full-stack engineer');
  console.log('💾 Total Effort: ~485 minutes (8 hours)');
  console.log('');
  console.log('🚀 Next Steps:');
  console.log('   1. Review document with stakeholders');
  console.log('   2. Schedule Phase 1 kick-off (Database setup)');
  console.log('   3. Allocate engineer resources');
  console.log('   4. Verify Redshift environment access');
  console.log('   5. Begin Phase 1 implementation');
}).catch(err => {
  console.error('❌ Error creating DOCX:', err);
  process.exit(1);
});
