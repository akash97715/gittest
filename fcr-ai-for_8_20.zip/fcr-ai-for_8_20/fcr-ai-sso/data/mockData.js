// Mock data matching the reference screenshots
export const kpiData = {
  fcrsInView: 38,
  fcrsInViewSub: 'since Mar 21',
  coachesWithFCR: '86%',
  coachesWithFCRSub: '12 of 14',
  prelaunchComplete: '79%',
  prelaunchSub: '9 of 11 Coaches',
  avgFCRsPerCoach: '2.7',
  avgFCRsPerCoachSub: 'target: 3.0',
  avgDaysBetweenObs: '37d',
  avgDaysSub: 'target: ≤30d',
};

export const pipelineData = [
  { label: 'Completed', count: 20, color: '#16a34a' },
  { label: 'Submitted', count: 11, color: '#2563eb' },
  { label: 'Draft',     count: 7,  color: '#d97706' },
  { label: 'Overdue',   count: 2,  color: '#dc2626' },
];

// Generate daily data for May 4 – Jun 5 (33 days) — values match reference (stacked total ~40)
const genDate = (start, days) => {
  const d = new Date(start);
  d.setDate(d.getDate() + days);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

export const submissionsDaily = Array.from({ length: 33 }, (_, i) => ({
  date: genDate('2026-05-04', i),
  Oncology:       Math.round(4 + Math.sin(i * 0.3) * 2 + i * 0.12),
  Immunology:     Math.round(5 + Math.cos(i * 0.25) * 2 + i * 0.15),
  Neuroscience:   Math.round(6 + Math.sin(i * 0.4 + 1) * 2 + i * 0.18),
  Cardiovascular: Math.round(7 + Math.cos(i * 0.35 + 0.5) * 2 + i * 0.2),
  Other:          Math.round(8 + Math.sin(i * 0.2) * 1.5 + i * 0.25),
}));

export const submissionsMonthly = [
  { date: 'Jan', Oncology: 42, Immunology: 35, Neuroscience: 28, Cardiovascular: 20, Other: 10 },
  { date: 'Feb', Oncology: 55, Immunology: 40, Neuroscience: 32, Cardiovascular: 24, Other: 12 },
  { date: 'Mar', Oncology: 48, Immunology: 52, Neuroscience: 38, Cardiovascular: 30, Other: 15 },
  { date: 'Apr', Oncology: 63, Immunology: 47, Neuroscience: 42, Cardiovascular: 35, Other: 18 },
  { date: 'May', Oncology: 72, Immunology: 60, Neuroscience: 50, Cardiovascular: 40, Other: 20 },
];

export const coverageData = [
  { org: 'East Oncology Coaching Team',       active: 3, target: 3, pct: 100, fcrs: 12, cadence: '28d' },
  { org: 'West Immunology & Cardio Team',     active: 3, target: 3, pct: 100, fcrs: 0,  cadence: '35d' },
  { org: 'Southeast Neuro & Immunology Team', active: 2, target: 2, pct: 100, fcrs: 0,  cadence: '20d' },
  { org: 'Central Cardie & Pulmonary Team',   active: 3, target: 3, pct: 100, fcrs: 5,  cadence: '52d' },
  { org: 'Southern Specialty TA Team',        active: 1, target: 3, pct: 33,  fcrs: 3,  cadence: '36d' },
];

export const recentFCRs = [
  { id: 'FCR-2026-0129', manager: 'Dr. Naomi Carter',   msl: 'Dr. Marcus White',    ta: 'Infectious Disease',   date: '2026-04-27', status: 'Completed' },
  { id: 'FCR-2026-0118', manager: 'Dr. Rachel Okonkwo', msl: 'Dr. Luca Fernandez',  ta: 'Neuroscience',         date: '2026-04-25', status: 'Submitted' },
  { id: 'FCR-2026-0120', manager: 'Dr. Andre DuBois',   msl: 'Dr. Felix Sauer',     ta: 'Cardiovascular',       date: '2026-04-25', status: 'Completed' },
  { id: 'FCR-2026-0127', manager: 'Dr. Naomi Carter',   msl: 'Dr. Lina Park',       ta: 'Infectious Disease',   date: '2026-04-25', status: 'Completed' },
  { id: 'FCR-2026-0117', manager: 'Dr. Priya Shah',     msl: 'Dr. Elliott Reyes',   ta: 'Oncology',             date: '2026-04-23', status: 'Completed' },
  { id: 'FCR-2026-0116', manager: 'Dr. Wei Chen',       msl: 'Dr. Rosa Lin',        ta: 'Pulmonary Hypertension',date: '2026-04-23', status: 'Completed' },
  { id: 'FCR-2026-0115', manager: 'Dr. Hana Mori',      msl: 'Dr. Hana Mori',       ta: 'Infectious Disease',   date: '2026-04-22', status: 'Submitted' },
  { id: 'FCR-2026-0125', manager: 'Dr. Sofia Martinez', msl: 'Dr. Karim Hassan',    ta: 'Immunology',           date: '2026-04-22', status: 'Draft'     },
  { id: 'FCR-2026-0102', manager: 'Alyson Williamson',  msl: 'Toya Bowles',         ta: 'Oncology',             date: '2026-04-21', status: 'Submitted' },
  { id: 'FCR-2026-0123', manager: 'Dr. Sofia Martinez', msl: 'Dr. Emma Sundberg',   ta: 'Immunology',           date: '2026-04-21', status: 'Completed' },
  { id: 'FCR-2026-0171', manager: 'Dr. Sofia Martinez', msl: 'Dr. Carlos Mendez',   ta: 'Immunology',           date: '2026-04-20', status: 'Draft'     },
  { id: 'FCR-2026-0189', manager: 'Dr. Rachel Okonkwo', msl: 'Dr. Luca Fernandez',  ta: 'Neuroscience',         date: '2026-04-17', status: 'Completed' },
];
