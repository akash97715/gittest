import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  host:     process.env.REDSHIFT_HOST,
  port:     parseInt(process.env.REDSHIFT_PORT || '5439'),
  database: process.env.REDSHIFT_DB,
  user:     process.env.REDSHIFT_USER,
  password: process.env.REDSHIFT_PASSWORD,
  ssl:      { rejectUnauthorized: false }, // required for Redshift
  max:      10,                  // increased from 5 — supports multiple concurrent users
  min:      2,                   // keep 2 connections warm to avoid cold-start latency
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  query_timeout: 55000,          // abort queries that run > 55 s (client-side)
  statement_timeout: 55000,      // ask Redshift to cancel after 55 s (server-side)
});

pool.on('error', (err) => {
  console.error('Redshift pool error:', err.message);
});

export default pool;
