#!/usr/bin/env node
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;
const pool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

const client = await pool.connect();

// Check all tables in telemetry schema
console.log('\n=== TELEMETRY TABLES ===');
const tablesResult = await client.query(`
  SELECT table_name 
  FROM information_schema.tables 
  WHERE table_schema = 'telemetry'
  ORDER BY table_name
`);

console.log('Available tables:');
tablesResult.rows.forEach(row => {
  console.log('  -', row.table_name);
});

// Check event_processing_status for errors
console.log('\n=== RECENT EVENT PROCESSING STATUS ===');
const statusResult = await client.query(`
  SELECT * FROM telemetry.event_processing_status 
  ORDER BY created_at DESC
  LIMIT 10
`);

console.log('Recent processing statuses:');
statusResult.rows.forEach((row, idx) => {
  console.log(`  ${idx + 1}. Status: ${row.status}, Event Type: ${row.event_type}, Error: ${row.error_message || 'none'}`);
});

// Check user_events for ANY recent events
console.log('\n=== RECENT USER EVENTS (ANY TYPE) ===');
const allEventsResult = await client.query(`
  SELECT event_type, COUNT(*) as count, MAX(event_timestamp) as last_event
  FROM telemetry.user_events
  GROUP BY event_type
  ORDER BY MAX(event_timestamp) DESC
  LIMIT 20
`);

console.log('Event types and counts:');
allEventsResult.rows.forEach((row, idx) => {
  console.log(`  ${idx + 1}. ${row.event_type.padEnd(20)} : ${row.count} events (last: ${row.last_event})`);
});

// Check for any errors table
console.log('\n=== CHECKING TELEMETRY SCHEMA OBJECTS ===');
const objResult = await client.query(`
  SELECT table_name, table_type
  FROM information_schema.tables
  WHERE table_schema = 'telemetry'
`);

console.log('All objects:');
objResult.rows.forEach(row => {
  console.log(`  - ${row.table_type}: ${row.table_name}`);
});

client.release();
pool.end();
