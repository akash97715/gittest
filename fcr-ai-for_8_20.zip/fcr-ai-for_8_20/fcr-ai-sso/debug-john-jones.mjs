import pool from './db.js';

try {
  // Search for John Jones to find the real FCR IDs
  const r = await pool.query(`
    SELECT DISTINCT
      survey_target_id,
      chnl_engagement_id_value,
      rep_first_nm, rep_last_nm, rep_wwid,
      ta, reg_nm, acty_dt, engagement_title
    FROM odp.dp_cust_pers_engagement_dly
    WHERE chnl = 'SURVEY'
      AND LOWER(rep_first_nm) LIKE '%john%'
      AND LOWER(rep_last_nm)  LIKE '%jones%'
    ORDER BY acty_dt DESC
    LIMIT 10
  `);
  console.log('John Jones FCRs:');
  r.rows.forEach(x => console.log(JSON.stringify(x)));

  // Also try searching by the PIN number in all text columns
  const r2 = await pool.query(`
    SELECT DISTINCT
      survey_target_id,
      chnl_engagement_id_value,
      survey_question_text,
      survey_question_response,
      survey_question_response_text
    FROM odp.dp_cust_pers_engagement_dly
    WHERE survey_question_response_text ILIKE '%49XJVYAY%'
       OR survey_question_response       ILIKE '%49XJVYAY%'
       OR chnl_engagement_id_value       ILIKE '%49XJVYAY%'
       OR survey_target_id               ILIKE '%49XJVYAY%'
    LIMIT 10
  `);
  console.log('\nDirect 49XJVYAY search across all columns:');
  r2.rows.forEach(x => console.log(JSON.stringify(x)));

} catch(e) {
  console.error('Error:', e.message);
}
process.exit(0);
