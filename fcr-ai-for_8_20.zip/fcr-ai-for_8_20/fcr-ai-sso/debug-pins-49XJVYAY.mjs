import pool from './db.js';

// 49XJVYAY is the chnl_engagement_id_value (the short PIN number shown in the UI)
// The /api/pins-score endpoint queries using survey_target_id (18-char Salesforce ID)
// Step 1: Resolve the real survey_target_id from chnl_engagement_id_value
const PIN_NUMBER = '49XJVYAY';

try {
  // 1. Look up the real survey_target_id for this PIN number
  const r1 = await pool.query(`
    SELECT DISTINCT
      survey_target_id,
      chnl_engagement_id_value,
      rep_first_nm,
      rep_last_nm,
      chnl,
      engagement_title
    FROM odp.dp_cust_pers_engagement_dly
    WHERE UPPER(TRIM(chnl_engagement_id_value)) = UPPER(TRIM($1))
    LIMIT 5
  `, [PIN_NUMBER]);
  console.log('\n=== 1. Resolved survey_target_id from PIN number ===');
  r1.rows.forEach(x => console.log(JSON.stringify(x)));

  if (r1.rows.length === 0) {
    console.log('\nNot found by chnl_engagement_id_value. Trying partial match...');
    const r1b = await pool.query(`
      SELECT DISTINCT survey_target_id, chnl_engagement_id_value, rep_first_nm, rep_last_nm
      FROM odp.dp_cust_pers_engagement_dly
      WHERE UPPER(chnl_engagement_id_value) LIKE $1
      LIMIT 10
    `, [`%${PIN_NUMBER}%`]);
    r1b.rows.forEach(x => console.log(JSON.stringify(x)));
    process.exit(0);
  }

  const REAL_FCR_ID = r1.rows[0].survey_target_id;
  console.log('\n>>> Real survey_target_id:', REAL_FCR_ID);

  // 2. Now run the exact same query that /api/pins-score sends to GPT
  const pinsResult = await pool.query(`
    SELECT
      UPPER(LTRIM(survey_question_text))    AS q_upper,
      survey_question_text                  AS question,
      survey_question_response              AS response,
      survey_question_response_text         AS narrative
    FROM odp.dp_cust_pers_engagement_dly
    WHERE survey_target_id = $1
      AND chnl = 'SURVEY'
      AND (
        UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'NEGOT%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%'
      )
    ORDER BY survey_question_order NULLS LAST
  `, [REAL_FCR_ID]);

  console.log('\n=== 2. PINS rows sent to GPT (exact query from /api/pins-score) ===');
  console.log('Total rows:', pinsResult.rows.length);
  pinsResult.rows.forEach(x => console.log(JSON.stringify(x)));

  // 3. If still blank, show ALL rows for this FCR so we can see what's there
  if (pinsResult.rows.length === 0) {
    console.log('\n=== 3. All rows for this FCR (no PINS filter) — debugging ===');
    const r3 = await pool.query(`
      SELECT survey_question_text, survey_question_response, survey_question_response_text, chnl
      FROM odp.dp_cust_pers_engagement_dly
      WHERE survey_target_id = $1
      ORDER BY survey_question_order NULLS LAST
      LIMIT 50
    `, [REAL_FCR_ID]);
    console.log('Total rows:', r3.rows.length);
    r3.rows.forEach(x => console.log(JSON.stringify(x)));
  }

} catch(e) {
  console.error('Error:', e.message);
}
process.exit(0);
