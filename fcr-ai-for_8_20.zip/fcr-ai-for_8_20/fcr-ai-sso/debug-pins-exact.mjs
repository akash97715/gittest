import pool from './db.js';

// The real survey_target_id for PIN 49XJVYAY
const REAL_FCR_ID = 'a2zWQ0000049xJVYAY';

try {
  console.log('=== EXACT QUERY SENT TO GPT (/api/pins-score) ===');
  console.log(`survey_target_id = '${REAL_FCR_ID}'\n`);

  // This is the EXACT query from server.js /api/pins-score
  const pinsResult = await pool.query(`
    SELECT
      UPPER(LTRIM(survey_question_text))    AS q_upper,
      survey_question_text                  AS question,
      survey_question_response              AS response,
      survey_question_response_text         AS narrative
    FROM odp.dp_cust_pers_engagement_dly
    WHERE survey_target_id = $1
      AND chnl = 'SURVEY'
      AND (
        UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'NEGOT%'
        OR UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%'
      )
    ORDER BY survey_question_order NULLS LAST
  `, [REAL_FCR_ID]);

  console.log(`Rows matched by PINS filter: ${pinsResult.rows.length}`);
  pinsResult.rows.forEach(x => console.log(JSON.stringify(x)));

  // Show what the contextBlock sent to GPT looks like
  const sections = { P: [], I: [], N: [], S: [] };
  const trainingFlags = { P: null, I: null, N: null, S: null };
  for (const row of pinsResult.rows) {
    const q = row.q_upper || '';
    const isTraining = q.includes('TRAINING NEEDED');
    let letter = null;
    if (q.startsWith('PLAN'))    letter = 'P';
    else if (q.startsWith('INVEST')) letter = 'I';
    else if (q.startsWith('NAVIGAT') || q.startsWith('NEGOT')) letter = 'N';
    else if (q.startsWith('SECURE')) letter = 'S';
    if (!letter) continue;
    if (isTraining) {
      trainingFlags[letter] = row.response === 'Yes';
    } else if (row.narrative?.trim()) {
      sections[letter].push(row.narrative.trim());
    }
  }
  const sectionNames = { P: 'Planning for Perspective', I: 'Investigate Issues', N: 'Navigate & Negotiate Needs', S: 'Secure Action' };
  console.log('\n=== CONTEXT BLOCK SENT TO GPT ===');
  for (const [letter, texts] of Object.entries(sections)) {
    const name = sectionNames[letter];
    const trainingFlag = trainingFlags[letter] === true ? ' [Training Needed: YES]' : trainingFlags[letter] === false ? ' [Training Needed: No]' : '';
    console.log(`\n${name}${trainingFlag}:`);
    console.log(texts.length > 0 ? texts.join('\n') : '(no narrative recorded)');
  }

  // Show ALL rows for this FCR so we can see what's being missed
  console.log('\n\n=== ALL ROWS FOR THIS FCR (what the filter is MISSING) ===');
  const allRows = await pool.query(`
    SELECT
      survey_question_text,
      survey_question_response,
      survey_question_response_text,
      survey_question_order,
      chnl
    FROM odp.dp_cust_pers_engagement_dly
    WHERE survey_target_id = $1
    ORDER BY survey_question_order NULLS LAST
  `, [REAL_FCR_ID]);
  console.log(`Total rows in FCR: ${allRows.rows.length}`);
  allRows.rows.forEach(x => console.log(JSON.stringify(x)));

} catch(e) {
  console.error('Error:', e.message);
}
process.exit(0);
