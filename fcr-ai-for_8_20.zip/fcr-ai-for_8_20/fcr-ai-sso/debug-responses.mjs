import pool from './db.js';

const fcrId = 'a2zWQ000000dYZhYAM';

const res = await pool.query(`
  SELECT
    survey_question_order,
    survey_question_name,
    survey_question_response
  FROM odp.dp_cust_pers_engagement_dly
  WHERE survey_target_id = $1
    AND chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
  ORDER BY survey_question_order
`, [fcrId]);

console.log(`Total rows: ${res.rows.length}`);
console.table(res.rows.slice(0, 20));

await pool.end();
