#!/bin/bash
set -e

echo "=== Installing dependencies ==="
npm install --omit=dev

echo "=== Build already done locally (dist/ included) ==="
echo "=== Deploy complete ==="
