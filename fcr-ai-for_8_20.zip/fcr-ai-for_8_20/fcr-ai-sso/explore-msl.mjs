import pool from './db.js';

try {
  // Find PINS-related questions and their answer types
  const r = await pool.query(`
    SELECT
      TRIM(SPLIT_PART(survey_question_text, E'\n', 1)) AS question_first_line,
      survey_question_answer_choice,
      survey_question_response,
      COUNT(*) AS cnt
    FROM odp.dp_cust_pers_engagement_dly
    WHERE chnl = 'SURVEY'
      AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND (UPPER(BTRIM(survey_question_text)) LIKE 'PLAN%'
          OR UPPER(BTRIM(survey_question_text)) LIKE 'INVEST%'
          OR UPPER(BTRIM(survey_question_text)) LIKE 'NAVIGAT%'
          OR UPPER(BTRIM(survey_question_text)) LIKE 'NEGOT%'
          OR UPPER(BTRIM(survey_question_text)) LIKE 'SECURE%')
    GROUP BY 1, 2, 3
    ORDER BY 1, cnt DESC
    LIMIT 40
  `);
  console.log('=== PINS question rows ===');
  console.log(JSON.stringify(r.rows, null, 2));
} catch(e) {
  console.error('Error:', e.message);
}
process.exit(0);
