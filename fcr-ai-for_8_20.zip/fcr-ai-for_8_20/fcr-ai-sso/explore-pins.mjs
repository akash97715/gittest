import pool from './db.js';

try {
  const r = await pool.query(`
    SELECT
      SUBSTRING(UPPER(LTRIM(survey_question_text)), 1, 80) AS question_start,
      survey_question_answer_choice,
      survey_question_response,
      COUNT(*) AS cnt
    FROM odp.dp_cust_pers_engagement_dly
    WHERE chnl = 'SURVEY'
      AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
      AND (
          UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'NEGOT%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%'
      )
    GROUP BY 1, 2, 3
    ORDER BY cnt DESC
    LIMIT 50
  `);
  console.log('PINS question rows found:', r.rows.length);
  console.log(JSON.stringify(r.rows, null, 2));

  // Also check how many distinct FCRs have these questions
  const r2 = await pool.query(`
    SELECT COUNT(DISTINCT survey_target_id) AS fcrs_with_pins
    FROM odp.dp_cust_pers_engagement_dly
    WHERE chnl = 'SURVEY'
      AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
      AND (
          UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%'
      )
  `);
  console.log('\nDistinct FCRs with PINS questions:', r2.rows[0].fcrs_with_pins);
} catch(e) {
  console.error('Error:', e.message);
}
process.exit(0);
