import pool from './db.js';

const sql = 
  SELECT 
    survey_target_id,
    engagement_title,
    rep_wwid,
    rep_first_nm,
    rep_last_nm,
    rep_desig,
    ownr_id,
    terr_nm,
    survey_target_status
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND LOWER(engagement_title) LIKE '%coaching%'
    AND survey_target_id IS NOT NULL
  GROUP BY 1,2,3,4,5,6,7,8,9
  LIMIT 5
;

pool.query(sql)
  .then(r => { console.log(JSON.stringify(r.rows, null, 2)); process.exit(0); })
  .catch(e => { console.error('FAILED:', e.message); process.exit(1); });
