// export-10-pins.mjs
// Fetches 10 PINS (MSL/VESE FBMS) FCRs + full Q&A and writes to a markdown doc

import fs from 'fs';

const BASE = 'http://localhost:8080';

async function fetchJson(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`HTTP ${r.status} for ${url}`);
  return r.json();
}

// 1. Get 10 PINS FCRs
console.log('Fetching 10 PINS FCRs...');
const list = await fetchJson(`${BASE}/api/fcrs?pinsOnly=1&limit=10&offset=0`);
const fcrs = list.rows || [];
console.log(`Got ${fcrs.length} FCRs`);

let doc = `# 10 MSL PINS Field Coaching Reports — Full Q&A Export
Generated: ${new Date().toISOString().slice(0,19).replace('T',' ')}
Source: Live Redshift · FBMS MSL/VESE Forms Only
Total PINS FCRs available: ${list.total}

---

`;

// 2. For each FCR fetch full detail
for (let idx = 0; idx < fcrs.length; idx++) {
  const fcr = fcrs[idx];
  const fcrId = fcr.fcr_id;
  console.log(`Fetching detail ${idx+1}/10 — ${fcrId} (${fcr.coachee_first} ${fcr.coachee_last})`);

  let detail = [];
  try {
    detail = await fetchJson(`${BASE}/api/fcr/${fcrId}`);
  } catch(e) {
    console.warn(`  ⚠ Could not fetch detail for ${fcrId}: ${e.message}`);
  }

  const meta = detail[0] || {};
  const rawSt = (meta.survey_target_status || '').toLowerCase();
  const status = (rawSt.includes('late') && rawSt.includes('submission')) ? 'Late Submission'
               : rawSt.includes('submitted') ? 'Submitted'
               : (rawSt.includes('saved') || rawSt.includes('draft')) ? 'Draft'
               : 'Draft';

  // Training flags
  const trainingRows = detail.filter(r => /training needed/i.test(r.survey_question_text || '') && r.survey_question_response);
  const trainingFlags = trainingRows.map(r => {
    const q = (r.survey_question_text || '').trim();
    const section = /plan/i.test(q) ? 'P' : /invest/i.test(q) ? 'I' : /navigat|negot/i.test(q) ? 'N' : /secure/i.test(q) ? 'S' : '?';
    return `${section}:${r.survey_question_response}`;
  }).join(' | ');

  doc += `## ${idx+1}. ${fcr.coachee_first || ''} ${fcr.coachee_last || ''}
**FCR ID:** ${fcrId}
**Form:** ${meta.engagement_title || fcr.engagement_title || '—'}
**Role:** ${fcr.coachee_role || '—'}
**TA:** ${fcr.ta || '—'} | **Region:** ${fcr.region || '—'} | **Territory:** ${fcr.territory || fcr.district || '—'}
**Coaching Date:** ${fcr.coaching_date ? String(fcr.coaching_date).slice(0,10) : '—'}
**Session Duration:** ${meta.survey_target_session_duration || '—'}
**Status:** ${status}
**Training Flags:** ${trainingFlags || '—'}
**Total Q&A Rows:** ${detail.length}

`;

  if (detail.length === 0) {
    doc += `_No detail data available._\n\n---\n\n`;
    continue;
  }

  doc += `### Questions & Answers\n\n`;
  doc += `| # | Question | Response | Notes |\n`;
  doc += `|---|----------|----------|-------|\n`;

  for (let i = 0; i < detail.length; i++) {
    const row = detail[i];
    const q   = (row.survey_question_text || '—').replace(/\|/g, '\\|').replace(/\n/g, ' ');
    const ans = (row.survey_question_response || '').replace(/\|/g, '\\|').replace(/\n/g, ' ');
    const txt = (row.survey_question_response_text || '').replace(/\|/g, '\\|').replace(/\n/g, ' ').slice(0, 300);
    const txtDisplay = txt.length === 300 ? txt + '…' : txt;
    doc += `| ${i+1} | ${q} | ${ans || '—'} | ${txtDisplay || '—'} |\n`;
  }

  // Also add the coaching narratives in full (not truncated)
  const narrativeRows = detail.filter(r => {
    const u = (r.survey_question_text || '').trimStart().toUpperCase();
    return (u.startsWith('PLAN') || u.startsWith('INVEST') || u.startsWith('NAVIGAT') || u.startsWith('NEGOT') || u.startsWith('SECURE'))
      && !(/training needed/i.test(r.survey_question_text || ''))
      && r.survey_question_response_text?.trim();
  });

  if (narrativeRows.length > 0) {
    doc += `\n### PINS Coaching Narratives (Full Text)\n\n`;
    for (const r of narrativeRows) {
      const section = (r.survey_question_text || '').trim();
      doc += `**${section}**\n\n${r.survey_question_response_text?.trim()}\n\n`;
    }
  }

  doc += `\n---\n\n`;
}

const outFile = 'PINS_10_MSL_QA_Export.md';
fs.writeFileSync(outFile, doc, 'utf8');
console.log(`\n✅ Done! Written to: ${outFile}`);
console.log(`   Size: ${(fs.statSync(outFile).size / 1024).toFixed(1)} KB`);
