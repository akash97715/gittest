import pool from './db.js';

// Find an FCR with actual FBMS behavior ratings
const res = await pool.query(`
  SELECT DISTINCT survey_target_id, rep_first_nm, rep_last_nm
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
    AND survey_question_response IN ('Expert', 'Advanced', 'Skilled', 'Awareness')
  LIMIT 1
`);

if (res.rows.length > 0) {
  console.log('FCR with FBMS ratings:');
  console.log(JSON.stringify(res.rows[0], null, 2));
} else {
  console.log('No FBMS rated FCRs found');
}

await pool.end();
