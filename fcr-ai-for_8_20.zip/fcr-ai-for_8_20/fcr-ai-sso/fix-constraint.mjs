#!/usr/bin/env node
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;
const pool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

const client = await pool.connect();

console.log('\n' + '='.repeat(80));
console.log('DATABASE CHECK CONSTRAINT ANALYSIS');
console.log('='.repeat(80));

// Get constraint definition
console.log('\n✓ Fetching CHECK constraint definition...');
const constraintResult = await client.query(`
  SELECT 
    con.conname,
    pg_get_constraintdef(con.oid) AS definition
  FROM pg_constraint con
  JOIN pg_class rel ON rel.oid = con.conrelid
  WHERE rel.relname = 'user_events' 
    AND con.contype = 'c'
    AND con.conname = 'chk_event_type'
`);

if (constraintResult.rows.length === 0) {
  console.log('  ❌ Constraint not found');
  client.release();
  pool.end();
  process.exit(1);
}

const constraint = constraintResult.rows[0];
console.log('\n  Constraint Name:', constraint.conname);
console.log('  Definition:', constraint.definition);

// Parse the constraint to see what values are allowed
console.log('\n✓ Current allowed event types in constraint:');
const defString = constraint.definition;
const allowedValues = defString.match(/'([^']+)'/g);
if (allowedValues) {
  allowedValues.forEach((val, idx) => {
    const cleanVal = val.replace(/'/g, '');
    const isNewValue = cleanVal === 'browser_closed' ? ' ← ALREADY ADDED!' : '';
    console.log(`    ${idx + 1}. ${cleanVal}${isNewValue}`);
  });
}

// Check if browser_closed is already there
if (defString.includes("'browser_closed'")) {
  console.log('\n  ✅ browser_closed is already in the constraint!');
  client.release();
  pool.end();
  process.exit(0);
}

// Need to add browser_closed
console.log('\n❌ browser_closed NOT in constraint - need to fix!');
console.log('\n✓ Updating constraint...');

// Drop and recreate the constraint
const dropConstraintSql = `ALTER TABLE telemetry.user_events DROP CONSTRAINT chk_event_type`;
const addConstraintSql = `ALTER TABLE telemetry.user_events ADD CONSTRAINT chk_event_type CHECK (event_type IN ('user_login', 'user_logout', 'browser_closed', 'session_start', 'session_end', 'page_view', 'page_exit', 'button_click', 'search', 'data_export', 'api_call', 'error', 'custom'))`;

console.log('\n  SQL 1: DROP CONSTRAINT');
console.log('  ', dropConstraintSql);
await client.query(dropConstraintSql);
console.log('  ✅ Dropped');

console.log('\n  SQL 2: ADD CONSTRAINT with browser_closed');
console.log('  ', addConstraintSql);
await client.query(addConstraintSql);
console.log('  ✅ Added');

// Verify
console.log('\n✓ Verifying constraint was updated...');
const verifyResult = await client.query(`
  SELECT 
    con.conname,
    pg_get_constraintdef(con.oid) AS definition
  FROM pg_constraint con
  JOIN pg_class rel ON rel.oid = con.conrelid
  WHERE rel.relname = 'user_events' 
    AND con.contype = 'c'
    AND con.conname = 'chk_event_type'
`);

const verifyConstraint = verifyResult.rows[0];
console.log('\n  Updated Definition:');
console.log('  ', verifyConstraint.definition);

console.log('\n  Updated allowed event types:');
const updatedValues = verifyConstraint.definition.match(/'([^']+)'/g);
if (updatedValues) {
  updatedValues.forEach((val, idx) => {
    const cleanVal = val.replace(/'/g, '');
    const marker = cleanVal === 'browser_closed' ? ' ← NEW!' : '';
    console.log(`    ${idx + 1}. ${cleanVal}${marker}`);
  });
}

client.release();
pool.end();

console.log('\n' + '='.repeat(80));
console.log('✅ CHECK CONSTRAINT UPDATED SUCCESSFULLY!');
console.log('='.repeat(80) + '\n');

process.exit(0);
