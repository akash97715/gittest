#!/usr/bin/env python3
"""
Generate a comprehensive Word document for Backend API Testing
"""

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from datetime import datetime

# Create a new Document
doc = Document()

# Add title
title = doc.add_heading('FCR AI Insights - Backend API Testing Documentation', 0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER

# Add subtitle with date
subtitle = doc.add_paragraph(f'Generated: {datetime.now().strftime("%B %d, %Y")}')
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
subtitle.runs[0].font.size = Pt(12)
subtitle.runs[0].font.italic = True

doc.add_paragraph()

# Introduction
doc.add_heading('Introduction', 1)
doc.add_paragraph(
    'This document provides comprehensive information about all 16 backend API endpoints for the FCR AI Insights dashboard. '
    'Each API is documented with its purpose, HTTP method, authentication requirements, query/body parameters, response format, and testing notes.'
)

# Table of Contents
doc.add_heading('API Endpoints Overview', 1)
doc.add_paragraph('Total Backend APIs: 16')
doc.add_paragraph('Base URL: http://localhost:8080 (development) | https://azr-iay-fcrai-spn-iacdev.azurewebsites.net (production)')

# Add overview table
table = doc.add_table(rows=1, cols=4)
table.style = 'Light Grid Accent 1'
hdr_cells = table.rows[0].cells
hdr_cells[0].text = 'API Endpoint'
hdr_cells[1].text = 'Method'
hdr_cells[2].text = 'Type'
hdr_cells[3].text = 'Purpose'

endpoints = [
    ('/api/ping', 'GET', 'Utility', 'Database health check'),
    ('/api/schema', 'GET', 'Utility', 'List all database schemas and tables'),
    ('/api/schema/:schema/:table', 'GET', 'Utility', 'List columns for a specific table'),
    ('/api/summary', 'GET', 'Analytics', 'Dashboard KPIs and trends'),
    ('/api/fcrs', 'GET', 'Analytics', 'Paginated FCR list with filters'),
    ('/api/fcr/:id', 'GET', 'Analytics', 'Single FCR detail with all questions'),
    ('/api/rep-trend/:wwid', 'GET', 'Analytics', 'MSL proficiency trend over time'),
    ('/api/kpis', 'GET', 'Analytics', 'Summary KPI numbers for dashboard'),
    ('/api/capability', 'GET', 'Analytics', 'FBMS competency proficiency breakdown'),
    ('/api/pins-summary', 'GET', 'Analytics', 'PINS training flags aggregated summary'),
    ('/api/pins-trend', 'GET', 'Analytics', 'Monthly PINS proficiency trend'),
    ('/api/ask', 'POST', 'AI', 'Text-to-SQL conversational AI'),
    ('/api/fcr-insight', 'POST', 'AI', 'AI-powered FCR coaching analysis'),
    ('/api/pins-score', 'POST', 'AI', 'AI-powered PINS behavior scoring'),
    ('/api/pins-insight', 'POST', 'AI', 'AI-generated PINS PDF narrative'),
    ('/api/skill-trend-insight', 'POST', 'AI', 'AI insights for skill proficiency trends'),
]

for endpoint_info in endpoints:
    row_cells = table.add_row().cells
    row_cells[0].text = endpoint_info[0]
    row_cells[1].text = endpoint_info[1]
    row_cells[2].text = endpoint_info[2]
    row_cells[3].text = endpoint_info[3]

doc.add_page_break()

# Detailed API Documentation
doc.add_heading('Detailed API Documentation', 1)

apis = [
    {
        'endpoint': '/api/ping',
        'method': 'GET',
        'type': 'Utility',
        'description': 'Health check endpoint to verify Redshift database connectivity.',
        'auth': 'Azure AD Token',
        'timeout': '10 seconds',
        'cache': 'No',
        'params': 'None',
        'request_body': 'N/A',
        'response': '{ connected: true, db: "awprdrsdb", usr: "vkrish53" }',
        'status_codes': '200 (success), 500 (connection failed)',
        'test_notes': 'Use for monitoring endpoint health. No parameters required.',
    },
    {
        'endpoint': '/api/schema',
        'method': 'GET',
        'type': 'Utility',
        'description': 'Lists all database schemas and tables (for exploration/debugging).',
        'auth': 'Azure AD Token',
        'timeout': '10 seconds',
        'cache': 'No',
        'params': 'None',
        'request_body': 'N/A',
        'response': 'Array of objects: [{ table_schema: "odp", table_name: "dp_cust_pers_engagement_dly" }, ...]',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Used primarily for development. Returns all schemas except information_schema and pg_catalog.',
    },
    {
        'endpoint': '/api/schema/:schema/:table',
        'method': 'GET',
        'type': 'Utility',
        'description': 'Lists all columns and data types for a specific table.',
        'auth': 'Azure AD Token',
        'timeout': '10 seconds',
        'cache': 'No',
        'params': ':schema (string) - schema name, :table (string) - table name',
        'request_body': 'N/A',
        'response': 'Array of objects: [{ column_name: "survey_target_id", data_type: "character varying", ordinal_position: 1 }, ...]',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Example: /api/schema/odp/dp_cust_pers_engagement_dly',
    },
    {
        'endpoint': '/api/summary',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Full dashboard data including KPIs, TA breakdown, region breakdown, and 6-month trend.',
        'auth': 'Azure AD Token',
        'timeout': '15 seconds',
        'cache': 'Yes (5-minute TTL)',
        'params': 'ta (string), timeframe (number/days), region (string), from (date), to (date)',
        'request_body': 'N/A',
        'response': '{ kpi: {...}, by_ta: [...], by_region: [...], trend: [...], _cached: boolean }',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Supports filtering by TA, region, and date range. Example: /api/summary?ta=ONC&timeframe=30',
    },
    {
        'endpoint': '/api/fcrs',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Paginated FCR list with optional filters (status, TA, search, etc.).',
        'auth': 'Azure AD Token',
        'timeout': '28 seconds',
        'cache': 'Yes (2-minute TTL)',
        'params': 'ta, status (Draft/Submitted/Late Submission), timeframe, search, limit (default 100), offset (default 0), pinsOnly',
        'request_body': 'N/A',
        'response': '{ total: number, rows: [{ fcr_id, survey_id, coachee_first, coachee_last, status, coaching_date, ... }] }',
        'status_codes': '200 (success), 504 (timeout)',
        'test_notes': 'Max 100 rows per request. Use offset for pagination. Status codes: Draft, Submitted, Late Submission.',
    },
    {
        'endpoint': '/api/fcr/:id',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Full detail of a single FCR including all 42 question-answer pairs.',
        'auth': 'Azure AD Token',
        'timeout': '25 seconds',
        'cache': 'Yes (10-minute TTL)',
        'params': ':id (string) - survey_target_id (e.g., "a2zWQ000004AODFYA4")',
        'request_body': 'N/A',
        'response': 'Array of 42-50 objects: [{ survey_target_id, survey_question_name, survey_question_text, survey_question_response, survey_question_response_text, ... }]',
        'status_codes': '200 (success), 404 (FCR not found), 504 (timeout)',
        'test_notes': 'Returns all question responses including free-text observations (survey_question_response_text).',
    },
    {
        'endpoint': '/api/rep-trend/:wwid',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Last 20 FCR average FBMS scores for a specific MSL (for trend charting).',
        'auth': 'Azure AD Token',
        'timeout': '10 seconds',
        'cache': 'No',
        'params': ':wwid (string) - MSL\'s WWID employee ID',
        'request_body': 'N/A',
        'response': 'Array of up to 20 objects: [{ fcr_id, coaching_date, avg_score (1-4), rated_behaviors }] ordered oldest-first',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Used in the Capability page to show individual MSL improvement trends.',
    },
    {
        'endpoint': '/api/kpis',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Summary KPI numbers for the dashboard hero cards.',
        'auth': 'Azure AD Token',
        'timeout': '10 seconds',
        'cache': 'Yes (5-minute TTL)',
        'params': 'None (global MSL filter applied)',
        'request_body': 'N/A',
        'response': '{ total_fcrs, total_reps, submitted, submitted_pct, avg_days_to_submit, compliance_rate, non_compliant_count }',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Always returns global statistics. No filters supported.',
    },
    {
        'endpoint': '/api/capability',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'FBMS competency proficiency breakdown (skill-level distribution).',
        'auth': 'Azure AD Token',
        'timeout': '15 seconds',
        'cache': 'Yes (5-minute TTL)',
        'params': 'ta, timeframe, region, from, to',
        'request_body': 'N/A',
        'response': '{ kpi: {...}, competencies: [...], trend: [...], levels: [...], lead: [...], compliance: {...} }',
        'status_codes': '200 (success), 500 (query failed)',
        'test_notes': 'Supports filtering and includes LEAD model scores, compliance rates, and competency trends.',
    },
    {
        'endpoint': '/api/pins-summary',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Aggregate PINS training flags (training-needed counts by section P/I/N/S).',
        'auth': 'Azure AD Token',
        'timeout': '55 seconds',
        'cache': 'Yes (5-minute TTL)',
        'params': 'ta, region, timeframe (default 90 days), from, to',
        'request_body': 'N/A',
        'response': '{ kpi: {...}, sections: [...], levels: [...], reps: [...], by_ta: [...] }',
        'status_codes': '200 (success), 504 (timeout)',
        'test_notes': 'Scans millions of rows. Default 90-day timeframe. Training flags: Yes/No for each PINS section.',
    },
    {
        'endpoint': '/api/pins-trend',
        'method': 'GET',
        'type': 'Analytics',
        'description': 'Monthly PINS proficiency trend (12-month history).',
        'auth': 'Azure AD Token',
        'timeout': '55 seconds',
        'cache': 'Yes (5-minute TTL)',
        'params': 'ta, region',
        'request_body': 'N/A',
        'response': '{ trend: [{ month, month_dt, fcrs, P, I, N, S }] } where P/I/N/S are scores 1-3',
        'status_codes': '200 (success), 504 (timeout)',
        'test_notes': 'Covers last 12 months. Scores derived from training flag percentages (1-3 scale).',
    },
    {
        'endpoint': '/api/ask',
        'method': 'POST',
        'type': 'AI',
        'description': 'Text-to-SQL conversational AI. User asks a question, GPT generates SQL, runs it, explains results.',
        'auth': 'Azure AD Token',
        'timeout': '30 seconds',
        'cache': 'No',
        'params': 'N/A',
        'request_body': '{ "question": "How many MSLs scored Advanced?", "history": [] }',
        'response': '{ sql: "...", rows: [...], summary: "AI explanation", error: null }',
        'status_codes': '200 (success), 400 (invalid query), 502 (AI error), 504 (timeout)',
        'test_notes': 'Two GPT calls: 1) generate SQL, 2) explain results. History supports multi-turn conversation.',
    },
    {
        'endpoint': '/api/fcr-insight',
        'method': 'POST',
        'type': 'AI',
        'description': 'GPT-powered coaching analysis for a single FCR.',
        'auth': 'Azure AD Token',
        'timeout': '30 seconds',
        'cache': 'No',
        'params': 'N/A',
        'request_body': '{ fcrId, coacheeName, coacheeRole, ta, region, sessionDuration, coachingDate, competencyScores, observations, actionItem, trendData }',
        'response': '{ insight: "4-section coaching narrative (Overall Assessment, Key Strengths, Priority Development Areas, Recommendation)" }',
        'status_codes': '200 (success), 400 (missing fcrId), 502 (AI error)',
        'test_notes': 'Generates structured coaching insights. References specific competencies and scores.',
    },
    {
        'endpoint': '/api/pins-score',
        'method': 'POST',
        'type': 'AI',
        'description': 'GPT scores PINS narrative sections (P/I/N/S) on 1-3 scale.',
        'auth': 'Azure AD Token',
        'timeout': '30 seconds',
        'cache': 'No',
        'params': 'N/A',
        'request_body': '{ fcrId, jobLevel }',
        'response': '{ sections: {...}, skills: {...}, summary: "...", gaps: {...}, trainingFlags: {...}, detectedLevel, hasPinsData: true }',
        'status_codes': '200 (success), 400 (missing fcrId), 404 (no PINS data), 502 (AI error)',
        'test_notes': 'Fetches PINS narratives from FCR and scores observable behaviors against FBMS framework.',
    },
    {
        'endpoint': '/api/pins-insight',
        'method': 'POST',
        'type': 'AI',
        'description': 'GPT generates insights from aggregated PINS summary data.',
        'auth': 'Azure AD Token',
        'timeout': '30 seconds',
        'cache': 'No',
        'params': 'N/A',
        'request_body': '{ summary: { kpi: {...}, sections: [...], levels: [...], reps: [...] } }',
        'response': '{ insight: "AI analysis of training coverage, priority areas, recommendations, at-risk reps" }',
        'status_codes': '200 (success), 400 (missing summary), 502 (AI error)',
        'test_notes': 'Uses /api/pins-summary data as input. Provides strategic coaching recommendations.',
    },
    {
        'endpoint': '/api/skill-trend-insight',
        'method': 'POST',
        'type': 'AI',
        'description': 'AI insights for skill proficiency trend analysis (12-month history).',
        'auth': 'Azure AD Token',
        'timeout': '30 seconds',
        'cache': 'No',
        'params': 'N/A',
        'request_body': '{ trendData: [...], pinsTrend: [...], latestSkill, skillChange, improving }',
        'response': '{ insight: "4-section trend analysis (Summary, Strongest Months, Concerns, Recommendations)" }',
        'status_codes': '200 (success), 502 (AI error)',
        'test_notes': 'Analyzes 12-month trend data. Identifies performance patterns and coaching focus areas.',
    },
]

for idx, api in enumerate(apis, 1):
    doc.add_heading(f'{idx}. {api["endpoint"]} [{api["method"]}]', 2)
    
    p = doc.add_paragraph()
    p.add_run('Type: ').bold = True
    p.add_run(api['type'])
    
    doc.add_paragraph(api['description'])
    
    # Create detailed info table
    info_table = doc.add_table(rows=11, cols=2)
    info_table.style = 'Light Grid Accent 1'
    
    rows = [
        ('Description', api['description']),
        ('Authentication', api['auth']),
        ('Timeout', api['timeout']),
        ('Caching', api['cache']),
        ('Parameters', api['params']),
        ('Request Body', api['request_body']),
        ('Response Format', api['response']),
        ('HTTP Status Codes', api['status_codes']),
        ('Test Notes', api['test_notes']),
    ]
    
    for i, (label, value) in enumerate(rows):
        row = info_table.rows[i]
        row.cells[0].text = label
        row.cells[1].text = value
        row.cells[0].paragraphs[0].runs[0].bold = True
    
    doc.add_paragraph()

# Testing Best Practices
doc.add_page_break()
doc.add_heading('Testing Best Practices', 1)

doc.add_heading('1. Authentication Testing', 2)
doc.add_paragraph('• All endpoints require an Azure AD token in the Authorization header')
doc.add_paragraph('• Format: "Bearer <token>"')
doc.add_paragraph('• Test invalid/expired tokens → expect 401 Unauthorized')

doc.add_heading('2. Parameter Validation', 2)
doc.add_paragraph('• Test with missing required parameters')
doc.add_paragraph('• Test with invalid data types (string instead of number, etc.)')
doc.add_paragraph('• Test boundary values (limit=0, limit=99999, offset=1000000)')
doc.add_paragraph('• Test special characters in search strings')

doc.add_heading('3. Performance Testing', 2)
doc.add_paragraph('• Monitor timeout behavior for analytics endpoints (28-55 seconds)')
doc.add_paragraph('• Test pagination with large offsets')
doc.add_paragraph('• Verify cache hit responses (_cached: true) are faster')
doc.add_paragraph('• Load test AI endpoints with concurrent requests')

doc.add_heading('4. Error Handling', 2)
doc.add_paragraph('• Test database connectivity failures → expect 500 errors')
doc.add_paragraph('• Test malformed JSON in request body → expect 400 errors')
doc.add_paragraph('• Test missing FCR IDs → expect 404 errors')
doc.add_paragraph('• Test Azure OpenAI service unavailability → expect 502 errors')

doc.add_heading('5. Data Validation', 2)
doc.add_paragraph('• Verify response schemas match documented format')
doc.add_paragraph('• Check data type consistency (numbers, dates, arrays)')
doc.add_paragraph('• Validate MSL-only filter applied (no non-MSL data returned)')
doc.add_paragraph('• Verify pagination totals match sum of returned rows')

doc.add_heading('6. Filter Testing', 2)
doc.add_paragraph('• Test each filter parameter individually')
doc.add_paragraph('• Test combinations of multiple filters')
doc.add_paragraph('• Test with empty/null filter values')
doc.add_paragraph('• Verify filter results are correct (spot-check data)')

doc.add_heading('7. AI Endpoint Testing', 2)
doc.add_paragraph('• Test malformed GPT responses → expect graceful error handling')
doc.add_paragraph('• Test SQL injection attempts in /api/ask → expect blocked queries')
doc.add_paragraph('• Verify AI always applies MSL-only filter to queries')
doc.add_paragraph('• Test conversation history in /api/ask with multiple turns')

# Environment & Configuration
doc.add_page_break()
doc.add_heading('Environment & Configuration', 1)

doc.add_heading('Development Environment', 2)
dev_config = [
    'Backend: http://localhost:8080',
    'Frontend: http://localhost:5173 (Vite dev server)',
    'Vite proxies /api/* to localhost:8080 automatically',
    'Redshift connection via .env file (REDSHIFT_HOST, REDSHIFT_USER, REDSHIFT_PASSWORD)',
    'Azure OpenAI via .env file (AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_DEPLOYMENT)',
]
for config in dev_config:
    doc.add_paragraph(config, style='List Bullet')

doc.add_heading('Production Environment', 2)
prod_config = [
    'URL: https://azr-iay-fcrai-spn-iacdev.azurewebsites.net',
    'Deployment: Azure App Service',
    'Database: Amazon Redshift (production cluster)',
    'AI: Azure OpenAI (production deployment)',
    'Auth: Azure AD (J&J corporate SSO)',
]
for config in prod_config:
    doc.add_paragraph(config, style='List Bullet')

# Glossary
doc.add_page_break()
doc.add_heading('Glossary', 1)

glossary_table = doc.add_table(rows=1, cols=2)
glossary_table.style = 'Light Grid Accent 1'
hdr = glossary_table.rows[0].cells
hdr[0].text = 'Term'
hdr[1].text = 'Definition'

glossary_items = [
    ('FCR', 'Field Coaching Report - A form completed by Field Directors after coaching an MSL'),
    ('MSL', 'Medical Science Liaison - J&J field representative who interacts with healthcare providers'),
    ('FBMS', 'J&J framework for evaluating MSL behaviors and competencies'),
    ('PINS', 'Planning, Investigating, Navigating, Securing - 4-step coaching framework'),
    ('TA', 'Therapeutic Area - ONC (Oncology), IMM (Immunology), NS (Neuroscience), SCG (Special Care & General)'),
    ('WWID', 'Unique employee ID for identifying MSLs'),
    ('Redshift', 'Amazon Redshift - J&J\'s enterprise data warehouse'),
    ('GPT', 'Generative Pre-trained Transformer - Azure OpenAI AI service used for insights'),
    ('TTL', 'Time-To-Live - Cache expiration duration'),
]

for term, definition in glossary_items:
    row = glossary_table.add_row()
    row.cells[0].text = term
    row.cells[1].text = definition

# Save document
output_path = r'c:\Users\GReddy51\Downloads\fcr-ai-for\fcr-ai-sso\FCR_AI_Backend_API_Testing_Guide.docx'
doc.save(output_path)
print(f'✓ Word document created successfully: {output_path}')
