import pool from './db.js';

// First, get a valid FCR ID
const res = await pool.query(`
  SELECT DISTINCT survey_target_id, rep_first_nm, rep_last_nm
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl = 'SURVEY'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')
  LIMIT 1
`);

if (res.rows.length > 0) {
  console.log('Valid FCR IDs:');
  console.log(res.rows[0]);
}

await pool.end();
