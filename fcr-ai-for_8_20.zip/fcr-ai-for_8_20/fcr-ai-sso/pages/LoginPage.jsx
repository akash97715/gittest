import jnjLogo from '../assets/logo.png';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../authConfig';
import { useEffect } from 'react';
import { telemetryService } from '../services/telemetryService';

export default function LoginPage() {
  const { instance } = useMsal();

  // Track page view on mount
  useEffect(() => {
    console.log('[LoginPage] Component mounted, tracking page view');
    telemetryService.trackPageView('login', '/login');
    
    return () => {
      console.log('[LoginPage] Component unmounting, tracking page exit');
      telemetryService.trackPageExit('login', 0);
    };
  }, []);

  const handleLogin = () => {
    console.log('[LoginPage] Sign in button clicked, tracking event');
    telemetryService.trackButtonClick('sign_in_button', { page: 'login' });
    instance.loginPopup(loginRequest).catch((e) => {
      console.error(e);
    });
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#f0ede8',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Inter', sans-serif",
      padding: '32px 16px',
    }}>

      {/* J&J Logo */}
      <img
        src={jnjLogo}
        alt="Johnson & Johnson"
        style={{ height: 52, marginBottom: 28, objectFit: 'contain' }}
      />

      {/* Card */}
      <div style={{
        background: '#ffffff',
        borderRadius: 16,
        boxShadow: '0 4px 32px rgba(0,0,0,0.10)',
        padding: '48px 52px 36px',
        maxWidth: 540,
        width: '100%',
        textAlign: 'center',
      }}>

        {/* App title */}
        <h1 style={{
          fontSize: 28,
          fontWeight: 800,
          color: '#1a1a2e',
          margin: '0 0 4px',
          letterSpacing: '-0.5px',
          lineHeight: 1.2,
        }}>
          Field Coaching Report
        </h1>
        <h2 style={{
          fontSize: 18,
          fontWeight: 600,
          color: '#c41230',
          margin: '0 0 6px',
          letterSpacing: '-0.2px',
        }}>
          AI-Powered Analytics &amp; Insights
        </h2>

        {/* Powered by */}
        <p style={{ fontSize: 13, color: '#6b7280', margin: '0 0 24px' }}>
          powered by <strong style={{ color: '#374151' }}>Agentic AI</strong>
        </p>

        {/* Divider */}
        <div style={{ height: 1, background: '#f3f4f6', margin: '0 0 24px' }} />

        {/* Description */}
        <p style={{
          fontSize: 14,
          color: '#4b5563',
          lineHeight: 1.7,
          margin: '0 0 32px',
          maxWidth: 380,
          marginLeft: 'auto',
          marginRight: 'auto',
        }}>
          Sign in securely with your J&amp;J account to explore Field Coaching Report insights — from adoption tracking to AI-driven coaching quality analysis.
        </p>

        {/* Sign in button */}
        <button
          id="btn-sign-in"
          onClick={handleLogin}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            background: 'linear-gradient(135deg, #c41230 0%, #9e0e26 100%)',
            color: '#fff',
            border: 'none',
            borderRadius: 30,
            padding: '14px 52px',
            fontSize: 15,
            fontWeight: 700,
            cursor: 'pointer',
            fontFamily: 'inherit',
            boxShadow: '0 4px 16px rgba(196,18,48,0.35)',
            transition: 'all 0.2s',
            letterSpacing: '0.01em',
          }}
          onMouseOver={e => {
            e.currentTarget.style.transform = 'translateY(-1px)';
            e.currentTarget.style.boxShadow = '0 6px 20px rgba(196,18,48,0.45)';
          }}
          onMouseOut={e => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(196,18,48,0.35)';
          }}
        >
          Sign in
        </button>

        {/* Links */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          marginTop: 32,
          paddingTop: 24,
          borderTop: '1px solid #f3f4f6',
        }}>
          {['Privacy Policy', 'Legal Notice', 'Help & Support'].map((link, i, arr) => (
            <span key={link} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <a href="#" style={{ fontSize: 12, color: '#c41230', textDecoration: 'none', fontWeight: 500 }}
                onMouseOver={e => e.target.style.textDecoration = 'underline'}
                onMouseOut={e => e.target.style.textDecoration = 'none'}
              >{link}</a>
              {i < arr.length - 1 && <span style={{ color: '#d1d5db', fontSize: 12 }}>|</span>}
            </span>
          ))}
        </div>

        {/* Warning notice */}
        <div style={{
          marginTop: 20,
          padding: '14px 16px',
          background: '#fafafa',
          borderRadius: 8,
          border: '1px solid #f3f4f6',
          textAlign: 'left',
        }}>
          <p style={{
            fontSize: 10,
            color: '#9ca3af',
            lineHeight: 1.7,
            margin: 0,
            textTransform: 'uppercase',
            letterSpacing: '0.03em',
          }}>
            <strong>Warning Notice:</strong> This system is restricted solely to Johnson &amp; Johnson users for legitimate business only. The actual or attempted unauthorized access, use or modification of this system is strictly prohibited by Johnson &amp; Johnson. Unauthorized users are subject to company disciplinary proceedings and/or criminal and civil penalties under state, federal or other applicable domestic and foreign laws. The use of this system may be monitored and recorded for administrative and security reasons. &copy; Information Technology Shared Services, a division of Johnson and Johnson Services, Inc. 2026
          </p>
        </div>
      </div>
    </div>
  );
}
