#!/usr/bin/env python3
"""
Redshift Connectivity & Permissions Diagnostic Report
"""

import psycopg2
from datetime import datetime

config = {
    'host': 'itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com',
    'port': 5439,
    'database': 'awprdrsdb',
    'user': 'dmp_fcr_ai_development_prod_read',
    'password': 'fPmzkv-12rfF',
    'sslmode': 'require'
}

print("\n" + "=" * 100)
print("REDSHIFT CONNECTIVITY & PERMISSIONS DIAGNOSTIC REPORT")
print("=" * 100)
print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Service Account: {config['user']}")

print("\n" + "=" * 100)
print("ISSUE IDENTIFIED")
print("=" * 100)

try:
    conn = psycopg2.connect(**config)
    cursor = conn.cursor()
    
    print("\n✓ CONNECTION STATUS: SUCCESS")
    print("  ✓ Can connect to Redshift database")
    
    # Get user info
    cursor.execute("SELECT current_database(), current_user")
    db, user = cursor.fetchone()
    print(f"  ✓ Connected as: {user}")
    print(f"  ✓ Database: {db}")
    
    # Check role memberships
    print("\n" + "-" * 100)
    print("USER ROLES & MEMBERSHIPS")
    print("-" * 100)
    
    cursor.execute("""
        SELECT rolname FROM pg_roles 
        WHERE pg_has_role(current_user, oid, 'member')
        ORDER BY rolname
    """)
    
    roles = cursor.fetchall()
    print(f"\nThis user is a member of these roles:")
    for role in roles:
        print(f"  • {role[0]}")
    
    # Check schema access
    print("\n" + "-" * 100)
    print("SCHEMA PERMISSIONS")
    print("-" * 100)
    
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('information_schema', 'pg_catalog', 'pg_internal')
        ORDER BY schema_name
    """)
    
    schemas = cursor.fetchall()
    print(f"\nAccessible schemas ({len(schemas)}):")
    for schema in schemas:
        print(f"  • {schema[0]}")
    
    # Try to access ODP schema
    print("\n" + "-" * 100)
    print("ODP SCHEMA ACCESS ATTEMPT")
    print("-" * 100)
    
    try:
        cursor.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'odp'
            LIMIT 5
        """)
        tables = cursor.fetchall()
        if tables:
            print(f"\n✓ ODP schema found! Tables in ODP schema:")
            for table in tables:
                print(f"  • {table[0]}")
        else:
            print("\n✗ ODP schema exists but is empty or not accessible")
    except psycopg2.Error as e:
        print(f"\n✗ ERROR accessing ODP schema: {e}")
    
    # Direct table access attempt
    print("\n" + "-" * 100)
    print("TABLE ACCESS ATTEMPT: odp.dp_cust_pers_engagement_dly")
    print("-" * 100)
    
    try:
        cursor.execute("""
            SELECT COUNT(*) FROM odp.dp_cust_pers_engagement_dly LIMIT 1
        """)
        result = cursor.fetchone()
        print(f"\n✓ Table is accessible! Row count: {result[0]:,}")
        
    except psycopg2.Error as e:
        error_msg = str(e)
        print(f"\n✗ ERROR: {error_msg}")
        
        if "permission denied" in error_msg.lower():
            print("\n" + "!" * 100)
            print("PERMISSION ISSUE DETECTED")
            print("!" * 100)
            print("""
The service account user 'dmp_fcr_ai_development_prod_read' does NOT have 
read permissions on the ODP table 'dp_cust_pers_engagement_dly'.

RECOMMENDED SOLUTIONS:

1. GRANT READ ACCESS (Contact Redshift Admin):
   
   As a Redshift superuser, run:
   
   --- Connect as superuser and execute: ---
   GRANT USAGE ON SCHEMA odp TO dmp_fcr_ai_development_prod_read;
   GRANT SELECT ON ALL TABLES IN SCHEMA odp TO dmp_fcr_ai_development_prod_read;
   ALTER DEFAULT PRIVILEGES IN SCHEMA odp 
   GRANT SELECT ON TABLES TO dmp_fcr_ai_development_prod_read;
   
2. OR USE EXISTING READ-ONLY ROLE:
   
   Ask your Redshift admin if there's an existing read-only role that has 
   access to ODP data. Example:
   
   GRANT ROLE <existing_odp_read_role> TO dmp_fcr_ai_development_prod_read;

3. OR CREATE NEW DEDICATED ROLE:
   
   CREATE ROLE fcr_app_read;
   GRANT USAGE ON SCHEMA odp TO fcr_app_read;
   GRANT SELECT ON ALL TABLES IN SCHEMA odp TO fcr_app_read;
   GRANT fcr_app_read TO dmp_fcr_ai_development_prod_read;

ACTIONS TO TAKE:
✓ Contact your Redshift/AWS data team
✓ Reference this diagnostic report
✓ Request GRANT SELECT on odp.dp_cust_pers_engagement_dly
✓ Once permissions are granted, re-run this test
""")
    
    cursor.close()
    conn.close()
    
except Exception as e:
    print(f"\n✗ CRITICAL ERROR: {e}")
    print("\nCannot connect to Redshift. Check:")
    print("  • Network connectivity to AWS Redshift endpoint")
    print("  • Credentials are correct (.env file)")
    print("  • Service account is not locked/expired")
    print("  • Security groups allow connection on port 5439")

print("\n" + "=" * 100)
print("END OF DIAGNOSTIC REPORT")
print("=" * 100 + "\n")
