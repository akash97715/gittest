import pool from './db.js';

// 1. All distinct engagement titles (form types)
const t1 = await pool.query(`
  SELECT engagement_title, COUNT(DISTINCT survey_target_id) AS fcrs
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%' AND survey_target_id IS NOT NULL
  GROUP BY 1 ORDER BY fcrs DESC LIMIT 30
`);
console.log('\n=== ENGAGEMENT TITLES (form types) ===');
t1.rows.forEach(x => console.log(JSON.stringify(x)));

// 2. All distinct question texts with counts
const t2 = await pool.query(`
  SELECT survey_question_text, COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND survey_question_text IS NOT NULL AND survey_question_text != ''
  GROUP BY 1 ORDER BY cnt DESC LIMIT 50
`);
console.log('\n=== TOP QUESTION TEXTS ===');
t2.rows.forEach(x => console.log(JSON.stringify({ q: x.survey_question_text?.substring(0,100), cnt: x.cnt })));

// 3. Session duration values
const t3 = await pool.query(`
  SELECT survey_target_session_duration, COUNT(DISTINCT survey_target_id) AS fcrs
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%' AND survey_target_id IS NOT NULL
    AND survey_target_session_duration IS NOT NULL
  GROUP BY 1 ORDER BY fcrs DESC LIMIT 20
`);
console.log('\n=== SESSION DURATIONS ===');
t3.rows.forEach(x => console.log(JSON.stringify(x)));

// 4. Scientific exchange / compliance question
const t4 = await pool.query(`
  SELECT survey_question_text, survey_question_response, COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND (LOWER(survey_question_text) LIKE '%scientific%' OR LOWER(survey_question_text) LIKE '%complian%'
      OR LOWER(survey_question_text) LIKE '%non-promot%' OR LOWER(survey_question_text) LIKE '%adverse%')
  GROUP BY 1, 2 ORDER BY cnt DESC LIMIT 20
`);
console.log('\n=== SCIENTIFIC/COMPLIANCE QUESTIONS ===');
t4.rows.forEach(x => console.log(JSON.stringify({ q: x.survey_question_text?.substring(0,80), r: x.survey_question_response, cnt: x.cnt })));

// 5. Training needed questions
const t5 = await pool.query(`
  SELECT survey_question_text, survey_question_response, COUNT(*) AS cnt
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND LOWER(survey_question_text) LIKE '%training%'
  GROUP BY 1, 2 ORDER BY cnt DESC LIMIT 20
`);
console.log('\n=== TRAINING NEEDED QUESTIONS ===');
t5.rows.forEach(x => console.log(JSON.stringify({ q: x.survey_question_text?.substring(0,80), r: x.survey_question_response, cnt: x.cnt })));

// 6. Free-text observation fields (response_text samples)
const t6 = await pool.query(`
  SELECT survey_question_text, LENGTH(survey_question_response_text) AS txt_len
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL
    AND survey_question_response_text IS NOT NULL
    AND LENGTH(survey_question_response_text) > 50
  ORDER BY txt_len DESC LIMIT 10
`);
console.log('\n=== RICHEST FREE-TEXT FIELDS ===');
t6.rows.forEach(x => console.log(JSON.stringify({ q: x.survey_question_text?.substring(0,80), txt_len: x.txt_len })));

// 7. Available coach (ownr) data
const t7 = await pool.query(`
  SELECT ownr_id, COUNT(DISTINCT survey_target_id) AS fcrs_written, COUNT(DISTINCT rep_wwid) AS reps_coached
  FROM odp.dp_cust_pers_engagement_dly
  WHERE chnl ILIKE '%survey%'
    AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
    AND survey_target_id IS NOT NULL AND ownr_id IS NOT NULL
  GROUP BY 1 ORDER BY fcrs_written DESC LIMIT 10
`);
console.log('\n=== TOP COACHES (by FCR count) ===');
t7.rows.forEach(x => console.log(JSON.stringify(x)));

process.exit(0);
