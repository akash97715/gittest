import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from './db.js';
import telemetryPool from './telemetryDb.js';
import * as publisher from './backend/telemetry/publisher.js';
import { VALID_EVENT_TYPES, TELEMETRY_CONFIG } from './backend/telemetry/constants.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ── MSL/VESE-only filter (applied globally to all endpoints) ──
const MSL_FILTER = `(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`;

// ── In-memory TTL cache ──────────────────────────────────────
const _cache = new Map();
const CACHE_TTL      = 5 * 60 * 1000;   // 5 min  — summary/kpis
const CACHE_TTL_FCR  = 2 * 60 * 1000;   // 2 min  — FCR list (changes less often)
const CACHE_TTL_DETAIL = 10 * 60 * 1000; // 10 min — FCR detail rows (static per FCR)
function cacheGet(key) {
  const e = _cache.get(key);
  if (!e) return null;
  if (Date.now() > e.exp) { _cache.delete(key); return null; }
  return e.data;
}
function cacheSet(key, data, ttl = CACHE_TTL) {
  _cache.set(key, { data, exp: Date.now() + ttl });
}

const app = express();
const port = process.env.PORT || 8080;

app.use(express.json());

// ── Test connection ──────────────────────────────────────────
app.get('/api/ping', async (req, res) => {
  try {
    const result = await pool.query('SELECT 1 AS ok, current_database() AS db, current_user AS usr');
    res.json({ connected: true, ...result.rows[0] });
  } catch (err) {
    res.status(500).json({ connected: false, error: err.message });
  }
});

// ── List all schemas + tables (for exploration) ──────────────
app.get('/api/schema', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT table_schema, table_name
      FROM information_schema.tables
      WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'pg_internal')
      ORDER BY table_schema, table_name
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── List columns for a given table ───────────────────────────
app.get('/api/schema/:schema/:table', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT column_name, data_type, ordinal_position
      FROM information_schema.columns
      WHERE table_schema = $1 AND table_name = $2
      ORDER BY ordinal_position
    `, [req.params.schema, req.params.table]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Telemetry endpoint ───────────────────────────────────────
// Receive events from frontend, validate, publish to telemetry system
// Fire-and-forget: Returns 200 immediately, never blocks user request
app.post('/api/telemetry', async (req, res) => {
  console.log('[TELEMETRY] POST /api/telemetry received');
  console.log('[TELEMETRY] TELEMETRY_CONFIG.ENABLED:', TELEMETRY_CONFIG.ENABLED);
  
  if (!TELEMETRY_CONFIG.ENABLED) {
    console.log('[TELEMETRY] Telemetry is disabled, returning 200');
    return res.status(200).json({ received: 0, message: 'Telemetry disabled' });
  }

  const { events } = req.body;
  console.log('[TELEMETRY] Received events count:', events?.length);
  
  // Validate events array
  if (!Array.isArray(events) || events.length === 0) {
    console.log('[TELEMETRY] Invalid events array');
    return res.status(400).json({ error: 'events must be a non-empty array' });
  }

  // Validate event types
  const invalid = events.filter(e => !VALID_EVENT_TYPES.includes(e.event_type));
  if (invalid.length > 0) {
    console.log('[TELEMETRY] Invalid event types found:', invalid.map(e => e.event_type));
    return res.status(400).json({ 
      error: 'Invalid event types',
      count: invalid.length,
      samples: invalid.slice(0, 3).map(e => e.event_type)
    });
  }

  console.log('[TELEMETRY] All events validated. Publishing...');
  // Fire and forget: publish asynchronously, never block response
  publisher.publish(events).catch(err => {
    console.error('[TELEMETRY] Publish error (async):', err.message, err.stack);
  });

  console.log('[TELEMETRY] Returning 200 immediately (fire-and-forget)');
  // Return 200 immediately
  res.status(200).json({ received: events.length });
});

// ── /api/summary  — Dashboard hero KPI card ─────────────────
app.get('/api/summary', async (req, res) => {
  const ck = `summary:${JSON.stringify(req.query)}`;
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });
  try {
    const { ta, timeframe, region, from: fromDate, to: toDate } = req.query;
    const conditions = [
      `chnl = 'SURVEY'`,
      `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
      `survey_target_id IS NOT NULL`,
      MSL_FILTER,
    ];
    const params = [];

    if (ta) {
      params.push(ta.toUpperCase());
      conditions.push(`ta = $${params.length}`);
    }
    if (timeframe && timeframe !== 'custom') {
      const d = new Date(); d.setDate(d.getDate() - parseInt(timeframe));
      params.push(d.toISOString().slice(0, 10));
      conditions.push(`acty_dt >= $${params.length}::date`);
    } else if (!timeframe && !fromDate && !toDate) {
      // Apply default 6-month filter when no timeframe is specified
      const d = new Date(); d.setDate(d.getDate() - 180);
      params.push(d.toISOString().slice(0, 10));
      conditions.push(`acty_dt >= $${params.length}::date`);
    }
    if (region) {
      params.push(region);
      conditions.push(`reg_nm ILIKE $${params.length}`);
    }
    if (fromDate) {
      params.push(fromDate);
      conditions.push(`acty_dt >= $${params.length}::date`);
    }
    if (toDate) {
      params.push(toDate);
      conditions.push(`acty_dt <= $${params.length}::date`);
    }

    const where = conditions.join(' AND ');

    const sql = `
      SELECT
        COUNT(DISTINCT survey_target_id)                           AS total_fcrs,
        COUNT(DISTINCT rep_wwid)                                   AS total_reps,
        COUNT(DISTINCT rep_wwid)                                   AS msl_covered,
        COUNT(DISTINCT rep_wwid)                                   AS required_fcrs,
        ROUND(
          1.0 * COUNT(DISTINCT survey_target_id)
          / NULLIF(COUNT(DISTINCT rep_wwid), 0), 1
        )                                                          AS fcrs_per_rep,
        COUNT(DISTINCT CASE
          WHEN LOWER(survey_target_status) LIKE '%submitted%'
          THEN survey_target_id END)                               AS submitted_fcrs,
        ROUND(
          100.0 * COUNT(DISTINCT CASE
            WHEN LOWER(survey_target_status) LIKE '%submitted%'
            THEN survey_target_id END)
          / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1
        )                                                          AS submitted_pct,
        COUNT(DISTINCT CASE
          WHEN LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%'
          THEN survey_target_id END)                               AS draft_fcrs,
        COUNT(DISTINCT CASE
          WHEN UPPER(survey_question_text) LIKE '%TRAINING NEEDED%' AND survey_question_response = 'Yes'
          THEN survey_target_id END)                               AS flagged_fcrs,
        ROUND(
          100.0 * COUNT(DISTINCT CASE
            WHEN UPPER(survey_question_text) LIKE '%TRAINING NEEDED%' AND survey_question_response = 'Yes'
            THEN survey_target_id END)
          / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1
        )                                                          AS flagged_pct,
        COUNT(DISTINCT CASE
          WHEN UPPER(survey_question_text) LIKE '%TRAINING NEEDED%' AND survey_question_response = 'Yes'
          THEN rep_wwid END)                                       AS reps_needing_training,
        ROUND(
          100.0 * COUNT(DISTINCT CASE
            WHEN UPPER(survey_question_text) LIKE '%TRAINING NEEDED%' AND survey_question_response = 'Yes'
            THEN rep_wwid END)
          / NULLIF(COUNT(DISTINCT rep_wwid), 0), 1
        )                                                          AS reps_training_pct
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
    `;

    // FCRs by TA breakdown
    const taSql = `
      SELECT
        ta,
        COUNT(DISTINCT survey_target_id) AS fcrs,
        COUNT(DISTINCT rep_wwid)          AS reps
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      GROUP BY ta
      ORDER BY fcrs DESC
    `;

    // FCRs by region
    const regionSql = `
      SELECT
        COALESCE(reg_nm, 'Unknown') AS region,
        COUNT(DISTINCT survey_target_id) AS fcrs
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
        AND reg_nm IS NOT NULL
      GROUP BY reg_nm
      ORDER BY fcrs DESC
      LIMIT 8
    `;

    // FCRs trend — last 6 quarters by quarter (stacked: coached + repeats)
    const trendSql = `
      WITH quarterly_data AS (
        SELECT
          DATE_TRUNC('quarter', acty_dt) AS quarter_dt,
          COUNT(DISTINCT survey_target_id) AS total_fcrs,
          COUNT(DISTINCT rep_wwid) AS coached
        FROM odp.dp_cust_pers_engagement_dly
        WHERE ${where}
          AND acty_dt >= ADD_MONTHS(CURRENT_DATE, -24)
        GROUP BY DATE_TRUNC('quarter', acty_dt)
      )
      SELECT
        TO_CHAR(quarter_dt, '"Q"Q YYYY') AS quarter,
        quarter_dt,
        coached,
        GREATEST(total_fcrs - coached, 0) AS repeats,
        total_fcrs
      FROM quarterly_data
      ORDER BY quarter_dt ASC
    `;
    
    // Take the last 6 quarters after ordering
    const [kpi, ta_rows, region_rows, allTrendRows] = await Promise.all([
      pool.query(sql, params),
      pool.query(taSql, params),
      pool.query(regionSql, params),
      pool.query(trendSql, params),
    ]);

    const trend_rows = { rows: allTrendRows.rows.slice(-6) };
    const payload = { kpi: kpi.rows[0], by_ta: ta_rows.rows, by_region: region_rows.rows, trend: trend_rows.rows };
    cacheSet(ck, payload);
    res.json(payload);
  } catch (err) {
    console.error('/api/summary error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/fcrs  — FCR listing with filters ───────────────────
// Query params: ta, status, timeframe (days), search, limit, offset
app.get('/api/fcrs', async (req, res) => {
  // Cache check — skip Redshift entirely if result is fresh
  const ck = `fcrs:${JSON.stringify(req.query)}`;
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });

  // Set a 25-second timeout so slow Redshift scans don't hang the request
  res.setTimeout(28000, () => {
    if (!res.headersSent) res.status(504).json({ error: 'Request timed out — please try again' });
  });
  try {
    const { ta, status, timeframe, search, limit = 100, offset = 0, pinsOnly } = req.query;

    // Status label → SQL condition fragment (survey_target_status Veeva values)
    const STATUS_SQL = {
      'Draft':           `(LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%')`,
      'Submitted':       `(LOWER(survey_target_status) LIKE '%submitted%')`,
      'Late Submission': `(LOWER(survey_target_status) LIKE '%late%' AND LOWER(survey_target_status) LIKE '%submission%')`,
    };

    const conditions = [
      `chnl = 'SURVEY'`,
      `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
      `survey_target_id IS NOT NULL`,
      MSL_FILTER,
    ];
    const params = [];

    if (ta) {
      params.push(ta.toUpperCase());
      conditions.push(`ta = $${params.length}`);
    }
    if (status && STATUS_SQL[status]) {
      conditions.push(STATUS_SQL[status]);
    }
    if (timeframe && timeframe !== 'custom') {
      const d = new Date(); d.setDate(d.getDate() - parseInt(timeframe));
      params.push(d.toISOString().slice(0, 10));
      conditions.push(`acty_dt >= $${params.length}::date`);
    }
    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      const idx = params.length;
      conditions.push(`(LOWER(rep_first_nm) LIKE $${idx} OR LOWER(rep_last_nm) LIKE $${idx} OR LOWER(survey_target_id) LIKE $${idx} OR LOWER(chnl_engagement_id_value) LIKE $${idx})`);
    }
    if (pinsOnly === '1' || pinsOnly === 'true') {
      conditions.push(`(LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')`);
    }

    const where = conditions.join(' AND ');

    // One row per FCR (GROUP BY to deduplicate question-level rows)
    const dataSql = `
      SELECT
        survey_target_id                                        AS fcr_id,
        chnl_engagement_id_value                                AS survey_id,
        engagement_title,
        rep_wwid                                                AS coachee_wwid,
        rep_first_nm                                            AS coachee_first,
        rep_last_nm                                             AS coachee_last,
        NULLIF(TRIM(rep_desig), '')                             AS coachee_role,
        ownr_id                                                 AS field_director_id,
        ta,
        reg_nm                                                  AS region,
        distrc_nm                                               AS district,
        terr_nm                                                 AS territory,
        survey_status                                           AS status_raw,
        survey_target_status,
        CASE
          WHEN LOWER(survey_target_status) LIKE '%late%' AND LOWER(survey_target_status) LIKE '%submission%' THEN 'Late Submission'
          WHEN LOWER(survey_target_status) LIKE '%submitted%'                                                 THEN 'Submitted'
          WHEN LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%'       THEN 'Draft'
          ELSE COALESCE(NULLIF(TRIM(survey_status), ''), 'Draft')
        END                                                     AS status,
        MIN(acty_dt)                                            AS coaching_date,
        survey_target_created_date                              AS created_date,
        survey_target_last_modified_date                        AS modified_date,
        survey_target_start_date,
        survey_target_last_modified_date                        AS survey_target_completed_date,
        survey_target_session_duration                          AS session_duration,
        DATEDIFF('day', survey_target_start_date, survey_target_last_modified_date) AS days_to_submit,
        DATEDIFF('day', MIN(acty_dt), CURRENT_DATE)             AS days_since_coaching
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      GROUP BY
        survey_target_id, chnl_engagement_id_value, engagement_title,
        rep_wwid, rep_first_nm, rep_last_nm, rep_desig,
        ownr_id, ta, reg_nm, distrc_nm, terr_nm,
        survey_status, survey_target_status, survey_target_created_date,
        survey_target_last_modified_date, survey_target_start_date,
        survey_target_session_duration
      ORDER BY coaching_date DESC NULLS LAST
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
    params.push(parseInt(limit), parseInt(offset));

    // Count query (no limit/offset)
    const countSql = `
      SELECT COUNT(DISTINCT survey_target_id) AS total
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
    `;
    const countParams = params.slice(0, -2); // remove limit/offset

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataSql, params),
      pool.query(countSql, countParams),
    ]);

    const payload = {
      total: parseInt(countResult.rows[0].total),
      rows:  dataResult.rows,
    };
    cacheSet(ck, payload, CACHE_TTL_FCR);
    res.json(payload);
  } catch (err) {
    console.error('/api/fcrs error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/fcr/:id  — Full FCR detail (all question rows) ──────
app.get('/api/fcr/:id', async (req, res) => {
  const ck = `fcr_detail:${req.params.id}`;
  const hit = cacheGet(ck);
  if (hit) return res.json(hit);

  res.setTimeout(25000, () => {
    if (!res.headersSent) res.status(504).json({ error: 'Request timed out — please try again' });
  });
  try {
    const sql = `
      SELECT
        survey_target_id, engagement_title,
        rep_wwid, rep_first_nm, rep_last_nm,
        NULLIF(TRIM(rep_desig), '') AS rep_desig,
        ownr_id, ta, reg_nm, distrc_nm, terr_nm,
        survey_status,
        survey_target_status,
        chnl_engagement_id_value,
        survey_target_session_duration,
        survey_target_created_date,
        survey_target_last_modified_date,
        survey_target_start_date,
        survey_target_last_modified_date AS survey_target_completed_date,
        survey_target_action_item,
        survey_target_previous_action_item,
        survey_question_name,
        survey_question_text,
        survey_question_response,
        survey_question_response_text,
        survey_question_answer_choice,
        survey_question_order,
        MIN(acty_dt) OVER (PARTITION BY survey_target_id) AS coaching_date
      FROM odp.dp_cust_pers_engagement_dly
      WHERE survey_target_id = $1
        AND chnl = 'SURVEY'
        AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
      ORDER BY survey_question_order NULLS LAST, survey_question_name
    `;
    const r = await pool.query(sql, [req.params.id]);
    if (r.rows.length === 0) return res.status(404).json({ error: 'FCR not found' });
    cacheSet(ck, r.rows, CACHE_TTL_DETAIL);
    res.json(r.rows);
  } catch (err) {
    console.error('/api/fcr/:id error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/rep-trend/:wwid  — Last 20 FCR avg FBMS scores for a rep ──
app.get('/api/rep-trend/:wwid', async (req, res) => {
  try {
    const sql = `
      SELECT
        survey_target_id AS fcr_id,
        MIN(acty_dt) AS coaching_date,
        ROUND(AVG(CASE
          WHEN survey_question_response = 'Expert'                 THEN 4
          WHEN survey_question_response = 'Clear Strength'         THEN 4
          WHEN survey_question_response = 'Advanced'               THEN 3
          WHEN survey_question_response = 'Emerging Strength'      THEN 3
          WHEN survey_question_response = 'Skilled'                THEN 2
          WHEN survey_question_response = 'Development Need'       THEN 2
          WHEN survey_question_response = 'Awareness'              THEN 1
          WHEN survey_question_response = 'Clear Development Need' THEN 1
        END), 2) AS avg_score,
        COUNT(DISTINCT CASE
          WHEN survey_question_response IN ('Expert','Advanced','Skilled','Awareness',
            'Clear Strength','Emerging Strength','Development Need','Clear Development Need')
          THEN survey_question_name END) AS rated_behaviors
      FROM odp.dp_cust_pers_engagement_dly
      WHERE rep_wwid = $1
        AND chnl = 'SURVEY'
        AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
        AND ${MSL_FILTER}
        AND survey_question_response IN (
          'Expert','Advanced','Skilled','Awareness',
          'Clear Strength','Emerging Strength','Development Need','Clear Development Need'
        )
      GROUP BY survey_target_id
      HAVING AVG(CASE
        WHEN survey_question_response = 'Expert'                 THEN 4
        WHEN survey_question_response = 'Clear Strength'         THEN 4
        WHEN survey_question_response = 'Advanced'               THEN 3
        WHEN survey_question_response = 'Emerging Strength'      THEN 3
        WHEN survey_question_response = 'Skilled'                THEN 2
        WHEN survey_question_response = 'Development Need'       THEN 2
        WHEN survey_question_response = 'Awareness'              THEN 1
        WHEN survey_question_response = 'Clear Development Need' THEN 1
      END) IS NOT NULL
      ORDER BY MIN(acty_dt) DESC
      LIMIT 20
    `;
    const r = await pool.query(sql, [req.params.wwid]);
    res.json(r.rows.reverse()); // oldest first for chart
  } catch (err) {
    console.error('/api/rep-trend error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/kpis  — Summary numbers for hero card ──────────────
app.get('/api/kpis', async (req, res) => {
  const ck = 'kpis:global';
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });
  try {
    const sql = `
      SELECT
        COUNT(DISTINCT survey_target_id)                          AS total_fcrs,
        COUNT(DISTINCT rep_wwid)                                  AS total_reps,
        COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END) AS submitted,
        ROUND(
          100.0 * COUNT(DISTINCT CASE WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN survey_target_id END)
          / NULLIF(COUNT(DISTINCT survey_target_id), 0), 1
        )                                                         AS submitted_pct,
        ROUND(AVG(
          CASE WHEN LOWER(survey_target_status) LIKE '%submitted%'
          THEN DATEDIFF('day', survey_target_start_date, survey_target_last_modified_date)
          END
        ), 1)                                                     AS avg_days_to_submit
      FROM odp.dp_cust_pers_engagement_dly
      WHERE chnl = 'SURVEY'
        AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
        AND survey_target_id IS NOT NULL
        AND ${MSL_FILTER}
    `;
    const complianceSql = `
      SELECT
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response = 'Yes' THEN 1 END)
          / NULLIF(COUNT(*), 0), 1) AS compliance_rate,
        COUNT(CASE WHEN survey_question_response = 'No' THEN 1 END) AS non_compliant_count
      FROM odp.dp_cust_pers_engagement_dly
      WHERE chnl = 'SURVEY'
        AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
        AND survey_target_id IS NOT NULL
        AND ${MSL_FILTER}
        AND LOWER(survey_question_text) LIKE '%field observation%'
        AND survey_question_response IN ('Yes','No')
    `;
    const [r, cr] = await Promise.all([pool.query(sql), pool.query(complianceSql)]);
    const payload = { ...r.rows[0], ...cr.rows[0], submitted: r.rows[0]?.submitted, submitted_pct: r.rows[0]?.submitted_pct };
    cacheSet(ck, payload);
    res.json(payload);
  } catch (err) {
    console.error('/api/kpis error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/ask  — Azure OpenAI text-to-SQL conversational AI ──
const SCHEMA_CONTEXT = `
You are an AI assistant for the FCR AI Insights dashboard at Johnson & Johnson.
You have access to ONE table in Amazon Redshift:

TABLE: odp.dp_cust_pers_engagement_dly

ALWAYS apply these base filters in every query:
  chnl = 'SURVEY'
  AND (LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')
  AND survey_target_id IS NOT NULL
  AND (LOWER(engagement_title) LIKE '%msl%' OR LOWER(engagement_title) LIKE '%vese%')

KEY COLUMNS:
  survey_target_id        — internal engagement lookup key (use for JOIN/WHERE)
  chnl_engagement_id_value — unique Survey ID (display this to users as the FCR/Survey ID)
  rep_wwid                — rep (coachee) unique ID
  rep_first_nm            — rep first name
  rep_last_nm             — rep last name
  rep_desig               — rep designation/title (raw, may be inconsistent)
  ownr_id                 — field director Salesforce ID
  ta                      — therapeutic area: IMM, ONC, NS, SCG
  acty_dt                 — coaching activity date (DATE)
  reg_nm                  — region name
  distrc_nm               — district name
  terr_nm                 — territory name
  engagement_title        — FCR form name
  survey_target_status    — engagement status: Saved_vod (draft), Submitted_vod (submitted on time), Late Submission_vod (submitted late), Pending_vod (pending)
  survey_target_start_date          — timestamp when survey engagement began on iConnect
  survey_target_last_modified_date   — timestamp when survey engagement was last modified/submitted (use as completion date)
  survey_question_text    — question asked in the coaching form
  survey_question_response — rated response (e.g. Learning, Applying, Leading, Clear Strength, Emerging Strength, Development Need, Clear Development Need)
  survey_question_response_text — free-text written by the field director
  company_nm              — company name
  brand                   — product brand

LEAD MODEL questions (survey_question_text exactly 'Learn','Engage','Advance','Deliver'):
  Filter: LOWER(survey_question_text) IN ('learn','engage','advance','deliver')
    AND survey_question_response IN ('Learning','Applying','Leading')
  Score: Learning (1) → Applying (2) → Leading (3)

COMPETENCY questions include:
  Selling Skills, Healthcare Marketplace, Analytics and Insight Generation,
  Internal Partnerships, Account Management, Business & Market Planning
  Rated: Clear Development Need (1) → Development Need (2) → Emerging Strength (3) → Clear Strength (4)

COMPLIANCE question:
  Filter: LOWER(survey_question_text) LIKE '%field observation%'
    AND survey_question_response IN ('Yes','No')
  'Yes' = compliant, 'No' = non-compliant
  compliance_rate = ROUND(100.0 * COUNT(CASE WHEN survey_question_response='Yes' THEN 1 END) / NULLIF(COUNT(*),0), 1)

PINS FRAMEWORK (free-text coaching sections, scored 1-3 by AI):
  Filter: UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%' → Planning for Perspective (P)
          UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%' → Investigate Issues (I)
          UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%' OR LIKE 'NEGOT%' → Navigate & Negotiate (N)
          UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%' → Secure Action (S)
  Narrative in: survey_question_response_text
  Training needed flags: question contains 'TRAINING NEEDED' → survey_question_response = 'Yes'/'No'
  NOTE: ~2,817 FCRs have PINS data (FBMS coaching form)



GOAL ATTAINMENT:
  LOWER(survey_question_text) LIKE '%goal attainment%'  → survey_question_response

SESSION DURATION: survey_target_session_duration ('1 hour','Half day','One day','Two days','Three days')

RULES:
- Always return results as clean JSON — an array of objects or a single object
- Use COUNT(DISTINCT survey_target_id) for FCR counts
- Use COUNT(DISTINCT rep_wwid) for rep/MSL/coachee counts
- For days to submit: DATEDIFF('day', survey_target_start_date, survey_target_last_modified_date)
- Submitted FCRs: LOWER(survey_target_status) LIKE '%submitted%'
- Late Submission FCRs: LOWER(survey_target_status) LIKE '%late%' AND LOWER(survey_target_status) LIKE '%submission%'
- Draft FCRs: LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%'
- Limit results to 100 rows unless the user asks for more
- For names, concat rep_first_nm || ' ' || rep_last_nm
- When asked about "LEAD scores", query survey_question_response for LEARN/ENGAGE/ADVANCE/DELIVER questions
- NEVER use DROP, INSERT, UPDATE, DELETE, TRUNCATE or any write operation
- If a question cannot be answered from this table, say so clearly
- Always respond with valid Redshift-compatible SQL (use ILIKE for case-insensitive string matching, DATE_TRUNC for time grouping)
`;

app.post('/api/ask', async (req, res) => {
  const { question, history = [] } = req.body;
  if (!question?.trim()) return res.status(400).json({ error: 'No question provided' });

  const endpoint = process.env.AZURE_OPENAI_ENDPOINT?.replace(/\/$/, '');
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION;
  const apiKey = process.env.AZURE_OPENAI_API_KEY;

  if (!endpoint || !apiKey) {
    console.error('/api/ask: OpenAI not configured. endpoint=', !!endpoint, 'apiKey=', !!apiKey);
    return res.status(500).json({ error: 'Azure OpenAI not configured' });
  }
  console.log('/api/ask: calling', `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`);

  try {
    // Step 1: Ask GPT to generate SQL
    const sqlMessages = [
    { role: 'system', content: SCHEMA_CONTEXT + `

Your job: Given the user question, write a single valid Redshift SQL query.

STRICT OUTPUT RULES:
- Return ONLY the raw SQL, no explanation, no markdown fences, no backticks
- NEVER use JSON_SERIALIZE, JSON_PARSE, LISTAGG, or any JSON wrapping
- NEVER wrap results into a single JSON column
- Always return plain tabular results with named columns
- For scalar results (single number), just SELECT the value with a clear alias e.g. SELECT COUNT(DISTINCT survey_target_id) AS fcr_count FROM ...
- Limit to 100 rows unless user asks for more` },
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: question },
    ];

    const sqlResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({ messages: sqlMessages, temperature: 0, max_completion_tokens: 800 }),
      }
    );
    if (!sqlResp.ok) {
      const err = await sqlResp.text();
      console.error('OpenAI SQL gen error:', err);
      return res.status(502).json({ error: 'AI service error', detail: err });
    }
    const sqlJson = await sqlResp.json();
    let sql = sqlJson.choices?.[0]?.message?.content?.trim() ?? '';

    // Strip markdown fences if model added them
    sql = sql.replace(/^```(?:sql)?\s*/i, '').replace(/\s*```$/, '').trim();

    // Safety: block write operations
    if (/\b(drop|insert|update|delete|truncate|alter|create|grant|revoke)\b/i.test(sql)) {
      return res.status(400).json({ error: 'Query not allowed' });
    }

    // Safety: enforce only the approved table is queried
    const allowedTable = 'odp.dp_cust_pers_engagement_dly';
    const tableRefs = sql.match(/\bfrom\s+([\w.]+)/gi) || [];
    const joinRefs  = sql.match(/\bjoin\s+([\w.]+)/gi)  || [];
    const allRefs   = [...tableRefs, ...joinRefs].map(r => r.replace(/^(from|join)\s+/i, '').toLowerCase().trim());
    const forbidden = allRefs.filter(t => t !== allowedTable && !t.startsWith('('));
    if (forbidden.length > 0) {
      console.warn('/api/ask: blocked query referencing unauthorized table(s):', forbidden);
      return res.status(400).json({ error: `Query references unauthorized table(s): ${forbidden.join(', ')}` });
    }

    // Step 2: Run the SQL against Redshift
    let rows = [], queryError = null;
    try {
      const result = await pool.query(sql);
      rows = result.rows;
    } catch (dbErr) {
      queryError = dbErr.message;
    }

    // Step 3: Ask GPT to explain the results in plain English
    const explainMessages = [
      { role: 'system', content: `You are a senior FCR analytics expert at Johnson & Johnson.
Analyze the SQL query result thoroughly and provide a clear, detailed answer to the user's question.
Be specific with numbers, percentages, and names. Highlight the most important findings.
If there was a query error, explain it simply and suggest how to rephrase.
Do NOT mention SQL or technical details in your response.` },
      { role: 'user', content: `Question: ${question}\n\nSQL used:\n${sql}\n\n${queryError ? `Error: ${queryError}` : `Full Results (${rows.length} rows):\n${JSON.stringify(rows, null, 2)}`}` },
    ];

    const explainResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({ messages: explainMessages, temperature: 0.2, max_completion_tokens: 1500 }),
      }
    );
    const explainJson = await explainResp.json();
    const summary = explainJson.choices?.[0]?.message?.content?.trim() ?? '';

    res.json({ sql, rows, summary, error: queryError });
  } catch (err) {
    console.error('/api/ask error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/fcr-insight  — AI coaching analysis for a single FCR ──
app.post('/api/fcr-insight', async (req, res) => {
  const { fcrId, coacheeName, coacheeRole, ta, region, sessionDuration, coachingDate,
          competencyScores, observations, actionItem, prevActionItem, trendData } = req.body;

  if (!fcrId) return res.status(400).json({ error: 'fcrId required' });

  const endpoint   = process.env.AZURE_OPENAI_ENDPOINT?.replace(/\/$/, '');
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION;
  const apiKey     = process.env.AZURE_OPENAI_API_KEY;

  if (!endpoint || !apiKey) {
    return res.status(500).json({ error: 'Azure OpenAI not configured' });
  }

  // Build a structured context from the FCR data
  const competencyText = competencyScores && Object.keys(competencyScores).length
    ? Object.entries(competencyScores)
        .map(([comp, { avg, responses }]) =>
          `  - ${comp}: avg ${avg.toFixed(1)}/4 (${responses.join(', ')})`)
        .join('\n')
    : '  (no competency scores recorded)';

  const observationsText = observations && observations.length
    ? observations.map(o => `  [${o.question}]: "${o.text}"`).join('\n')
    : '  (no written observations)';

  const trendText = trendData && trendData.length > 1
    ? trendData.map((t, i) => `  Session ${i + 1}: ${t.score != null ? Number(t.score).toFixed(1) : 'N/A'}`).join(', ')
    : '  (insufficient history for trend)';

  const prompt = `You are an expert field coaching advisor at Johnson & Johnson reviewing a Field Coaching Report.

FCR DETAILS:
  FCR ID: ${fcrId}
  Coachee: ${coacheeName || 'Unknown'} (${coacheeRole || 'Unknown role'})
  Therapeutic Area: ${ta || 'Unknown'} | Region: ${region || 'Unknown'}
  Coaching Date: ${coachingDate || 'Unknown'} | Session Duration: ${sessionDuration || 'Unknown'}

COMPETENCY SCORES (scale 1–4: 1=Clear Development Need, 2=Development Need, 3=Emerging Strength, 4=Clear Strength):
${competencyText}

COACHING OBSERVATIONS (written by field director):
${observationsText}

PROGRESS TREND (avg competency score per session, most recent last):
${trendText}

PREVIOUS ACTION ITEMS:
  ${prevActionItem || '(none)'}

CURRENT ACTION ITEMS:
  ${actionItem || '(none)'}

Provide a thorough, data-driven coaching analysis with exactly these four sections:
1. **Overall Assessment**: Summarize the coachee's current performance level, trajectory, and key context from observations. Reference specific scores and trends.
2. **Key Strengths**: Detailed bullet points on what is going well. Quote or reference specific language from the coaching observations. Name the competencies performing at Emerging Strength or Clear Strength level.
3. **Priority Development Areas**: Specific bullet points for each area below target. Reference the exact competency name, its score, and what the coaching observations reveal about the root cause. Be precise and constructive.
4. **Coaching Recommendation**: Concrete, specific next steps the field director should take in the next 1–2 sessions. Include which behavior to target, what to observe for, and how to measure progress.

Be thorough and specific. Reference actual competency names, scores, and quotes from observations. Professional and constructive tone.`;

  try {
    const aiResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are a professional field coaching advisor at a pharmaceutical company. Provide clear, concise, data-driven coaching analysis.' },
            { role: 'user', content: prompt },
          ],
          temperature: 0.3,
          max_completion_tokens: 2500,
        }),
      }
    );

    if (!aiResp.ok) {
      const err = await aiResp.text();
      console.error('OpenAI FCR insight error:', err);
      return res.status(502).json({ error: 'AI service error', detail: err });
    }

    const aiJson = await aiResp.json();
    const insight = aiJson.choices?.[0]?.message?.content?.trim() ?? '';
    res.json({ insight });
  } catch (err) {
    console.error('/api/fcr-insight error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/pins-score  — AI-powered PINS scoring from free-text ──
// Fetches PINS narratives for an FCR and scores P/I/N/S 1-3 using GPT
app.post('/api/pins-score', async (req, res) => {
  const { fcrId, jobLevel } = req.body;
  if (!fcrId) return res.status(400).json({ error: 'fcrId required' });

  const endpoint   = process.env.AZURE_OPENAI_ENDPOINT?.replace(/\/$/, '');
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION;
  const apiKey     = process.env.AZURE_OPENAI_API_KEY;
  if (!endpoint || !apiKey) return res.status(500).json({ error: 'Azure OpenAI not configured' });

  try {
    // Fetch all PINS rows for this FCR
    const pinsResult = await pool.query(`
      SELECT
        UPPER(LTRIM(survey_question_text))    AS q_upper,
        survey_question_text                  AS question,
        survey_question_response              AS response,
        survey_question_response_text         AS narrative
      FROM odp.dp_cust_pers_engagement_dly
      WHERE survey_target_id = $1
        AND chnl = 'SURVEY'
        AND (
          UPPER(LTRIM(survey_question_text)) LIKE 'PLAN%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'INVEST%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'NAVIGAT%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'NEGOT%'
          OR UPPER(LTRIM(survey_question_text)) LIKE 'SECURE%'
        )
      ORDER BY survey_question_order NULLS LAST
    `, [fcrId]);

    if (pinsResult.rows.length === 0) {
      return res.status(404).json({ error: 'No PINS data found for this FCR' });
    }

    // Bucket rows into P / I / N / S sections and extract training flags
    const sections = { P: [], I: [], N: [], S: [] };
    const trainingFlags = { P: null, I: null, N: null, S: null };

    for (const row of pinsResult.rows) {
      const q = row.q_upper || '';
      const isTraining = q.includes('TRAINING NEEDED');
      let letter = null;
      if (q.startsWith('PLAN'))    letter = 'P';
      else if (q.startsWith('INVEST')) letter = 'I';
      else if (q.startsWith('NAVIGAT') || q.startsWith('NEGOT')) letter = 'N';
      else if (q.startsWith('SECURE')) letter = 'S';

      if (!letter) continue;

      if (isTraining) {
        // Yes/No training flag — store directly
        trainingFlags[letter] = row.response === 'Yes';
      } else if (row.narrative?.trim()) {
        sections[letter].push(row.narrative.trim());
      }
    }

    // Build a text block for GPT
    const sectionNames = {
      P: 'Planning for Perspective',
      I: 'Investigate Issues',
      N: 'Navigate & Negotiate Needs',
      S: 'Secure Action',
    };
    const contextBlock = Object.entries(sections).map(([letter, texts]) => {
      const name = sectionNames[letter];
      const trainingFlag = trainingFlags[letter] === true ? ' [Training Needed: YES]'
                         : trainingFlags[letter] === false ? ' [Training Needed: No]' : '';
      return `${name}${trainingFlag}:\n${texts.length > 0 ? texts.join('\n') : '(no narrative recorded)'}`;
    }).join('\n\n');

    // ── Job level → FBMS proficiency targets (official J&J pay-grade matrix) ─
    // 1=Awareness · 2=Skilled · 3=Advanced · 4=Expert
    const PROFICIENCY_TABLE = {
      PG30: { DataGathering:2, StrategicThinking:1, CompetitiveLandscape:1, Influencing:2, ClinicalExpertise:2, ProblemSolving:2, CrossFunctional:2 },
      PG31: { DataGathering:2, StrategicThinking:2, CompetitiveLandscape:2, Influencing:3, ClinicalExpertise:3, ProblemSolving:2, CrossFunctional:3 },
      PG40: { DataGathering:3, StrategicThinking:3, CompetitiveLandscape:3, Influencing:3, ClinicalExpertise:4, ProblemSolving:3, CrossFunctional:3 },
      PG41: { DataGathering:3, StrategicThinking:4, CompetitiveLandscape:4, Influencing:4, ClinicalExpertise:4, ProblemSolving:3, CrossFunctional:4 },
    };
    const detectLevel = (desig) => {
      const d = (desig || '').toLowerCase();
      if (d.includes('sr dir') || d.includes('senior dir') || d.includes('msl head') || /\bpg41\b/.test(d)) return 'PG41';
      if (d.includes('principal') || d.includes('field dir') || /\bpg40\b/.test(d)) return 'PG40';
      if (d.includes('senior') || d.includes('sr ') || d.includes('value') || d.includes('acct dir') || /\bpg31\b/.test(d)) return 'PG31';
      return 'PG30';
    };
    const detectedLevel = detectLevel(jobLevel);
    const targetProf    = PROFICIENCY_TABLE[detectedLevel];

    const prompt = `You are an expert J&J FBMS field coaching analyst. Analyze the PINS coaching narratives and score every observable behaviour using the official J&J FBMS framework below.

OFFICIAL PINS OBSERVABLE BEHAVIOURS & FBMS SKILL MAPPINGS:

P – Planning for Perspective
  P1. Developed strategically aligned goals reflecting business partner's account strategy and translated into clear, actionable objectives → Strategic Thinking, Competitive Landscape
  P2. Incorporated insights using digital tools (e.g. AIDA, HI), clinical and market access readiness, and business priorities → Data Gathering
  P3. Selected resources support the stated strategy, objectives, and address anticipated objections → Clinical Expertise, Data Gathering

I – Investigate Issues
  I1. Outlined meeting objectives, recapped previous discussions, invited HCP/PHDM input and adjusted as needed → Influencing
  I2. Engaged HCPs/PHDMs with open-ended questions, active listening, and clear communication → Influencing, Problem Solving
  I3. Identified HCP/PHDM motivators, barriers, objections, and unmet needs to capture actionable insights → Data Gathering, Problem Solving

N – Navigate & Negotiate Needs
  N1. Confidently delivered key data and seamlessly facilitated scientific exchange to meet HCP/PHDM needs → Clinical Expertise, Influencing
  N2. Confidently addressed HCP/PHDM misunderstanding of J&J or competitor data, helping close knowledge gaps → Influencing, Competitive Landscape
  N3. Used role-aligned, approved scientific resources aligned with MAF/SA strategy and identified Documented Interests → Clinical Expertise, Strategic Thinking

S – Secure Action
  S1. Meeting objectives were achieved with appropriate clinical reinforcement used to secure next steps → Strategic Thinking
  S2. Appropriate follow-up planned with internal partners → Cross-functional Collaboration
  S3. Documentation of actionable insights (VoC) → Data Gathering
  S4. Appropriate documentation in CRM system (e.g. Veeva, iConnect) → Data Gathering

PROFICIENCY SCALE: 1=Awareness (significant gaps) | 2=Skilled (meets expectations) | 3=Advanced (exceeds expectations) | 4=Expert (role model / coaches others)
COACHEE JOB LEVEL: ${jobLevel || 'Not specified — default to PG30 MSL'}

PINS SECTION NARRATIVES:
${contextBlock}

Return ONLY valid JSON (no explanation, no markdown):
{
  "sections": {
    "P": {
      "score": <1|2|3|4>,
      "strength": "<specific observed strength from narrative>",
      "opportunity": "<concrete gap + next-step recommendation>",
      "behaviors": [
        { "id": "P1", "label": "Strategically aligned goals & objectives", "skills": ["Strategic Thinking","Competitive Landscape"], "score": <1|2|3|4>, "note": "<one sentence evidence or gap>" },
        { "id": "P2", "label": "Digital insights & pre-call preparation", "skills": ["Data Gathering"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "P3", "label": "Resource selection aligned to strategy", "skills": ["Clinical Expertise","Data Gathering"], "score": <1|2|3|4>, "note": "<one sentence>" }
      ]
    },
    "I": {
      "score": <1|2|3|4>,
      "strength": "<...>",
      "opportunity": "<...>",
      "behaviors": [
        { "id": "I1", "label": "Objectives recap & HCP input invited", "skills": ["Influencing"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "I2", "label": "Open-ended questions & active listening", "skills": ["Influencing","Problem Solving"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "I3", "label": "Surfaced motivators, barriers & unmet needs", "skills": ["Data Gathering","Problem Solving"], "score": <1|2|3|4>, "note": "<one sentence>" }
      ]
    },
    "N": {
      "score": <1|2|3|4>,
      "strength": "<...>",
      "opportunity": "<...>",
      "behaviors": [
        { "id": "N1", "label": "Confident scientific data delivery", "skills": ["Clinical Expertise","Influencing"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "N2", "label": "Addressed J&J / competitor misunderstandings", "skills": ["Influencing","Competitive Landscape"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "N3", "label": "Role-aligned resources per MAF/SA strategy", "skills": ["Clinical Expertise","Strategic Thinking"], "score": <1|2|3|4>, "note": "<one sentence>" }
      ]
    },
    "S": {
      "score": <1|2|3|4>,
      "strength": "<...>",
      "opportunity": "<...>",
      "behaviors": [
        { "id": "S1", "label": "Objectives achieved with clinical reinforcement", "skills": ["Strategic Thinking"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "S2", "label": "Follow-up planned with internal partners", "skills": ["Cross-functional Collaboration"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "S3", "label": "VoC insights documented", "skills": ["Data Gathering"], "score": <1|2|3|4>, "note": "<one sentence>" },
        { "id": "S4", "label": "CRM entry completed (Veeva/iConnect)", "skills": ["Data Gathering"], "score": <1|2|3|4>, "note": "<one sentence>" }
      ]
    }
  },
  "skills": {
    "DataGathering":        { "score": <1|2|3|4>, "evidence": "<one sentence from narratives>" },
    "StrategicThinking":    { "score": <1|2|3|4>, "evidence": "<one sentence>" },
    "CompetitiveLandscape": { "score": <1|2|3|4>, "evidence": "<one sentence>" },
    "Influencing":          { "score": <1|2|3|4>, "evidence": "<one sentence>" },
    "ClinicalExpertise":    { "score": <1|2|3|4>, "evidence": "<one sentence>" },
    "ProblemSolving":       { "score": <1|2|3|4>, "evidence": "<one sentence>" },
    "CrossFunctional":      { "score": <1|2|3|4>, "evidence": "<one sentence>" }
  },
  "summary": "<2–3 sentences: overall proficiency, top strength, top development priority>"
}`;

    const aiResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are an expert J&J FBMS field coaching analyst. Return only valid JSON as instructed.' },
            { role: 'user', content: prompt },
          ],
          temperature: 0.1,
          max_completion_tokens: 2000,
        }),
      }
    );
    if (!aiResp.ok) {
      const err = await aiResp.text();
      return res.status(502).json({ error: 'AI service error', detail: err });
    }
    const aiJson = await aiResp.json();
    let raw = aiJson.choices?.[0]?.message?.content?.trim() ?? '';
    raw = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return res.status(502).json({ error: 'Failed to parse AI response', raw });
    }

    // Compute skill gaps vs job level targets
    const gaps = {};
    if (parsed.skills && targetProf) {
      for (const skillKey of Object.keys(targetProf)) {
        const actual = parsed.skills[skillKey]?.score ?? null;
        const target = targetProf[skillKey];
        if (actual !== null) gaps[skillKey] = { actual, target, gap: actual - target };
      }
    }

    res.json({
      sections: parsed.sections || {},
      skills:   parsed.skills   || {},
      summary:  parsed.summary  || '',
      gaps,
      trainingFlags,
      detectedLevel,
      hasPinsData: true,
    });
  } catch (err) {
    console.error('/api/pins-score error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/pins-summary  — Aggregate PINS training flags (pure SQL, no GPT) ──
app.get('/api/pins-summary', async (req, res) => {
  res.setTimeout(55000, () => {
    if (!res.headersSent) res.status(504).json({ error: 'Query timed out — try a shorter timeframe or add a TA filter' });
  });

  const ck = `pins-summary:${JSON.stringify(req.query)}`;
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });

  try {
    const { ta, region, timeframe, from: fromDate, to: toDate } = req.query;

    const baseConds = [
      `chnl = 'SURVEY'`,
      `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
      `survey_target_id IS NOT NULL`,
      `(TRIM(survey_question_text) ILIKE 'plan%'` +
        ` OR TRIM(survey_question_text) ILIKE 'invest%'` +
        ` OR TRIM(survey_question_text) ILIKE 'navigat%'` +
        ` OR TRIM(survey_question_text) ILIKE 'negot%'` +
        ` OR TRIM(survey_question_text) ILIKE 'secure%')`,
    ];
    const params = [];

    if (ta) {
      params.push(ta.toUpperCase());
      baseConds.push(`ta = $${params.length}`);
    }
    if (region) {
      params.push(region);
      baseConds.push(`reg_nm ILIKE $${params.length}`);
    }
    if (timeframe && timeframe !== 'custom') {
      const d = new Date(); d.setDate(d.getDate() - parseInt(timeframe));
      params.push(d.toISOString().slice(0, 10));
      baseConds.push(`acty_dt >= $${params.length}::date`);
    } else if (!fromDate) {
      // Default: last 90 days to keep scan fast
      const d = new Date(); d.setDate(d.getDate() - 90);
      params.push(d.toISOString().slice(0, 10));
      baseConds.push(`acty_dt >= $${params.length}::date`);
    }
    if (fromDate) {
      params.push(fromDate);
      baseConds.push(`acty_dt >= $${params.length}::date`);
    }
    if (toDate) {
      params.push(toDate);
      baseConds.push(`acty_dt <= $${params.length}::date`);
    }

    const where = baseConds.join(' AND ');

    // KEY OPTIMISATION: filter survey_question_response IN ('Yes','No') in WHERE
    // — this eliminates all narrative/competency-score rows before the ILIKE scan,
    // shrinking the row count from millions to just the training-flag rows.
    const sql = `
      SELECT
        rep_wwid,
        MAX(rep_first_nm)                                          AS first_nm,
        MAX(rep_last_nm)                                           AS last_nm,
        COALESCE(NULLIF(MAX(TRIM(rep_desig)), ''), 'Unknown')      AS job_level,
        COALESCE(NULLIF(MAX(TRIM(ta)), ''), 'Unknown')             AS ta,
        COALESCE(NULLIF(MAX(TRIM(reg_nm)), ''), 'Unknown')         AS region,
        CASE
          WHEN TRIM(survey_question_text) ILIKE 'plan%'    THEN 'P'
          WHEN TRIM(survey_question_text) ILIKE 'invest%'  THEN 'I'
          WHEN TRIM(survey_question_text) ILIKE 'navigat%'
            OR TRIM(survey_question_text) ILIKE 'negot%'   THEN 'N'
          WHEN TRIM(survey_question_text) ILIKE 'secure%'  THEN 'S'
        END                                                        AS sec,
        survey_question_response                                   AS yn_resp,
        COUNT(DISTINCT survey_target_id)                           AS fcrs
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
        AND survey_question_response IN ('Yes','No')
        AND (TRIM(survey_question_text) ILIKE 'plan%'
          OR TRIM(survey_question_text) ILIKE 'invest%'
          OR TRIM(survey_question_text) ILIKE 'navigat%'
          OR TRIM(survey_question_text) ILIKE 'negot%'
          OR TRIM(survey_question_text) ILIKE 'secure%')
      GROUP BY rep_wwid, sec, survey_question_response
      HAVING sec IS NOT NULL
    `;

    const result = await pool.query(sql, params);

    // ── Pivot flat rows entirely in Node ────────────────────────────────────
    const secMap   = {};
    const levelMap = {};
    const taMap    = {};
    const repMap   = {};

    for (const row of result.rows) {
      const wwid  = row.rep_wwid;
      const sec   = row.sec;
      const isYes = row.yn_resp === 'Yes';
      const n     = parseInt(row.fcrs) || 0;
      const jl    = row.job_level;
      const ta    = row.ta;

      if (!secMap[sec]) secMap[sec] = { yn: 0, nn: 0 };
      if (isYes) secMap[sec].yn += n; else secMap[sec].nn += n;

      if (!repMap[wwid]) repMap[wwid] = { first_nm: row.first_nm, last_nm: row.last_nm, desig: jl, ta, region: row.region, p: 0, i: 0, n: 0, s: 0, yn_total: 0, fcrs: 0 };
      repMap[wwid].fcrs += n;
      if (isYes) { repMap[wwid][sec.toLowerCase()] += n; repMap[wwid].yn_total += n; }

      if (!levelMap[jl]) levelMap[jl] = { fcrs: 0, reps: new Set(), p: 0, i: 0, n: 0, s: 0 };
      levelMap[jl].fcrs += n;
      levelMap[jl].reps.add(wwid);
      if (isYes) levelMap[jl][sec.toLowerCase()] += n;

      if (!taMap[ta]) taMap[ta] = { fcrs: 0, reps: new Set(), yn: 0 };
      taMap[ta].fcrs += n;
      taMap[ta].reps.add(wwid);
      if (isYes) taMap[ta].yn += n;
    }

    const totalYn  = Object.values(secMap).reduce((s, v) => s + v.yn, 0);
    const totalNn  = Object.values(secMap).reduce((s, v) => s + v.nn, 0);
    const kpi = {
      total_pins_fcrs:           Object.values(taMap).reduce((s, t) => s + t.fcrs, 0),
      total_pins_reps:           Object.keys(repMap).length,
      fcrs_with_training_needed: totalYn,
      total_training_flags:      totalYn,
      fcrs_training_not_needed:  totalNn,
    };

    const sections = ['P','I','N','S'].map(s => ({
      section:             s,
      section_fcrs:        (secMap[s]?.yn || 0) + (secMap[s]?.nn || 0),
      training_needed:     secMap[s]?.yn || 0,
      training_not_needed: secMap[s]?.nn || 0,
    }));

    const levelsArr = Object.entries(levelMap).map(([jl, v]) => ({
      job_level: jl, fcrs: v.fcrs, reps: v.reps.size,
      p_training: v.p, i_training: v.i, n_training: v.n, s_training: v.s,
    }));
    levelsArr.sort((a, b) => b.fcrs - a.fcrs);
    const levels = levelsArr.slice(0, 12);

    const repsArr = Object.entries(repMap)
      .filter(([, r]) => r.yn_total > 0)
      .map(([wwid, r]) => ({
        rep_wwid: wwid, first_nm: r.first_nm, last_nm: r.last_nm,
        desig: r.desig, ta: r.ta, region: r.region,
        total_pins_fcrs: r.fcrs,
        p_flags: r.p, i_flags: r.i, n_flags: r.n, s_flags: r.s,
      }));
    repsArr.sort((a, b) => (b.p_flags+b.i_flags+b.n_flags+b.s_flags) - (a.p_flags+a.i_flags+a.n_flags+a.s_flags));
    const reps = repsArr.slice(0, 40);

    const by_ta = Object.entries(taMap)
      .map(([ta, v]) => ({ ta, pins_fcrs: v.fcrs, pins_reps: v.reps.size, fcrs_training_needed: v.yn }))
      .sort((a, b) => b.pins_fcrs - a.pins_fcrs)
      .slice(0, 20);

    const payload = { kpi, sections, levels, reps, by_ta };
    cacheSet(ck, payload);
    res.json(payload);
  } catch (err) {
    console.error('/api/pins-summary error:', err.message);
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

// ── /api/capability  — Competency proficiency breakdown ──────
app.get('/api/capability', async (req, res) => {
  const ck = `capability:${JSON.stringify(req.query)}`;
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });
  try {
    const { ta, timeframe, region, from: fromDate, to: toDate } = req.query;

    // Base conditions (shared, no response-type filter)
    const baseConds = [
      `chnl = 'SURVEY'`,
      `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
      `survey_target_id IS NOT NULL`,
      MSL_FILTER,
    ];
    const filterConds = [];
    const params = [];
    if (ta)     { params.push(ta.toUpperCase()); filterConds.push(`ta = $${params.length}`); }
    if (region) { params.push(region);           filterConds.push(`reg_nm ILIKE $${params.length}`); }
    if (timeframe && timeframe !== 'custom') {
      const d = new Date(); d.setDate(d.getDate() - parseInt(timeframe));
      params.push(d.toISOString().slice(0, 10));
      filterConds.push(`acty_dt >= $${params.length}::date`);
    }
    if (fromDate) { params.push(fromDate); filterConds.push(`acty_dt >= $${params.length}::date`); }
    if (toDate)   { params.push(toDate);   filterConds.push(`acty_dt <= $${params.length}::date`); }

    const allBase = [...baseConds, ...filterConds];

    // WHERE for competency-scale questions — includes BOTH standard scale AND FBMS scale
    const FBMS_RESPONSES = `'Expert','Advanced','Skilled','Awareness','Clear Strength','Emerging Strength','Development Need','Clear Development Need'`;
    const where = [...allBase,
      `survey_question_response IN (${FBMS_RESPONSES})`,
      // Only scored behavior rows (not header rows, training-needed rows, or narrative rows)
      `survey_question_response NOT IN ('Yes','No','Area of strength','Area of development','Area of excellence','Not applicable to the observed interaction')`,
    ].join(' AND ');

    // WHERE for LEAD model questions (Learning/Applying/Leading)
    const leadWhere = [...allBase,
      `survey_question_response IN ('Learning','Applying','Leading')`,
      `LOWER(survey_question_text) IN ('learn','engage','advance','deliver')`,
    ].join(' AND ');

    // WHERE for compliance question
    const complianceWhere = [...allBase,
      `LOWER(survey_question_text) LIKE '%field observation%'`,
      `survey_question_response IN ('Yes','No')`,
    ].join(' AND ');

    // Unified score expression — handles both FBMS (Expert/Advanced/Skilled/Awareness)
    // and standard commercial scale (Clear Strength/Emerging Strength/etc.)
    const scoreExpr = `CASE
      WHEN survey_question_response = 'Expert'                  THEN 4
      WHEN survey_question_response = 'Clear Strength'          THEN 4
      WHEN survey_question_response = 'Advanced'                THEN 3
      WHEN survey_question_response = 'Emerging Strength'       THEN 3
      WHEN survey_question_response = 'Skilled'                 THEN 2
      WHEN survey_question_response = 'Development Need'        THEN 2
      WHEN survey_question_response = 'Awareness'               THEN 1
      WHEN survey_question_response = 'Clear Development Need'  THEN 1
    END`;

    // Competency mapping — FBMS behavior questions → FBMS Core Skills
    const compExpr = `CASE
      -- ── FBMS Behavior Questions (MSL/VESE forms) ───────────────────────
      WHEN LOWER(survey_question_text) LIKE '%strategically aligned goals%'                                 THEN 'Strategic Thinking'
      WHEN LOWER(survey_question_text) LIKE '%digital tools%' AND LOWER(survey_question_text) LIKE '%aida%' THEN 'Data Gathering'
      WHEN LOWER(survey_question_text) LIKE '%selected resources%' AND LOWER(survey_question_text) LIKE '%strategy%' THEN 'Clinical Expertise'
      WHEN LOWER(survey_question_text) LIKE '%outlined meeting objectives%'                                 THEN 'Influencing Others'
      WHEN LOWER(survey_question_text) LIKE '%open-ended questions%' AND LOWER(survey_question_text) LIKE '%active listening%' THEN 'Influencing Others'
      WHEN LOWER(survey_question_text) LIKE '%motivators%' AND LOWER(survey_question_text) LIKE '%barriers%' THEN 'Data Gathering'
      WHEN LOWER(survey_question_text) LIKE '%confidently delivered key data%'                              THEN 'Clinical Expertise'
      WHEN LOWER(survey_question_text) LIKE '%misunderstanding%' AND LOWER(survey_question_text) LIKE '%competitor%' THEN 'Competitive Landscape'
      WHEN LOWER(survey_question_text) LIKE '%role-aligned%' AND LOWER(survey_question_text) LIKE '%resources%' THEN 'Clinical Expertise'
      WHEN LOWER(survey_question_text) LIKE '%meeting objectives were achieved%'                            THEN 'Strategic Thinking'
      WHEN LOWER(survey_question_text) LIKE '%follow-up planned with internal%'                             THEN 'Cross-functional Collaboration'
      WHEN LOWER(survey_question_text) LIKE '%documentation of actionable insights%'                       THEN 'Data Gathering'
      WHEN LOWER(survey_question_text) LIKE '%documentation in crm%' OR LOWER(survey_question_text) LIKE '%veeva%' OR LOWER(survey_question_text) LIKE '%iconnect%' THEN 'Data Gathering'
      -- ── Standard Commercial Competency Questions ───────────────────────
      WHEN LOWER(survey_question_text) LIKE '%selling skill%'                                               THEN 'Selling Skills'
      WHEN LOWER(survey_question_text) LIKE '%healthcare marketplace%'                                      THEN 'Healthcare Marketplace'
      WHEN LOWER(survey_question_text) LIKE '%analytics%' AND LOWER(survey_question_text) LIKE '%insight%'  THEN 'Analytics & Insights'
      WHEN LOWER(survey_question_text) LIKE '%internal partner%'                                            THEN 'Internal Partnerships'
      WHEN LOWER(survey_question_text) LIKE '%account management%'                                          THEN 'Account Management'
      WHEN LOWER(survey_question_text) LIKE '%market%plan%' AND LOWER(survey_question_text) LIKE '%business%' THEN 'Business Planning'
      WHEN LOWER(survey_question_text) LIKE '%pre-call%' OR LOWER(survey_question_text) LIKE '%pre call%'   THEN 'Pre-Call Planning'
      ELSE NULL
    END`;

    // KPIs
    const kpiSql = `
      SELECT
        ROUND(AVG(${scoreExpr}), 2)                                                            AS avg_score,
        COUNT(*)                                                                                AS total_ratings,
        COUNT(DISTINCT survey_target_id)                                                        AS rated_fcrs,
        COUNT(DISTINCT rep_wwid)                                                                AS rated_reps,
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response IN ('Emerging Strength','Clear Strength','Advanced','Expert') THEN 1 END)
              / NULLIF(COUNT(*), 0), 1)                                                        AS pct_at_target,
        COUNT(DISTINCT CASE WHEN survey_question_response IN ('Clear Development Need','Awareness')
                            THEN survey_target_id END)                                         AS flagged_fcrs
      FROM odp.dp_cust_pers_engagement_dly WHERE ${where}`;

    // Competency breakdown
    const compSql = `
      SELECT competency,
        ROUND(AVG(score_num), 2)                                                               AS avg_score,
        COUNT(*)                                                                                AS ratings,
        ROUND(100.0 * COUNT(CASE WHEN score_num >= 3 THEN 1 END) / NULLIF(COUNT(*), 0), 1)   AS pct_at_target
      FROM (
        SELECT ${compExpr} AS competency, ${scoreExpr} AS score_num
        FROM odp.dp_cust_pers_engagement_dly WHERE ${where}
      ) t
      WHERE competency IS NOT NULL
      GROUP BY competency ORDER BY avg_score DESC`;

    // Trend (6 months)
    const trendSql = `
      SELECT TO_CHAR(DATE_TRUNC('month', acty_dt), 'Mon YY') AS month,
             DATE_TRUNC('month', acty_dt)                    AS month_dt,
             ROUND(AVG(${scoreExpr}), 2)                     AS avg_score,
             COUNT(DISTINCT survey_target_id)                AS fcrs
      FROM odp.dp_cust_pers_engagement_dly WHERE ${where}
        AND acty_dt >= ADD_MONTHS(CURRENT_DATE, -12)
      GROUP BY 1, 2 ORDER BY 2`;

    // By job level
    const levelSql = `
      SELECT COALESCE(NULLIF(TRIM(rep_desig), ''), 'Unknown') AS level,
             ROUND(AVG(${scoreExpr}), 2)   AS avg_score,
             COUNT(DISTINCT survey_target_id) AS fcrs,
             COUNT(DISTINCT rep_wwid)         AS reps
      FROM odp.dp_cust_pers_engagement_dly WHERE ${where}
      GROUP BY 1 ORDER BY avg_score DESC LIMIT 8`;

    const [kpi, comps, trend, levels] = await Promise.all([
      pool.query(kpiSql, params),
      pool.query(compSql, params),
      pool.query(trendSql, params),
      pool.query(levelSql, params),
    ]);

    // ── LEAD model (Learning / Applying / Leading) ────────
    const leadScoreExpr = `CASE
      WHEN survey_question_response = 'Learning' THEN 1
      WHEN survey_question_response = 'Applying' THEN 2
      WHEN survey_question_response = 'Leading'  THEN 3
    END`;

    const leadSql = `
      SELECT survey_question_text AS behavior,
        ROUND(AVG(${leadScoreExpr}), 2) AS avg_score,
        COUNT(*) AS ratings,
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response = 'Leading'  THEN 1 END) / NULLIF(COUNT(*), 0), 1) AS pct_leading,
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response = 'Applying' THEN 1 END) / NULLIF(COUNT(*), 0), 1) AS pct_applying,
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response = 'Learning' THEN 1 END) / NULLIF(COUNT(*), 0), 1) AS pct_learning
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${leadWhere}
      GROUP BY 1
      ORDER BY CASE survey_question_text
        WHEN 'Learn'   THEN 1
        WHEN 'Engage'  THEN 2
        WHEN 'Advance' THEN 3
        WHEN 'Deliver' THEN 4
        ELSE 5 END`;

    // ── Compliance rate ───────────────────────────────────
    const complianceSql = `
      SELECT
        COUNT(CASE WHEN survey_question_response = 'Yes' THEN 1 END) AS compliant,
        COUNT(CASE WHEN survey_question_response = 'No'  THEN 1 END) AS non_compliant,
        COUNT(*) AS total,
        ROUND(100.0 * COUNT(CASE WHEN survey_question_response = 'Yes' THEN 1 END) / NULLIF(COUNT(*), 0), 1) AS compliance_rate
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${complianceWhere}`;

    const [lead, compliance] = await Promise.all([
      pool.query(leadSql, params),
      pool.query(complianceSql, params),
    ]);

    const payload = {
      kpi: kpi.rows[0],
      competencies: comps.rows,
      trend: trend.rows,
      levels: levels.rows,
      lead: lead.rows,
      compliance: compliance.rows[0],
    };
    cacheSet(ck, payload);
    res.json(payload);
  } catch (err) {
    console.error('/api/capability error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/pins-insight  — AI-generated insights from PINS summary data ──
app.post('/api/pins-insight', async (req, res) => {
  const { summary } = req.body;
  if (!summary) return res.status(400).json({ error: 'summary required' });

  const endpoint   = process.env.AZURE_OPENAI_ENDPOINT?.replace(/\/$/, '');
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION;
  const apiKey     = process.env.AZURE_OPENAI_API_KEY;
  if (!endpoint || !apiKey) return res.status(500).json({ error: 'Azure OpenAI not configured' });

  const kpi      = summary.kpi      || {};
  const sections = summary.sections || [];
  const levels   = (summary.levels  || []).slice(0, 6);
  const reps     = (summary.reps    || []).slice(0, 8);

  const totalPins    = Number(kpi.total_pins_fcrs)          || 0;
  const withTraining = Number(kpi.fcrs_with_training_needed) || 0;
  const trainingPct  = totalPins > 0 ? Math.round((withTraining / totalPins) * 100) : 0;

  const prompt = `You are a field coaching analytics expert at Johnson & Johnson reviewing PINS coaching framework data.

PINS TRAINING COVERAGE (last 90 days):
- Total PINS FCRs: ${totalPins}
- Total Reps coached with PINS: ${kpi.total_pins_reps || 0}
- FCRs with Training Needed flagged: ${withTraining} (${trainingPct}% of total)
- Total Training Flags raised: ${kpi.total_training_flags || 0}

TRAINING FLAGS BY SECTION:
${sections.map(s => `  ${s.section} – ${s.training_needed || 0} FCRs need training, ${s.training_not_needed || 0} don't (${s.section_fcrs || 0} total)`).join('\n')}

JOB LEVELS (highest need first):
${levels.map(l => `  ${l.job_level}: ${l.fcrs} FCRs | P=${l.p_training||0} I=${l.i_training||0} N=${l.n_training||0} S=${l.s_training||0}`).join('\n')}

TOP REPS WITH TRAINING FLAGS:
${reps.map(r => `  ${[r.first_nm, r.last_nm].filter(Boolean).join(' ')} (${r.ta||'?'}): P=${r.p_flags||0} I=${r.i_flags||0} N=${r.n_flags||0} S=${r.s_flags||0}`).join('\n')}

Provide concise, actionable coaching insights structured exactly as:

**Overall Assessment**
[2 sentences on training coverage health and the most critical finding]

**Priority Areas**
- [Most flagged PINS section with specific numbers and why it matters]
- [Second priority with numbers]
- [Which job levels need the most intervention]

**Top Recommendations**
- [Specific, actionable step 1 with reference to data]
- [Specific, actionable step 2]
- [Specific, actionable step 3]

**Reps at Risk**
- [Comment on the 2-3 reps with the most flags — name them, state their flags, suggest next action]

Keep each bullet to 1-2 sentences. Be specific with numbers. No generic advice.`;

  try {
    const aiResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are a J&J FBMS field coaching expert. Be concise and data-driven.' },
            { role: 'user', content: prompt },
          ],
          temperature: 0.3,
          max_completion_tokens: 900,
        }),
      }
    );
    if (!aiResp.ok) {
      const err = await aiResp.text();
      return res.status(502).json({ error: 'AI service error', detail: err });
    }
    const aiJson = await aiResp.json();
    const insight = aiJson.choices?.[0]?.message?.content?.trim() ?? '';
    res.json({ insight });
  } catch (err) {
    console.error('/api/pins-insight error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/skill-trend-insight  — AI insights for Skill Proficiency Trend tab ──
app.post('/api/skill-trend-insight', async (req, res) => {
  const { trendData, pinsTrend, latestSkill, skillChange, improving } = req.body;

  const endpoint   = process.env.AZURE_OPENAI_ENDPOINT?.replace(/\/$/, '');
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION;
  const apiKey     = process.env.AZURE_OPENAI_API_KEY;
  if (!endpoint || !apiKey) return res.status(500).json({ error: 'Azure OpenAI not configured' });

  const trendRows  = (trendData  || []).slice(-12);
  const pinsRows   = (pinsTrend  || []).slice(-12);

  const prompt = `You are a J&J field coaching analytics expert reviewing skill proficiency trend data over time.

COMPETENCY SCORE TREND (last 12 months, scale 1–4):
${trendRows.map(r => `  ${r.month}: avg skill=${r.skill != null ? Number(r.skill).toFixed(2) : 'N/A'}, FCRs coached=${r.fcrs}`).join('\n')}

PINS PROFICIENCY BY SECTION (last 12 months, scale 1–3 where 3=no training needed):
${pinsRows.map(r => `  ${r.month}: P=${r.P ?? 'N/A'} I=${r.I ?? 'N/A'} N=${r.N ?? 'N/A'} S=${r.S ?? 'N/A'}`).join('\n')}

OVERALL SUMMARY:
- Current avg skill proficiency: ${latestSkill != null ? Number(latestSkill).toFixed(2) + '/4' : 'N/A'}
- Change over period: ${skillChange != null ? (skillChange >= 0 ? '+' : '') + Number(skillChange).toFixed(2) : 'N/A'}
- Trajectory: ${improving ? 'Improving' : 'Declining / flat'}

Provide concise, data-driven insights structured exactly as:

**Trend Summary**
[2 sentences summarizing the overall proficiency direction with specific numbers]

**Strongest Performing Months**
- [Month with highest score — what drove it]
- [Notable coaching volume spike and its effect on scores]

**Areas of Concern**
- [Lowest scoring PINS section with months and numbers]
- [Any divergence between coaching volume and quality]

**Coaching Recommendations**
- [Specific action tied to the weakest PINS trend]
- [Recommendation on coaching frequency based on volume data]
- [Suggested focus for the next quarter]

Be specific with numbers. Reference exact months and scores.`;

  try {
    const aiResp = await fetch(
      `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are a J&J field coaching analytics expert. Be concise, specific, and data-driven.' },
            { role: 'user', content: prompt },
          ],
          temperature: 0.3,
          max_completion_tokens: 800,
        }),
      }
    );
    if (!aiResp.ok) {
      const err = await aiResp.text();
      return res.status(502).json({ error: 'AI service error', detail: err });
    }
    const aiJson = await aiResp.json();
    const insight = aiJson.choices?.[0]?.message?.content?.trim() ?? '';
    res.json({ insight });
  } catch (err) {
    console.error('/api/skill-trend-insight error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── /api/pins-trend  — Monthly PINS proficiency proxy (training flag %) ──
app.get('/api/pins-trend', async (req, res) => {
  const ck = `pins-trend:${JSON.stringify(req.query)}`;
  const hit = cacheGet(ck);
  if (hit) return res.json({ ...hit, _cached: true });

  res.setTimeout(55000, () => {
    if (!res.headersSent) res.status(504).json({ error: 'Query timed out' });
  });

  try {
    const { ta, region } = req.query;
    const baseConds = [
      `chnl = 'SURVEY'`,
      `(LOWER(engagement_title) LIKE '%coaching%' OR LOWER(engagement_title) LIKE '%fcr%')`,
      `survey_target_id IS NOT NULL`,
      `survey_question_response IN ('Yes','No')`,
      `(TRIM(survey_question_text) ILIKE 'plan%'
        OR TRIM(survey_question_text) ILIKE 'invest%'
        OR TRIM(survey_question_text) ILIKE 'navigat%'
        OR TRIM(survey_question_text) ILIKE 'negot%'
        OR TRIM(survey_question_text) ILIKE 'secure%')`,
      `acty_dt >= ADD_MONTHS(CURRENT_DATE, -12)`,
    ];
    const params = [];
    if (ta)     { params.push(ta.toUpperCase()); baseConds.push(`ta = $${params.length}`); }
    if (region) { params.push(region);           baseConds.push(`reg_nm ILIKE $${params.length}`); }

    const where = baseConds.join(' AND ');

    const sql = `
      SELECT
        TO_CHAR(DATE_TRUNC('month', acty_dt), 'Mon YY') AS month,
        DATE_TRUNC('month', acty_dt)                    AS month_dt,
        CASE
          WHEN TRIM(survey_question_text) ILIKE 'plan%'    THEN 'P'
          WHEN TRIM(survey_question_text) ILIKE 'invest%'  THEN 'I'
          WHEN TRIM(survey_question_text) ILIKE 'navigat%'
            OR TRIM(survey_question_text) ILIKE 'negot%'   THEN 'N'
          WHEN TRIM(survey_question_text) ILIKE 'secure%'  THEN 'S'
        END                                              AS section,
        COUNT(DISTINCT survey_target_id)                 AS fcrs,
        ROUND(
          100.0 * COUNT(CASE WHEN survey_question_response = 'No' THEN 1 END)
          / NULLIF(COUNT(*), 0), 1
        )                                                AS no_training_pct
      FROM odp.dp_cust_pers_engagement_dly
      WHERE ${where}
      GROUP BY 1, 2, section
      HAVING section IS NOT NULL
      ORDER BY 2, section
    `;
    const result = await pool.query(sql, params);

    // Pivot into { month, P, I, N, S, fcrs } objects (score 1–3 scale)
    const monthMap = {};
    for (const row of result.rows) {
      const m = row.month;
      if (!monthMap[m]) monthMap[m] = { month: m, month_dt: row.month_dt, fcrs: 0, P: null, I: null, N: null, S: null };
      monthMap[m].fcrs += parseInt(row.fcrs) || 0;
      // Map no_training_pct 0–100 → score 1–3 (higher = more proficient)
      const pct = parseFloat(row.no_training_pct) || 0;
      monthMap[m][row.section] = parseFloat((1 + (pct / 100) * 2).toFixed(2));
    }
    const trend = Object.values(monthMap).sort((a, b) => new Date(a.month_dt) - new Date(b.month_dt));
    const payload = { trend };
    cacheSet(ck, payload);
    res.json(payload);
  } catch (err) {
    console.error('/api/pins-trend error:', err.message);
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

// Serve static files from the 'dist' directory
app.use(express.static(path.join(__dirname, 'dist')));

// For any other routes, serve index.html (SPA routing)
app.get('/{*path}', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
