import { useState, useEffect } from 'react';
import { useIsAuthenticated, useAccount } from '@azure/msal-react';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import DashboardPage from './pages/DashboardPage';
import ActivityPage from './pages/ActivityPage';
import CapabilityPage from './pages/CapabilityPage';
import AskAIPage from './pages/AskAIPage';
import ReferencePage from './pages/ReferencePage';
import FCRsPage from './pages/FCRsPage';
import LoginPage from './pages/LoginPage';
import ConsentPage from './pages/ConsentPage';
import { telemetryService } from './services/telemetryService';
import './index.css';

function PlaceholderPage({ title }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, color: '#9ca3af', padding: 48 }}>
      <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.25 }}>📋</div>
      <div style={{ fontSize: 17, fontWeight: 700, color: '#374151' }}>{title}</div>
      <div style={{ fontSize: 12, marginTop: 6 }}>Coming soon — will be connected to the live backend.</div>
    </div>
  );
}

export default function App() {
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount();
  const [hasConsented, setHasConsented] = useState(false);
  const [active, setActive] = useState('summary');

  /**
   * Initialize telemetry with authenticated user info (SSO)
   * This runs ONLY after user successfully completes SSO login
   * Captures: email (username), full name, and account ID from Azure AD
   * All subsequent events will include this user context
   */
  useEffect(() => {
    if (isAuthenticated && account) {
      const userEmail = account.username; // Email from Azure AD
      const userName = account.name; // Full name from Azure AD
      const userId = account.localAccountId; // Local account ID
      
      console.log('[App] User authenticated via SSO');
      console.log('[App] Email:', userEmail);
      console.log('[App] Name:', userName);
      console.log('[App] Initializing telemetry with authenticated user info');
      
      // Initialize telemetry service - all future events will include this user context
      telemetryService.init(userEmail, userName, userEmail);
    }
  }, [isAuthenticated, account]);

  /**
   * Track page navigation for authenticated users
   * Captures which page/feature user is viewing and for how long
   */
  useEffect(() => {
    if (isAuthenticated && hasConsented) {
      const pageNames = {
        'summary': 'dashboard',
        'capability': 'capability',
        'fcrs': 'fcrs',
        'askai': 'askai',
        'activity': 'activity',
        'reference': 'reference'
      };
      const pageName = pageNames[active] || active;
      
      console.log('[App] Page navigation:', pageName);
      telemetryService.trackPageView(pageName, `/${active}`);
    }
  }, [active, isAuthenticated, hasConsented]);

  // Step 1: Login via Microsoft SSO
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // Step 2: Consent / Warning
  if (!hasConsented) {
    return <ConsentPage onAccept={() => setHasConsented(true)} />;
  }

  const renderPage = () => {
    switch (active) {
      case 'summary':    return <DashboardPage />;
      case 'capability': return <CapabilityPage />;
      case 'fcrs':       return <FCRsPage />;
      case 'askai':      return <AskAIPage />;
      case 'reference':  return <ReferencePage />;
      default:           return <PlaceholderPage title="Coming Soon" />;
    }
  };

  return (
    <div className="app-shell">
      <Sidebar active={active} onNavigate={setActive} />
      <div className="main-area">
        <Topbar onNavigate={setActive} />
        <main className="page-content" id="main-content" role="main">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
