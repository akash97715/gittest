export const msalConfig = {
    auth: {
        clientId: "d33645b3-66c1-4adf-93c1-fde580806208",
        authority: "https://login.microsoftonline.com/3ac94b33-9135-4821-9502-eafda6592a35",
        redirectUri: window.location.origin + "/",
    },
    cache: {
        cacheLocation: "memory",
        storeAuthStateInCookie: false,
    }
};

export const loginRequest = {
    scopes: ["User.Read"],
    domainHint: "its.jnj.com"
};
