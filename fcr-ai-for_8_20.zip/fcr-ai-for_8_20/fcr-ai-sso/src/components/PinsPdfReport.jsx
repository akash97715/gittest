import {
  Document, Page, Text, View, StyleSheet, pdf, Font,
} from '@react-pdf/renderer';

// ── Color palette ────────────────────────────────────────────
const RED   = '#CC0000';
const DARK  = '#1B1F2A';
const GRAY  = '#6B7280';
const LGRAY = '#F3F4F6';
const BORDER= '#D1D5DB';
const WHITE = '#FFFFFF';
const PURPLE= '#5B21B6';
const GREEN = '#15803D';
const AMBER = '#D97706';

const SECTION_COLORS = {
  P: { header: '#7C3AED', light: '#F5F3FF', border: '#DDD6FE' },
  I: { header: '#2563EB', light: '#EFF6FF', border: '#BFDBFE' },
  N: { header: '#0369A1', light: '#F0F9FF', border: '#BAE6FD' },
  S: { header: '#059669', light: '#F0FDF4', border: '#BBF7D0' },
};

const SCORE_COLORS = {
  4: { color: '#1D4ED8', bg: '#DBEAFE' },
  3: { color: '#15803D', bg: '#DCFCE7' },
  2: { color: '#D97706', bg: '#FEF9C3' },
  1: { color: '#DC2626', bg: '#FEE2E2' },
};

const scLabel = s => s === 4 ? 'Expert' : s === 3 ? 'Advanced' : s === 2 ? 'Skilled' : 'Awareness';

const styles = StyleSheet.create({
  page: {
    fontFamily: 'Helvetica',
    fontSize: 8,
    color: DARK,
    paddingTop: 36,
    paddingBottom: 48,
    paddingHorizontal: 36,
  },
  // ── Header ──────────────────────────────────────────────────
  headerBar: {
    backgroundColor: RED,
    borderRadius: 4,
    padding: '10 14',
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: { color: WHITE, fontSize: 14, fontFamily: 'Helvetica-Bold' },
  headerSub:   { color: 'rgba(255,255,255,0.75)', fontSize: 8, marginTop: 2 },
  headerRight: { alignItems: 'flex-end' },
  headerDate:  { color: WHITE, fontSize: 9, fontFamily: 'Helvetica-Bold' },

  // ── Meta grid ───────────────────────────────────────────────
  metaGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 12,
  },
  metaCell: {
    width: '23%',
    backgroundColor: LGRAY,
    borderRadius: 4,
    padding: '5 7',
    border: `1 solid ${BORDER}`,
  },
  metaLabel: { fontSize: 6.5, color: GRAY, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 2 },
  metaValue: { fontSize: 8.5, fontFamily: 'Helvetica-Bold', color: DARK },

  // ── Disclaimer box ───────────────────────────────────────────
  disclaimer: {
    backgroundColor: '#FFFBEB',
    border: `1 solid #FDE68A`,
    borderRadius: 4,
    padding: '6 8',
    marginBottom: 12,
  },
  disclaimerText: { fontSize: 7, color: '#92400E', lineHeight: 1.4 },

  // ── Section heading ──────────────────────────────────────────
  sectionWrap: { marginBottom: 14 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: '6 10',
    borderRadius: '4 4 0 0',
  },
  sectionLetter: {
    width: 18, height: 18, borderRadius: 3,
    backgroundColor: WHITE,
    alignItems: 'center', justifyContent: 'center',
    marginRight: 7,
  },
  sectionLetterText: { fontSize: 10, fontFamily: 'Helvetica-Bold' },
  sectionTitle: { color: WHITE, fontSize: 10, fontFamily: 'Helvetica-Bold' },
  sectionSubtitle: { color: 'rgba(255,255,255,0.75)', fontSize: 7, marginLeft: 'auto' },

  sectionBody: {
    border: `1 solid ${BORDER}`,
    borderTop: 0,
    borderRadius: '0 0 4 4',
    padding: '8 10',
  },

  // FBMS skills pill row
  skillsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    marginBottom: 8,
  },
  skillPill: {
    backgroundColor: '#EDE9FE',
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  skillPillText: { fontSize: 6.5, color: PURPLE, fontFamily: 'Helvetica-Bold' },

  // Behavior rows table
  behaviorTable: { marginBottom: 8 },
  behaviorHeader: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    borderBottom: `1 solid ${BORDER}`,
    paddingVertical: 3,
    paddingHorizontal: 6,
  },
  behaviorHeaderText: { fontSize: 6.5, color: GRAY, textTransform: 'uppercase', letterSpacing: 0.4 },
  behaviorRow: {
    flexDirection: 'row',
    borderBottom: `1 solid #F0EDF0`,
    paddingVertical: 5,
    paddingHorizontal: 6,
    alignItems: 'flex-start',
  },
  behaviorId: { width: 20, flexShrink: 0 },
  behaviorIdText: { fontSize: 7.5, fontFamily: 'Helvetica-Bold', color: PURPLE },
  behaviorLabel: { flex: 1, paddingRight: 6 },
  behaviorLabelText: { fontSize: 7.5, color: DARK, lineHeight: 1.4 },
  behaviorSkills: { width: 90, paddingRight: 6 },
  behaviorSkillsText: { fontSize: 6.5, color: GRAY, lineHeight: 1.4 },
  behaviorScore: { width: 60, alignItems: 'flex-end' },
  scoreBadge: { borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  scoreBadgeText: { fontSize: 7, fontFamily: 'Helvetica-Bold' },

  // Overall impression row
  impressionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
    padding: '5 8',
    backgroundColor: '#FAFAFA',
    borderRadius: 4,
    border: `1 solid ${BORDER}`,
  },
  impressionLabel: { fontSize: 7.5, color: GRAY, flex: 1 },
  impressionBadge: { borderRadius: 4, paddingHorizontal: 8, paddingVertical: 3 },
  impressionText: { fontSize: 8, fontFamily: 'Helvetica-Bold' },

  // Two-column observation + training block
  twoCol: { flexDirection: 'row', gap: 8, marginBottom: 6 },
  colBox: {
    flex: 1,
    borderRadius: 4,
    padding: '6 8',
    border: `1 solid ${BORDER}`,
  },
  colLabel: {
    fontSize: 6.5, textTransform: 'uppercase', letterSpacing: 0.5,
    fontFamily: 'Helvetica-Bold', marginBottom: 4,
  },
  colText: { fontSize: 7.5, lineHeight: 1.5, color: DARK },

  // Compliance row
  complianceBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    border: `1 solid #BBF7D0`,
    borderRadius: 4,
    padding: '6 10',
    marginBottom: 12,
    gap: 10,
  },
  complianceLabel: { fontSize: 7.5, color: DARK, flex: 1, lineHeight: 1.4 },
  complianceValue: { fontSize: 9, fontFamily: 'Helvetica-Bold', color: GREEN },

  // FBMS skills summary panel (dark)
  skillsPanel: {
    backgroundColor: DARK,
    borderRadius: 6,
    padding: '10 12',
    marginBottom: 12,
  },
  skillsPanelTitle: { fontSize: 7, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 },
  skillRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  skillName: { width: 120, fontSize: 7.5, color: 'rgba(255,255,255,0.85)' },
  skillBarBg: { flex: 1, height: 4, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 2, marginHorizontal: 8, position: 'relative' },
  skillBarFill: { height: 4, borderRadius: 2 },
  skillScoreText: { width: 60, fontSize: 7, color: 'rgba(255,255,255,0.5)', textAlign: 'right' },
  skillBadge: { borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2, marginLeft: 6 },
  skillBadgeText: { fontSize: 6.5, fontFamily: 'Helvetica-Bold' },

  // AI Summary
  summaryBox: {
    backgroundColor: '#EDE9FE',
    border: `1 solid #C4B5FD`,
    borderRadius: 4,
    padding: '8 10',
    marginBottom: 12,
  },
  summaryLabel: { fontSize: 6.5, color: PURPLE, textTransform: 'uppercase', letterSpacing: 0.5, fontFamily: 'Helvetica-Bold', marginBottom: 4 },
  summaryText: { fontSize: 8, color: '#3B1F7A', lineHeight: 1.6 },

  // Action items
  actionBox: {
    borderRadius: 4,
    padding: '6 8',
    marginBottom: 6,
    border: `1 solid ${BORDER}`,
  },
  actionLabel: { fontSize: 6.5, textTransform: 'uppercase', letterSpacing: 0.5, fontFamily: 'Helvetica-Bold', marginBottom: 3 },
  actionText: { fontSize: 7.5, lineHeight: 1.5, color: DARK },

  // Footer
  footer: {
    position: 'absolute', bottom: 20, left: 36, right: 36,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderTop: `1 solid ${BORDER}`,
    paddingTop: 6,
  },
  footerText: { fontSize: 6.5, color: GRAY },

  // Divider
  divider: { borderBottom: `1 solid ${BORDER}`, marginVertical: 8 },
});

// ── FBMS skill abbreviations ─────────────────────────────────
const SKILL_ABBR = {
  DataGathering:        'DG',
  StrategicThinking:    'ST',
  CompetitiveLandscape: 'CL',
  Influencing:          'IO',
  ClinicalExpertise:    'CE',
  ProblemSolving:       'PS',
  CrossFunctional:      'CC',
};
const SKILL_LABELS = {
  DataGathering:        'Data Gathering & Analysis',
  StrategicThinking:    'Strategic Thinking',
  CompetitiveLandscape: 'Competitive Landscape',
  Influencing:          'Influencing Others',
  ClinicalExpertise:    'Clinical Expertise',
  ProblemSolving:       'Problem Solving',
  CrossFunctional:      'Cross-functional Collaboration',
};
const SKILL_COLORS = ['#6366F1','#7C3AED','#EC4899','#F59E0B','#10B981','#3B82F6','#14B8A6'];

const SECTION_NAMES = {
  P: 'Planning for Perspective',
  I: 'Investigate Issues',
  N: 'Navigate and Negotiate Needs',
  S: 'Secure Action',
};

// ── ScoreBadge helper ─────────────────────────────────────────
function ScoreBadge({ score, large }) {
  if (!score) return null;
  const c = SCORE_COLORS[score] || SCORE_COLORS[1];
  return (
    <View style={[styles.scoreBadge, { backgroundColor: c.bg }]}>
      <Text style={[styles.scoreBadgeText, { color: c.color, fontSize: large ? 8 : 7 }]}>
        {scLabel(score)}
      </Text>
    </View>
  );
}

// ── PINS Section component ────────────────────────────────────
function PinsSection({ letter, sectionData, trainingFlag, detectedLevel }) {
  const name  = SECTION_NAMES[letter];
  const c     = SECTION_COLORS[letter];
  const d     = sectionData || {};
  const behaviors = d.behaviors || [];
  const trainingNeeded = trainingFlag === true;

  return (
    <View style={styles.sectionWrap} wrap={false}>
      {/* Coloured section header */}
      <View style={[styles.sectionHeader, { backgroundColor: c.header }]}>
        <View style={styles.sectionLetter}>
          <Text style={[styles.sectionLetterText, { color: c.header }]}>{letter}</Text>
        </View>
        <Text style={styles.sectionTitle}>{name} of PINS</Text>
        <Text style={styles.sectionSubtitle}>Aligning to FBMS Core Skills</Text>
      </View>

      <View style={[styles.sectionBody, { borderColor: c.border }]}>
        {/* FBMS skill pills */}
        <View style={styles.skillsRow}>
          {Object.entries(SKILL_ABBR).map(([key, abbr]) => (
            <View key={key} style={styles.skillPill}>
              <Text style={styles.skillPillText}>• {SKILL_LABELS[key]} ({abbr})</Text>
            </View>
          ))}
        </View>

        {/* Behavior rows */}
        {behaviors.length > 0 && (
          <View style={styles.behaviorTable}>
            <View style={styles.behaviorHeader}>
              <Text style={[styles.behaviorHeaderText, { flex: 1 }]}>Observable Behaviour</Text>
              <Text style={[styles.behaviorHeaderText, { width: 90 }]}>FBMS Skills</Text>
              <Text style={[styles.behaviorHeaderText, { width: 60, textAlign: 'right' }]}>Proficiency</Text>
            </View>
            {behaviors.map((b) => (
              <View key={b.id} style={styles.behaviorRow}>
                <View style={styles.behaviorId}>
                  <Text style={styles.behaviorIdText}>{b.id}</Text>
                </View>
                <View style={styles.behaviorLabel}>
                  <Text style={styles.behaviorLabelText}>{b.label}</Text>
                  {b.note ? <Text style={{ fontSize: 6.5, color: GRAY, marginTop: 2, lineHeight: 1.4 }}>{b.note}</Text> : null}
                </View>
                <View style={styles.behaviorSkills}>
                  <Text style={styles.behaviorSkillsText}>{(b.skills || []).map(s => {
                    const key = Object.keys(SKILL_LABELS).find(k => SKILL_LABELS[k] === s || k === s.replace(/\s/g,''));
                    return key ? `${SKILL_LABELS[key]} (${SKILL_ABBR[key]})` : s;
                  }).join(', ')}</Text>
                </View>
                <View style={styles.behaviorScore}>
                  <ScoreBadge score={b.score} />
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Overall impression */}
        <View style={styles.impressionRow}>
          <Text style={styles.impressionLabel}>
            Rate the overall quality of the {name} section of PINS
          </Text>
          {d.score && <ScoreBadge score={d.score} large />}
        </View>

        {/* Observations + Training side by side */}
        <View style={styles.twoCol}>
          <View style={[styles.colBox, { backgroundColor: '#F9FAFB' }]}>
            <Text style={[styles.colLabel, { color: DARK }]}>{name}:</Text>
            <Text style={{ fontSize: 6.5, color: GRAY, marginBottom: 4 }}>
              Comment on observations, specific examples and coaching provided (N/A if not applicable):
            </Text>
            <Text style={styles.colText}>{d.strength || '—'}</Text>
            {d.opportunity ? (
              <>
                <Text style={{ fontSize: 6.5, color: AMBER, marginTop: 5, marginBottom: 2, fontFamily: 'Helvetica-Bold' }}>Development Opportunity:</Text>
                <Text style={styles.colText}>{d.opportunity}</Text>
              </>
            ) : null}
          </View>
          <View style={[styles.colBox, { backgroundColor: trainingNeeded ? '#FEF2F2' : '#F0FDF4', borderColor: trainingNeeded ? '#FECACA' : '#BBF7D0' }]}>
            <Text style={[styles.colLabel, { color: trainingNeeded ? '#991B1B' : GREEN }]}>
              {name}: Training Needed? {trainingNeeded ? 'YES ⚠' : trainingFlag === false ? 'No ✓' : 'N/A'}
            </Text>
            {trainingNeeded && d.opportunity ? (
              <>
                <Text style={{ fontSize: 6.5, color: GRAY, marginBottom: 3 }}>Identify specific training needs and date for follow-up:</Text>
                <Text style={[styles.colText, { color: '#7F1D1D' }]}>{d.opportunity}</Text>
              </>
            ) : (
              <Text style={[styles.colText, { color: GREEN }]}>No additional training identified at this time.</Text>
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

// ── Main PDF Document ─────────────────────────────────────────
function PinsPdfDocument({ fcr, detail, pinsScores }) {
  if (!fcr || !pinsScores) return null;

  const meta = detail[0] || {};
  const rawSt = (meta.survey_target_status || '').toLowerCase();
  const statusLabel = (rawSt.includes('late') && rawSt.includes('submission')) ? 'Late Submission'
                    : rawSt.includes('submitted') ? 'Submitted'
                    : (rawSt.includes('saved') || rawSt.includes('draft')) ? 'Draft' : 'Draft';

  const coacheeName = `${fcr.coachee_first || ''} ${fcr.coachee_last || ''}`.trim() || '—';
  const coachDate   = fcr.coaching_date ? new Date(fcr.coaching_date).toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' }) : '—';
  const modDate     = meta.survey_target_last_modified_date ? new Date(meta.survey_target_last_modified_date).toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' }) : '—';

  const prevAction  = meta.survey_target_previous_action_item || fcr.prev_action || '';
  const nextAction  = meta.survey_target_action_item || fcr.action_item || '';

  const complianceRow = detail.find(r => r.survey_question_text && /field observation/i.test(r.survey_question_text) && r.survey_question_response);
  const isCompliant   = complianceRow?.survey_question_response === 'Yes';

  const secs    = pinsScores.sections  || {};
  const skills  = pinsScores.skills    || {};
  const gaps    = pinsScores.gaps      || {};
  const flags   = pinsScores.trainingFlags || {};
  const lvl     = pinsScores.detectedLevel || 'PG30';
  const lvlLabel = { PG30:'MSL (PG30)', PG31:'Sr MSL / Reg Acct Dir (PG31)', PG40:'Principal MSL / Field Dir (PG40)', PG41:'Sr Dir / MSL Head (PG41)' }[lvl] || lvl;

  const skillKeys = Object.keys(SKILL_LABELS);

  return (
    <Document title={`PINS FCR — ${coacheeName}`} author="FCR AI Insights · Johnson & Johnson">

      {/* ── PAGE 1 ── */}
      <Page size="A4" style={styles.page}>

        {/* Red header bar */}
        <View style={styles.headerBar}>
          <View>
            <Text style={styles.headerTitle}>MSL/VESE Field Coaching Report</Text>
            <Text style={styles.headerSub}>PINS Framework · AI-Scored · Johnson &amp; Johnson · FCR AI Insights</Text>
          </View>
          <View style={styles.headerRight}>
            <Text style={styles.headerDate}>{coachDate}</Text>
            <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 7, marginTop: 2 }}>FCR ID: {fcr.fcr_id?.slice(-10).toUpperCase()}</Text>
          </View>
        </View>

        {/* Meta grid */}
        <View style={styles.metaGrid}>
          {[
            ['Coachee',          coacheeName],
            ['Role / Title',     fcr.coachee_role || '—'],
            ['Coaching Date',    coachDate],
            ['Coaching End Date',modDate],
            ['Coach (FD ID)',    fcr.field_director_id || '—'],
            ['Session Duration', meta.survey_target_session_duration || '—'],
            ['Report Status',    statusLabel],
            ['Job Level (FBMS)', lvlLabel],
            ['TA',               fcr.ta || '—'],
            ['Region',           fcr.region || '—'],
            ['Territory',        fcr.territory || fcr.district || '—'],
            ['Form',             'MSL/VESE Field Coaching Report'],
          ].map(([label, val]) => (
            <View key={label} style={styles.metaCell}>
              <Text style={styles.metaLabel}>{label}</Text>
              <Text style={styles.metaValue}>{val}</Text>
            </View>
          ))}
        </View>

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            Reports must follow Clear Communications standards and reflect accurate, objective information.
            Any potential Adverse Events (AEs) or Product Quality Complaints (PQCs) must be reported
            immediately per company requirements.
          </Text>
        </View>

        {/* Session Goals / Previous Action */}
        {(prevAction || nextAction) && (
          <View style={{ marginBottom: 12 }}>
            <Text style={{ fontSize: 8.5, fontFamily: 'Helvetica-Bold', color: DARK, marginBottom: 6 }}>Session Goals &amp; Previous Action Items</Text>
            <View style={styles.twoCol}>
              {prevAction ? (
                <View style={[styles.colBox, { backgroundColor: '#FFF7ED', borderColor: '#FED7AA' }]}>
                  <Text style={[styles.colLabel, { color: '#C2410C' }]}>Previous Action Items</Text>
                  <Text style={styles.colText}>{prevAction}</Text>
                </View>
              ) : null}
              {nextAction ? (
                <View style={[styles.colBox, { backgroundColor: '#F0FDF4', borderColor: '#BBF7D0' }]}>
                  <Text style={[styles.colLabel, { color: GREEN }]}>Action Items / Next Steps</Text>
                  <Text style={styles.colText}>{nextAction}</Text>
                </View>
              ) : null}
            </View>
          </View>
        )}

        {/* AI Summary */}
        {pinsScores.summary && (
          <View style={styles.summaryBox}>
            <Text style={styles.summaryLabel}>⬡ AI PINS Summary — {lvlLabel} targets applied</Text>
            <Text style={styles.summaryText}>{pinsScores.summary}</Text>
          </View>
        )}

        {/* P section */}
        <PinsSection letter="P" sectionData={secs.P} trainingFlag={flags.P} detectedLevel={lvl} />

        {/* Footer */}
        <View style={styles.footer} fixed>
          <Text style={styles.footerText}>FCR AI Insights · Johnson &amp; Johnson · Confidential</Text>
          <Text style={styles.footerText} render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
        </View>
      </Page>

      {/* ── PAGE 2 ── */}
      <Page size="A4" style={styles.page}>
        <PinsSection letter="I" sectionData={secs.I} trainingFlag={flags.I} detectedLevel={lvl} />
        <PinsSection letter="N" sectionData={secs.N} trainingFlag={flags.N} detectedLevel={lvl} />
        <View style={styles.footer} fixed>
          <Text style={styles.footerText}>FCR AI Insights · Johnson &amp; Johnson · Confidential</Text>
          <Text style={styles.footerText} render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
        </View>
      </Page>

      {/* ── PAGE 3 ── */}
      <Page size="A4" style={styles.page}>
        <PinsSection letter="S" sectionData={secs.S} trainingFlag={flags.S} detectedLevel={lvl} />

        {/* Compliance / Scientific Exchange */}
        <View style={styles.complianceBox}>
          <Text style={styles.complianceLabel}>
            During this field observation, did the FBMS engage in appropriate, non-promotional scientific
            exchange consistent with their medical role, Company policies, and medical–commercial independence?
          </Text>
          <Text style={[styles.complianceValue, { color: isCompliant ? GREEN : '#DC2626' }]}>
            {complianceRow ? (isCompliant ? '✓ Yes' : '✗ No') : 'N/A'}
          </Text>
        </View>

        {/* 7 FBMS Core Skills Panel */}
        <View style={styles.skillsPanel}>
          <Text style={styles.skillsPanelTitle}>7 FBMS Core Skills — AI Scored vs {lvlLabel} Target</Text>
          {skillKeys.map((key, idx) => {
            const s = skills[key];
            const g = gaps[key];
            if (!s) return null;
            const barPct    = Math.round((s.score / 4) * 100);
            const targetPct = g ? Math.round((g.target / 4) * 100) : null;
            const onTarget  = !g || g.gap >= 0;
            const barColor  = SKILL_COLORS[idx % SKILL_COLORS.length];
            return (
              <View key={key} style={styles.skillRow}>
                <Text style={styles.skillName}>{SKILL_LABELS[key]}</Text>
                <View style={styles.skillBarBg}>
                  <View style={[styles.skillBarFill, { width: `${barPct}%`, backgroundColor: barColor }]} />
                </View>
                <Text style={styles.skillScoreText}>{s.score}/4 · {scLabel(s.score)}</Text>
                <View style={[styles.skillBadge, {
                  backgroundColor: onTarget ? 'rgba(22,163,74,0.2)' : 'rgba(220,38,38,0.2)',
                }]}>
                  <Text style={[styles.skillBadgeText, { color: onTarget ? '#86EFAC' : '#FCA5A5' }]}>
                    {onTarget ? '✓ Target' : `↑ Need ${g?.target}`}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* System info row */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
          <View style={[styles.colBox, { flex: 1, marginRight: 8, backgroundColor: '#F9FAFB' }]}>
            <Text style={[styles.colLabel, { color: GRAY }]}>Coaching Report Employee Review</Text>
            <Text style={styles.colText}>{coacheeName}</Text>
          </View>
          <View style={[styles.colBox, { flex: 1, backgroundColor: '#F9FAFB' }]}>
            <Text style={[styles.colLabel, { color: GRAY }]}>System Information</Text>
            <Text style={styles.colText}>Generated: {new Date().toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' })}</Text>
            <Text style={[styles.colText, { marginTop: 2 }]}>Source: FCR AI Insights · Redshift ODP</Text>
          </View>
        </View>

        <View style={styles.footer} fixed>
          <Text style={styles.footerText}>FCR AI Insights · Johnson &amp; Johnson · Confidential</Text>
          <Text style={styles.footerText} render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`} />
        </View>
      </Page>
    </Document>
  );
}

// ── Export: async download function ─────────────────────────
export async function downloadPinsPdf({ fcr, detail, pinsScores }) {
  const doc  = <PinsPdfDocument fcr={fcr} detail={detail} pinsScores={pinsScores} />;
  const blob = await pdf(doc).toBlob();
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const coacheeName = `${fcr.coachee_first || ''}_${fcr.coachee_last || ''}`.trim().replace(/\s+/g, '_');
  const dateStr = fcr.coaching_date ? new Date(fcr.coaching_date).toISOString().slice(0,10) : 'undated';
  a.href     = url;
  a.download = `PINS_FCR_${coacheeName}_${dateStr}.pdf`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
