import { LayoutDashboard, BarChart2, Bot, BookOpen, FileText, Settings, LogOut } from 'lucide-react';
import { useMsal } from '@azure/msal-react';

const NAV = [
  { id: 'summary',    icon: LayoutDashboard, label: 'Summary' },
  { id: 'capability', icon: BarChart2,        label: 'Skill & Compliance' },
  { id: 'fcrs',       icon: FileText,         label: 'FCRs' },
  { id: 'askai',      icon: Bot,              label: 'Ask AI' },
  { id: 'reference',  icon: BookOpen,         label: 'Reference' },
];

export default function Sidebar({ active, onNavigate }) {
  const { instance, accounts } = useMsal();
  const account   = accounts[0];
  const fullName  = account?.name ?? 'User';
  const jobTitle  = account?.idTokenClaims?.jobTitle || account?.idTokenClaims?.title || account?.idTokenClaims?.preferred_username?.split('@')[0] || 'MSL Field Team';
  const initials  = fullName.split(' ').filter(Boolean).map(w => w[0].toUpperCase()).slice(0, 2).join('');

  const handleLogout = () => instance.logoutRedirect({ postLogoutRedirectUri: '/' });
  const handleSettings = () => alert('Settings panel coming soon.');

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="jnj">Johnson&amp;Johnson</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
          <div className="brand">FCR Insights</div>
          <span className="ai-badge">⚡ AI Powered</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {NAV.map(item => (
          <div
            key={item.id}
            id={`nav-${item.id}`}
            className={`nav-item ${active === item.id ? 'active' : ''} ${item.muted ? 'muted' : ''}`}
            onClick={() => !item.muted && onNavigate(item.id)}
            aria-label={item.label}
          >
            <item.icon size={14} />
            {item.label}
          </div>
        ))}
      </nav>

      <div className="sidebar-user">
        <div className="user-info">
          <div className="avatar">{initials}</div>
          <div>
            <div className="name">{fullName}</div>
            <div className="role">{jobTitle}</div>
          </div>
        </div>
        <div className="sidebar-user-links">
          <div className="sidebar-user-link" onClick={handleSettings} style={{ cursor:'pointer' }}><Settings size={11} /> Settings</div>
          <div className="sidebar-user-link" onClick={handleLogout}   style={{ cursor:'pointer' }}><LogOut size={11} /> Log out</div>
        </div>
      </div>
    </aside>
  );
}
