import { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import './TelemetryDashboard.css';

/**
 * Telemetry Analytics Dashboard
 * Displays user tracking and engagement metrics
 */

export default function TelemetryDashboard() {
  const [summary, setSummary] = useState(null);
  const [pageAnalytics, setPageAnalytics] = useState([]);
  const [buttonClicks, setButtonClicks] = useState([]);
  const [userSessions, setUserSessions] = useState([]);
  const [errors, setErrors] = useState([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState(7);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTelemetryData();
  }, [selectedTimeframe]);

  const fetchTelemetryData = async () => {
    setLoading(true);
    try {
      const [summaryRes, pagesRes, buttonsRes, sessionsRes, errorsRes] = await Promise.all([
        fetch(`/api/telemetry/usage-summary?days=${selectedTimeframe}`),
        fetch(`/api/telemetry/page-analytics?days=${selectedTimeframe}`),
        fetch(`/api/telemetry/button-clicks?days=${selectedTimeframe}&limit=10`),
        fetch(`/api/telemetry/user-sessions?days=${selectedTimeframe}&limit=20`),
        fetch(`/api/telemetry/errors?days=${selectedTimeframe}&limit=10`),
      ]);

      if (summaryRes.ok) setSummary(await summaryRes.json());
      if (pagesRes.ok) setPageAnalytics(await pagesRes.json());
      if (buttonsRes.ok) setButtonClicks(await buttonsRes.json());
      if (sessionsRes.ok) setUserSessions(await sessionsRes.json());
      if (errorsRes.ok) setErrors(await errorsRes.json());
    } catch (error) {
      console.error('Error fetching telemetry data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="telemetry-loading">Loading analytics...</div>;
  }

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="telemetry-dashboard">
      <div className="telemetry-header">
        <h1>📊 FCR AI Analytics Dashboard</h1>
        <div className="timeframe-selector">
          <label>Timeframe:</label>
          <select value={selectedTimeframe} onChange={(e) => setSelectedTimeframe(parseInt(e.target.value))}>
            <option value={1}>Last 24 Hours</option>
            <option value={7}>Last 7 Days</option>
            <option value={30}>Last 30 Days</option>
            <option value={90}>Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      {summary && (
        <div className="kpi-grid">
          <div className="kpi-card">
            <div className="kpi-label">Active Users</div>
            <div className="kpi-value">{summary.active_users}</div>
            <div className="kpi-detail">users in last {selectedTimeframe} days</div>
          </div>

          <div className="kpi-card">
            <div className="kpi-label">Total Sessions</div>
            <div className="kpi-value">{summary.total_sessions}</div>
            <div className="kpi-detail">{(summary.total_sessions / summary.active_users || 0).toFixed(1)} per user</div>
          </div>

          <div className="kpi-card">
            <div className="kpi-label">Total Logins</div>
            <div className="kpi-value">{summary.total_logins}</div>
            <div className="kpi-detail">authentication events</div>
          </div>

          <div className="kpi-card">
            <div className="kpi-label">Avg Session Duration</div>
            <div className="kpi-value">{Math.round(summary.avg_session_duration_seconds / 60)}m</div>
            <div className="kpi-detail">{summary.avg_session_duration_seconds}s total</div>
          </div>

          <div className="kpi-card">
            <div className="kpi-label">Page Views</div>
            <div className="kpi-value">{summary.total_events}</div>
            <div className="kpi-detail">interactions tracked</div>
          </div>

          <div className={`kpi-card ${summary.total_errors > 20 ? 'error' : ''}`}>
            <div className="kpi-label">Total Errors</div>
            <div className="kpi-value" style={{ color: summary.total_errors > 20 ? '#ef4444' : '#10b981' }}>
              {summary.total_errors}
            </div>
            <div className="kpi-detail">{summary.total_errors > 20 ? '⚠️ Monitor' : '✓ Healthy'}</div>
          </div>
        </div>
      )}

      <div className="analytics-grid">
        {/* Page Analytics */}
        {pageAnalytics.length > 0 && (
          <div className="analytics-card">
            <h2>📄 Page Performance (Last {selectedTimeframe} Days)</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={pageAnalytics}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="page_name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="view_count" fill="#3b82f6" name="Page Views" />
                <Bar dataKey="unique_visitors" fill="#10b981" name="Unique Visitors" />
              </BarChart>
            </ResponsiveContainer>

            <table className="analytics-table">
              <thead>
                <tr>
                  <th>Page</th>
                  <th>Views</th>
                  <th>Unique Visitors</th>
                  <th>Avg Time (s)</th>
                </tr>
              </thead>
              <tbody>
                {pageAnalytics.map((page, idx) => (
                  <tr key={idx}>
                    <td><strong>{page.page_name}</strong></td>
                    <td>{page.page_views}</td>
                    <td>{page.unique_sessions}</td>
                    <td>{page.avg_time_spent_seconds}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Button Click Analytics */}
        {buttonClicks.length > 0 && (
          <div className="analytics-card">
            <h2>🖱️ Most Used Features (Top 10)</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={buttonClicks} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis type="category" dataKey="button_name" width={150} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="click_count" fill="#8b5cf6" name="Clicks" />
              </BarChart>
            </ResponsiveContainer>

            <table className="analytics-table">
              <thead>
                <tr>
                  <th>Feature</th>
                  <th>Page</th>
                  <th>Clicks</th>
                  <th>Unique Users</th>
                </tr>
              </thead>
              <tbody>
                {buttonClicks.map((btn, idx) => (
                  <tr key={idx}>
                    <td><strong>{btn.button_name}</strong></td>
                    <td>{btn.page}</td>
                    <td>{btn.click_count}</td>
                    <td>{btn.unique_users}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* User Sessions */}
      {userSessions.length > 0 && (
        <div className="analytics-card full-width">
          <h2>👥 Recent User Sessions</h2>
          <table className="sessions-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Email</th>
                <th>Session Start</th>
                <th>Duration</th>
                <th>Events</th>
                <th>Event Types</th>
              </tr>
            </thead>
            <tbody>
              {userSessions.slice(0, 15).map((session, idx) => (
                <tr key={idx}>
                  <td>{session.user_name}</td>
                  <td className="email">{session.user_email}</td>
                  <td>{new Date(session.session_start).toLocaleString()}</td>
                  <td>{Math.round(session.duration_seconds / 60)}m</td>
                  <td>{session.event_count}</td>
                  <td>{session.event_types}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Errors */}
      {errors.length > 0 && (
        <div className="analytics-card full-width">
          <h2>⚠️ Recent Errors ({errors.length} total)</h2>
          <table className="errors-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>User</th>
                <th>Page</th>
                <th>Error Message</th>
                <th>Count</th>
              </tr>
            </thead>
            <tbody>
              {errors.map((err, idx) => (
                <tr key={idx} className="error-row">
                  <td>{new Date(err.timestamp).toLocaleString()}</td>
                  <td>{err.user_name}</td>
                  <td>{err.page}</td>
                  <td className="error-message">{err.error_message}</td>
                  <td>{err.occurrence_count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Engagement Summary */}
      {summary && (
        <div className="analytics-card">
          <h2>📈 Engagement Metrics</h2>
          <div className="metrics-grid">
            <div className="metric">
              <div className="metric-label">Active Days</div>
              <div className="metric-value">{selectedTimeframe}</div>
            </div>
            <div className="metric">
              <div className="metric-label">Avg Events/User</div>
              <div className="metric-value">{(summary.total_events / summary.active_users || 0).toFixed(1)}</div>
            </div>
            <div className="metric">
              <div className="metric-label">Login Rate</div>
              <div className="metric-value">{((summary.total_logins / summary.active_users || 0).toFixed(1))}</div>
            </div>
            <div className="metric">
              <div className="metric-label">Error Rate</div>
              <div className="metric-value">{((summary.total_errors / summary.total_events * 100) || 0).toFixed(2)}%</div>
            </div>
          </div>
        </div>
      )}

      <div className="telemetry-footer">
        <p>📊 Telemetry data updated every 30 seconds. Last refresh: {new Date().toLocaleTimeString()}</p>
      </div>
    </div>
  );
}
