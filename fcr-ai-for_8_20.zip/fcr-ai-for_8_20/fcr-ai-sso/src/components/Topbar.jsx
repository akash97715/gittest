import { useState, useRef } from 'react';
import { Sparkles, ChevronDown, Moon, Sun, Bell, Users, LogOut, X } from 'lucide-react';
import { useMsal } from '@azure/msal-react';

export default function Topbar({ onNavigate }) {
  const { instance, accounts } = useMsal();
  const fullName = accounts[0]?.name ?? 'User';
  const initials = fullName.split(' ').filter(Boolean).map(w => w[0].toUpperCase()).slice(0, 2).join('');
  const [searchVal, setSearchVal] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const [showNotif, setShowNotif] = useState(false);
  const notifRef = useRef(null);

  const handleLogout = () => instance.logoutRedirect({ postLogoutRedirectUri: '/' });

  const handleSearch = () => {
    if (!searchVal.trim()) return;
    // Store query for AskAI page to pick up, then navigate
    sessionStorage.setItem('pendingAIQuery', searchVal.trim());
    setSearchVal('');
    onNavigate?.('askai');
  };

  const toggleTheme = () => {
    const next = !darkMode;
    setDarkMode(next);
    document.documentElement.setAttribute('data-theme', next ? 'dark' : 'light');
  };

  const NOTIFS = [
    { type: 'high',   text: '3 FCRs overdue >7 days in Southeast region' },
    { type: 'medium', text: 'Compliance flag on FCR from ONC — review needed' },
    { type: 'medium', text: 'Oncology submissions dropped 12% this week' },
    { type: 'low',    text: 'New coaching form version available (v3.2)' },
  ];
  const typeColor = { high: '#E60012', medium: '#D97706', low: '#6B7280' };
  const typeBg    = { high: '#FEF2F2', medium: '#FFFBEB', low: '#F9FAFB' };

  return (
    <header className="topbar">
      {/* Page title + badge */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
        <span className="topbar-logo">FCR AI Insights</span>
        <span className="medical-badge">MEDICAL</span>
      </div>

      {/* AI Search bar */}
      <div className="topbar-search-wrap">
        <Sparkles size={14} className="si" style={{ color: '#E60012' }} />
        <input
          id="global-search"
          type="text"
          placeholder="Ask anything, search MSLs, medical reports, scientific insights…"
          aria-label="AI Search"
          value={searchVal}
          onChange={e => setSearchVal(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSearch()}
        />
        <button className="topbar-search-btn" id="btn-ai-search" onClick={handleSearch}>AI Search</button>
      </div>

      {/* Right side controls */}
      <div className="topbar-right" style={{ position: 'relative' }}>
        {/* Theme toggle */}
        <div
          className="topbar-icon"
          title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          aria-label="Toggle theme"
          onClick={toggleTheme}
          style={{ cursor: 'pointer' }}
        >
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </div>

        {/* Notifications */}
        <div
          ref={notifRef}
          className="topbar-icon"
          id="btn-notifications"
          title="Notifications"
          aria-label="Notifications"
          onClick={() => setShowNotif(v => !v)}
          style={{ cursor: 'pointer', position: 'relative' }}
        >
          <Bell size={17} />
          <span className="notif-badge">{NOTIFS.length}</span>
        </div>

        {/* Notification dropdown */}
        {showNotif && (
          <div style={{
            position: 'absolute', top: 40, right: 0, width: 320, zIndex: 500,
            background: '#fff', border: '1px solid #E9E5E7', borderRadius: 12,
            boxShadow: '0 8px 30px rgba(0,0,0,0.14)', overflow: 'hidden',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', borderBottom: '1px solid #F3F4F6' }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#1B1F2A' }}>Notifications</span>
              <button onClick={() => setShowNotif(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2 }}><X size={14} color="#9CA3AF" /></button>
            </div>
            {NOTIFS.map((n, i) => (
              <div key={i} style={{ padding: '10px 16px', borderBottom: i < NOTIFS.length - 1 ? '1px solid #F9FAFB' : 'none', background: typeBg[n.type], display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: typeColor[n.type], flexShrink: 0, marginTop: 4 }} />
                <span style={{ fontSize: 12, color: '#374151', lineHeight: 1.5 }}>{n.text}</span>
              </div>
            ))}
          </div>
        )}

        {/* Avatar */}
        <div className="topbar-avatar" id="user-avatar" title={fullName} aria-label="User menu">{initials}</div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          title="Sign out"
          aria-label="Sign out"
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '5px 10px', borderRadius: 8,
            border: '1px solid #E9E5E7', background: '#fff',
            color: '#6B7280', fontSize: 11, fontWeight: 600,
            cursor: 'pointer', fontFamily: 'inherit',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = '#FEF2F2'; e.currentTarget.style.color = '#E60012'; e.currentTarget.style.borderColor = '#FECACA'; }}
          onMouseLeave={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.color = '#6B7280'; e.currentTarget.style.borderColor = '#E9E5E7'; }}
        >
          <LogOut size={13} />
          Sign out
        </button>
      </div>
    </header>
  );
}
