/**
 * Telemetry Constants for Frontend
 * Mirrors backend/telemetry/constants.js for consistency
 */

export const VALID_EVENT_TYPES = [
  'user_login',
  'user_logout',
  'browser_closed',
  'session_start',
  'session_end',
  'page_view',
  'page_exit',
  'button_click',
  'search',
  'data_export',
  'api_call',
  'error',
  'custom'
];

/**
 * Frontend telemetry configuration from Vite environment
 */
export const TELEMETRY_CONFIG = {
  ENABLED: import.meta.env.VITE_TELEMETRY_ENABLED === 'true',
  BATCH_SIZE: parseInt(import.meta.env.VITE_TELEMETRY_BATCH_SIZE || '10'),
  FLUSH_INTERVAL_MS: parseInt(import.meta.env.VITE_TELEMETRY_FLUSH_INTERVAL_MS || '30000')
};

/**
 * Event payload builder
 */
export function createEventPayload(type, data = {}) {
  if (!VALID_EVENT_TYPES.includes(type)) {
    throw new Error(`Invalid event type: ${type}`);
  }
  return {
    event_type: type,
    event_data: data,
    timestamp: new Date().toISOString()
  };
}
