import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { PublicClientApplication } from '@azure/msal-browser';
import { MsalProvider } from '@azure/msal-react';
import { msalConfig } from './authConfig';
import './index.css'
import App from './App.jsx'

const msalInstance = new PublicClientApplication(msalConfig);

msalInstance.initialize().then(() => {
  return msalInstance.handleRedirectPromise();
}).then((response) => {
  const accounts = msalInstance.getAllAccounts();
  if (response?.account) {
    msalInstance.setActiveAccount(response.account);
  } else if (accounts.length > 0) {
    msalInstance.setActiveAccount(accounts[0]);
  }
  createRoot(document.getElementById('root')).render(
    <StrictMode>
      <MsalProvider instance={msalInstance}>
        <App />
      </MsalProvider>
    </StrictMode>,
  );
});
