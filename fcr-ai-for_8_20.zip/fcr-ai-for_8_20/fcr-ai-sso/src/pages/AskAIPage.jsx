import { useState, useRef, useEffect } from 'react';
import {
  Sparkles, Send, CheckCircle2,
  LayoutGrid, Users, Briefcase, User, BookOpen,
  Target, TrendingUp, Zap, RotateCcw, ChevronDown, ChevronUp,
} from 'lucide-react';

// ── Role filter data ─────────────────────────────────────────
const SUGGESTIONS = [
  'How many FCRs were written this quarter?',
  'Which region has the most coaching activity?',
  'Top 5 reps by FCR count',
];

const ROLES = [
  { id: 'all',      label: 'All',            Icon: LayoutGrid },
  { id: 'hr',       label: 'HR / Talent',    Icon: Users },
  { id: 'director', label: 'Field Director', Icon: Briefcase },
  { id: 'msl',      label: 'MSL Leader',     Icon: User },
  { id: 'ld',       label: 'L&D',            Icon: BookOpen },
];

const SUGGESTED_CARDS = [
  {
    category: 'ADOPTION',
    catColor: '#E11937',
    catBg:    '#FDECEE',
    Icon: Target,
    q: 'How many FCRs were written this quarter?',
  },
  {
    category: 'GEOGRAPHY',
    catColor: '#7C3AED',
    catBg:    '#F5F3FF',
    Icon: TrendingUp,
    q: 'Which region has the most coaching activity in the past 30 days?',
  },
  {
    category: 'REP RANKING',
    catColor: '#2563EB',
    catBg:    '#EFF6FF',
    Icon: Zap,
    q: 'Show me the top 10 reps by number of FCRs written',
  },
];

// ── Main page ────────────────────────────────────────────────
export default function AskAIPage() {
  const [activeRole, setActiveRole]   = useState('all');
  const [query,      setQuery]        = useState('');
  const [messages,   setMessages]     = useState([]);   // {role:'user'|'ai', content, rows, sql, loading}
  const [isLoading,  setIsLoading]    = useState(false);
  const bottomRef = useRef(null);

  // Pick up query forwarded from the Topbar global search
  useEffect(() => {
    const pending = sessionStorage.getItem('pendingAIQuery');
    if (pending) {
      sessionStorage.removeItem('pendingAIQuery');
      handleAsk(pending);
    }
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const isConversationStarted = messages.length > 0;

  const handleAsk = async (q = query) => {
    const trimmed = q.trim();
    if (!trimmed || isLoading) return;
    setQuery('');

    const userMsg  = { role: 'user', content: trimmed };
    const loadingMsg = { role: 'ai', content: '', loading: true };
    setMessages(prev => [...prev, userMsg, loadingMsg]);
    setIsLoading(true);

    // Build history for context (last 6 messages, exclude loading)
    const history = messages.slice(-6).filter(m => !m.loading).map(m => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
    }));

    try {
      const resp = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed, history }),
      });
      const data = await resp.json();
      setMessages(prev => [
        ...prev.slice(0, -1),   // remove loading bubble
        { role: 'ai', content: data.summary || data.error || 'No response', rows: data.rows, sql: data.sql, error: data.error },
      ]);
    } catch {
      setMessages(prev => [
        ...prev.slice(0, -1),
        { role: 'ai', content: 'Network error — is the server running?', error: true },
      ]);
    }
    setIsLoading(false);
  };

  const handleReset = () => { setMessages([]); setQuery(''); };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* ── HERO CARD ──────────────────────────────────────── */}
      <div className="dash-card">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10, background: '#E11937', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Sparkles size={20} color="#fff" />
            </div>
            <div>
              <div className="section-eyebrow" style={{ color: '#E11937' }}>CONVERSATIONAL INSIGHTS</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#1B1F2A', marginTop: 2, letterSpacing: '-0.3px' }}>Ask AI</div>
              <div style={{ fontSize: 12, color: '#6B7280', marginTop: 3 }}>
                Natural-language exploration across FCRs, skills, adoption and coaching themes
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {isConversationStarted && (
              <button onClick={handleReset} style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', borderRadius: 20, border: '1px solid #E8E5E8',
                background: '#fff', color: '#374151', fontSize: 12, fontWeight: 600,
                cursor: 'pointer', fontFamily: 'inherit',
              }}>
                <RotateCcw size={12} /> New conversation
              </button>
            )}
            <div className="sync-pill">
              <CheckCircle2 size={12} color="#16A34A" />
              GPT-powered · Live Redshift
            </div>
          </div>
        </div>
      </div>

      {/* ── CONVERSATION VIEW ──────────────────────────────── */}
      {isConversationStarted ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {messages.map((msg, i) => (
            msg.role === 'user'
              ? <UserBubble key={i} content={msg.content} />
              : <AIBubble    key={i} msg={msg} />
          ))}
          <div ref={bottomRef} />

          {/* Sticky input at bottom */}
          <div style={{ position: 'sticky', bottom: 16, zIndex: 50 }}>
            <AskInputBar value={query} onChange={setQuery} onSubmit={handleAsk} loading={isLoading} />
          </div>
        </div>
      ) : (
        /* ── EMPTY STATE ─────────────────────────────────── */
        <div style={{
          background: '#FDFAF8',
          backgroundImage: `
            linear-gradient(rgba(225,25,55,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(225,25,55,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '36px 36px',
          border: '1.5px solid #F5D0D6',
          borderRadius: 18,
          padding: '56px 40px 48px',
          textAlign: 'center',
          boxShadow: '0 2px 14px rgba(225,25,55,0.05)',
        }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 7,
            background: '#fff', border: '1px solid #F5C6CE', borderRadius: 20,
            padding: '5px 14px', marginBottom: 28,
            boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
          }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#22C55E', flexShrink: 0, display: 'inline-block' }} />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#1B1F2A' }}>FCR Intelligence</span>
            <span style={{ fontSize: 11, color: '#6B7280' }}>· online</span>
          </div>

          <h2 style={{ fontSize: 32, fontWeight: 800, color: '#1B1F2A', lineHeight: 1.2, marginBottom: 14, letterSpacing: '-0.5px' }}>
            Ask anything about your{' '}
            <span style={{ color: '#E11937' }}>field coaching data</span>
          </h2>
          <p style={{ fontSize: 14, color: '#6B7280', maxWidth: 540, margin: '0 auto 34px', lineHeight: 1.7 }}>
            Grounded answers with stats, tables and trends — across adoption, quality, talent risk
            and coaching themes. Pick a role below to tune the questions.
          </p>

          <AskInputBar value={query} onChange={setQuery} onSubmit={handleAsk} loading={isLoading} />

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, flexWrap: 'wrap', marginBottom: 36, marginTop: 14 }}>
            <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.1em', color: '#9CA3AF', textTransform: 'uppercase' }}>TRY</span>
            {SUGGESTIONS.map((s, i) => (
              <TryPill key={i} label={s} onClick={() => handleAsk(s)} />
            ))}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
            {ROLES.map(r => (
              <RolePill key={r.id} role={r} active={activeRole === r.id} onClick={() => setActiveRole(r.id)} />
            ))}
          </div>
          <p style={{ fontSize: 11, color: '#9CA3AF' }}>Most-asked questions across roles</p>
        </div>
      )}

      {/* ── SUGGESTED CARDS (only in empty state) ────────── */}
      {!isConversationStarted && (
        <div>
          <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.1em', color: '#9CA3AF', textTransform: 'uppercase', marginBottom: 12 }}>
            SUGGESTED FOR ALL
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {SUGGESTED_CARDS.map((card, i) => (
              <SuggestedCard key={i} card={card} onAsk={handleAsk} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Conversation bubbles ──────────────────────────────────────
function UserBubble({ content }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
      <div style={{
        maxWidth: 560, background: '#E11937', color: '#fff',
        borderRadius: '18px 18px 4px 18px', padding: '13px 18px',
        fontSize: 14, fontWeight: 500, lineHeight: 1.6,
        boxShadow: '0 2px 12px rgba(225,25,55,0.25)',
      }}>
        {content}
      </div>
    </div>
  );
}

// ── Markdown-lite renderer ────────────────────────────────────
function FormattedText({ text }) {
  if (!text) return null;
  const lines = text.split('\n');
  const elements = [];
  let i = 0;
  while (i < lines.length) {
    const raw = lines[i];
    const trimmed = raw.trim();
    if (!trimmed) { elements.push(<div key={i} style={{ height: 8 }} />); i++; continue; }

    // H3 ### heading
    if (trimmed.startsWith('### ')) {
      elements.push(
        <div key={i} style={{ fontSize: 13, fontWeight: 800, color: '#1B1F2A', marginTop: 14, marginBottom: 4, letterSpacing: '-0.1px' }}>
          {renderInline(trimmed.slice(4))}
        </div>
      );
      i++; continue;
    }
    // H2 ## heading
    if (trimmed.startsWith('## ')) {
      elements.push(
        <div key={i} style={{ fontSize: 14, fontWeight: 800, color: '#1B1F2A', marginTop: 16, marginBottom: 4, letterSpacing: '-0.2px' }}>
          {renderInline(trimmed.slice(3))}
        </div>
      );
      i++; continue;
    }
    // Bullet: lines starting with - or •
    if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
      const bulletContent = trimmed.startsWith('- ') ? trimmed.slice(2) : trimmed.slice(2);
      elements.push(
        <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', marginTop: 5 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#E11937', flexShrink: 0, marginTop: 7 }} />
          <span style={{ fontSize: 14, color: '#374151', lineHeight: 1.65 }}>{renderInline(bulletContent)}</span>
        </div>
      );
      i++; continue;
    }
    // Numbered list
    const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
    if (numMatch) {
      elements.push(
        <div key={i} style={{ display: 'flex', gap: 9, alignItems: 'flex-start', marginTop: 5 }}>
          <span style={{ minWidth: 20, fontWeight: 700, color: '#E11937', fontSize: 13, marginTop: 1, textAlign: 'right', flexShrink: 0 }}>{numMatch[1]}.</span>
          <span style={{ fontSize: 14, color: '#374151', lineHeight: 1.65 }}>{renderInline(numMatch[2])}</span>
        </div>
      );
      i++; continue;
    }
    // Paragraph
    elements.push(
      <p key={i} style={{ margin: '4px 0', fontSize: 14, color: '#374151', lineHeight: 1.7 }}>
        {renderInline(trimmed)}
      </p>
    );
    i++;
  }
  return <div>{elements}</div>;
}

// Renders inline **bold**, *italic*, and `code` within a line
function renderInline(text) {
  const parts = [];
  // Split on **bold**, *italic*, `code`
  const regex = /(\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`)/g;
  let last = 0, m;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[0].startsWith('**')) {
      parts.push(<strong key={m.index} style={{ fontWeight: 700, color: '#1B1F2A' }}>{m[2]}</strong>);
    } else if (m[0].startsWith('*')) {
      parts.push(<em key={m.index} style={{ fontStyle: 'italic' }}>{m[3]}</em>);
    } else {
      parts.push(<code key={m.index} style={{ background: '#F3F4F6', borderRadius: 4, padding: '1px 5px', fontSize: 12, fontFamily: 'monospace', color: '#1B1F2A' }}>{m[4]}</code>);
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts.length === 1 && typeof parts[0] === 'string' ? parts[0] : parts;
}

function AIBubble({ msg }) {
  if (msg.loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#E11937', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Sparkles size={15} color="#fff" />
        </div>
        <div style={{ background: '#fff', border: '1px solid #E8E5E8', borderRadius: '4px 18px 18px 18px', padding: '16px 20px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
            {[0,1,2].map(i => (
              <span key={i} style={{
                width: 7, height: 7, borderRadius: '50%', background: '#E11937',
                animation: 'pulse 1.2s ease-in-out infinite',
                animationDelay: `${i * 0.2}s`, display: 'inline-block', opacity: 0.7,
              }} />
            ))}
            <span style={{ fontSize: 12, color: '#9CA3AF', marginLeft: 6 }}>Querying your data…</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
      <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#E11937', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 4 }}>
        <Sparkles size={15} color="#fff" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          background: '#fff', border: '1px solid #E8E5E8',
          borderRadius: '4px 18px 18px 18px', padding: '18px 22px',
          boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
        }}>
          <FormattedText text={msg.content} />
        </div>
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────
function AskInputBar({ value, onChange, onSubmit, loading }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      maxWidth: 700, margin: '0 auto',
      background: '#fff',
      border: `1.5px solid ${focused ? '#E11937' : '#E8E5E8'}`,
      borderRadius: 50,
      boxShadow: focused
        ? '0 0 0 3px rgba(225,25,55,0.1), 0 4px 18px rgba(0,0,0,0.07)'
        : '0 4px 18px rgba(0,0,0,0.07)',
      overflow: 'hidden',
      transition: 'border-color 0.15s, box-shadow 0.15s',
    }}>
      <div style={{ paddingLeft: 22, display: 'flex', alignItems: 'center', flexShrink: 0 }}>
        <Sparkles size={15} color={loading ? '#9CA3AF' : '#E11937'} />
      </div>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && !loading && onSubmit()}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={loading ? 'Querying your data…' : 'Ask about adoption, FCR counts, top reps, regions, skill trends…'}
        disabled={loading}
        aria-label="Ask AI about field coaching data"
        style={{
          flex: 1, height: 54, padding: '0 16px',
          border: 'none', outline: 'none',
          fontSize: 14, fontFamily: 'inherit', color: '#1B1F2A',
          background: 'transparent', opacity: loading ? 0.6 : 1,
        }}
      />
      <button
        onClick={() => !loading && onSubmit()}
        disabled={loading}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 7,
          height: 54, padding: '0 26px',
          background: loading ? '#9CA3AF' : '#E11937', border: 'none',
          borderRadius: '0 50px 50px 0',
          color: '#fff', fontSize: 13, fontWeight: 700,
          cursor: loading ? 'not-allowed' : 'pointer', fontFamily: 'inherit', whiteSpace: 'nowrap',
          transition: 'background 0.15s',
        }}
      >
        <Send size={13} />
        {loading ? 'Thinking…' : 'Ask AI'}
      </button>
    </div>
  );
}

function TryPill({ label, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '5px 13px', border: '1px solid #E8E5E8', borderRadius: 20,
        background: '#fff', color: '#374151', fontSize: 12, fontWeight: 500,
        cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = '#E11937'; e.currentTarget.style.color = '#E11937'; e.currentTarget.style.background = '#FDECEE'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = '#E8E5E8'; e.currentTarget.style.color = '#374151'; e.currentTarget.style.background = '#fff'; }}
    >
      {label}
    </button>
  );
}

function RolePill({ role, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '7px 17px', borderRadius: 24,
        border: active ? '1.5px solid #E11937' : '1.5px solid #E8E5E8',
        background: active ? '#E11937' : '#fff',
        color: active ? '#fff' : '#374151',
        fontSize: 12, fontWeight: 600, cursor: 'pointer',
        fontFamily: 'inherit', transition: 'all 0.15s',
        boxShadow: active ? '0 2px 10px rgba(225,25,55,0.25)' : '0 1px 3px rgba(0,0,0,0.04)',
      }}
    >
      <role.Icon size={12} />
      {role.label}
    </button>
  );
}

function SuggestedCard({ card, onAsk }) {
  return (
    <div
      onClick={() => onAsk(card.q)}
      style={{
        background: '#fff', border: '1px solid #E8E5E8', borderRadius: 14,
        padding: '20px 22px', cursor: 'pointer',
        boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
        transition: 'transform 0.15s, box-shadow 0.15s, border-color 0.15s',
        display: 'flex', flexDirection: 'column', gap: 14,
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = '0 8px 28px rgba(0,0,0,0.09)';
        e.currentTarget.style.borderColor = '#F5C6CE';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = '';
        e.currentTarget.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)';
        e.currentTarget.style.borderColor = '#E8E5E8';
      }}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: card.catBg, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <card.Icon size={16} color={card.catColor} />
        </div>
        <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '0.07em', background: card.catBg, color: card.catColor, borderRadius: 10, padding: '3px 9px', whiteSpace: 'nowrap', marginTop: 5 }}>
          {card.category}
        </span>
      </div>
      <p style={{ fontSize: 13.5, fontWeight: 600, color: '#1B1F2A', lineHeight: 1.55, margin: 0 }}>
        {card.q}
      </p>
    </div>
  );
}
