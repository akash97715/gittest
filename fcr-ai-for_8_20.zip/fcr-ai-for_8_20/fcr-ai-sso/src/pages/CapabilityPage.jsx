import { useState, useEffect, useRef } from 'react';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  BarChart, Bar, LineChart, Line, ReferenceLine, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { CheckCircle2, ChevronDown, Award, TrendingUp, AlertTriangle, FileText, Target, Info, ShieldCheck, Zap } from 'lucide-react';

const scoreLabel = s => s >= 3.5 ? 'Expert' : s >= 2.5 ? 'Advanced' : s >= 1.5 ? 'Skilled' : 'Awareness';
const scoreColor = s => s >= 3 ? '#15803D' : s >= 2 ? '#D97706' : '#E60012';
const fmt = n => n != null ? Number(n).toLocaleString() : '—';

const TIMEFRAME_OPTIONS = [
  { label: 'All time', value: null }, { label: 'Past 7 days', value: '7' },
  { label: 'Past 30 days', value: '30' }, { label: 'Past quarter', value: '90' },
  { label: 'Past 6 months', value: '180' }, { label: 'Past year', value: '365' },
  { label: 'Custom range', value: 'custom' },
];
const TA_OPTIONS = [
  { label: 'All TAs', value: null }, { label: 'Immunology (IMM)', value: 'IMM' },
  { label: 'Oncology (ONC)', value: 'ONC' }, { label: 'Neuroscience (NS)', value: 'NS' },
  { label: 'Specialty Care (SCG)', value: 'SCG' },
];
const REGION_OPTIONS = [
  { label: 'All regions', value: null }, { label: 'West', value: 'West' },
  { label: 'Central', value: 'Central' }, { label: 'Northeast', value: 'Northeast' },
  { label: 'Southeast', value: 'Southeast' }, { label: 'East', value: 'East' },
];

const ACCENT_MAP = {
  green:  { iconBg: '#DCFCE7', iconColor: '#15803D', Icon: Award },
  amber:  { iconBg: '#FEF9C3', iconColor: '#A16207', Icon: TrendingUp },
  red:    { iconBg: '#FDECEC', iconColor: '#E60012', Icon: FileText },
  redhl:  { iconBg: '#FDECEC', iconColor: '#E60012', Icon: AlertTriangle },
  blue:   { iconBg: '#EFF6FF', iconColor: '#2563EB', Icon: ShieldCheck },
  purple: { iconBg: '#F5F3FF', iconColor: '#7C3AED', Icon: Zap },
};
function KpiTile({ label, tag, value, valueSuffix, sub, accent, highlighted }) {
  const { iconBg, iconColor, Icon } = ACCENT_MAP[accent] || ACCENT_MAP.red;
  return (
    <div className="kpi-tile" style={{ background: highlighted ? '#FDECEC' : '#fff', border: highlighted ? '1.5px solid #E60012' : '1px solid #EEE7E8' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div><div className="kpi-label">{label}</div><div className="kpi-tag">📅 {tag}</div></div>
        <div style={{ width: 30, height: 30, borderRadius: 8, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon size={15} color={iconColor} />
        </div>
      </div>
      <div className="kpi-value">{value}{valueSuffix && <span className="kpi-suffix">{valueSuffix}</span>}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function FilterDropdown({ id, label, options, value, onChange, open, onToggle, extra }) {
  const selected = options.find(o => o.value === value);
  const isActive = value !== null;
  return (
    <div style={{ position: 'relative' }}>
      <button className="filter-pill" onClick={() => onToggle(open ? null : id)}
        style={isActive ? { background: '#E60012', color: '#fff', borderColor: '#E60012', fontWeight: 600 } : {}}>
        {isActive ? selected?.label ?? label : label}
        {isActive
          ? <span onMouseDown={e => { e.stopPropagation(); onChange(null); onToggle(null); }} style={{ marginLeft: 5, opacity: 0.8, fontSize: 14, lineHeight: 1 }}>×</span>
          : <ChevronDown size={11} color="#9CA3AF" style={{ marginLeft: 4 }} />}
      </button>
      {open && (
        <div style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, zIndex: 200, background: '#fff', border: '1px solid #E9E5E7', borderRadius: 12, boxShadow: '0 8px 28px rgba(0,0,0,0.13)', minWidth: 190, padding: '6px 0' }}>
          {options.map(opt => (
            <button key={String(opt.value)} onMouseDown={() => { onChange(opt.value); if (opt.value !== 'custom') onToggle(null); }}
              style={{ display: 'block', width: '100%', textAlign: 'left', padding: '9px 16px', fontSize: 13, fontWeight: opt.value === value ? 700 : 400, color: opt.value === value ? '#E60012' : '#1B1F2A', background: opt.value === value ? '#FFF0F0' : 'transparent', border: 'none', cursor: 'pointer' }}>
              {opt.value === value ? '✓ ' : '   '}{opt.label}
            </button>
          ))}
          {extra}
        </div>
      )}
    </div>
  );
}

const ChartTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 10, padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)', fontSize: 11, minWidth: 150 }}>
      <div style={{ fontWeight: 700, color: '#1B1F2A', marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color || p.stroke, display: 'inline-block' }} />
          <span style={{ color: '#6B7280' }}>{p.name}:</span>
          <span style={{ fontWeight: 700, color: '#1B1F2A' }}>{typeof p.value === 'number' ? p.value.toFixed(2) : p.value}</span>
        </div>
      ))}
    </div>
  );
};

const RadarTip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  return (
    <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 10, padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)', fontSize: 11, minWidth: 160 }}>
      <div style={{ fontWeight: 700, color: '#1B1F2A', marginBottom: 6 }}>{d?.fullName}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color || p.stroke, display: 'inline-block' }} />
          <span style={{ color: '#6B7280' }}>{p.name}:</span>
          <span style={{ fontWeight: 700, color: '#1B1F2A' }}>{Number(p.value).toFixed(2)}</span>
        </div>
      ))}
    </div>
  );
};

const SHORT = { 'Selling Skills':'Selling','Healthcare Marketplace':'HCP Mktpl.','Analytics & Insights':'Analytics','Internal Partnerships':'Partnerships','Account Management':'Acct Mgmt','Business Planning':'Biz Planning','Pre-Call Planning':'Pre-Call','Advance':'Advance','Learn':'Learn','Deliver':'Deliver','Engage':'Engage','Stakeholder Mapping':'Stakeholders' };

const ScaleLegend = () => (
  <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
    {[['1','#E60012','Awareness'],['2','#D97706','Skilled'],['3','#15803D','Advanced'],['4','#15803D','Expert']].map(([n,c,l]) => (
      <span key={n} style={{ fontSize: 10, color: '#6B7280', display: 'flex', alignItems: 'center', gap: 4 }}>
        <span style={{ width: 8, height: 8, borderRadius: 2, background: c, display: 'inline-block', flexShrink: 0 }} />{n} · {l}
      </span>
    ))}
  </div>
);

export default function CapabilityPage() {
  const [data, setData]           = useState(null);
  const [loading, setLoading]     = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [chartView, setChartView] = useState('radar');
  const [filterTA, setFilterTA]               = useState(null);
  const [filterTimeframe, setFilterTimeframe] = useState(null);
  const [filterRegion, setFilterRegion]       = useState(null);
  const [customFrom, setCustomFrom]           = useState('');
  const [customTo, setCustomTo]               = useState('');
  const [openDropdown, setOpenDropdown]       = useState(null);
  const filterBarRef = useRef(null);

  useEffect(() => {
    const h = e => { if (filterBarRef.current && !filterBarRef.current.contains(e.target)) setOpenDropdown(null); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  useEffect(() => {
    const p = new URLSearchParams();
    if (filterTA) p.set('ta', filterTA);
    if (filterRegion) p.set('region', filterRegion);
    if (filterTimeframe && filterTimeframe !== 'custom') p.set('timeframe', filterTimeframe);
    if (filterTimeframe === 'custom' && customFrom) p.set('from', customFrom);
    if (filterTimeframe === 'custom' && customTo)   p.set('to', customTo);
    const cacheKey = `fcr_capability_${p.toString()}`;
    try {
      const stale = localStorage.getItem(cacheKey);
      if (stale) { setData(JSON.parse(stale)); setLoading(false); setRefreshing(true); }
      else { setLoading(true); }
    } catch { setLoading(true); }
    fetch(`/api/capability?${p}`)
      .then(r => r.json())
      .then(d => {
        setData(d); setLoading(false); setRefreshing(false);
        try { localStorage.setItem(cacheKey, JSON.stringify(d)); } catch {}
      })
      .catch(() => { setLoading(false); setRefreshing(false); });
  }, [filterTA, filterTimeframe, filterRegion, customFrom, customTo]);

  const kpi          = data?.kpi;
  const competencies = data?.competencies || [];
  const trend        = data?.trend?.map(r => ({ month: r.month, score: Number(r.avg_score) })) || [];
  const levels       = data?.levels || [];
  const lead         = data?.lead || [];
  const compliance   = data?.compliance;
  const tlbl = filterTimeframe === null ? 'All time' : filterTimeframe === '7' ? 'Past 7 days' : filterTimeframe === '30' ? 'Past 30 days' : filterTimeframe === '90' ? 'Past quarter' : filterTimeframe === '180' ? 'Past 6 months' : filterTimeframe === '365' ? 'Past year' : 'Custom range';
  const activeFilterCount = [filterTA, filterTimeframe, filterRegion].filter(Boolean).length;
  const radarData = competencies.map(c => ({ competency: SHORT[c.competency] || c.competency, fullName: c.competency, score: Number(c.avg_score), target: 3 }));

  const customDateExtra = filterTimeframe === 'custom' && (
    <div style={{ padding: '10px 14px', borderTop: '1px solid #F3F4F6', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#6B7280' }}>Custom date range</div>
      <div><div style={{ fontSize: 11, color: '#6B7280', marginBottom: 3 }}>From</div>
        <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} style={{ fontSize: 12, border: '1px solid #E9E5E7', borderRadius: 7, padding: '5px 8px', width: '100%', outline: 'none', color: '#1B1F2A' }} /></div>
      <div><div style={{ fontSize: 11, color: '#6B7280', marginBottom: 3 }}>To</div>
        <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} style={{ fontSize: 12, border: '1px solid #E9E5E7', borderRadius: 7, padding: '5px 8px', width: '100%', outline: 'none', color: '#1B1F2A' }} /></div>
      <button onMouseDown={() => setOpenDropdown(null)} style={{ background: '#E60012', color: '#fff', border: 'none', borderRadius: 8, padding: '6px 0', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>Apply</button>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* HERO */}
      <div className="dash-card">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: '#E60012', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Target size={20} color="#fff" />
            </div>
            <div>
              <div className="section-eyebrow">Capability · {tlbl}{filterTA ? ` · ${filterTA}` : ''}{filterRegion ? ` · ${filterRegion}` : ''}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#1A1A1A', marginTop: 2, letterSpacing: '-0.3px' }}>Skill &amp; Compliance Deep Dive</div>
            </div>
          </div>
          {refreshing ? (
            <div className="refresh-pill"><span className="refresh-spin" />Refreshing data…</div>
          ) : (
            <div className="sync-pill"><CheckCircle2 size={12} color="#16A34A" /> Synced from iConnect · Live</div>
          )}
        </div>
      </div>

      {/* KPI TILES */}
      <div className="kpi-grid">
        <KpiTile label="Avg FBMS Proficiency" tag={tlbl}
          value={loading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : kpi?.avg_score ? Number(kpi.avg_score).toFixed(1) : '—'} valueSuffix={loading ? null : ' / 4'}
          sub={loading ? null : kpi?.avg_score ? `${scoreLabel(Number(kpi.avg_score))} — observed average` : 'No behavior ratings found'} accent="green" />
        <KpiTile label="Meeting Target" tag="Score ≥ 3 · Advanced+"
          value={loading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : kpi?.pct_at_target != null ? `${kpi.pct_at_target}%` : '—'}
          sub={loading ? null : `across ${fmt(kpi?.total_ratings)} FBMS behavior ratings`} accent="amber" />
        <KpiTile label="MSL FCRs Assessed" tag={tlbl}
          value={loading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.rated_fcrs)}
          sub={loading ? null : `${fmt(kpi?.rated_reps)} MSLs with behavior ratings`} accent="red" />
        <KpiTile label="Awareness Flagged" tag="Needs Development (Score 1)"
          value={loading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.flagged_fcrs)}
          sub={loading ? null : 'FCRs with at least one Awareness rating'} accent="redhl" highlighted />
        <KpiTile label="Compliance Rate" tag="Compliant field interactions"
          value={loading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : compliance?.compliance_rate != null ? `${compliance.compliance_rate}%` : '—'}
          sub={loading ? null : `${fmt(compliance?.non_compliant)} non-compliant flagged`} accent="blue" />
      </div>

      {/* FILTER ROW */}
      <div className="filter-row" ref={filterBarRef}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: '#1A1A1A', display: 'flex', alignItems: 'center', gap: 4 }}>
            <ChevronDown size={13} /> Filters
            {activeFilterCount > 0 && <span style={{ background: '#E60012', color: '#fff', borderRadius: 20, fontSize: 10, padding: '1px 6px', fontWeight: 700 }}>{activeFilterCount}</span>}
          </span>
          <FilterDropdown id="timeframe" label="Timeframe" options={TIMEFRAME_OPTIONS} value={filterTimeframe} onChange={setFilterTimeframe} open={openDropdown === 'timeframe'} onToggle={setOpenDropdown} extra={customDateExtra} />
          <FilterDropdown id="ta" label="Therapeutic Area" options={TA_OPTIONS} value={filterTA} onChange={setFilterTA} open={openDropdown === 'ta'} onToggle={setOpenDropdown} />
          <FilterDropdown id="region" label="Region" options={REGION_OPTIONS} value={filterRegion} onChange={setFilterRegion} open={openDropdown === 'region'} onToggle={setOpenDropdown} />
          {activeFilterCount > 0 && (
            <button className="filter-pill" onMouseDown={() => { setFilterTA(null); setFilterTimeframe(null); setFilterRegion(null); setCustomFrom(''); setCustomTo(''); }} style={{ color: '#E60012', borderColor: '#E60012', fontWeight: 600 }}>Clear all</button>
          )}
        </div>
        <span style={{ fontSize: 11, color: '#6B7280' }}>
          <strong>{loading ? '…' : fmt(kpi?.rated_fcrs)} MSL FCRs</strong> · <strong>{loading ? '…' : fmt(kpi?.rated_reps)} MSLs</strong> with FBMS behavior ratings
        </span>
      </div>

      {/* PROFICIENCY CARD */}
      <div className="dash-card">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
          <div>
            <div className="section-eyebrow">FBMS Skill Proficiency</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#1A1A1A', marginTop: 2 }}>FBMS Core Skill Proficiency — Observed vs. Target</div>
            <div style={{ fontSize: 12, color: '#6B7280', marginTop: 3 }}>Based on behavior ratings (Expert=4 · Advanced=3 · Skilled=2 · Awareness=1) · Target ≥ 3 (Advanced)</div>
          </div>
          <div className="toggle-group-pill">
            {[['radar','Radar'],['bar','Bar']].map(([k,l]) => (
              <button key={k} onClick={() => setChartView(k)} className={`toggle-pill${chartView === k ? ' active' : ''}`}>{l}</button>
            ))}
          </div>
        </div>

        {loading ? (
          <div style={{ height: 320, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: 13 }}>Loading proficiency data…</div>
        ) : competencies.length === 0 ? (
          <div style={{ height: 320, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: 13 }}>No competency ratings found for this filter.</div>
        ) : chartView === 'radar' ? (
          <div style={{ display: 'flex', gap: 28, alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ flex: '0 0 340px', minWidth: 260 }}>
              <ResponsiveContainer width="100%" height={320}>
                <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                  <PolarGrid stroke="#E9E5E7" />
                  <PolarAngleAxis dataKey="competency" tick={{ fontSize: 10.5, fill: '#6B7280', fontFamily: 'Inter, system-ui, sans-serif' }} />
                  <PolarRadiusAxis domain={[0, 4]} tickCount={5} tick={{ fontSize: 9, fill: '#C4C4C4' }} axisLine={false} />
                  <Radar name="Observed" dataKey="score" stroke="#E60012" fill="#E60012" fillOpacity={0.15} strokeWidth={2.5} dot={{ r: 3, fill: '#E60012', strokeWidth: 0 }} />
                  <Radar name="Target" dataKey="target" stroke="#9CA3AF" fill="none" strokeDasharray="5 4" strokeWidth={1.5} />
                  <Tooltip content={<RadarTip />} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div style={{ flex: 1, minWidth: 200, display: 'flex', flexDirection: 'column', gap: 9 }}>
              <div style={{ display: 'flex', gap: 18, marginBottom: 6 }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#374151' }}>
                  <span style={{ width: 22, height: 3, background: '#E60012', borderRadius: 2, display: 'inline-block' }} />Observed
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#374151' }}>
                  <span style={{ width: 22, borderTop: '2px dashed #9CA3AF', display: 'inline-block' }} />Target (3.0)
                </span>
              </div>
              {competencies.map(c => {
                const s = Number(c.avg_score);
                return (
                  <div key={c.competency} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ fontSize: 11.5, color: '#374151', flex: 1, minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.competency}</div>
                    <div style={{ width: 88, height: 6, background: '#F3F4F6', borderRadius: 3, overflow: 'hidden', flexShrink: 0 }}>
                      <div style={{ width: `${(s / 4) * 100}%`, height: '100%', background: scoreColor(s), borderRadius: 3 }} />
                    </div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: scoreColor(s), width: 30, textAlign: 'right', flexShrink: 0 }}>{s.toFixed(1)}</div>
                    <div style={{ fontSize: 10, color: '#9CA3AF', width: 34, textAlign: 'right', flexShrink: 0 }}>{c.pct_at_target}%</div>
                  </div>
                );
              })}
              <div style={{ marginTop: 6, borderTop: '1px solid #F3F4F6', paddingTop: 8 }}><ScaleLegend /></div>
            </div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={Math.max(300, competencies.length * 38)}>
            <BarChart data={competencies} layout="vertical" margin={{ top: 4, right: 60, left: 132, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" horizontal={false} />
              <XAxis type="number" domain={[0, 4]} ticks={[0,1,2,3,4]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="competency" width={128} tick={{ fontSize: 11, fill: '#374151' }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTip />} cursor={{ fill: '#FEF2F2' }} />
              <ReferenceLine x={3} stroke="#9CA3AF" strokeDasharray="4 3" label={{ value: 'Target', position: 'insideTopRight', fontSize: 10, fill: '#9CA3AF' }} />
              <Bar dataKey="avg_score" name="Avg Score" radius={[0,6,6,0]} maxBarSize={22}>
                {competencies.map((c, i) => <Cell key={i} fill={scoreColor(Number(c.avg_score))} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* CHARTS GRID */}
      <div className="charts-grid">
        <div className="chart-card">
          <div className="chart-card-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 3, height: 16, background: '#E60012', borderRadius: 2 }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#1A1A1A' }}>Proficiency Trend — 6 Months</span>
            </div>
            <span style={{ fontSize: 10, color: '#9CA3AF' }}>avg score / month</span>
          </div>
          {loading || trend.length === 0 ? (
            <div style={{ height: 190, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: 12 }}>{loading ? 'Loading…' : 'No trend data'}</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={190}>
                <LineChart data={trend} margin={{ top: 10, right: 8, left: -22, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                  <YAxis domain={[1, 4]} ticks={[1,2,3,4]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                  <Tooltip content={<ChartTip />} />
                  <ReferenceLine y={3} stroke="#9CA3AF" strokeDasharray="5 4" />
                  <Line type="monotone" dataKey="score" name="Avg Score" stroke="#E60012" strokeWidth={2.5} dot={{ r: 4, fill: '#E60012', strokeWidth: 0 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 8, paddingTop: 8, borderTop: '1px solid #F3F4F6', flexWrap: 'wrap' }}>
                <ScaleLegend />
                <span style={{ fontSize: 10, color: '#9CA3AF', marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <span style={{ width: 16, borderTop: '2px dashed #9CA3AF', display: 'inline-block' }} />Target (3.0)
                </span>
              </div>
            </>
          )}
        </div>

        <div className="chart-card">
          <div className="chart-card-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 3, height: 16, background: '#E60012', borderRadius: 2 }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#1A1A1A' }}>Proficiency by Job Level</span>
            </div>
            <span style={{ fontSize: 10, color: '#9CA3AF' }}>avg score / 4</span>
          </div>
          {loading ? (
            <div style={{ height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: 12 }}>Loading…</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginTop: 10 }}>
              {levels.map(l => {
                const s = Number(l.avg_score);
                return (
                  <div key={l.level} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ fontSize: 11.5, color: '#374151', flex: 1, minWidth: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.level}</div>
                    <div style={{ width: 100, height: 8, background: '#F3F4F6', borderRadius: 4, overflow: 'hidden', flexShrink: 0 }}>
                      <div style={{ width: `${(s / 4) * 100}%`, height: '100%', background: scoreColor(s), borderRadius: 4 }} />
                    </div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: scoreColor(s), width: 28, textAlign: 'right', flexShrink: 0 }}>{s.toFixed(1)}</div>
                    <div style={{ fontSize: 10, color: '#9CA3AF', width: 48, textAlign: 'right', flexShrink: 0 }}>{fmt(l.fcrs)} FCRs</div>
                  </div>
                );
              })}
              <div style={{ fontSize: 10, color: '#9CA3AF', borderTop: '1px solid #F3F4F6', paddingTop: 8, marginTop: 2 }}>
                Bar = avg score out of 4 · based on rated FCR competency questions
              </div>
            </div>
          )}
        </div>
      </div>

      {/* COMPLIANCE SECTION */}
      <div className="dash-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
          <div>
            <div className="section-eyebrow">Healthcare Compliance · Field Observations</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#1A1A1A', marginTop: 2 }}>Compliant Interaction Rate</div>
            <div style={{ fontSize: 12, color: '#6B7280', marginTop: 3 }}>
              "Did the commercial field employee engage in compliant promotional interaction?"
            </div>
          </div>
          {!loading && compliance && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: Number(compliance.compliance_rate) >= 98 ? '#DCFCE7' : '#FEF9C3', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <span style={{ fontSize: 16, fontWeight: 900, color: Number(compliance.compliance_rate) >= 98 ? '#15803D' : '#D97706', lineHeight: 1 }}>{compliance.compliance_rate}%</span>
                <span style={{ fontSize: 8, color: '#6B7280', fontWeight: 600 }}>compliant</span>
              </div>
            </div>
          )}
        </div>
        {loading ? (
          <div style={{ height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9CA3AF', fontSize: 13 }}>Loading…</div>
        ) : compliance ? (
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {[
              { label: 'Compliant',      value: Number(compliance.compliant).toLocaleString(),     bg: '#F0FDF4', color: '#15803D', border: '#BBF7D0' },
              { label: 'Non-Compliant',  value: Number(compliance.non_compliant).toLocaleString(), bg: '#FEF2F2', color: '#E60012', border: '#FECACA' },
              { label: 'Total Checked',  value: Number(compliance.total).toLocaleString(),         bg: '#F9FAFB', color: '#374151', border: '#E5E7EB' },
            ].map(s => (
              <div key={s.label} style={{ flex: 1, minWidth: 120, background: s.bg, border: `1px solid ${s.border}`, borderRadius: 10, padding: '12px 14px', textAlign: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: s.color }}>{s.value}</div>
                <div style={{ fontSize: 11, color: '#6B7280', marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
            {/* Compliance bar */}
            <div style={{ width: '100%', marginTop: 4 }}>
              <div style={{ height: 8, background: '#F3F4F6', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ width: `${compliance.compliance_rate}%`, height: '100%', background: Number(compliance.compliance_rate) >= 98 ? '#15803D' : '#D97706', borderRadius: 4, transition: 'width 0.5s' }} />
              </div>
              <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 4 }}>{compliance.compliance_rate}% compliance rate across all observed coaching sessions</div>
            </div>
          </div>
        ) : (
          <div style={{ fontSize: 12, color: '#9CA3AF' }}>No compliance data available.</div>
        )}
      </div>

      {/* INFO BANNER */}
      <div className="info-banner">
        <Info size={14} color="#4B6EA8" />
        <span style={{ fontSize: 11, color: '#4B6EA8' }}>
          <strong>Scoring:</strong> Clear Strength = 4 · Emerging Strength = 3 · Development Need = 2 · Clear Development Need = 1.
          &nbsp;"Meeting target" = Emerging Strength or above (≥ 3).
        </span>
      </div>

    </div>
  );
}