import { useState, useEffect, useRef } from 'react';
import {
  BarChart, Bar, LineChart, Line, ComposedChart,
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine,
} from 'recharts';
import {
  Layers, FileText, Users, GraduationCap, AlertTriangle,
  ChevronDown, Info, Activity, Target, Sparkles, CheckCircle2,
} from 'lucide-react';
import TrainingSkillGapsView from './TrainingSkillGapsView';
import SkillProficiencyTrendView from './SkillProficiencyTrendView';

// ── Static fallback chart data (shown while loading) ──────────
const fcrByRegion = [
  { region: 'Northeast', count: 0 },
  { region: 'Southeast', count: 0 },
  { region: 'Central',   count: 0 },
  { region: 'West',      count: 0 },
];

const completionTrend = [
  { quarter: 'Q1 2026', coached: 0, repeats: 0, total: 0 },
];

// ── Filter options ─────────────────────────────────────────────
const TIMEFRAME_OPTIONS = [
  { label: 'All time',      value: null },
  { label: 'Past 7 days',   value: '7' },
  { label: 'Past 30 days',  value: '30' },
  { label: 'Past quarter',  value: '90' },
  { label: 'Past 6 months', value: '180' },
  { label: 'Past year',     value: '365' },
  { label: 'Custom range',  value: 'custom' },
];

const TA_OPTIONS = [
  { label: 'All TAs',              value: null },
  { label: 'Immunology (IMM)',     value: 'IMM' },
  { label: 'Oncology (ONC)',       value: 'ONC' },
  { label: 'Neuroscience (NS)',    value: 'NS' },
  { label: 'Specialty Care (SCG)', value: 'SCG' },
];

const REGION_OPTIONS = [
  { label: 'All regions', value: null },
  { label: 'West',        value: 'West' },
  { label: 'Central',     value: 'Central' },
  { label: 'Northeast',   value: 'Northeast' },
  { label: 'Southeast',   value: 'Southeast' },
  { label: 'East',        value: 'East' },
];

// ── KPI Tile ───────────────────────────────────────────────────
const ACCENT_MAP = {
  red:   { iconBg: '#FDECEC', iconColor: '#E60012', Icon: FileText      },
  green: { iconBg: '#DCFCE7', iconColor: '#15803D', Icon: Users         },
  amber: { iconBg: '#FEF9C3', iconColor: '#A16207', Icon: GraduationCap },
  redhl: { iconBg: '#FDECEC', iconColor: '#E60012', Icon: AlertTriangle },
};

function KpiTile({ label, tag, value, valueSuffix, sub, accent, highlighted }) {
  const { iconBg, iconColor, Icon } = ACCENT_MAP[accent] || ACCENT_MAP.red;
  return (
    <div
      className="kpi-tile"
      style={{
        background:   highlighted ? '#FDECEC' : '#fff',
        border:       highlighted ? '1.5px solid #E60012' : '1px solid #EEE7E8',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div className="kpi-label">{label}</div>
          <div className="kpi-tag">📅 {tag}</div>
        </div>
        <div style={{ width: 30, height: 30, borderRadius: 8, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon size={15} color={iconColor} />
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, margin: '8px 0 4px' }}>
        <span style={{ fontSize: 38, fontWeight: 800, lineHeight: 1, color: highlighted ? '#E60012' : '#1A1A1A' }}>{value}</span>
        {valueSuffix && <span style={{ fontSize: 16, color: '#9CA3AF', fontWeight: 500 }}>{valueSuffix}</span>}
      </div>
      <div className="kpi-sub">{sub}</div>
    </div>
  );
}

// ── View Selector Card ─────────────────────────────────────────
function ViewCard({ num, icon: Icon, title, sub, active, onClick }) {
  return (
    <div
      className="view-card"
      onClick={onClick}
      role="button"
      aria-pressed={active}
      style={{
        border:     active ? '2px solid #E60012' : '1.5px solid #EEE7E8',
        background: active ? '#FDECEC' : '#fff',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          background: active ? '#E60012' : '#F3F4F6',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={17} color={active ? '#fff' : '#9CA3AF'} />
        </div>
        {active
          ? <span className="live-pill"><span className="live-dot" />LIVE</span>
          : <ChevronDown size={14} color="#9CA3AF" style={{ transform: 'rotate(-90deg)' }} />
        }
      </div>
      <div style={{ fontSize: 10, fontWeight: 700, color: active ? '#E60012' : '#9CA3AF', marginTop: 10 }}>
        {String(num).padStart(2, '0')}
      </div>
      <div style={{ marginTop: 4 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#1A1A1A' }}>{title}</div>
        <div style={{ fontSize: 11, color: '#6B7280', marginTop: 3 }}>{sub}</div>
      </div>
    </div>
  );
}

// ── Tooltips ───────────────────────────────────────────────────
const BarTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tip">
      <div className="chart-tip-label">{label}</div>
      <div style={{ color: '#E60012', fontWeight: 600 }}>{payload[0].value} FCRs</div>
    </div>
  );
};

const LineTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tip">
      <div className="chart-tip-label">{label}</div>
      <div style={{ color: '#E60012', fontWeight: 600 }}>Completed: {payload[0].value}</div>
    </div>
  );
};

// ── Filter Dropdown ────────────────────────────────────────────
function FilterDropdown({ id, label, options, value, onChange, open, onToggle, extra }) {
  const selected = options.find(o => o.value === value);
  const isActive = value !== null;
  const displayLabel = isActive ? selected?.label ?? label : label;

  return (
    <div style={{ position: 'relative' }}>
      <button
        className="filter-pill"
        onClick={() => onToggle(open ? null : id)}
        style={isActive ? { background: '#E60012', color: '#fff', borderColor: '#E60012', fontWeight: 600 } : {}}
      >
        {displayLabel}
        {isActive
          ? <span onMouseDown={e => { e.stopPropagation(); onChange(null); onToggle(null); }} style={{ marginLeft: 5, opacity: 0.8, fontSize: 14, lineHeight: 1 }}>×</span>
          : <ChevronDown size={11} color="#9CA3AF" style={{ marginLeft: 4 }} />
        }
      </button>
      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 6px)', left: 0, zIndex: 200,
          background: '#fff', border: '1px solid #E9E5E7', borderRadius: 12,
          boxShadow: '0 8px 28px rgba(0,0,0,0.13)', minWidth: 190, padding: '6px 0',
        }}>
          {options.map(opt => (
            <button
              key={String(opt.value)}
              onMouseDown={() => { onChange(opt.value); if (opt.value !== 'custom') onToggle(null); }}
              style={{
                display: 'block', width: '100%', textAlign: 'left',
                padding: '9px 16px', fontSize: 13,
                fontWeight: opt.value === value ? 700 : 400,
                color: opt.value === value ? '#E60012' : '#1B1F2A',
                background: opt.value === value ? '#FFF0F0' : 'transparent',
                border: 'none', cursor: 'pointer',
              }}
            >
              {opt.value === value ? '✓ ' : '   '}{opt.label}
            </button>
          ))}
          {extra}
        </div>
      )}
    </div>
  );
}

// ── Dashboard Page ─────────────────────────────────────────────
export default function DashboardPage() {
  const [activeView, setActiveView]     = useState(0);
  const [regionToggle, setRegionToggle] = useState('region');
  const [completionToggle, setCompletionToggle] = useState('overall');
  const [summary, setSummary]               = useState(null);
  const [summaryLoading, setSummaryLoading]   = useState(true);
  const [summaryRefreshing, setSummaryRefreshing] = useState(false);

  // Filters
  const [filterTA,        setFilterTA]        = useState(null);
  const [filterTimeframe, setFilterTimeframe] = useState(null);
  const [filterRegion,    setFilterRegion]    = useState(null);
  const [customFrom,      setCustomFrom]      = useState('');
  const [customTo,        setCustomTo]        = useState('');
  const [openDropdown,    setOpenDropdown]    = useState(null);
  const filterBarRef = useRef(null);

  // Close dropdowns when clicking outside the filter bar
  useEffect(() => {
    const handler = e => {
      if (filterBarRef.current && !filterBarRef.current.contains(e.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Fetch summary with stale-while-revalidate
  useEffect(() => {
    const p = new URLSearchParams();
    if (filterTA) p.set('ta', filterTA);
    if (filterRegion) p.set('region', filterRegion);
    if (filterTimeframe && filterTimeframe !== 'custom') p.set('timeframe', filterTimeframe);
    if (filterTimeframe === 'custom' && customFrom) p.set('from', customFrom);
    if (filterTimeframe === 'custom' && customTo)   p.set('to',   customTo);
    const cacheKey = `fcr_summary_${p.toString()}`;
    // Show stale data immediately if available
    try {
      const stale = localStorage.getItem(cacheKey);
      if (stale) { setSummary(JSON.parse(stale)); setSummaryLoading(false); setSummaryRefreshing(true); }
      else { setSummaryLoading(true); }
    } catch { setSummaryLoading(true); }
    fetch(`/api/summary?${p}`)
      .then(r => r.json())
      .then(d => {
        setSummary(d); setSummaryLoading(false); setSummaryRefreshing(false);
        try { localStorage.setItem(cacheKey, JSON.stringify(d)); } catch {}
      })
      .catch(() => { setSummaryLoading(false); setSummaryRefreshing(false); });
  }, [filterTA, filterTimeframe, filterRegion, customFrom, customTo]);

  // Derive display values
  const kpi = summary?.kpi;
  const fcrsByRegion = summary?.by_region?.map(r => ({ region: r.region.replace(/ - .*/, '').trim(), count: Number(r.fcrs) })) || fcrByRegion;
  const fcrsByTA     = summary?.by_ta?.map(r => ({ region: r.ta || 'Unknown', count: Number(r.fcrs) })) || [];
  const barChartData = regionToggle === 'ta' ? fcrsByTA : fcrsByRegion;
  const barChartLabel = regionToggle === 'ta' ? 'FCRs by therapeutic area' : 'FCRs by region';
  const requiredFcrs = kpi?.required_fcrs ? Number(kpi.required_fcrs) : 0;
  const mslCovered = kpi?.msl_covered ? Number(kpi.msl_covered) : 0;
  const completedFcrs = kpi?.total_fcrs ? Number(kpi.total_fcrs) : 0;
  const fcrsDiff = completedFcrs - requiredFcrs;
  const fcrsTrend = summary?.trend?.map(r => ({ 
    quarter: r.quarter, 
    coached: Number(r.coached),
    repeats: Number(r.repeats),
    total: Number(r.total_fcrs)
  })) || completionTrend;
  const fmt = n => n != null ? Number(n).toLocaleString() : '—';

  const timeframeLabel = filterTimeframe === null ? 'All time'
    : filterTimeframe === '7'      ? 'Past 7 days'
    : filterTimeframe === '30'     ? 'Past 30 days'
    : filterTimeframe === '90'     ? 'Past quarter'
    : filterTimeframe === '180'    ? 'Past 6 months'
    : filterTimeframe === '365'    ? 'Past year'
    : filterTimeframe === 'custom' ? (customFrom || customTo ? `${customFrom || '…'} → ${customTo || '…'}` : 'Custom range')
    : 'All time';

  const activeFilterCount = [filterTA, filterTimeframe, filterRegion].filter(Boolean).length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* ── HERO SUMMARY CARD ── */}
      <div className="dash-card">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: '#E60012', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Layers size={20} color="#fff" />
            </div>
            <div>
              <div className="section-eyebrow">Summary · {timeframeLabel}{filterTA ? ` · ${filterTA}` : ''}{filterRegion ? ` · ${filterRegion}` : ''}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#1A1A1A', marginTop: 2, letterSpacing: '-0.3px' }}>
                Coaching activity at a glance
              </div>
            </div>
          </div>
          {summaryRefreshing ? (
            <div className="refresh-pill">
              <span className="refresh-spin" />
              Refreshing data…
            </div>
          ) : (
            <div className="sync-pill"><CheckCircle2 size={12} color="#16A34A" /> MSL/VESE FCRs · Synced from iConnect · Live</div>
          )}
        </div>

        {/* KPI tiles */}
        <div className="kpi-grid">
          <KpiTile label="MSL FCRs Written"       tag={timeframeLabel}
            value={summaryLoading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.total_fcrs)}
            sub={summaryLoading ? null : `${kpi?.fcrs_per_rep ?? '—'} per MSL on average`}
            accent="red" />
          <KpiTile label="MSLs Coached"           tag={timeframeLabel}
            value={summaryLoading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.total_reps)}
            sub={summaryLoading ? null : `${kpi?.fcrs_per_rep ?? '—'} FCRs written per MSL`}
            accent="green" />
          <KpiTile label="FCRs Flagging Training"  tag={timeframeLabel}
            value={summaryLoading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.flagged_fcrs)}
            sub={summaryLoading ? null : `${kpi?.flagged_pct ?? 0}% of all FCRs`}
            accent="amber" />
          <KpiTile label="MSLs Needing Training"  tag={timeframeLabel}
            value={summaryLoading ? <><span className="skeleton skeleton-value" /><span className="skeleton skeleton-sub" /></> : fmt(kpi?.reps_needing_training)}
            sub={summaryLoading ? null : `${kpi?.reps_training_pct ?? 0}% of all coached MSLs`}
            accent="redhl" highlighted />
        </div>
      </div>

      {/* ── FILTER ROW ── */}
      <div className="filter-row" ref={filterBarRef}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: '#1A1A1A', display: 'flex', alignItems: 'center', gap: 4 }}>
            <ChevronDown size={13} /> Filters {activeFilterCount > 0 && <span style={{ background: '#E60012', color: '#fff', borderRadius: 20, fontSize: 10, padding: '1px 6px', fontWeight: 700 }}>{activeFilterCount}</span>}
          </span>

          {/* Timeframe */}
          <FilterDropdown
            id="timeframe" label="Timeframe"
            options={TIMEFRAME_OPTIONS}
            value={filterTimeframe}
            onChange={setFilterTimeframe}
            open={openDropdown === 'timeframe'}
            onToggle={setOpenDropdown}
            extra={filterTimeframe === 'custom' && (
              <div style={{ padding: '10px 14px', borderTop: '1px solid #F3F4F6', display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#6B7280', marginBottom: 2 }}>Custom date range</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div>
                    <div style={{ fontSize: 11, color: '#6B7280', marginBottom: 3 }}>From</div>
                    <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
                      style={{ fontSize: 12, border: '1px solid #E9E5E7', borderRadius: 7, padding: '5px 8px', width: '100%', outline: 'none', color: '#1B1F2A' }} />
                  </div>
                  <div>
                    <div style={{ fontSize: 11, color: '#6B7280', marginBottom: 3 }}>To</div>
                    <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
                      style={{ fontSize: 12, border: '1px solid #E9E5E7', borderRadius: 7, padding: '5px 8px', width: '100%', outline: 'none', color: '#1B1F2A' }} />
                  </div>
                </div>
                <button onMouseDown={() => setOpenDropdown(null)}
                  style={{ background: '#E60012', color: '#fff', border: 'none', borderRadius: 8, padding: '6px 0', fontSize: 12, fontWeight: 700, cursor: 'pointer', marginTop: 2 }}>
                  Apply
                </button>
              </div>
            )}
          />

          {/* Therapeutic Area */}
          <FilterDropdown
            id="ta" label="Therapeutic Area"
            options={TA_OPTIONS}
            value={filterTA}
            onChange={setFilterTA}
            open={openDropdown === 'ta'}
            onToggle={setOpenDropdown}
          />

          {/* Region */}
          <FilterDropdown
            id="region" label="Region"
            options={REGION_OPTIONS}
            value={filterRegion}
            onChange={setFilterRegion}
            open={openDropdown === 'region'}
            onToggle={setOpenDropdown}
          />

          {/* Clear all */}
          {activeFilterCount > 0 && (
            <button
              className="filter-pill"
              onMouseDown={() => { setFilterTA(null); setFilterTimeframe(null); setFilterRegion(null); setCustomFrom(''); setCustomTo(''); }}
              style={{ color: '#E60012', borderColor: '#E60012', fontWeight: 600 }}
            >
              Clear all
            </button>
          )}
        </div>
        <span style={{ fontSize: 11, color: '#6B7280' }}>
          Showing <strong>{summaryLoading ? '…' : fmt(kpi?.total_fcrs)} FCRs</strong> · <strong>{summaryLoading ? '…' : fmt(kpi?.total_reps)} Reps</strong> · <strong>{summaryLoading ? '…' : fmt(kpi?.submitted_fcrs)} Published</strong>
        </span>
      </div>

      {/* ── CHOOSE A VIEW ── */}
      <div>
        <div className="section-eyebrow" style={{ marginBottom: 10 }}>Choose a View</div>
        <div className="view-cards-grid">
          <ViewCard num={1} icon={Activity} title="Coaching Coverage & Cadence" sub="Reach, cadence & completion"  active={activeView === 0} onClick={() => setActiveView(0)} />
          <ViewCard num={2} icon={Target}   title="Training & Skill Gaps"        sub="Where coaching should focus"  active={activeView === 1} onClick={() => setActiveView(1)} />
          <ViewCard num={3} icon={Sparkles} title="Skill Proficiency Trend"      sub="Score trends over time"       active={activeView === 2} onClick={() => setActiveView(2)} />
        </div>
      </div>

      {/* ── DATA SECTION: view 0 (Coverage) ── */}
      {activeView === 1 && <TrainingSkillGapsView />}
      {activeView === 2 && <SkillProficiencyTrendView />}
      {activeView === 0 && <div className="dash-card">
        {/* Toggle row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
          <button className="all-pill">🏠 All</button>
          <div className="toggle-group-pill">
            {[['region', 'By region'], ['ta', 'By therapeutic area']].map(([key, label]) => (
              <button
                key={key}
                onClick={() => setRegionToggle(key)}
                className={`toggle-pill${regionToggle === key ? ' active' : ''}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Info banner */}
        <div className="info-banner">
          <Info size={14} color="#4B6EA8" />
          <div style={{ flex: 1 }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#4B6EA8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
              For Your Information · 5
            </span>
            <span style={{ fontSize: 11, color: '#4B6EA8', marginLeft: 8 }}>
              Region factors affecting these counts — tap to review before acting
            </span>
          </div>
          <ChevronDown size={14} color="#4B6EA8" />
        </div>

        {/* Charts row */}
        <div className="charts-grid">

          {/* Bar chart */}
          <div className="chart-card">
            <div className="chart-card-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 3, height: 16, background: '#E60012', borderRadius: 2 }} />
                <span style={{ fontSize: 13, fontWeight: 700, color: '#1A1A1A' }}>{barChartLabel}</span>
              </div>
              <span style={{ fontSize: 10, color: '#9CA3AF' }}>click to drill in</span>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={barChartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="region" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                <YAxis ticks={[0, 60, 120, 180, 240]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                <Tooltip content={<BarTip />} cursor={{ fill: '#FEF2F2' }} />
                <Bar dataKey="count" fill="#E60012" radius={[6, 6, 0, 0]} maxBarSize={48} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Stacked bar chart */}
          <div className="chart-card">
            <div className="chart-card-header" style={{ flexWrap: 'wrap', gap: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#1A1A1A' }}>FCR Completion vs. Required Base</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span className="trending-pill">📉 Trending down</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <ComposedChart data={fcrsTrend} margin={{ top: 22, right: 8, left: -16, bottom: 32 }}>
                <CartesianGrid strokeDasharray="5 4" stroke="#F3F4F6" vertical={false} />
                <XAxis 
                  dataKey="quarter" 
                  tick={(props) => {
                    const { x, y, payload } = props;
                    const dataPoint = fcrsTrend.find(d => d.quarter === payload.value);
                    const coverage = requiredFcrs > 0 ? Math.round((dataPoint?.coached / requiredFcrs) * 100) : 0;
                    return (
                      <g>
                        <text x={x} y={y} textAnchor="middle" fill="#6B7280" fontSize={11}>
                          {payload.value}
                        </text>
                        <text x={x} y={y + 16} textAnchor="middle" fill="#9CA3AF" fontSize={10} fontWeight={600}>
                          {coverage}% coverage
                        </text>
                      </g>
                    );
                  }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis 
                  domain={[0, Math.max(requiredFcrs * 1.2, 120)]} 
                  tick={{ fontSize: 10, fill: '#9CA3AF' }} 
                  axisLine={false} 
                  tickLine={false} 
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload?.[0]) {
                      const data = payload[0].payload;
                      const coveragePct = requiredFcrs ? Math.round((data.coached / requiredFcrs) * 100) : 0;
                      const uncoached = Math.max(requiredFcrs - data.coached, 0);
                      return (
                        <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 6, padding: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                          <div style={{ fontSize: 12, fontWeight: 600, color: '#1A1A1A', marginBottom: 8 }}>{data.quarter}</div>
                          <div style={{ fontSize: 11, color: '#4B5563', marginBottom: 4 }}>FCRs completed: <strong>{data.total}</strong></div>
                          <div style={{ fontSize: 11, color: '#4B5563', marginBottom: 4 }}>
                            MSLs coached: <strong>{data.coached} of {requiredFcrs}</strong> <span style={{ color: '#E60012', fontWeight: 600 }}>({coveragePct}%)</span>
                          </div>
                          <div style={{ fontSize: 11, color: '#4B5563', marginBottom: 8 }}>Repeat observations: <strong>{data.repeats}</strong></div>
                          <div style={{ fontSize: 11, color: uncoached > 0 ? '#DC2626' : '#15803D', fontWeight: 600 }}>
                            {uncoached > 0 ? `${uncoached} MSLs with no FCR` : '✓ Every MSL coached'}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                  cursor={{ fill: '#FEF2F2' }}
                />
                <Bar dataKey="coached" stackId="coverage" fill="#E60012" maxBarSize={56} radius={[0, 0, 0, 0]} />
                <Bar dataKey="repeats" stackId="coverage" fill="#E60012" fillOpacity={0.28} radius={[4, 4, 0, 0]} maxBarSize={56} />
                {requiredFcrs > 0 && <ReferenceLine y={requiredFcrs} stroke="#9CA3AF" strokeDasharray="5 4" strokeWidth={2} label={{ value: `Required ${fmt(requiredFcrs)}`, position: 'insideTopLeft', fill: '#9CA3AF', fontSize: 10, offset: 10 }} />}
              </ComposedChart>
            </ResponsiveContainer>
            <div className="chart-legend-row">
              <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
                <span className="legend-item">
                  <span style={{ width: 10, height: 3, background: '#E60012', borderRadius: 2, display: 'inline-block' }} />
                  MSLs coached (distinct)
                </span>
                <span className="legend-item">
                  <span style={{ width: 10, height: 3, background: '#E60012', borderRadius: 2, display: 'inline-block', opacity: 0.28 }} />
                  Repeat observations
                </span>
                <span className="legend-item" style={{ color: '#9CA3AF' }}>
                  <span style={{ width: 10, borderTop: '2px dashed #9CA3AF', display: 'inline-block' }} />
                  Required base (1 per MSL per quarter = {fmt(requiredFcrs)})
                </span>
              </div>
              <span className={`positive-pill${fcrsDiff < 0 ? ' negative' : ''}`}>
                {fcrsDiff >= 0 ? '+' : ''}{fmt(fcrsDiff)} total FCRs vs required base
              </span>
            </div>
          </div>

        </div>
      </div>}
    </div>
  );
}
