import { useState, useEffect, useCallback, useRef } from 'react';
import {
  FileText, CheckCircle2, Clock, AlertTriangle,
  ChevronDown, Search, RefreshCw, X, TrendingUp, MessageSquare, Target, Sparkles, Download,
} from 'lucide-react';
import { downloadPinsPdf } from '../components/PinsPdfReport';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

// ── TA pill colors ─────────────────────────────────────────────
const TA_COLORS = {
  'IMM': { bg:'#FDF4FF', color:'#7E22CE', label:'Immunology' },
  'ONC': { bg:'#FEF9C3', color:'#92400E', label:'Oncology' },
  'NS':  { bg:'#FFF7ED', color:'#C2410C', label:'Neuroscience' },
  'SCG': { bg:'#F0F9FF', color:'#0369A1', label:'SCG' },
  'Scientific Affairs (Janssen)': { bg:'#F0FDF4', color:'#166534', label:'Sci. Affairs' },
};


// ── Status config ──────────────────────────────────────────────
const STATUS = {
  Submitted:          { dot:'#16A34A', bg:'#DCFCE7', color:'#15803D' },
  Published:          { dot:'#16A34A', bg:'#DCFCE7', color:'#15803D' },
  'Late Submission':  { dot:'#F97316', bg:'#FFF7ED', color:'#C2410C' },
  Draft:              { dot:'#F5A524', bg:'#FEF3C7', color:'#92400E' },
  Completed:          { dot:'#4FAF7A', bg:'#DCFCE7', color:'#15803D' },
};

// ── Sub-components ─────────────────────────────────────────────
function KpiCard({ label, sublabel, value, sub, accent, highlighted, Icon }) {
  const colors = {
    red:   { iconBg:'#FDECEE', iconColor:'#E11937' },
    green: { iconBg:'#DCFCE7', iconColor:'#15803D' },
    gray:  { iconBg:'#F1F5F9', iconColor:'#94A3B8' },
    redhl: { iconBg:'#FDECEE', iconColor:'#E11937' },
  };
  const { iconBg, iconColor } = colors[accent] || colors.red;
  return (
    <div style={{
      background: highlighted ? '#FDF5F6' : '#fff',
      border: highlighted ? '1.5px solid #F5C6CE' : '1px solid #E8E5E8',
      borderRadius: 14, padding: '18px 18px 16px', flex: 1, minWidth: 0,
      boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      transition: 'transform 0.15s, box-shadow 0.15s',
    }}
    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 6px 18px rgba(0,0,0,0.08)'; }}
    onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)'; }}
    >
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 8 }}>
        <div>
          <div style={{ fontSize:9, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.07em', color:'#6B7280' }}>{label}</div>
          <div style={{ fontSize:10, color:'#9CA3AF', marginTop:2 }}>{sublabel}</div>
        </div>
        <div style={{ width:30, height:30, borderRadius:8, background:iconBg, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <Icon size={14} color={iconColor} />
        </div>
      </div>
      <div style={{ fontSize:36, fontWeight:800, lineHeight:1, color: highlighted ? '#E11937' : '#1B1F2A', margin:'8px 0 4px' }}>{value}</div>
      <div style={{ fontSize:11, color:'#6B7280' }}>{sub}</div>
    </div>
  );
}

function Avatar({ initials, red }) {
  return (
    <span style={{
      width:26, height:26, borderRadius:'50%', flexShrink:0,
      background: red ? '#FDECEE' : '#F1F5F9',
      color: red ? '#E11937' : '#6B7280',
      fontSize:9, fontWeight:800,
      display:'inline-flex', alignItems:'center', justifyContent:'center',
    }}>{initials}</span>
  );
}

function TaPill({ ta }) {
  const c = TA_COLORS[ta] || { bg:'#F1F5F9', color:'#475569' };
  return (
    <span style={{ fontSize:10, fontWeight:600, background:c.bg, color:c.color, borderRadius:10, padding:'2px 8px', whiteSpace:'nowrap' }}>
      {ta}
    </span>
  );
}

function StatusBadge({ status }) {
  const s = STATUS[status] || STATUS.Submitted;
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:10, fontWeight:700, background:s.bg, color:s.color, borderRadius:10, padding:'3px 9px', whiteSpace:'nowrap' }}>
      <span style={{ width:5, height:5, borderRadius:'50%', background:s.dot, flexShrink:0, display:'inline-block' }} />
      {status}
    </span>
  );
}

function TrainingTags({ tags }) {
  if (!tags || tags.length === 0) return <span style={{ fontSize:10, color:'#C9CDD4' }}>None</span>;
  return (
    <span style={{ display:'flex', gap:3 }}>
      {tags.map(t => (
        <span key={t} style={{ width:16, height:16, borderRadius:3, background:'#E11937', color:'#fff', fontSize:8, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center' }}>{t}</span>
      ))}
    </span>
  );
}

// ── Helpers ────────────────────────────────────────────────────
function initials(first, last) {
  return `${(first || '?')[0]}${(last || '?')[0]}`.toUpperCase();
}
function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toISOString().split('T')[0];
}

// ── Score helpers ──────────────────────────────────────────────
const SCORE_MAP = { 'Clear Strength': 4, 'Emerging Strength': 3, 'Development Need': 2, 'Clear Development Need': 1 };
const scoreColor = s => s >= 3 ? '#15803D' : s >= 2 ? '#D97706' : '#E60012';
const scoreBg    = s => s >= 3 ? '#DCFCE7' : s >= 2 ? '#FEF9C3' : '#FDECEC';

// ── Competency label from question text ───────────────────────
function compLabel(txt) {
  const t = (txt || '').toLowerCase();
  if (t.includes('selling skill'))                           return 'Selling Skills';
  if (t.includes('healthcare marketplace'))                  return 'Healthcare Marketplace';
  if (t.includes('analytics') && t.includes('insight'))     return 'Analytics & Insights';
  if (t.includes('internal partner'))                        return 'Internal Partnerships';
  if (t.includes('account management'))                      return 'Account Management';
  if (t.includes('business') && t.includes('planning'))      return 'Business Planning';
  if (t.includes('pre-call') || t.includes('pre call'))      return 'Pre-Call Planning';
  if (t.startsWith('advance'))                               return 'Advance';
  if (t.startsWith('learn') && t.includes('customer'))       return 'Learn';
  if (t.startsWith('deliver'))                               return 'Deliver';
  if (t.startsWith('engage'))                                return 'Engage';
  if (t.includes('stakeholder'))                             return 'Stakeholder Mapping';
  return null;
}

// ── FCR Detail Panel ───────────────────────────────────────────
function FCRDetailPanel({ fcr, detail, trend, trendLoading, onClose }) {
  const [aiInsight, setAiInsight] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError]     = useState(null);
  const [pinsScores, setPinsScores]     = useState(null);
  const [pinsLoading, setPinsLoading]   = useState(false);
  const [pinsError, setPinsError]       = useState(null);
  const [expandedSection, setExpandedSection] = useState(null);
  const [showAllQA, setShowAllQA]       = useState(true);

  if (!fcr) return null;

  // Derive meta from first row
  const meta  = detail[0] || {};
  // Derive status label from survey_target_status (more accurate than survey_status)
  const rawSt = (meta.survey_target_status || '').toLowerCase();
  const statusLabel = (rawSt.includes('late') && rawSt.includes('submission')) ? 'Late Submission'
                    : rawSt.includes('submitted')                               ? 'Submitted'
                    : (rawSt.includes('saved') || rawSt.includes('draft'))      ? 'Draft'
                    : meta.status || 'Draft';
  const isPublished = statusLabel === 'Submitted' || statusLabel === 'Late Submission';

  // Separate scored questions from free-text
  const scored = detail.filter(r => SCORE_MAP[r.survey_question_response]);
  const notes  = detail.filter(r => !SCORE_MAP[r.survey_question_response] && r.survey_question_response_text && r.survey_question_response_text.trim());

  // Group scored by competency
  const compGroups = {};
  scored.forEach(r => {
    const c = compLabel(r.survey_question_text) || 'Other';
    if (!compGroups[c]) compGroups[c] = [];
    compGroups[c].push(r);
  });

  // Action items (de-duplicate across rows)
  const actionItem = meta.survey_target_action_item || '';
  const prevAction = meta.survey_target_previous_action_item || '';

  // Scientific exchange — look for compliance question
  const sciRow = detail.find(r => r.survey_question_text && /(scientific|non.?promot|complian)/i.test(r.survey_question_text));
  const trainingRows = detail.filter(r => r.survey_question_text && /training needed/i.test(r.survey_question_text) && r.survey_question_response);

  // Extra rich data fields
  const prevProgressRow = detail.find(r => r.survey_question_text && /previous action item/i.test(r.survey_question_text) && r.survey_question_response_text?.trim());
  const goalAttainmentRow = detail.find(r => r.survey_question_text && /goal attainment/i.test(r.survey_question_text) && r.survey_question_response);
  const leadFeedbackRow = detail.find(r => r.survey_question_text && /lead.*coaching feedback/i.test(r.survey_question_text) && r.survey_question_response_text?.trim());
  const complianceRow = detail.find(r => r.survey_question_text && /field observation/i.test(r.survey_question_text) && r.survey_question_response);
  const safeFleetRow = detail.find(r => r.survey_question_text && /safe fleet/i.test(r.survey_question_text) && r.survey_question_response);

  // PINS detection — rows whose question starts with P/I/N/S section keywords
  const isPinsQ = (text) => {
    const u = (text || '').trimStart().toUpperCase();
    return u.startsWith('PLAN') || u.startsWith('INVEST') || u.startsWith('NAVIGAT') || u.startsWith('NEGOT') || u.startsWith('SECURE');
  };
  const pinsRows = detail.filter(r => isPinsQ(r.survey_question_text));
  const pinsTrainingFlags = {
    P: pinsRows.find(r => /plan.*training needed/i.test(r.survey_question_text))?.survey_question_response,
    I: pinsRows.find(r => /invest.*training needed/i.test(r.survey_question_text))?.survey_question_response,
    N: pinsRows.find(r => /(navigat|negot).*training needed/i.test(r.survey_question_text))?.survey_question_response,
    S: pinsRows.find(r => /secure.*training needed/i.test(r.survey_question_text))?.survey_question_response,
  };
  const hasPins = pinsRows.length > 0;

  const handleScorePins = async () => {
    setPinsLoading(true);
    setPinsError(null);
    setPinsScores(null);
    setExpandedSection(null);
    try {
      const resp = await fetch('/api/pins-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fcrId: fcr.fcr_id, jobLevel: fcr.coachee_role }),
      });
      const data = await resp.json();
      if (data.error) throw new Error(data.error);
      setPinsScores(data);
    } catch (e) {
      setPinsError(e.message);
    } finally {
      setPinsLoading(false);
    }
  };

  const chartData = trend.map((t, i) => ({
    label: `S${i + 1}`,
    score: t.avg_score != null ? Number(t.avg_score) : null,
    current: t.fcr_id === fcr.fcr_id,
  }));

  const handleGenerateInsight = async () => {
    setAiLoading(true);
    setAiError(null);
    setAiInsight(null);

    // Build competency scores payload
    const competencyScores = {};
    Object.entries(compGroups).forEach(([comp, qs]) => {
      const avg = qs.reduce((s, q) => s + (SCORE_MAP[q.survey_question_response] || 0), 0) / qs.length;
      competencyScores[comp] = {
        avg,
        responses: qs.map(q => q.survey_question_response),
      };
    });

    const observations = notes.map(r => ({
      question: r.survey_question_text,
      text: r.survey_question_response_text,
    }));

    const trendPayload = trend.map(t => ({ score: t.avg_score }));

    try {
      const resp = await fetch('/api/fcr-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fcrId: fcr.fcr_id,
          coacheeName: `${fcr.coachee_first || ''} ${fcr.coachee_last || ''}`.trim(),
          coacheeRole: fcr.coachee_role,
          ta: fcr.ta,
          region: fcr.region,
          sessionDuration: meta.survey_target_session_duration,
          coachingDate: fcr.coaching_date,
          competencyScores,
          observations,
          actionItem,
          prevActionItem: prevAction,
          trendData: trendPayload,
        }),
      });
      const data = await resp.json();
      if (data.error) throw new Error(data.error);
      setAiInsight(data.insight);
    } catch (e) {
      setAiError(e.message);
    } finally {
      setAiLoading(false);
    }
  };

  // Parse the insight text into sections for display
  function parseInsightSections(text) {
    if (!text) return [];
    const sections = [];
    const regex = /\*\*(.+?)\*\*[:\s]*([\s\S]*?)(?=\*\*|$)/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
      const title = match[1].trim();
      const body  = match[2].trim();
      if (title && body) sections.push({ title, body });
    }
    return sections.length > 0 ? sections : [{ title: 'AI Analysis', body: text }];
  }

  return (
    <>
      {/* Backdrop */}
      <div onClick={onClose} style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.35)', zIndex:400 }} />
      {/* Panel */}
      <div style={{
        position:'fixed', top:0, right:0, height:'100vh', width: 540, zIndex:401,
        background:'#fff', boxShadow:'-8px 0 40px rgba(0,0,0,0.16)',
        display:'flex', flexDirection:'column', overflowY:'hidden',
      }}>
        {/* Panel header — dark profile card */}
        <div style={{ background:'linear-gradient(135deg, #18181B 0%, #1E1B4B 100%)', padding:'16px 20px 18px', flexShrink:0 }}>
          {/* Close + form label */}
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <FileText size={12} color='rgba(255,255,255,0.45)' />
              <span style={{ fontSize:10, fontWeight:600, color:'rgba(255,255,255,0.45)', letterSpacing:'0.06em', textTransform:'uppercase' }}>MSL Field Coaching Report</span>
              <span style={{ fontSize:9, fontWeight:700, color:'rgba(255,255,255,0.3)', fontFamily:'monospace' }}>· {fcr.fcr_id.slice(-8).toUpperCase()}</span>
            </div>
            <button onClick={onClose} style={{ width:26, height:26, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.15)', background:'rgba(255,255,255,0.08)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <X size={12} color='rgba(255,255,255,0.6)' />
            </button>
          </div>
          {/* Avatar + name + role */}
          <div style={{ display:'flex', alignItems:'center', gap:13 }}>
            <div style={{ width:50, height:50, borderRadius:14, background:'linear-gradient(135deg,#E60012,#9B1A1A)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:18, fontWeight:800, color:'#fff', letterSpacing:'-0.5px', boxShadow:'0 4px 14px rgba(230,0,18,0.4)' }}>
              {initials(fcr.coachee_first, fcr.coachee_last)}
            </div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:18, fontWeight:800, color:'#fff', lineHeight:1.2, letterSpacing:'-0.3px' }}>
                {fcr.coachee_first} {fcr.coachee_last}
              </div>
              <div style={{ fontSize:11, color:'rgba(255,255,255,0.55)', marginTop:3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{fcr.coachee_role}</div>
            </div>
          </div>
          {/* Tag pills */}
          <div style={{ display:'flex', flexWrap:'wrap', gap:5, marginTop:13 }}>
            {fcr.ta && <span style={{ fontSize:9, fontWeight:700, background:'rgba(255,255,255,0.12)', color:'rgba(255,255,255,0.85)', borderRadius:8, padding:'3px 9px' }}>{fcr.ta}</span>}
            {fcr.region && <span style={{ fontSize:9, fontWeight:700, background:'rgba(255,255,255,0.12)', color:'rgba(255,255,255,0.85)', borderRadius:8, padding:'3px 9px' }}>{fcr.region}</span>}
            {fcr.coaching_date && <span style={{ fontSize:9, fontWeight:700, background:'rgba(255,255,255,0.10)', color:'rgba(255,255,255,0.7)', borderRadius:8, padding:'3px 9px' }}>📅 {formatDate(fcr.coaching_date)}</span>}
            <span style={{ fontSize:9, fontWeight:700, borderRadius:8, padding:'3px 9px',
              background: isPublished ? 'rgba(21,128,61,0.35)' : 'rgba(217,119,6,0.35)',
              color: isPublished ? '#86EFAC' : '#FDE68A'
            }}>{statusLabel}</span>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex:1, overflowY:'auto', padding:'16px 20px', display:'flex', flexDirection:'column', gap:16 }}>

          {/* Session meta strip */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6 }}>
            {[
              ['📅', 'Coaching Date', formatDate(fcr.coaching_date)],
              ['⏱', 'Session', meta.survey_target_session_duration || '—'],
              ['📍', 'Territory', fcr.territory || fcr.district || '—'],
              ['🏥', 'TA', fcr.ta || '—'],
              ['🌐', 'Region', fcr.region || '—'],
              ['📋', 'Published', isPublished ? formatDate(meta.survey_target_last_modified_date) : 'Not yet'],
            ].map(([icon, label, val]) => (
              <div key={label} style={{ background:'#F8F7FF', border:'1px solid #EDE9FE', borderRadius:9, padding:'8px 10px' }}>
                <div style={{ fontSize:9, fontWeight:700, color:'#7C3AED', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:3, display:'flex', alignItems:'center', gap:3 }}>
                  <span>{icon}</span>{label}
                </div>
                <div style={{ fontSize:11, fontWeight:700, color:'#1B1F2A', lineHeight:1.3 }}>{val}</div>
              </div>
            ))}
          </div>

          {/* PINS Training flags strip */}
          {Object.entries(pinsTrainingFlags).some(([,v]) => v != null) && (
            <div style={{ display:'flex', gap:6, flexWrap:'wrap', background:'#F0FDF4', border:'1px solid #BBF7D0', borderRadius:10, padding:'10px 14px', alignItems:'center' }}>
              <span style={{ fontSize:9, fontWeight:800, color:'#166534', textTransform:'uppercase', letterSpacing:'0.07em', marginRight:2 }}>Training Assessment</span>
              {[['P','Planning','#E60012'],['I','Investigate','#2563EB'],['N','Navigate','#059669'],['S','Secure','#D97706']].map(([letter, name, col]) => {
                const flag = pinsTrainingFlags[letter];
                const needed = flag === 'Yes';
                if (flag == null) return null;
                return (
                  <span key={letter} style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:10, fontWeight:700, padding:'3px 10px', borderRadius:20,
                    background: needed ? '#FEE2E2' : '#DCFCE7',
                    color: needed ? '#DC2626' : '#15803D',
                    border: `1px solid ${needed ? '#FECACA' : '#BBF7D0'}`,
                  }}>
                    <span style={{ width:14, height:14, borderRadius:'50%', background:col, color:'#fff', fontSize:8, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center' }}>{letter}</span>
                    {needed ? '⚠ Needs Training' : '✓ Proficient'}
                  </span>
                );
              })}
              {complianceRow && (
                <span style={{ marginLeft:'auto', display:'inline-flex', alignItems:'center', gap:5, fontSize:10, fontWeight:700, padding:'3px 10px', borderRadius:20,
                  background: complianceRow.survey_question_response === 'Yes' ? '#DCFCE7' : '#FEE2E2',
                  color: complianceRow.survey_question_response === 'Yes' ? '#15803D' : '#DC2626',
                  border: `1px solid ${complianceRow.survey_question_response === 'Yes' ? '#BBF7D0' : '#FECACA'}`,
                }}>
                  {complianceRow.survey_question_response === 'Yes' ? '✓ Compliant' : '✗ Non-Compliant'}
                </span>
              )}
            </div>
          )}

          {/* Rep proficiency — trend if 2+ sessions, snapshot if 1 */}
          {(() => {
            const FBMS_SCORE = { Expert:4, Advanced:3, Skilled:2, Awareness:1 };
            const allRated = detail.filter(r => FBMS_SCORE[r.survey_question_response]);
            const avgNow   = allRated.length ? (allRated.reduce((s,r) => s + FBMS_SCORE[r.survey_question_response], 0) / allRated.length) : null;
            const levelNow = avgNow >= 3.5 ? 'Expert' : avgNow >= 2.5 ? 'Advanced' : avgNow >= 1.5 ? 'Skilled' : avgNow ? 'Awareness' : null;
            const levelColor = avgNow >= 3.5 ? '#1D4ED8' : avgNow >= 2.5 ? '#15803D' : avgNow >= 1.5 ? '#D97706' : '#DC2626';
            const levelBg   = avgNow >= 3.5 ? '#DBEAFE' : avgNow >= 2.5 ? '#DCFCE7' : avgNow >= 1.5 ? '#FEF9C3' : '#FEE2E2';
            const ratingCounts = { Expert: 0, Advanced: 0, Skilled: 0, Awareness: 0 };
            allRated.forEach(r => { if (ratingCounts[r.survey_question_response] !== undefined) ratingCounts[r.survey_question_response]++; });
            const sectionImpress = {
              P: detail.find(r => /rate.*planning/i.test(r.survey_question_text))?.survey_question_response,
              I: detail.find(r => /rate.*investigate/i.test(r.survey_question_text))?.survey_question_response,
              N: detail.find(r => /rate.*navigate/i.test(r.survey_question_text))?.survey_question_response,
              S: detail.find(r => /rate.*secure/i.test(r.survey_question_text))?.survey_question_response,
            };
            return (
              <div style={{ background:'#F9FAFB', borderRadius:10, padding:'12px 14px' }}>
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                    <TrendingUp size={13} color="#E60012" />
                    <span style={{ fontSize:12, fontWeight:700, color:'#1B1F2A' }}>{fcr.coachee_first} {fcr.coachee_last} — FBMS Proficiency</span>
                  </div>
                  {trendLoading
                    ? <span style={{ fontSize:9, color:'#9CA3AF' }}>Loading history…</span>
                    : chartData.length >= 2
                      ? <span style={{ fontSize:9, fontWeight:600, color:'#15803D', background:'#DCFCE7', borderRadius:8, padding:'2px 7px' }}>{chartData.length} sessions tracked</span>
                      : <span style={{ fontSize:9, fontWeight:600, color:'#9CA3AF', background:'#F3F4F6', borderRadius:8, padding:'2px 7px' }}>1 session · tracking begins with 2nd</span>
                  }
                </div>

                {/* Show chart if 2+ sessions */}
                {!trendLoading && chartData.length >= 2 && (
                  <ResponsiveContainer width="100%" height={90}>
                    <LineChart data={chartData} margin={{ top:4, right:8, left:-28, bottom:0 }}>
                      <XAxis dataKey="label" tick={{ fontSize:10, fill:'#9CA3AF' }} axisLine={false} tickLine={false} />
                      <YAxis domain={[1,4]} ticks={[1,2,3,4]} tickFormatter={v => ['','A','Sk','Ad','Ex'][v] || v} tick={{ fontSize:8, fill:'#C4C4C4' }} axisLine={false} tickLine={false} />
                      <Tooltip formatter={v => {
                        const lbl = Number(v) >= 3.5 ? 'Expert' : Number(v) >= 2.5 ? 'Advanced' : Number(v) >= 1.5 ? 'Skilled' : 'Awareness';
                        return [`${Number(v).toFixed(1)} — ${lbl}`, 'FBMS Avg'];
                      }} labelStyle={{ fontSize:11 }} contentStyle={{ fontSize:11, borderRadius:8 }} />
                      <ReferenceLine y={3} stroke="#7C3AED" strokeDasharray="4 3" />
                      <Line type="monotone" dataKey="score" stroke="#E60012" strokeWidth={2} dot={(props) => {
                        const isCurrent = chartData[props.index]?.current;
                        return <circle key={props.index} cx={props.cx} cy={props.cy} r={isCurrent ? 5 : 3} fill={isCurrent ? '#E60012' : '#fff'} stroke="#E60012" strokeWidth={2} />;
                      }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}

                {/* Always show current session snapshot */}
                {avgNow !== null && (
                  <div style={{ marginTop: chartData.length >= 2 ? 10 : 0 }}>
                    {/* Score badge + bar */}
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
                      <div style={{ background:levelBg, border:`1.5px solid ${levelColor}`, borderRadius:10, padding:'6px 14px', textAlign:'center', flexShrink:0 }}>
                        <div style={{ fontSize:22, fontWeight:800, color:levelColor, lineHeight:1 }}>{avgNow.toFixed(1)}</div>
                        <div style={{ fontSize:9, fontWeight:700, color:levelColor, marginTop:1 }}>{levelNow}</div>
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:10, color:'#6B7280', marginBottom:4 }}>This session · {allRated.length} behaviors rated · target ≥ 3.0 (Advanced)</div>
                        <div style={{ height:8, background:'#E9E5E7', borderRadius:4, overflow:'hidden' }}>
                          <div style={{ height:8, width:`${((avgNow-1)/3)*100}%`, background:levelColor, borderRadius:4, transition:'width 0.5s' }} />
                        </div>
                        <div style={{ display:'flex', justifyContent:'space-between', marginTop:3, fontSize:8, color:'#9CA3AF' }}>
                          <span>1 Awareness</span><span>2 Skilled</span><span>3 Advanced</span><span>4 Expert</span>
                        </div>
                      </div>
                    </div>
                    {/* Rating distribution pills */}
                    <div style={{ display:'flex', gap:5, flexWrap:'wrap', marginBottom:8 }}>
                      {[['Expert','#DBEAFE','#1D4ED8'],['Advanced','#DCFCE7','#15803D'],['Skilled','#FEF9C3','#D97706'],['Awareness','#FEE2E2','#DC2626']].map(([l,bg,c]) => (
                        ratingCounts[l] > 0 && (
                          <span key={l} style={{ fontSize:10, fontWeight:700, background:bg, color:c, borderRadius:20, padding:'3px 10px' }}>
                            {ratingCounts[l]}× {l}
                          </span>
                        )
                      ))}
                    </div>
                    {/* P/I/N/S impressions */}
                    {Object.values(sectionImpress).some(Boolean) && (
                      <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
                        {[['P','#E60012'],['I','#2563EB'],['N','#059669'],['S','#D97706']].map(([s,c]) => {
                          const imp = sectionImpress[s];
                          if (!imp) return null;
                          const isStrength = /strength/i.test(imp);
                          return (
                            <span key={s} style={{ fontSize:9, fontWeight:700, padding:'2px 8px', borderRadius:8,
                              background: isStrength ? '#DCFCE7' : '#FEF9C3',
                              color: isStrength ? '#15803D' : '#92400E',
                              border:`1px solid ${isStrength ? '#BBF7D0' : '#FDE68A'}`,
                              display:'flex', alignItems:'center', gap:4
                            }}>
                              <span style={{ width:12, height:12, borderRadius:'50%', background:c, color:'#fff', fontSize:7, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center' }}>{s}</span>
                              {isStrength ? 'Strength' : 'Development'}
                            </span>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
                {avgNow === null && !trendLoading && (
                  <div style={{ fontSize:11, color:'#9CA3AF', textAlign:'center', padding:'12px 0' }}>No FBMS behavior ratings in this FCR</div>
                )}
              </div>
            );
          })()}

          {/* Competency scores */}
          {Object.keys(compGroups).length > 0 && (
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:8 }}>
                <Target size={13} color="#E60012" />
                <span style={{ fontSize:12, fontWeight:700, color:'#1B1F2A' }}>Competency Scores</span>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {Object.entries(compGroups).map(([comp, qs]) => {
                  const avgScore = qs.reduce((s, q) => s + (SCORE_MAP[q.survey_question_response] || 0), 0) / qs.length;
                  return (
                    <div key={comp} style={{ background:'#F9FAFB', borderRadius:8, padding:'8px 10px' }}>
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
                        <span style={{ fontSize:11, fontWeight:700, color:'#1B1F2A' }}>{comp}</span>
                        <span style={{ fontSize:11, fontWeight:800, color: scoreColor(avgScore), background: scoreBg(avgScore), borderRadius:6, padding:'2px 7px' }}>
                          {avgScore.toFixed(1)}
                        </span>
                      </div>
                      <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
                        {qs.map((q, i) => (
                          <span key={i} title={q.survey_question_text} style={{ fontSize:9, fontWeight:700, color: scoreColor(SCORE_MAP[q.survey_question_response]), background: scoreBg(SCORE_MAP[q.survey_question_response]), borderRadius:5, padding:'2px 6px', cursor:'default' }}>
                            {q.survey_question_response === 'Clear Strength' ? 'CS' :
                             q.survey_question_response === 'Emerging Strength' ? 'ES' :
                             q.survey_question_response === 'Development Need' ? 'DN' : 'CDN'}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Coaching observations — PINS color-coded */}
          {notes.length > 0 && (() => {
            const PINS_OBS = {
              P: { color:'#E60012', bg:'#FFF5F5', border:'#FECACA', label:'Planning for Perspective' },
              I: { color:'#2563EB', bg:'#EFF6FF', border:'#BFDBFE', label:'Investigate Issues' },
              N: { color:'#059669', bg:'#F0FDF4', border:'#A7F3D0', label:'Navigate & Negotiate' },
              S: { color:'#D97706', bg:'#FFFBEB', border:'#FDE68A', label:'Secure Action' },
            };
            return (
              <div>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:10 }}>
                  <MessageSquare size={13} color='#1B1F2A' />
                  <span style={{ fontSize:12, fontWeight:800, color:'#1B1F2A' }}>Coaching Observations</span>
                </div>
                <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                  {notes.slice(0, 6).map((r, i) => {
                    const q = (r.survey_question_text || '').trimStart().toUpperCase();
                    let pKey = null;
                    if (q.startsWith('PLAN')) pKey = 'P';
                    else if (q.startsWith('INVEST')) pKey = 'I';
                    else if (q.startsWith('NAVIGAT') || q.startsWith('NEGOT')) pKey = 'N';
                    else if (q.startsWith('SECURE')) pKey = 'S';
                    const m = pKey ? PINS_OBS[pKey] : null;
                    return (
                      <div key={i} style={{ background: m ? m.bg : '#F9FAFB', border:`1px solid ${m ? m.border : '#E9E5E7'}`, borderLeft:`3px solid ${m ? m.color : '#9CA3AF'}`, borderRadius:'0 10px 10px 0', padding:'10px 13px' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:6 }}>
                          {m && (
                            <span style={{ width:20, height:20, borderRadius:6, background:m.color, color:'#fff', fontSize:10, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>{pKey}</span>
                          )}
                          <span style={{ fontSize:10, fontWeight:800, color: m ? m.color : '#6B7280', textTransform:'uppercase', letterSpacing:'0.06em' }}>
                            {m ? m.label : r.survey_question_text}
                          </span>
                        </div>
                        <div style={{ fontSize:11, color:'#374151', lineHeight:1.7 }}>{r.survey_question_response_text}</div>
                      </div>
                    );
                  })}
                  {notes.length > 6 && <div style={{ fontSize:10, color:'#9CA3AF', textAlign:'center' }}>+{notes.length - 6} more</div>}
                </div>
              </div>
            );
          })()}

          {/* LEAD Coaching Feedback */}
          {leadFeedbackRow && (
            <div style={{ background:'#F5F3FF', border:'1px solid #DDD6FE', borderRadius:8, padding:'10px 12px' }}>
              <div style={{ fontSize:9, fontWeight:700, color:'#6D28D9', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:5 }}>LEAD Coaching Feedback</div>
              <div style={{ fontSize:11, color:'#374151', lineHeight:1.6 }}>{leadFeedbackRow.survey_question_response_text}</div>
            </div>
          )}

          {/* Previous Session Progress */}
          {prevProgressRow && (
            <div style={{ background:'#FFF7ED', border:'1px solid #FED7AA', borderRadius:8, padding:'10px 12px' }}>
              <div style={{ fontSize:9, fontWeight:700, color:'#C2410C', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:5 }}>Previous Session Progress</div>
              <div style={{ fontSize:11, color:'#374151', lineHeight:1.6 }}>{prevProgressRow.survey_question_response_text}</div>
            </div>
          )}

          {/* Goal Attainment */}
          {goalAttainmentRow && (
            <div style={{ display:'flex', alignItems:'center', gap:8, background:'#F0FDF4', border:'1px solid #BBF7D0', borderRadius:9, padding:'9px 13px' }}>
              <CheckCircle2 size={14} color='#15803D' />
              <div>
                <div style={{ fontSize:9, fontWeight:800, color:'#166534', textTransform:'uppercase', letterSpacing:'0.06em' }}>Goal Attainment</div>
                <div style={{ fontSize:12, fontWeight:700, color:'#15803D', marginTop:1 }}>{goalAttainmentRow.survey_question_response}</div>
              </div>
            </div>
          )}

          {/* Action items */}
          {(actionItem || prevAction) && (
            <div style={{ background:'#FAFAFA', border:'1px solid #E9E5E7', borderRadius:12, padding:'12px 14px' }}>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:10 }}>
                <CheckCircle2 size={13} color='#1B1F2A' />
                <span style={{ fontSize:12, fontWeight:800, color:'#1B1F2A' }}>Action Items</span>
              </div>
              {prevAction && (
                <div style={{ background:'#FFF7ED', border:'1px solid #FED7AA', borderLeft:'3px solid #D97706', borderRadius:'0 9px 9px 0', padding:'8px 12px', marginBottom:7 }}>
                  <div style={{ fontSize:9, fontWeight:800, color:'#92400E', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:3 }}>Previous</div>
                  <div style={{ fontSize:11, color:'#374151', lineHeight:1.6 }}>{prevAction}</div>
                </div>
              )}
              {actionItem && (
                <div style={{ background:'#F0FDF4', border:'1px solid #BBF7D0', borderLeft:'3px solid #15803D', borderRadius:'0 9px 9px 0', padding:'8px 12px' }}>
                  <div style={{ fontSize:9, fontWeight:800, color:'#166534', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:3 }}>Next Action</div>
                  <div style={{ fontSize:11, color:'#374151', lineHeight:1.6 }}>{actionItem}</div>
                </div>
              )}
            </div>
          )}

          {/* ── PINS Section ────────────────────────────────── */}
          {!hasPins && (
            <div style={{ background:'#F9F8FF', border:'1px dashed #DDD6FE', borderRadius:10, padding:'10px 14px', display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ fontSize:13, color:'#9CA3AF' }}>⬡</span>
              <span style={{ fontSize:11, color:'#A78BFA', fontWeight:500 }}>No PINS data — this FCR uses a non-FBMS coaching form</span>
            </div>
          )}
          {hasPins && (
            <div style={{ background:'#F5F3FF', border:'1px solid #DDD6FE', borderRadius:12, padding:'14px 16px' }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <div style={{ width:26, height:26, borderRadius:7, background:'#7C3AED', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    <span style={{ color:'#fff', fontSize:11, fontWeight:800 }}>P</span>
                  </div>
                  <div>
                    <div style={{ fontSize:12, fontWeight:700, color:'#4C1D95' }}>PINS Framework</div>
                    <div style={{ fontSize:10, color:'#7C3AED', marginTop:1 }}>Planning · Investigate · Navigate · Secure</div>
                  </div>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <button
                    onClick={handleScorePins}
                    disabled={pinsLoading}
                    style={{
                      display:'inline-flex', alignItems:'center', gap:5,
                      padding:'6px 13px', borderRadius:20,
                      background: pinsLoading ? '#C4B5FD' : '#7C3AED',
                      color:'#fff', border:'none', fontSize:11, fontWeight:600,
                      cursor: pinsLoading ? 'default' : 'pointer', fontFamily:'inherit',
                      opacity: pinsLoading ? 0.7 : 1,
                    }}
                  >
                    {pinsLoading ? '⚙ Scoring…' : <><Sparkles size={11} /> {pinsScores ? 'Re-score' : 'Score PINS'}</>}
                  </button>
                  {pinsScores && (
                    <button
                      onClick={() => downloadPinsPdf({ fcr, detail, pinsScores })}
                      title="Download PDF report"
                      style={{
                        display:'inline-flex', alignItems:'center', gap:5,
                        padding:'6px 13px', borderRadius:20,
                        background:'#fff', color:'#7C3AED',
                        border:'1.5px solid #7C3AED', fontSize:11, fontWeight:600,
                        cursor:'pointer', fontFamily:'inherit',
                      }}
                    >
                      <Download size={11} /> PDF
                    </button>
                  )}
                </div>
              </div>

              {/* Training needed flags */}
              {Object.entries(pinsTrainingFlags).some(([, v]) => v != null) && (
                <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:10 }}>
                  {[['P','Planning'],['I','Investigate'],['N','Navigate'],['S','Secure']].map(([letter, name]) => {
                    const flag = pinsTrainingFlags[letter];
                    if (flag == null) return null;
                    const needed = flag === 'Yes';
                    return (
                      <span key={letter} style={{ fontSize:10, fontWeight:700, padding:'2px 9px', borderRadius:10,
                        background: needed ? '#FDECEC' : '#DCFCE7',
                        color: needed ? '#E60012' : '#15803D',
                        border: `1px solid ${needed ? '#E6001222' : '#15803D22'}`,
                      }}>
                        {name}: Training {needed ? 'Needed ⚠' : 'Not Needed ✓'}
                      </span>
                    );
                  })}
                </div>
              )}

              {/* PINS AI scores */}
              {pinsError && (
                <div style={{ fontSize:11, color:'#E60012', background:'#FDECEC', borderRadius:8, padding:'8px 12px' }}>
                  {pinsError}
                </div>
              )}
              {pinsScores && (() => {
                const PINS_META = {
                  P: { label:'Planning for Perspective', color:'#7C3AED', bg:'#F5F3FF' },
                  I: { label:'Investigate Issues',       color:'#2563EB', bg:'#EFF6FF' },
                  N: { label:'Navigate & Negotiate',     color:'#0369A1', bg:'#F0F9FF' },
                  S: { label:'Secure Action',            color:'#059669', bg:'#F0FDF4' },
                };
                const SKILL_META = {
                  DataGathering:        { label:'Data Gathering',        color:'#6366F1' },
                  StrategicThinking:    { label:'Strategic Thinking',    color:'#7C3AED' },
                  CompetitiveLandscape: { label:'Competitive Landscape', color:'#EC4899' },
                  Influencing:          { label:'Influencing Others',    color:'#F59E0B' },
                  ClinicalExpertise:    { label:'Clinical Expertise',    color:'#10B981' },
                  ProblemSolving:       { label:'Problem Solving',       color:'#3B82F6' },
                  CrossFunctional:      { label:'Cross-functional',      color:'#14B8A6' },
                };
                const sc      = s => s === 4 ? '#1D4ED8' : s === 3 ? '#15803D' : s === 2 ? '#D97706' : '#DC2626';
                const scBg    = s => s === 4 ? '#DBEAFE' : s === 3 ? '#DCFCE7' : s === 2 ? '#FEF9C3' : '#FEE2E2';
                const scLabel = s => s === 4 ? 'Expert' : s === 3 ? 'Advanced' : s === 2 ? 'Skilled' : 'Awareness';
                const sectionData = pinsScores.sections || {};
                const skillData   = pinsScores.skills   || {};
                const gapData     = pinsScores.gaps     || {};
                const lvl         = pinsScores.detectedLevel || 'PG30';
                const lvlLabel    = { PG30:'MSL (PG30)', PG31:'Sr MSL / Reg Acct Dir (PG31)', PG40:'Principal MSL / Field Dir (PG40)', PG41:'Sr Dir / MSL Head (PG41)' }[lvl] || lvl;
                return (
                  <div>
                    {/* Job level badge */}
                    <div style={{ marginBottom:10 }}>
                      <span style={{ fontSize:10, fontWeight:700, background:'#EDE9FE', color:'#6D28D9', padding:'3px 9px', borderRadius:10 }}>
                        {lvlLabel} — FBMS proficiency targets applied
                      </span>
                    </div>

                    {/* P I N S section cards — full width stacked */}
                    <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom:12 }}>
                      {['P','I','N','S'].map(letter => {
                        const m = PINS_META[letter];
                        const d = sectionData[letter];
                        if (!d) return null;
                        const pct = Math.round((d.score / 4) * 100);
                        const isExpanded = expandedSection === letter;
                        return (
                          <div key={letter} style={{ background:'#fff', borderRadius:10, border:`1px solid ${m.color}30`, overflow:'hidden' }}>
                            {/* Section header */}
                            <div style={{ background:m.bg, padding:'7px 12px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                              <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                                <span style={{ width:22, height:22, borderRadius:6, background:m.color, color:'#fff', fontSize:11, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>{letter}</span>
                                <span style={{ fontSize:11, fontWeight:700, color:m.color }}>{m.label}</span>
                              </div>
                              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                                <span style={{ fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:8, background:scBg(d.score), color:sc(d.score) }}>
                                  {d.score}/4 · {scLabel(d.score)}
                                </span>
                                {d.behaviors && d.behaviors.length > 0 && (
                                  <button
                                    onClick={() => setExpandedSection(isExpanded ? null : letter)}
                                    style={{ fontSize:9, fontWeight:700, padding:'2px 7px', borderRadius:7,
                                      background: isExpanded ? m.color : 'rgba(0,0,0,0.06)',
                                      color: isExpanded ? '#fff' : m.color,
                                      border: `1px solid ${m.color}40`, cursor:'pointer', fontFamily:'inherit',
                                    }}
                                  >
                                    {isExpanded ? '▲ Hide' : '▾ Behaviors'}
                                  </button>
                                )}
                              </div>
                            </div>
                            {/* Score bar */}
                            <div style={{ height:3, background:'#E9E5E7' }}>
                              <div style={{ height:3, width:`${pct}%`, background:sc(d.score), transition:'width 0.6s' }} />
                            </div>
                            {/* Strength + Opportunity columns */}
                            <div style={{ padding:'8px 12px', display:'flex', gap:6 }}>
                              {d.strength && (
                                <div style={{ flex:1, background:'#F0FDF4', border:'1px solid #BBF7D0', borderRadius:7, padding:'6px 8px' }}>
                                  <div style={{ fontSize:8, fontWeight:800, color:'#166534', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:3 }}>Strength Observed</div>
                                  <div style={{ fontSize:10, color:'#374151', lineHeight:1.5 }}>{d.strength}</div>
                                </div>
                              )}
                              {d.opportunity && (
                                <div style={{ flex:1, background:'#FFFBEB', border:'1px solid #FDE68A', borderRadius:7, padding:'6px 8px' }}>
                                  <div style={{ fontSize:8, fontWeight:800, color:'#92400E', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:3 }}>Development Opportunity</div>
                                  <div style={{ fontSize:10, color:'#374151', lineHeight:1.5 }}>{d.opportunity}</div>
                                </div>
                              )}
                            </div>
                            {/* Per-behavior detail — shown when expanded */}
                            {isExpanded && d.behaviors && (
                              <div style={{ borderTop:`1px solid ${m.color}20`, padding:'8px 12px', background:'#FAFAFA', display:'flex', flexDirection:'column', gap:6 }}>
                                <div style={{ fontSize:9, fontWeight:800, color:m.color, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:2 }}>Observable Behaviour Scores</div>
                                {d.behaviors.map(b => (
                                  <div key={b.id} style={{ display:'flex', alignItems:'flex-start', gap:8, background:'#fff', borderRadius:7, padding:'6px 9px', border:'1px solid #E5E7EB' }}>
                                    <div style={{ width:26, flexShrink:0 }}>
                                      <span style={{ fontSize:9, fontWeight:800, background:m.color, color:'#fff', borderRadius:5, padding:'2px 5px' }}>{b.id}</span>
                                    </div>
                                    <div style={{ flex:1 }}>
                                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:3 }}>
                                        <span style={{ fontSize:10, fontWeight:600, color:'#1F2937' }}>{b.label}</span>
                                        <span style={{ fontSize:9, fontWeight:700, padding:'1px 6px', borderRadius:6, background:scBg(b.score), color:sc(b.score), flexShrink:0 }}>
                                          {b.score}/4 · {scLabel(b.score)}
                                        </span>
                                      </div>
                                      {b.skills && b.skills.length > 0 && (
                                        <div style={{ display:'flex', gap:4, flexWrap:'wrap', marginBottom:3 }}>
                                          {b.skills.map(sk => (
                                            <span key={sk} style={{ fontSize:8, background:'#EDE9FE', color:'#5B21B6', borderRadius:5, padding:'1px 5px', fontWeight:600 }}>{sk}</span>
                                          ))}
                                        </div>
                                      )}
                                      {b.note && <div style={{ fontSize:9, color:'#6B7280', lineHeight:1.45 }}>{b.note}</div>}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* 7 FBMS Core Skills panel */}
                    <div style={{ background:'#1B1F2A', borderRadius:10, padding:'12px 14px', marginBottom:10 }}>
                      <div style={{ fontSize:9, fontWeight:700, color:'rgba(255,255,255,0.45)', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:10 }}>
                        7 FBMS Core Skills · vs {lvlLabel} Target
                      </div>
                      <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                        {Object.entries(SKILL_META).map(([key, m]) => {
                          const s = skillData[key];
                          if (!s) return null;
                          const g = gapData[key];
                          const onTarget = !g || g.gap >= 0;
                          const barPct    = Math.round((s.score  / 4) * 100);
                          const targetPct = g ? Math.round((g.target / 4) * 100) : null;
                          return (
                            <div key={key}>
                              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:3 }}>
                                <span style={{ fontSize:10, fontWeight:600, color:'rgba(255,255,255,0.85)' }}>{m.label}</span>
                                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                                  <span style={{ fontSize:9, color:'rgba(255,255,255,0.4)' }}>{s.score}/4 · {scLabel(s.score)}</span>
                                  {g && (
                                    <span style={{ fontSize:9, fontWeight:700, padding:'1px 7px', borderRadius:6,
                                      background: onTarget ? 'rgba(22,163,74,0.2)' : 'rgba(220,38,38,0.2)',
                                      color: onTarget ? '#86EFAC' : '#FCA5A5',
                                    }}>
                                      {onTarget ? '✓ At target' : `↑ Need ${g.target}, got ${g.actual}`}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div style={{ height:4, background:'rgba(255,255,255,0.08)', borderRadius:2, position:'relative' }}>
                                <div style={{ height:4, width:`${barPct}%`, background:m.color, borderRadius:2, transition:'width 0.6s' }} />
                                {targetPct !== null && (
                                  <div style={{ position:'absolute', top:0, left:`${targetPct}%`, width:2, height:4, background:'rgba(255,255,255,0.5)', borderRadius:1 }} />
                                )}
                              </div>
                              {s.evidence && (
                                <div style={{ fontSize:9, color:'rgba(255,255,255,0.3)', marginTop:3, lineHeight:1.4 }}>{s.evidence}</div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Summary */}
                    {pinsScores.summary && (
                      <div style={{ fontSize:11, color:'#4C1D95', background:'#EDE9FE', borderRadius:8, padding:'9px 12px', lineHeight:1.6 }}>
                        {pinsScores.summary}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Raw PINS narratives collapsed */}
              {!pinsScores && (
                <div style={{ fontSize:10, color:'#7C3AED', marginTop:4 }}>
                  {pinsRows.filter(r => r.narrative || r.survey_question_response_text).length} narrative observations found.
                  Click "Score PINS" to generate AI scores for P · I · N · S sections.
                </div>
              )}
            </div>
          )}

          {/* ── AI Insights ─────────────────────────────────── */}
          <div style={{ background: 'linear-gradient(135deg, #1B1F2A 0%, #2D1F3A 100%)', borderRadius:12, padding:'14px 16px' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: aiInsight ? 12 : 0 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:26, height:26, borderRadius:7, background:'#E60012', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                  <Sparkles size={13} color="#fff" />
                </div>
                <div>
                  <div style={{ fontSize:12, fontWeight:700, color:'#fff', lineHeight:1 }}>AI Coaching Insights</div>
                  <div style={{ fontSize:10, color:'rgba(255,255,255,0.45)', marginTop:2 }}>GPT-powered analysis of this FCR</div>
                </div>
              </div>
              <button
                onClick={handleGenerateInsight}
                disabled={aiLoading}
                style={{
                  display:'inline-flex', alignItems:'center', gap:5,
                  padding:'6px 13px', borderRadius:20,
                  background: aiLoading ? 'rgba(255,255,255,0.08)' : '#E60012',
                  color:'#fff', border:'none', fontSize:11, fontWeight:600,
                  cursor: aiLoading ? 'default' : 'pointer', fontFamily:'inherit',
                  opacity: aiLoading ? 0.7 : 1, transition:'opacity 0.2s',
                }}
              >
                {aiLoading
                  ? <><span style={{ animation:'spin 1s linear infinite', display:'inline-block' }}>⚙</span> Analyzing…</>
                  : <><Sparkles size={11} /> {aiInsight ? 'Refresh' : 'Generate Insights'}</>}
              </button>
            </div>

            {aiError && (
              <div style={{ marginTop:10, background:'rgba(230,0,18,0.15)', borderRadius:8, padding:'8px 12px', fontSize:11, color:'#FCA5A5' }}>
                {aiError}
              </div>
            )}

            {aiInsight && (() => {
              const sections = parseInsightSections(aiInsight);
              const sectionColors = [
                { bg:'rgba(255,255,255,0.07)', label:'#9CA3AF' },
                { bg:'rgba(22,163,74,0.15)',   label:'#86EFAC' },
                { bg:'rgba(230,0,18,0.15)',    label:'#FCA5A5' },
                { bg:'rgba(37,99,235,0.15)',   label:'#93C5FD' },
              ];
              return (
                <div style={{ display:'flex', flexDirection:'column', gap:8, marginTop:4 }}>
                  {sections.map((sec, i) => {
                    const col = sectionColors[i % sectionColors.length];
                    const bullets = sec.body.split('\n').filter(l => l.trim());
                    return (
                      <div key={i} style={{ background: col.bg, borderRadius:8, padding:'9px 11px' }}>
                        <div style={{ fontSize:9, fontWeight:700, color: col.label, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:5 }}>{sec.title}</div>
                        {bullets.map((line, j) => {
                          const clean = line.replace(/^[-•*]\s*/, '').trim();
                          const isBullet = /^[-•*]/.test(line.trim());
                          return (
                            <div key={j} style={{ display:'flex', gap: isBullet ? 6 : 0, alignItems:'flex-start', marginBottom: j < bullets.length - 1 ? 4 : 0 }}>
                              {isBullet && <span style={{ color: col.label, fontSize:10, flexShrink:0, marginTop:1 }}>•</span>}
                              <span style={{ fontSize:11, color:'rgba(255,255,255,0.82)', lineHeight:1.55 }}>{clean}</span>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>

          {/* ── All Questions & Answers ────────────────── */}
          <div style={{ border:'1px solid #E9E5E7', borderRadius:10, overflow:'hidden' }}>
            <button
              onClick={() => setShowAllQA(v => !v)}
              style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 14px', background:'#F9FAFB', border:'none', cursor:'pointer', textAlign:'left' }}
            >
              <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                <span style={{ fontSize:11, fontWeight:700, color:'#374151' }}>All Questions &amp; Answers</span>
                <span style={{ fontSize:10, fontWeight:600, background:'#E9E5E7', color:'#6B7280', borderRadius:20, padding:'1px 7px' }}>{detail.length}</span>
              </div>
              <span style={{ fontSize:12, color:'#9CA3AF', transform: showAllQA ? 'rotate(180deg)' : 'none', display:'inline-block', transition:'transform 0.2s' }}>▼</span>
            </button>
            {showAllQA && (
              <div style={{ maxHeight:400, overflowY:'auto' }}>
                {detail.map((row, i) => {
                  const q   = row.survey_question_text || '—';
                  const ans = row.survey_question_response || '';
                  const txt = row.survey_question_response_text || '';
                  const score = SCORE_MAP[ans];
                  return (
                    <div key={i} style={{ padding:'9px 14px', borderTop:'1px solid #F0EDF0', background: i % 2 === 0 ? '#fff' : '#FAFAFA' }}>
                      <div style={{ fontSize:10, fontWeight:700, color:'#6B7280', marginBottom:3, display:'flex', alignItems:'center', gap:5 }}>
                        <span style={{ width:16, height:16, borderRadius:4, background:'#E9E5E7', color:'#374151', fontSize:8, fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>{i+1}</span>
                        {q}
                      </div>
                      {ans && (
                        <span style={{ fontSize:10, fontWeight:700, display:'inline-block', marginBottom: txt ? 3 : 0,
                          color: score ? scoreColor(score) : '#374151',
                          background: score ? scoreBg(score) : '#F3F4F6',
                          borderRadius:5, padding:'2px 7px'
                        }}>{ans}</span>
                      )}
                      {txt && <div style={{ fontSize:11, color:'#374151', lineHeight:1.55, marginTop:2 }}>{txt}</div>}
                      {!ans && !txt && <span style={{ fontSize:10, color:'#C4C4C4', fontStyle:'italic' }}>No response recorded</span>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div style={{ fontSize:10, color:'#C4C4C4', textAlign:'center', padding:'4px 0 8px' }}>
            FCR ID: {fcr.fcr_id} &nbsp;·&nbsp; {detail.length} question rows
          </div>

        </div>
      </div>
    </>
  );
}

// ── Main Page ──────────────────────────────────────────────────
const PAGE_SIZE = 50;

export default function FCRsPage() {
  const [search, setSearch]       = useState('');
  const [taFilter, setTaFilter]   = useState('');
  const [activeTab, setActiveTab] = useState('pins');
  const [rows, setRows]           = useState([]);
  const [total, setTotal]         = useState(0);
  const [kpis, setKpis]           = useState(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedFcr, setSelectedFcr]   = useState(null);
  const [fcrDetail, setFcrDetail]       = useState([]);
  const [fcrDetailLoading, setFcrDetailLoading] = useState(false);
  const [fcrDetailError, setFcrDetailError]     = useState(null);
  const [fcrDetailStarted, setFcrDetailStarted] = useState(false);
  const [repTrend, setRepTrend]         = useState([]);
  const [repTrendLoading, setRepTrendLoading]   = useState(false);

  // Track in-flight request so we can cancel it when a new one starts (prevents race condition on fast tab/filter switching)
  const inflightRef = useRef(null);

  const fetchData = useCallback(async (q = search, ta = taFilter, tab = 'pins', page = 1, _isRetry = false) => {
    // Cancel any previous in-flight fetch immediately
    if (inflightRef.current) {
      inflightRef.current.cancelled = true;
      inflightRef.current.controller.abort();
    }
    const token = { cancelled: false, controller: new AbortController(), _retried: _isRetry };
    inflightRef.current = token;

    setLoading(true);
    setError(null);

    let timedOut = false;
    const timeoutId = setTimeout(() => { timedOut = true; token.controller.abort(); }, 30000);

    try {
      const offset = (page - 1) * PAGE_SIZE;
      const params = new URLSearchParams({ limit: PAGE_SIZE, offset });
      if (q)  params.set('search', q);
      if (ta) params.set('ta', ta);
      if (tab === 'pins') params.set('pinsOnly', '1');

      const [fcrRes, kpiRes] = await Promise.all([
        fetch(`/api/fcrs?${params}`, { signal: token.controller.signal }),
        fetch('/api/kpis',            { signal: token.controller.signal }),
      ]);
      if (!fcrRes.ok) throw new Error(await fcrRes.text());
      const fcrData = await fcrRes.json();
      const kpiData = await kpiRes.json();

      // Only apply results if this fetch is still the latest one
      if (!token.cancelled) {
        setRows(fcrData.rows);
        setTotal(fcrData.total);
        setKpis(kpiData);
      }
    } catch (e) {
      if (token.cancelled) return; // superseded by a newer fetch — silently discard
      if (e.name === 'AbortError' && timedOut) {
        // Auto-retry once silently before showing error
        if (!token._retried) {
          token._retried = true;
          setTimeout(() => fetchData(q, ta, tab, page, true), 800);
          return;
        }
        setError('Loading timed out — please try again');
      } else if (e.name !== 'AbortError') {
        if (!token._retried) {
          token._retried = true;
          setTimeout(() => fetchData(q, ta, tab, page, true), 800);
          return;
        }
        setError(e.message);
      }
    } finally {
      clearTimeout(timeoutId);
      if (!token.cancelled) setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(search, taFilter, activeTab, 1); }, [fetchData]);

  // Debounce search/TA changes — reset to page 1
  useEffect(() => {
    const t = setTimeout(() => { setCurrentPage(1); fetchData(search, taFilter, activeTab, 1); }, 400);
    return () => clearTimeout(t);
  }, [search, taFilter, activeTab]);

  // Tab switch — reset to page 1 immediately
  const switchTab = (tab) => {
    setActiveTab(tab);
    setCurrentPage(1);
    fetchData(search, taFilter, tab, 1);
  };

  const totalPages = Math.ceil(total / PAGE_SIZE);

  const goToPage = (page) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
    fetchData(search, taFilter, activeTab, page);
    // Scroll table back to top
    document.querySelector('tbody')?.parentElement?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Fetch FCR detail when a row is clicked
  const detailRetryRef = useRef(0);
  useEffect(() => {
    if (!selectedFcr) return;
    detailRetryRef.current = 0;
    setFcrDetail([]);
    setFcrDetailError(null);
    setFcrDetailLoading(true);
    setFcrDetailStarted(true);
    setRepTrend([]);
    setRepTrendLoading(true);

    const doFetch = (attempt = 0) => {
      const ctrl = new AbortController();
      const tid  = setTimeout(() => ctrl.abort(), 25000);

      fetch(`/api/fcr/${encodeURIComponent(selectedFcr.fcr_id)}`, { signal: ctrl.signal })
        .then(r => r.json())
        .then(d => {
          if (d.error) throw new Error(d.error);
          setFcrDetail(Array.isArray(d) ? d : []);
        })
        .catch(e => {
          clearTimeout(tid);
          // Auto-retry once silently
          if (attempt < 1) {
            setTimeout(() => doFetch(attempt + 1), 800);
          } else {
            setFcrDetailError(e.name === 'AbortError' ? 'Loading timed out — please try again' : e.message);
            setFcrDetailLoading(false);
          }
          return; // skip finally below for aborted
        })
        .finally(() => { clearTimeout(tid); setFcrDetailLoading(false); });
    };

    doFetch(0);

    fetch(`/api/rep-trend/${encodeURIComponent(selectedFcr.coachee_wwid)}`)
      .then(r => r.json()).then(d => { setRepTrend(Array.isArray(d) ? d : []); })
      .catch(() => {})
      .finally(() => setRepTrendLoading(false));
  }, [selectedFcr]);

  const TA_PILLS = ['', 'IMM', 'ONC', 'NS', 'SCG'];

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:20 }}>

      {/* FCR Detail Panel */}
      {selectedFcr && !fcrDetailLoading && fcrDetail.length > 0 && (
        <FCRDetailPanel
          fcr={selectedFcr}
          detail={fcrDetail}
          trend={repTrend}
          trendLoading={repTrendLoading}
          onClose={() => { setSelectedFcr(null); setFcrDetailStarted(false); }}
        />
      )}
      {selectedFcr && fcrDetail.length === 0 && (fcrDetailLoading || fcrDetailError || fcrDetailStarted) && (
        <>
          <div onClick={() => { setSelectedFcr(null); setFcrDetailStarted(false); }} style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.25)', zIndex:400 }} />
          <div style={{ position:'fixed', top:0, right:0, height:'100vh', width:540, zIndex:401, background:'#fff', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:12, padding:24 }}>
            {fcrDetailLoading ? (
              <>
                <RefreshCw size={20} color="#E60012" style={{ animation:'spin 1s linear infinite' }} />
                <span style={{ fontSize:13, color:'#9CA3AF' }}>Loading FCR detail…</span>
              </>
            ) : fcrDetailError ? (
              <>
                <span style={{ fontSize:13, color:'#E60012', textAlign:'center' }}>⚠ {fcrDetailError}</span>
                <button
                  onClick={() => setSelectedFcr({ ...selectedFcr })}
                  style={{ fontSize:12, padding:'6px 14px', borderRadius:6, border:'1px solid #E60012', background:'#fff', color:'#E60012', cursor:'pointer' }}
                >Retry</button>
                <button onClick={() => { setSelectedFcr(null); setFcrDetailStarted(false); }} style={{ fontSize:11, color:'#9CA3AF', background:'none', border:'none', cursor:'pointer' }}>Close</button>
              </>
            ) : (
              <>
                <span style={{ fontSize:13, color:'#9CA3AF' }}>No detail found for this FCR.</span>
                <button onClick={() => { setSelectedFcr(null); setFcrDetailStarted(false); }} style={{ fontSize:11, color:'#9CA3AF', background:'none', border:'none', cursor:'pointer' }}>Close</button>
              </>
            )}
          </div>
        </>
      )}

      {/* ── HERO CARD ── */}
      <div className="dash-card">
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:20, flexWrap:'wrap', gap:12 }}>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <div style={{ width:40, height:40, borderRadius:10, background:'#E11937', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <FileText size={20} color="#fff" />
            </div>
            <div>
              <div className="section-eyebrow" style={{ color:'#7C3AED' }}>MSL / VESE · FBMS Coaching · Live</div>
              <div style={{ fontSize:22, fontWeight:800, color:'#1B1F2A', marginTop:2, letterSpacing:'-0.3px' }}>MSL Field Coaching Reports</div>
            </div>
          </div>
          <div className="sync-pill">
            <CheckCircle2 size={12} color="#16A34A" />
            Live from Redshift · ODP
          </div>
        </div>

        {/* KPI row */}
        <div className="kpi-grid">
          <KpiCard
            label="Total FCRs" sublabel="in current view"
            value={kpis ? Number(kpis.total_fcrs).toLocaleString() : '—'}
            sub="field coaching reports"
            accent="red" Icon={FileText}
          />
          <KpiCard
            label="Published" sublabel="of total FCRs"
            value={kpis ? `${kpis.submitted_pct ?? 0}%` : '—'}
            sub={kpis ? `${Number(kpis.submitted).toLocaleString()} published` : '—'}
            accent="green" Icon={CheckCircle2}
          />
          <KpiCard
            label="Avg Days to Publish" sublabel="created → published"
            value={kpis ? (kpis.avg_days_to_submit ?? '—') : '—'}
            sub="days, on average"
            accent="gray" Icon={Clock}
          />
          <KpiCard
            label="Total Reps" sublabel="coachees in dataset"
            value={kpis ? Number(kpis.total_reps).toLocaleString() : '—'}
            sub="unique reps coached"
            accent="redhl" Icon={AlertTriangle} highlighted
          />
        </div>
      </div>

      {/* ── FILTER ROW ── */}
      <div className="filter-row">
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <span style={{ fontSize:12, fontWeight:600, color:'#1B1F2A', display:'flex', alignItems:'center', gap:4 }}>
            <ChevronDown size={13} /> TA
          </span>
          {TA_PILLS.map(t => (
            <button
              key={t || 'all'}
              className="filter-pill"
              onClick={() => setTaFilter(t)}
              style={{
                background: taFilter === t ? '#E11937' : undefined,
                color:      taFilter === t ? '#fff'    : undefined,
                borderColor:taFilter === t ? '#E11937' : undefined,
              }}
            >
              {t || 'All TAs'}
            </button>
          ))}
        </div>
        <span style={{ fontSize:11, color:'#6B7280' }}>
          Showing <strong>{rows.length}</strong> of <strong>{total.toLocaleString()}</strong> FCRs
        </span>
      </div>

      {/* ── MSL badge ── */}
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, background:'#EDE9FE', border:'1px solid #C4B5FD', borderRadius:20, padding:'5px 14px' }}>
          <span style={{ fontSize:10 }}>⬡</span>
          <span style={{ fontSize:12, fontWeight:700, color:'#5B21B6' }}>MSL / VESE Field Coaching Reports (FBMS)</span>
          {!loading && <span style={{ fontSize:10, fontWeight:800, background:'#7C3AED', color:'#fff', borderRadius:10, padding:'1px 8px' }}>{total.toLocaleString()}</span>}
        </div>
      </div>

      {/* ── TABLE CARD ── */}
      <div style={{ background:'#fff', border:'1px solid #E8E5E8', borderRadius:16, boxShadow:'0 1px 4px rgba(0,0,0,0.04)', overflow:'hidden' }}>

        {/* Table header */}
        <div style={{ padding:'18px 22px 12px', display:'flex', alignItems:'flex-start', justifyContent:'space-between', flexWrap:'wrap', gap:12, borderBottom:'1px solid #F0EDF0' }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <FileText size={15} color={ activeTab === 'pins' ? '#7C3AED' : '#E11937' } />
              <span style={{ fontSize:14, fontWeight:800, color:'#1B1F2A' }}>MSL / VESE Field Coaching Reports</span>
              {loading
                ? <span style={{ fontSize:10, color:'#9CA3AF' }}><RefreshCw size={11} style={{ animation:'spin 1s linear infinite' }} /> Loading…</span>
                : <span style={{ fontSize:10, fontWeight:700,
                    color: activeTab === 'pins' ? '#7C3AED' : '#E11937',
                    background: activeTab === 'pins' ? '#EDE9FE' : '#FDECEE',
                    border: `1px solid ${activeTab === 'pins' ? '#C4B5FD' : '#F5C6CE'}`,
                    borderRadius:10, padding:'1px 8px'
                  }}>
                    {rows.length} shown · {total.toLocaleString()} total
                  </span>
              }
            </div>
            <div style={{ fontSize:11, color:'#9CA3AF', marginTop:4 }}>
              {activeTab === 'pins'
                ? <>MSL/VESE Field Coaching Reports with PINS framework — click a row to view &amp; score PINS.</>  
                : <>Live data from <code>odp.dp_cust_pers_engagement_dly</code> — click a row for full FCR detail.</> }
            </div>
          </div>
          {/* Search */}
          <div style={{ position:'relative', flexShrink:0 }}>
            <Search size={13} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'#9CA3AF' }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search name, FCR ID…"
              aria-label="Search FCRs"
              style={{
                height:34, paddingLeft:30, paddingRight:12,
                border:'1px solid #E8E5E8', borderRadius:20,
                fontSize:12, fontFamily:'inherit', color:'#1B1F2A',
                background:'#FAFAFA', outline:'none', width:240,
                transition:'border-color 0.15s',
              }}
              onFocus={e => e.target.style.borderColor = '#E11937'}
              onBlur={e => e.target.style.borderColor = '#E8E5E8'}
            />
          </div>
        </div>

        {/* Error state */}
        {error && (
          <div style={{ padding:'20px 22px', display:'flex', alignItems:'center', gap:12 }}>
            <span style={{ color:'#E11937', fontSize:13 }}>⚠ {error}</span>
            <button
              onClick={() => fetchData(search, taFilter)}
              style={{ fontSize:12, padding:'4px 12px', borderRadius:6, border:'1px solid #E11937', background:'#fff', color:'#E11937', cursor:'pointer', display:'flex', alignItems:'center', gap:5 }}
            >
              <RefreshCw size={11} /> Retry
            </button>
          </div>
        )}

        {/* Table */}
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
            <thead>
              <tr style={{ background:'#FAFAFA' }}>
                {(activeTab === 'pins'
                  ? ['FCR ID','Coachee','Role / Title','TA','Coaching Date','Days','Status','Form']
                  : ['FCR ID','Coachee','Role / Title','TA','Coaching Date','Days','Status','Territory']
                ).map(h => (
                  <th key={h} style={{
                    padding:'9px 16px', textAlign:'left',
                    fontSize:10, fontWeight:700, textTransform:'uppercase',
                    letterSpacing:'0.05em', color:'#9CA3AF',
                    borderBottom:'1px solid #F0EDF0', whiteSpace:'nowrap',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {!loading && rows.map((row) => {
                const ta = TA_COLORS[row.ta] || { bg:'#F1F5F9', color:'#475569', label: row.ta };
                const st = STATUS[row.status] || STATUS['Draft'];
                return (
                  <tr key={row.fcr_id}
                    style={{ borderBottom:'1px solid #F9F7F8', cursor:'pointer', transition:'background 0.1s' }}
                    onClick={() => setSelectedFcr(row)}
                    onMouseEnter={e => e.currentTarget.style.background = '#FDF8F9'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    {/* FCR ID */}
                    <td style={{ padding:'11px 16px', whiteSpace:'nowrap' }}>
                      <span style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
                        <span style={{ width:7, height:7, borderRadius:'50%', background:st.dot, flexShrink:0, display:'inline-block' }} />
                        <span style={{ fontSize:11, fontWeight:600, color:'#1B1F2A', fontFamily:'monospace' }}>
                          {row.fcr_id.slice(-8).toUpperCase()}
                        </span>
                        {activeTab === 'pins' && (
                          <span style={{ fontSize:8, fontWeight:800, background:'#EDE9FE', color:'#6D28D9', borderRadius:4, padding:'1px 5px' }}>PINS</span>
                        )}
                      </span>
                    </td>
                    {/* Coachee */}
                    <td style={{ padding:'11px 16px', whiteSpace:'nowrap' }}>
                      <span style={{ display:'inline-flex', alignItems:'center', gap:7 }}>
                        <Avatar initials={initials(row.coachee_first, row.coachee_last)} />
                        <span>{row.coachee_first} {row.coachee_last}</span>
                      </span>
                    </td>
                    {/* Role */}
                    <td style={{ padding:'11px 16px', color:'#6B7280', maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {row.coachee_role || '—'}
                    </td>
                    {/* TA */}
                    <td style={{ padding:'11px 16px', whiteSpace:'nowrap' }}>
                      <span style={{ fontSize:10, fontWeight:600, background:ta.bg, color:ta.color, borderRadius:10, padding:'2px 8px' }}>
                        {ta.label}
                      </span>
                    </td>
                    {/* Date */}
                    <td style={{ padding:'11px 16px', color:'#6B7280', whiteSpace:'nowrap' }}>{formatDate(row.coaching_date)}</td>
                    {/* Days */}
                    <td style={{ padding:'11px 16px', whiteSpace:'nowrap', textAlign:'center' }}>
                      {(() => {
                        const d = row.days_to_submit;
                        if (d == null) return <span style={{ color:'#9CA3AF' }}>—</span>;
                        if (d === 0) return <span style={{ color:'#15803D', fontWeight:700, fontSize:11 }}>Same day</span>;
                        const color = d <= 3 ? '#15803D' : d <= 7 ? '#D97706' : '#E60012';
                        return <span style={{ color, fontWeight:700, fontSize:11 }}>{d}d</span>;
                      })()}
                    </td>
                    {/* Status */}
                    <td style={{ padding:'11px 16px', whiteSpace:'nowrap' }}><StatusBadge status={row.status} /></td>
                    {/* Territory or Form */}
                    <td style={{ padding:'11px 16px', color:'#6B7280', maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {activeTab === 'pins'
                        ? <span title={row.engagement_title} style={{ fontSize:10, fontWeight:600, background:'#F5F3FF', color:'#6D28D9', borderRadius:6, padding:'2px 7px' }}>
                            {(row.engagement_title || '—')
                              .replace(/Field Coaching Report/i, 'FCR')
                              .replace(/- 2026/g, '')
                              .trim()}
                          </span>
                        : row.territory || row.district || row.region || '—'
                      }
                    </td>
                  </tr>
                );
              })}
              {!loading && rows.length === 0 && !error && (
                <tr>
                  <td colSpan={8} style={{ padding:'32px 16px', textAlign:'center', color:'#C9CDD4', fontSize:13 }}>
                    {activeTab === 'pins'
                      ? 'No PINS FCRs found — try adjusting the TA filter or time range.'
                      : 'No FCRs match your search.'}
                  </td>
                </tr>
              )}
              {loading && (
                <tr>
                  <td colSpan={8} style={{ padding:'32px 16px', textAlign:'center', color:'#9CA3AF', fontSize:13 }}>
                    <RefreshCw size={14} style={{ marginRight:6, verticalAlign:'middle' }} />
                    Loading from Redshift…
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div style={{ padding:'12px 22px', borderTop:'1px solid #F0EDF0', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:8 }}>
          <span style={{ fontSize:11, color:'#9CA3AF' }}>
            Showing <strong style={{ color:'#1B1F2A' }}>{(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, total)}</strong> of <strong style={{ color:'#1B1F2A' }}>{total.toLocaleString()}</strong> FCRs
            &nbsp;·&nbsp; Page {currentPage} of {totalPages || 1}
          </span>
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <button
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage <= 1 || loading}
              style={{
                padding:'5px 14px', borderRadius:8, border:'1px solid #E8E5E8',
                background: currentPage <= 1 || loading ? '#F9FAFB' : '#fff',
                color: currentPage <= 1 || loading ? '#C9CDD4' : '#1B1F2A',
                cursor: currentPage <= 1 || loading ? 'not-allowed' : 'pointer',
                fontSize:12, fontWeight:600, display:'flex', alignItems:'center', gap:4,
                transition:'all 0.15s',
              }}
            >
              ← Prev
            </button>

            {/* Page number pills — show up to 5 around current page */}
            <div style={{ display:'flex', gap:4 }}>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(p => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                .reduce((acc, p, idx, arr) => {
                  if (idx > 0 && p - arr[idx - 1] > 1) acc.push('...');
                  acc.push(p);
                  return acc;
                }, [])
                .map((p, i) =>
                  p === '...' ? (
                    <span key={`ellipsis-${i}`} style={{ fontSize:11, color:'#9CA3AF', padding:'0 2px', lineHeight:'28px' }}>…</span>
                  ) : (
                    <button
                      key={p}
                      onClick={() => goToPage(p)}
                      disabled={loading}
                      style={{
                        width:28, height:28, borderRadius:7, border:'1px solid',
                        borderColor: p === currentPage ? '#E11937' : '#E8E5E8',
                        background:  p === currentPage ? '#E11937' : '#fff',
                        color:       p === currentPage ? '#fff'    : '#6B7280',
                        fontSize:11, fontWeight:700, cursor: loading ? 'not-allowed' : 'pointer',
                        transition:'all 0.15s',
                      }}
                    >
                      {p}
                    </button>
                  )
                )
              }
            </div>

            <button
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage >= totalPages || loading}
              style={{
                padding:'5px 14px', borderRadius:8, border:'1px solid #E8E5E8',
                background: currentPage >= totalPages || loading ? '#F9FAFB' : '#E11937',
                color: currentPage >= totalPages || loading ? '#C9CDD4' : '#fff',
                cursor: currentPage >= totalPages || loading ? 'not-allowed' : 'pointer',
                fontSize:12, fontWeight:600, display:'flex', alignItems:'center', gap:4,
                transition:'all 0.15s',
              }}
            >
              Next →
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}


