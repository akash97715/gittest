import { useState, useEffect } from 'react';
import {
  ComposedChart, Bar, Line, LineChart,
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Info, TrendingUp, BarChart2, ChevronRight, ChevronUp, Sparkles, X } from 'lucide-react';

// ── AI insight text renderer ──────────────────────────────────
function renderInline(text) {
  const parts = text.split(/\*\*(.*?)\*\*/g);
  return parts.map((part, i) => i % 2 === 1 ? <strong key={i}>{part}</strong> : part);
}
function AiInsightText({ text }) {
  if (!text) return null;
  return (
    <div style={{ fontSize: 12, lineHeight: 1.75, color: '#374151' }}>
      {text.split('\n').map((line, i) => {
        if (!line.trim()) return <div key={i} style={{ height: 6 }} />;
        if (line.startsWith('**') && line.endsWith('**')) {
          return (
            <div key={i} style={{ fontWeight: 800, color: '#1B1F2A', fontSize: 13, marginTop: 16, marginBottom: 5,
              paddingBottom: 5, borderBottom: '1px solid #F3F0F1' }}>
              {line.replace(/\*\*/g, '')}
            </div>
          );
        }
        if (line.startsWith('- ') || line.startsWith('\u2022 ')) {
          return (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'flex-start' }}>
              <span style={{ color: '#E11937', flexShrink: 0, fontWeight: 700, marginTop: 1 }}>•</span>
              <span>{renderInline(line.slice(2))}</span>
            </div>
          );
        }
        return <div key={i} style={{ marginBottom: 4 }}>{renderInline(line)}</div>;
      })}
    </div>
  );
}

const scoreLabel = s => s >= 2.5 ? 'Advanced' : s >= 1.5 ? 'Skilled' : 'Awareness';

const PINS_LINES = [
  { key: 'P', label: 'Planning for Perspective',    color: '#E11937' },
  { key: 'I', label: 'Investigate Issues',           color: '#F08090' },
  { key: 'N', label: 'Navigate and Negotiate Needs', color: '#F4892A' },
  { key: 'S', label: 'Secure Action',                color: '#F4B252' },
];

// ── Custom dot ────────────────────────────────────────────────
const ColorDot = ({ cx, cy, stroke }) => (
  <circle cx={cx} cy={cy} r={3.5} fill="#fff" stroke={stroke} strokeWidth={2} />
);

// ── Tooltips ──────────────────────────────────────────────────
const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 10, padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)', fontSize: 11, minWidth: 160 }}>
      <div style={{ fontWeight: 700, color: '#1B1F2A', marginBottom: 6 }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
          <span style={{ width: 8, height: 8, borderRadius: p.name === 'fcrs' ? 2 : '50%', background: p.color, display: 'inline-block', flexShrink: 0 }} />
          <span style={{ color: '#6B7280' }}>
            {p.name === 'fcrs' ? 'FCRs coached' : p.name === 'pins' ? 'PINS proficiency' : 'Skill proficiency'}:
          </span>
          <span style={{ fontWeight: 700, color: '#1B1F2A' }}>{p.name === 'fcrs' ? p.value : p.value.toFixed(2)}</span>
        </div>
      ))}
    </div>
  );
};

const DrillTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 10, padding: '10px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.08)', fontSize: 11, minWidth: 170 }}>
      <div style={{ fontWeight: 700, color: '#1B1F2A', marginBottom: 6 }}>{label}</div>
      {payload.map(p => {
        const meta = PINS_LINES.find(l => l.key === p.dataKey);
        return (
          <div key={p.dataKey} style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: meta?.color, display: 'inline-block', flexShrink: 0 }} />
            <span style={{ color: '#6B7280' }}>{p.dataKey}:</span>
            <span style={{ fontWeight: 700, color: '#1B1F2A' }}>{p.value.toFixed(2)}</span>
          </div>
        );
      })}
    </div>
  );
};

// ── Sparkline card ────────────────────────────────────────────
function ChangeSummaryCard({ letter, title, score, sublabel, change, positive, data, accent, months }) {
  return (
    <div style={{
      background: positive ? '#fff' : '#FDF5F6',
      border: positive ? '1px solid #E9E5E7' : '1.5px solid #F5C6CE',
      borderRadius: 14, padding: '16px 16px 12px',
      flex: 1, minWidth: 0,
      boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      transition: 'transform 0.15s, box-shadow 0.15s',
    }}
    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 6px 18px rgba(0,0,0,0.08)'; }}
    onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)'; }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#1B1F2A' }}>{letter} · {title}</span>
        <span style={{
          fontSize: 10, fontWeight: 700,
          background: positive ? '#EDFAF3' : '#FDECEE',
          color: positive ? '#3FA46A' : '#E11937',
          border: `1px solid ${positive ? '#A7DDB8' : '#F5C6CE'}`,
          borderRadius: 10, padding: '2px 7px', flexShrink: 0,
        }}>{change}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginBottom: 2 }}>
        <span style={{ fontSize: 32, fontWeight: 800, color: '#1B1F2A', lineHeight: 1 }}>{score}</span>
      </div>
      <div style={{ fontSize: 10, color: '#9CA3AF', marginBottom: 12 }}>{sublabel}</div>
      {/* Mini sparkline */}
      <ResponsiveContainer width="100%" height={44}>
        <LineChart data={data} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
          <Line type="monotone" dataKey="v" stroke={accent} strokeWidth={2} dot={{ r: 2.5, fill: accent, strokeWidth: 0 }} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
        {(months || []).map(m => (
          <span key={m} style={{ fontSize: 8, color: '#C9CDD4' }}>{m}</span>
        ))}
      </div>
    </div>
  );
}

// ── Drill-down expanded panel ──────────────────────────────────
function DrilldownPanel({ pinsTrend }) {
  const [tab, setTab] = useState('pins');

  // Compute per-section sparkline cards from real data
  const CARD_ORDER = [
    { sec: 'N', label: 'Navigate and Negotiate Needs', accent: '#F4892A' },
    { sec: 'S', label: 'Secure Action',                accent: '#F4B252' },
    { sec: 'I', label: 'Investigate Issues',            accent: '#F08090' },
    { sec: 'P', label: 'Planning for Perspective',      accent: '#E11937' },
  ];
  const months = (pinsTrend || []).map(r => r.month.split(' ')[0]);
  const cards = CARD_ORDER.map(({ sec, label, accent }) => {
    const vals = (pinsTrend || []).map(r => r[sec]).filter(v => v != null);
    if (vals.length === 0) return { sec, label, accent, score: '-', change: '-', positive: true, data: [], sublabel: 'No data' };
    const first = vals[0], last = vals[vals.length - 1];
    const diff = parseFloat((last - first).toFixed(2));
    return {
      sec, label, accent,
      score: last.toFixed(1),
      change: diff >= 0 ? `+${Math.abs(diff).toFixed(2)}` : `-${Math.abs(diff).toFixed(2)}`,
      positive: diff >= 0,
      data: vals.map(v => ({ v })),
      sublabel: `now - ${scoreLabel(last)}`,
    };
  });
  cards.sort((a, b) => parseFloat(a.change) - parseFloat(b.change));

  return (
    <div style={{ borderTop: '1px solid #F0EAEc', marginTop: 0, paddingTop: 20, animation: 'fadeInUp 0.25s ease both' }}>

      {/* Toggle */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: '#6B7280' }}>Break down the score by:</span>
        <div style={{ display: 'flex', border: '1px solid #E9E5E7', borderRadius: 20, overflow: 'hidden' }}>
          {[['pins', 'By PINS'], ['skill', 'By skill']].map(([key, label]) => (
            <button key={key} onClick={() => setTab(key)} style={{
              padding: '5px 16px', fontSize: 11, fontWeight: 700,
              border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              background: tab === key ? '#E11937' : '#fff',
              color: tab === key ? '#fff' : '#6B7280',
              transition: 'all 0.15s',
            }}>{label}</button>
          ))}
        </div>
      </div>

      {/* Main multi-line chart */}
      <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 14, padding: '20px 20px 12px', marginBottom: 20 }}>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={pinsTrend || []} margin={{ top: 8, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#F0EDF0" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
            <YAxis domain={[1, 4]} ticks={[1, 1.75, 2.5, 3.25, 4]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
            <Tooltip content={<DrillTooltip />} />
            {PINS_LINES.map(({ key, color }) => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={color}
                strokeWidth={2.5}
                dot={<ColorDot stroke={color} />}
                activeDot={{ r: 5, fill: color, stroke: '#fff', strokeWidth: 2 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>

        {/* Legend */}
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 16, marginTop: 12 }}>
          {PINS_LINES.map(({ key, label, color }) => (
            <span key={key} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6B7280' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                <span style={{ width: 14, height: 2.5, background: color, borderRadius: 2, display: 'inline-block' }} />
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff', border: `2px solid ${color}`, display: 'inline-block' }} />
              </span>
              <strong style={{ color }}>{key}</strong> · {label}
            </span>
          ))}
        </div>

        {/* Footnote */}
        <div style={{ textAlign: 'center', fontSize: 10, color: '#C9CDD4', marginTop: 10 }}>
          Scale 1–4 (Awareness → Skilled → Advanced → Expert). One line per PINS section.
        </div>
      </div>

      {/* Section: Largest Changes */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <div style={{ width: 3, height: 16, background: '#E11937', borderRadius: 2, flexShrink: 0 }} />
            <span style={{ fontSize: 13, fontWeight: 800, color: '#1B1F2A' }}>Largest Proficiency Changes — by PINS area</span>
            <Info size={12} color="#C9CDD4" />
          </div>
          <button style={{ border: '1px solid #E9E5E7', background: '#fff', borderRadius: 7, width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Sparkles size={12} color="#9CA3AF" />
          </button>
        </div>

        {/* 4 summary cards */}
        <div className="tsg-pins-grid">
          {cards.map(c => (
            <ChangeSummaryCard
              key={c.sec}
              letter={c.sec}
              title={c.label}
              score={c.score}
              sublabel={c.sublabel}
              change={c.change}
              positive={c.positive}
              data={c.data}
              accent={c.accent}
              months={months}
            />
          ))}
        </div>

        <div style={{ fontSize: 10, color: '#C9CDD4', marginTop: 10 }}>
          Scale 1–4 (Awareness → Skilled → Advanced → Expert). Sorted with the steepest declines first.
        </div>
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────
export default function SkillProficiencyTrendView() {
  const [drillOpen, setDrillOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [trendData, setTrendData] = useState([]);
  const [pinsTrend, setPinsTrend] = useState([]);
  const [aiOpen,    setAiOpen]    = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiText,    setAiText]    = useState('');

  async function handleAiInsight() {
    setAiOpen(true);
    if (aiText) return;
    setAiLoading(true);
    try {
      const r = await fetch('/api/skill-trend-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trendData, pinsTrend, latestSkill, skillChange, improving }),
      });
      const j = await r.json();
      setAiText(j.insight || j.error || 'No insights available.');
    } catch (e) {
      setAiText('Failed to generate insights: ' + e.message);
    } finally {
      setAiLoading(false);
    }
  }

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch('/api/capability').then(r => r.json()),
      fetch('/api/pins-trend').then(r => r.json()),
    ]).then(([cap, pins]) => {
      const pinsMap = {};
      (pins.trend || []).forEach(r => { pinsMap[r.month] = r; });
      const merged = (cap.trend || []).map(r => {
        const pm = pinsMap[r.month];
        const parts = pm ? ['P','I','N','S'].map(k => pm[k]).filter(v => v != null) : [];
        return {
          month: r.month,
          fcrs: parseInt(r.fcrs) || 0,
          skill: r.avg_score != null ? parseFloat(r.avg_score) : null,
          pins: parts.length ? parseFloat((parts.reduce((a, b) => a + b, 0) / parts.length).toFixed(2)) : null,
        };
      });
      setTrendData(merged);
      setPinsTrend(pins.trend || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const skillVals = trendData.map(r => r.skill).filter(v => v != null);
  const latestSkill = skillVals.length ? skillVals[skillVals.length - 1] : null;
  const firstSkill  = skillVals.length ? skillVals[0] : null;
  const skillChange = (latestSkill != null && firstSkill != null) ? (latestSkill - firstSkill) : null;
  const improving   = skillChange == null || skillChange >= 0;

  return (
    <div style={{
      background: '#FDF1F3',
      border: '1.5px solid #F5C6CE',
      borderRadius: 18,
      padding: '26px 26px 22px',
      boxShadow: '0 2px 12px rgba(225,25,55,0.06)',
      animation: 'fadeInUp 0.3s ease both',
    }}>

      {/* ── Section header ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 3, height: 18, background: '#E11937', borderRadius: 2, flexShrink: 0 }} />
          <span style={{ fontSize: 15, fontWeight: 800, color: '#1B1F2A' }}>
            Skill Proficiency vs. Coaching Volume
          </span>
          <Info size={13} color="#C9CDD4" />
          <span style={{ fontSize: 10, fontWeight: 700, color: '#E11937', border: '1px solid #E11937', borderRadius: 10, padding: '1px 8px' }}>All time</span>
        </div>
        <button
          onClick={handleAiInsight}
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: aiOpen ? '#FDECEE' : '#fff',
            border: '1px solid #E11937',
            borderRadius: 20, padding: '5px 13px',
            fontSize: 11, fontWeight: 700, color: '#E11937',
            cursor: 'pointer', fontFamily: 'inherit', transition: 'background 0.15s',
            boxShadow: '0 1px 4px rgba(225,25,55,0.08)',
          }}
        >
          <Sparkles size={12} color="#E11937" />
          AI INSIGHTS
        </button>
      </div>

      {/* ── Green insight banner ── */}
      <div style={{ background: improving ? '#EEF9F1' : '#FDF5F6', border: `1px solid ${improving ? '#A7DDB8' : '#F5C6CE'}`, borderRadius: 12, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 22 }}>
        <div style={{ width: 36, height: 36, borderRadius: 10, background: improving ? '#3FA46A' : '#E11937', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <TrendingUp size={18} color="#fff" />
        </div>
        {loading ? (
          <div style={{ fontSize: 13, color: '#6B7280' }}>Loading trend data...</div>
        ) : (
          <div>
            <div style={{ fontSize: 13, fontWeight: 800, color: improving ? '#1B5E35' : '#7F1D22' }}>
              {improving ? 'Skills are improving' : 'Skills need attention'}
            </div>
            <div style={{ fontSize: 11, color: improving ? '#3D7A52' : '#9B1C2A', marginTop: 2 }}>
              {skillChange != null
                ? <>Average proficiency moved <strong>{skillChange >= 0 ? '+' : ''}{skillChange.toFixed(2)}</strong> across the period
                  {latestSkill != null && <> &mdash; now <strong>{latestSkill.toFixed(2)}/4</strong> ({scoreLabel(latestSkill)})</>}.</>
                : <>No competency trend data available for this period.</>}
            </div>
          </div>
        )}
      </div>

      {/* ── Main chart ── */}
      <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 14, padding: '20px 20px 12px', marginBottom: 16 }}>
        <ResponsiveContainer width="100%" height={280}>
          <ComposedChart data={trendData} margin={{ top: 8, right: 50, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#F0EDF0" vertical={false} />
            <YAxis yAxisId="fcr" orientation="left" ticks={[0, 50, 100, 150, 200]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="prof" orientation="right" domain={[1, 4]} ticks={[1, 1.75, 2.5, 3.25, 4]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false}
              label={{ value: 'Proficiency (1–4)', angle: 90, position: 'insideRight', offset: 14, style: { fontSize: 9, fill: '#C9CDD4', fontFamily: 'Inter, system-ui, sans-serif' } }}
            />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
            <Tooltip content={<ChartTooltip />} />
            <Bar yAxisId="fcr" dataKey="fcrs" fill="rgba(225,25,55,0.12)" stroke="#E11937" strokeWidth={1} radius={[6, 6, 0, 0]} maxBarSize={52} />
            <Line yAxisId="prof" type="monotone" dataKey="pins" stroke="#E11937" strokeWidth={2.5}
              dot={<ColorDot stroke="#E11937" />} activeDot={{ r: 6, fill: '#E11937', stroke: '#fff', strokeWidth: 2 }} />
            <Line yAxisId="prof" type="monotone" dataKey="skill" stroke="#F08090" strokeWidth={2} strokeDasharray="5 4"
              dot={<ColorDot stroke="#F08090" />} activeDot={{ r: 6, fill: '#F08090', stroke: '#fff', strokeWidth: 2 }} />
          </ComposedChart>
        </ResponsiveContainer>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20, marginTop: 10, flexWrap: 'wrap' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6B7280' }}>
            <span style={{ width: 12, height: 12, borderRadius: 3, background: 'rgba(225,25,55,0.18)', border: '1px solid #E11937', display: 'inline-block' }} />
            FCRs coached
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6B7280' }}>
            <span style={{ width: 18, height: 2.5, background: '#E11937', borderRadius: 2, display: 'inline-block' }} />
            PINS proficiency
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: '#6B7280' }}>
            <span style={{ width: 18, height: 0, display: 'inline-block', borderTop: '2.5px dashed #F08090' }} />
            Skill proficiency
          </span>
        </div>

        <div style={{ textAlign: 'center', fontSize: 10, color: '#C9CDD4', marginTop: 10, lineHeight: 1.6 }}>
          Bars = FCRs coached per month (left axis). Lines = average PINS &amp; skill proficiency 1–4 (right axis: Awareness → Skilled → Advanced → Expert).
        </div>
      </div>

      {/* ── Drill-in row ── */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => setDrillOpen(o => !o)}
        onKeyDown={e => e.key === 'Enter' && setDrillOpen(o => !o)}
        aria-expanded={drillOpen}
        aria-label="Drill into movement by PINS area and skill"
        style={{
          background: drillOpen ? '#FDF1F3' : '#fff',
          border: drillOpen ? '1.5px solid #F5C6CE' : '1px solid #E9E5E7',
          borderRadius: drillOpen ? '12px 12px 0 0' : 12,
          padding: '14px 18px',
          display: 'flex', alignItems: 'center', gap: 14,
          cursor: 'pointer', transition: 'background 0.15s, box-shadow 0.15s',
          boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
        }}
        onMouseEnter={e => { if (!drillOpen) { e.currentTarget.style.background = '#FDF1F3'; e.currentTarget.style.boxShadow = '0 4px 14px rgba(225,25,55,0.08)'; } }}
        onMouseLeave={e => { if (!drillOpen) { e.currentTarget.style.background = '#fff'; e.currentTarget.style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)'; } }}
      >
        <div style={{ width: 38, height: 38, borderRadius: '50%', background: '#FDECEE', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <BarChart2 size={17} color="#E11937" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#1B1F2A' }}>Drill into movement by PINS area &amp; skill</div>
          <div style={{ fontSize: 11, color: '#6B7280', marginTop: 2 }}>See which sections and skills are moving most — and which are slipping</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexShrink: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#E11937' }}>{drillOpen ? 'Hide' : 'Show'}</span>
          {drillOpen
            ? <ChevronUp size={16} color="#E11937" />
            : <ChevronRight size={16} color="#E11937" />
          }
        </div>
      </div>

      {/* ── Expanded panel ── */}
      {drillOpen && (
        <div style={{
          background: '#FDFBFB',
          border: '1.5px solid #F5C6CE',
          borderTop: 'none',
          borderRadius: '0 0 12px 12px',
          padding: '20px 20px 18px',
        }}>
          <DrilldownPanel pinsTrend={pinsTrend} />
        </div>
      )}

      {/* ═══ AI INSIGHTS SIDE PANEL ═══ */}
      {aiOpen && (
        <>
          <div
            onClick={() => setAiOpen(false)}
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.18)', zIndex: 999 }}
          />
          <div style={{
            position: 'fixed', right: 0, top: 0, bottom: 0, width: 400,
            background: '#fff', zIndex: 1000,
            boxShadow: '-6px 0 32px rgba(0,0,0,0.14)',
            display: 'flex', flexDirection: 'column',
            animation: 'slideInRight 0.22s ease both',
          }}>
            <div style={{
              padding: '16px 20px', borderBottom: '1px solid #E9E5E7',
              display: 'flex', alignItems: 'center', gap: 10,
              background: '#FDECEE',
            }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: '#E11937', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Sparkles size={15} color="#fff" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#1B1F2A' }}>AI Skill Trend Insights</div>
                <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>Powered by Azure OpenAI · Last 12 months</div>
              </div>
              <button
                onClick={() => setAiOpen(false)}
                style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#6B7280', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 6 }}
              >
                <X size={16} />
              </button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
              {aiLoading ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, paddingTop: 60 }}>
                  <div style={{
                    width: 36, height: 36, border: '3px solid #E11937',
                    borderTopColor: 'transparent', borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite',
                  }} />
                  <div style={{ fontSize: 13, color: '#6B7280', textAlign: 'center' }}>Analyzing skill trends…</div>
                  <div style={{ fontSize: 11, color: '#C9CDD4', textAlign: 'center' }}>This may take a moment</div>
                </div>
              ) : (
                <AiInsightText text={aiText} />
              )}
            </div>
            {!aiLoading && aiText && (
              <div style={{ padding: '12px 20px', borderTop: '1px solid #E9E5E7', background: '#FAFAFA', display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  onClick={() => { setAiText(''); handleAiInsight(); }}
                  style={{ fontSize: 11, fontWeight: 600, color: '#E11937', border: '1px solid #E11937', borderRadius: 8, padding: '5px 14px', background: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}
                >
                  <Sparkles size={11} color="#E11937" /> Regenerate
                </button>
              </div>
            )}
          </div>
        </>
      )}

    </div>
  );
}
