import { useState, useEffect } from 'react';
import {
  AlertTriangle, Info, Sparkles, GraduationCap,
  BarChart3, BookOpen, User, ChevronDown, X,
} from 'lucide-react';

// ── Section metadata ──────────────────────────────────────────
const SECTION_META = {
  P: { label: 'Planning for Perspective', color: '#8B5CF6', bg: '#F5F3FF', border: '#C4B5FD' },
  I: { label: 'Investigate Issues',        color: '#0EA5E9', bg: '#F0F9FF', border: '#BAE6FD' },
  N: { label: 'Navigate & Negotiate',      color: '#10B981', bg: '#F0FDF4', border: '#A7F3D0' },
  S: { label: 'Secure Action',             color: '#F59E0B', bg: '#FFFBEB', border: '#FDE68A' },
};
const SECTIONS = ['P', 'I', 'N', 'S'];

// ── Helpers ───────────────────────────────────────────────────
function fmt(n) { return n == null ? '—' : Number(n).toLocaleString(); }
function pct(a, b) { const v = b > 0 ? Math.round((Number(a) / Number(b)) * 100) : 0; return Math.min(v, 100); }
function repName(r) { return [r.first_nm, r.last_nm].filter(Boolean).join(' ') || r.rep_wwid || '—'; }
function totalFlags(r) { return (r.p_flags || 0) + (r.i_flags || 0) + (r.n_flags || 0) + (r.s_flags || 0); }

// ── PINS Section Card ─────────────────────────────────────────
function PinsCard({ section, data }) {
  const meta = SECTION_META[section];
  const sectionFcrs  = Number(data?.section_fcrs)    || 0;
  const needed       = Number(data?.training_needed)  || 0;
  const notNeeded    = Number(data?.training_not_needed) || 0;
  const flagged      = needed + notNeeded;
  const trainingPct  = pct(needed, flagged);
  const neededW      = pct(needed, sectionFcrs);
  const notNeededW   = pct(notNeeded, sectionFcrs);

  return (
    <div className="tsg-pins-card">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 28, height: 28, borderRadius: '50%',
            background: meta.color, color: '#fff',
            fontSize: 12, fontWeight: 800, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{section}</div>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#1B1F2A', lineHeight: 1.3 }}>{meta.label}</span>
        </div>
        <ChevronDown size={13} color="#C9CDD4" />
      </div>

      {/* Big number */}
      <div style={{ fontSize: 36, fontWeight: 800, color: meta.color, lineHeight: 1 }}>{trainingPct}%</div>
      <div style={{ fontSize: 11, color: '#6B7280', marginTop: 2 }}>of evaluated FCRs need training</div>
      <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 4, marginBottom: 12 }}>
        {fmt(sectionFcrs)} total FCRs · {fmt(flagged)} with training flag answered
      </div>

      {/* Split bar: needed (meta color) / not needed (green) / no flag (gray) */}
      <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', background: '#E9E5E7' }}>
        <div style={{ width: `${neededW}%`, background: meta.color, transition: 'width 0.5s ease' }} />
        <div style={{ width: `${notNeededW}%`, background: '#4FAF7A', transition: 'width 0.5s ease' }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 10 }}>
        <span style={{ color: meta.color, fontWeight: 600 }}>
          Needs Training&nbsp;<span style={{ color: '#6B7280', fontWeight: 400 }}>{fmt(needed)}</span>
        </span>
        <span style={{ color: '#4FAF7A', fontWeight: 600 }}>
          Not Needed&nbsp;<span style={{ color: '#6B7280', fontWeight: 400 }}>{fmt(notNeeded)}</span>
        </span>
      </div>
    </div>
  );
}

// ── Rep Row (attention list) ──────────────────────────────────
function RepRow({ rep }) {
  const total = totalFlags(rep);
  const badgeColor = total >= 4 ? '#DC2626' : total === 3 ? '#E11937' : total === 2 ? '#F59E0B' : '#6B7280';
  const name = repName(rep);

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 7,
      padding: '7px 0', borderBottom: '1px solid #F3F0F1',
    }}>
      <div style={{
        width: 26, height: 26, borderRadius: '50%', background: '#F3F0F1',
        flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <User size={12} color="#9CA3AF" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#1B1F2A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
        <div style={{ fontSize: 9, color: '#9CA3AF' }}>{rep.desig || '—'} · {rep.ta || rep.region || '—'}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 3, flexShrink: 0 }}>
        <span style={{
          fontSize: 9, fontWeight: 700, color: badgeColor,
          border: `1px solid ${badgeColor}`, borderRadius: 8, padding: '1px 5px',
        }}>{total}</span>
        {SECTIONS.map(s => Number(rep[`${s.toLowerCase()}_flags`]) > 0 && (
          <span key={s} style={{
            width: 15, height: 15, borderRadius: 3,
            background: SECTION_META[s].color, color: '#fff',
            fontSize: 8, fontWeight: 800,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{s}</span>
        ))}
      </div>
    </div>
  );
}

// ── Loading + Error states ────────────────────────────────────
function Loading() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 320, gap: 12 }}>
      <div style={{
        width: 36, height: 36, border: '3px solid #E11937',
        borderTopColor: 'transparent', borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }} />
      <div style={{ fontSize: 13, color: '#6B7280' }}>Loading PINS training data…</div>
    </div>
  );
}

function ErrorState({ msg }) {
  return (
    <div style={{ padding: 24, background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 12, color: '#991B1B', fontSize: 13 }}>
      Failed to load training data: {msg}
    </div>
  );
}

// ── AI insight text renderer ──────────────────────────────────
function renderInline(text) {
  const parts = text.split(/\*\*(.*?)\*\*/g);
  return parts.map((part, i) => i % 2 === 1 ? <strong key={i}>{part}</strong> : part);
}
function AiInsightText({ text }) {
  if (!text) return null;
  return (
    <div style={{ fontSize: 12, lineHeight: 1.75, color: '#374151' }}>
      {text.split('\n').map((line, i) => {
        if (!line.trim()) return <div key={i} style={{ height: 6 }} />;
        if (line.startsWith('**') && line.endsWith('**')) {
          return (
            <div key={i} style={{ fontWeight: 800, color: '#1B1F2A', fontSize: 13, marginTop: 16, marginBottom: 5,
              paddingBottom: 5, borderBottom: '1px solid #F3F0F1' }}>
              {line.replace(/\*\*/g, '')}
            </div>
          );
        }
        if (line.startsWith('- ') || line.startsWith('\u2022 ')) {
          return (
            <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'flex-start' }}>
              <span style={{ color: '#E11937', flexShrink: 0, fontWeight: 700, marginTop: 1 }}>•</span>
              <span>{renderInline(line.slice(2))}</span>
            </div>
          );
        }
        return <div key={i} style={{ marginBottom: 4 }}>{renderInline(line)}</div>;
      })}
    </div>
  );
}

// ── Main View ─────────────────────────────────────────────────
export default function TrainingSkillGapsView() {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);
  const [aiOpen,    setAiOpen]    = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiText,    setAiText]    = useState('');

  async function handleAiInsight() {
    setAiOpen(true);
    if (aiText) return;
    setAiLoading(true);
    try {
      const r = await fetch('/api/pins-insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ summary: data }),
      });
      const j = await r.json();
      setAiText(j.insight || j.error || 'No insights available.');
    } catch (e) {
      setAiText('Failed to generate insights: ' + e.message);
    } finally {
      setAiLoading(false);
    }
  }

  useEffect(() => {
    fetch('/api/pins-summary?timeframe=90')
      .then(r => r.json())
      .then(d => { if (d.error) throw new Error(d.error); setData(d); })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loading />;
  if (error)   return <ErrorState msg={error} />;

  const kpi      = data?.kpi      || {};
  const sections = data?.sections || [];
  const levels   = data?.levels   || [];
  const reps     = data?.reps     || [];
  const byTa     = data?.by_ta    || [];

  // Build section lookup
  const sectionMap = {};
  sections.forEach(s => { if (s.section) sectionMap[s.section] = s; });

  // KPI numbers
  const totalPins    = Number(kpi.total_pins_fcrs)          || 0;
  const totalReps    = Number(kpi.total_pins_reps)          || 0;
  const withTraining = Number(kpi.fcrs_with_training_needed) || 0;
  const totalFlags_  = Number(kpi.total_training_flags)     || 0;
  const trainingPct_ = pct(withTraining, totalPins);

  // Split reps into 2 columns
  const half = Math.ceil(reps.length / 2);
  const leftReps  = reps.slice(0, half);
  const rightReps = reps.slice(half);

  // Max flags for bar scaling in Section 3
  const maxRepFlags = reps.length ? totalFlags(reps[0]) : 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, animation: 'fadeInUp 0.3s ease both' }}>

      {/* ═══ SECTION 1 — PINS Coverage & Training Analysis ═══ */}
      <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 16, padding: 24, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>

        {/* Header + tab switcher */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 3, height: 18, background: '#E11937', borderRadius: 2, flexShrink: 0 }} />
            <span style={{ fontSize: 14, fontWeight: 800, color: '#1B1F2A' }}>PINS Coverage &amp; Training Analysis</span>
            <Info size={13} color="#C9CDD4" />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button
              onClick={handleAiInsight}
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                padding: '4px 12px', fontSize: 11, fontWeight: 700,
                border: '1px solid #E11937', borderRadius: 20,
                background: aiOpen ? '#FDECEE' : '#fff',
                color: '#E11937', cursor: 'pointer', fontFamily: 'inherit',
                transition: 'background 0.15s',
              }}
            >
              <Sparkles size={12} color="#E11937" />
              AI Insights
            </button>
          </div>
        </div>

        {/* KPI pills */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          {[
            { label: 'Total PINS FCRs',          val: fmt(totalPins),       color: '#1B1F2A', bg: '#F9FAFB', border: '#E9E5E7' },
            { label: 'Reps with PINS Coaching',   val: fmt(totalReps),       color: '#1B1F2A', bg: '#F9FAFB', border: '#E9E5E7' },
            { label: 'FCRs with Training Needed', val: fmt(withTraining),    color: '#DC2626', bg: '#FEF2F2', border: '#FECACA' },
            { label: 'Total Training Flags',      val: fmt(totalFlags_),     color: '#A16207', bg: '#FFFBEB', border: '#FDE68A' },
            { label: '% FCRs Needing Training',   val: `${trainingPct_}%`,
              color: trainingPct_ > 30 ? '#DC2626' : '#15803D',
              bg:    trainingPct_ > 30 ? '#FEF2F2' : '#F0FDF4',
              border:trainingPct_ > 30 ? '#FECACA' : '#BBF7D0' },
          ].map(({ label, val, color, bg, border }) => (
            <div key={label} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 10, padding: '8px 14px', flexShrink: 0 }}>
              <div style={{ fontSize: 18, fontWeight: 800, color, lineHeight: 1 }}>{val}</div>
              <div style={{ fontSize: 10, color: '#6B7280', marginTop: 3 }}>{label}</div>
            </div>
          ))}
        </div>

        {/* 4 section cards */}
        <div className="tsg-pins-grid">
          {SECTIONS.map(s => <PinsCard key={s} section={s} data={sectionMap[s]} />)}
        </div>

        {/* Job level breakdown table */}
        <div style={{ border: '1px solid #E9E5E7', borderRadius: 12, overflow: 'hidden', marginTop: 20 }}>
          <div style={{ padding: '11px 16px', borderBottom: '1px solid #E9E5E7', background: '#FAFAFA', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#1B1F2A' }}>Training Flags by Job Level</span>
            <span style={{ fontSize: 10, color: '#9CA3AF' }}>— FCRs where "Training Needed = Yes" per PINS section</span>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr>
                  {['Job Level', 'FCRs', 'Reps', 'P needed', 'I needed', 'N needed', 'S needed', 'Total flags'].map(h => (
                    <th key={h} style={{
                      padding: '8px 14px', textAlign: h === 'Job Level' ? 'left' : 'center',
                      fontSize: 10, fontWeight: 700, textTransform: 'uppercase',
                      letterSpacing: '0.05em', color: '#6B7280',
                      borderBottom: '1px solid #E9E5E7', background: '#FAFAFA',
                      whiteSpace: 'nowrap',
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {levels.map((row, i) => {
                  const pt = Number(row.p_training) || 0;
                  const it = Number(row.i_training) || 0;
                  const nt = Number(row.n_training) || 0;
                  const st = Number(row.s_training) || 0;
                  const fc = Number(row.fcrs)        || 0;
                  const tf = pt + it + nt + st;
                  const cellColor = (v) => {
                    const p = pct(v, fc);
                    return p > 30 ? '#DC2626' : p > 15 ? '#F59E0B' : '#4FAF7A';
                  };
                  return (
                    <tr key={i} style={{ background: i === 0 ? '#FAFAFA' : 'transparent' }}>
                      <td style={{ padding: '9px 14px', color: '#1B1F2A', fontWeight: 600, borderBottom: '1px solid #F3F0F1' }}>{row.job_level}</td>
                      <td style={{ padding: '9px 14px', textAlign: 'center', color: '#6B7280', borderBottom: '1px solid #F3F0F1' }}>{fmt(fc)}</td>
                      <td style={{ padding: '9px 14px', textAlign: 'center', color: '#6B7280', borderBottom: '1px solid #F3F0F1' }}>{fmt(row.reps)}</td>
                      {[pt, it, nt, st].map((v, ki) => (
                        <td key={ki} style={{ padding: '9px 14px', textAlign: 'center', fontWeight: 600, color: cellColor(v), borderBottom: '1px solid #F3F0F1' }}>
                          {fmt(v)}{fc > 0 && <span style={{ fontSize: 9, color: '#9CA3AF', fontWeight: 400, marginLeft: 2 }}>({pct(v, fc)}%)</span>}
                        </td>
                      ))}
                      <td style={{ padding: '9px 14px', textAlign: 'center', fontWeight: 700, color: tf > 0 ? '#DC2626' : '#6B7280', borderBottom: '1px solid #F3F0F1' }}>{fmt(tf)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '9px 16px', background: '#FAFAFA', fontSize: 10, color: '#9CA3AF', borderTop: '1px solid #E9E5E7', lineHeight: 1.7 }}>
            P=Planning for Perspective · I=Investigate Issues · N=Navigate &amp; Negotiate · S=Secure Action. &nbsp;
            "Needed %" = FCRs with &quot;Training Needed = Yes&quot; ÷ total PINS FCRs for that job level. &nbsp;
            <span style={{ color: '#4FAF7A', fontWeight: 600 }}>Green</span> &lt;15% · <span style={{ color: '#F59E0B', fontWeight: 600 }}>Amber</span> 15–30% · <span style={{ color: '#DC2626', fontWeight: 600 }}>Red</span> &gt;30%.
          </div>
        </div>
      </div>

      {/* ═══ SECTION 2 — People & Coverage ═══ */}
      <div className="tsg-mid-grid">

        {/* LEFT: Reps requiring attention */}
        <div style={{ background: '#FFFBF9', border: '1px solid #E9E5E7', borderRadius: 16, padding: 20, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <AlertTriangle size={15} color="#F4B252" />
              <span style={{ fontSize: 13, fontWeight: 800, color: '#1B1F2A' }}>Reps requiring training attention</span>
              <Info size={12} color="#C9CDD4" />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#6B7280', background: '#F3F0F1', borderRadius: 10, padding: '2px 8px' }}>{fmt(reps.length)}</span>
              <div style={{ display: 'flex', gap: 3 }}>
                {SECTIONS.map(s => (
                  <span key={s} style={{ width: 14, height: 14, background: SECTION_META[s].color, color: '#fff', borderRadius: 3, fontSize: 8, fontWeight: 800, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{s}</span>
                ))}
              </div>
            </div>
          </div>

          {reps.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 40, color: '#9CA3AF', fontSize: 12 }}>
              No reps with training flags found.
            </div>
          ) : (
            <div className="tsg-msl-cols">
              <div>{leftReps.map((r, i) => <RepRow key={r.rep_wwid || i} rep={r} />)}</div>
              <div>{rightReps.map((r, i) => <RepRow key={r.rep_wwid || i} rep={r} />)}</div>
            </div>
          )}
        </div>

        {/* RIGHT: Section bars + TA coverage */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Training flags by PINS section */}
          <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 16, padding: 18, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
              <BarChart3 size={14} color="#9CA3AF" style={{ marginRight: 7 }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: '#1B1F2A' }}>Training Flags by PINS Section</span>
            </div>
            {SECTIONS.map(s => {
              const d = sectionMap[s] || {};
              const needed     = Number(d.training_needed)  || 0;
              const sectionFcrs = Number(d.section_fcrs)    || 1;
              const flagged    = needed + (Number(d.training_not_needed) || 0);
              const barPct     = pct(needed, sectionFcrs);
              const flaggedPct = pct(flagged, sectionFcrs);
              const meta       = SECTION_META[s];
              return (
                <div key={s} style={{ marginBottom: 14 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ width: 18, height: 18, borderRadius: 4, background: meta.color, color: '#fff', fontSize: 9, fontWeight: 800, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{s}</span>
                      <span style={{ fontSize: 11, fontWeight: 600, color: '#1B1F2A' }}>{meta.label}</span>
                    </div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: barPct > 30 ? '#DC2626' : '#6B7280' }}>
                      {fmt(needed)}&nbsp;<span style={{ fontWeight: 400, color: '#9CA3AF' }}>({barPct}%)</span>
                    </div>
                  </div>
                  {/* Stacked bar: training needed | training not needed | no flag */}
                  <div style={{ height: 8, background: '#F0EEEF', borderRadius: 4, overflow: 'hidden', display: 'flex' }}>
                    <div style={{ width: `${barPct}%`, background: meta.color, transition: 'width 0.5s ease' }} />
                    <div style={{ width: `${flaggedPct - barPct}%`, background: '#4FAF7A', transition: 'width 0.5s ease' }} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3, fontSize: 9, color: '#9CA3AF' }}>
                    <span style={{ color: meta.color, fontWeight: 600 }}>Needed</span>
                    <span>{fmt(sectionMap[s]?.section_fcrs)} FCRs total</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* PINS coverage by TA */}
          <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 16, padding: 18, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
              <BookOpen size={14} color="#9CA3AF" style={{ marginRight: 7 }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: '#1B1F2A' }}>PINS Coverage by TA</span>
            </div>
            <div style={{ display: 'flex', gap: 8, fontSize: 10, fontWeight: 700, color: '#9CA3AF', marginBottom: 8, paddingBottom: 6, borderBottom: '1px solid #E9E5E7' }}>
              <span style={{ flex: 1 }}>TA</span>
              <span style={{ width: 46, textAlign: 'right' }}>FCRs</span>
              <span style={{ width: 36, textAlign: 'right' }}>Reps</span>
              <span style={{ width: 60, textAlign: 'right' }}>Trg Needed</span>
            </div>
            <div style={{ maxHeight: 178, overflowY: 'auto' }}>
              {byTa.slice(0, 14).map((t, i) => {
                const tNeeded = Number(t.fcrs_training_needed) || 0;
                const tFcrs   = Number(t.pins_fcrs) || 1;
                const tp      = pct(tNeeded, tFcrs);
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0', borderBottom: '1px solid #F9F9F9', fontSize: 11 }}>
                    <span style={{ flex: 1, fontWeight: 600, color: '#1B1F2A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.ta || 'Unknown'}</span>
                    <span style={{ width: 46, textAlign: 'right', color: '#6B7280' }}>{fmt(t.pins_fcrs)}</span>
                    <span style={{ width: 36, textAlign: 'right', color: '#6B7280' }}>{fmt(t.pins_reps)}</span>
                    <span style={{ width: 60, textAlign: 'right', fontWeight: 600, color: tp > 30 ? '#DC2626' : '#6B7280' }}>
                      {fmt(tNeeded)}&nbsp;<span style={{ fontSize: 9, color: '#9CA3AF', fontWeight: 400 }}>({tp}%)</span>
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>

      {/* ═══ SECTION 3 — Training Status (real data) ═══ */}
      <div style={{ background: '#FFFEF5', border: '1px solid #E9E5E7', borderRadius: 16, padding: 24, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <GraduationCap size={17} color="#F4B252" />
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: '#1B1F2A' }}>Training Status</div>
              <div style={{ fontSize: 11, color: '#6B7280', marginTop: 1 }}>
                Training needs identified via PINS coaching conversations in iConnect
              </div>
            </div>
          </div>
        </div>

        <div className="tsg-training-grid">
          {/* Left: headline KPIs + per-section pills */}
          <div>
            <div style={{ display: 'flex', gap: 24, marginBottom: 20, flexWrap: 'wrap' }}>
              <div>
                <div style={{ fontSize: 42, fontWeight: 800, color: '#E11937', lineHeight: 1 }}>{fmt(withTraining)}</div>
                <div style={{ fontSize: 11, color: '#6B7280', marginTop: 3 }}>FCRs with training needed</div>
              </div>
              <div>
                <div style={{ fontSize: 42, fontWeight: 800, color: '#F4B252', lineHeight: 1 }}>{fmt(totalFlags_)}</div>
                <div style={{ fontSize: 11, color: '#6B7280', marginTop: 3 }}>total training flags</div>
              </div>
              <div>
                <div style={{ fontSize: 42, fontWeight: 800, color: '#4FAF7A', lineHeight: 1 }}>{trainingPct_}%</div>
                <div style={{ fontSize: 11, color: '#6B7280', marginTop: 3 }}>of PINS FCRs flagged</div>
              </div>
            </div>

            {/* Per-section pill breakdown */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {SECTIONS.map(s => {
                const d      = sectionMap[s] || {};
                const needed = Number(d.training_needed) || 0;
                const tot    = Number(d.section_fcrs)    || 1;
                const p      = pct(needed, tot);
                const meta   = SECTION_META[s];
                return (
                  <div key={s} style={{ background: meta.bg, border: `1px solid ${meta.border}`, borderRadius: 10, padding: '8px 14px', minWidth: 118 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 4 }}>
                      <span style={{ width: 16, height: 16, borderRadius: 4, background: meta.color, color: '#fff', fontSize: 8, fontWeight: 800, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{s}</span>
                      <span style={{ fontSize: 10, fontWeight: 700, color: meta.color }}>{meta.label.split(' ')[0]}</span>
                    </div>
                    <div style={{ fontSize: 22, fontWeight: 800, color: meta.color, lineHeight: 1 }}>{fmt(needed)}</div>
                    <div style={{ fontSize: 10, color: '#6B7280', marginTop: 2 }}>flags · {p}% of FCRs</div>
                    {/* Mini bar */}
                    <div style={{ height: 4, background: '#E9E5E7', borderRadius: 2, marginTop: 6, overflow: 'hidden' }}>
                      <div style={{ width: `${p}%`, height: '100%', background: meta.color, borderRadius: 2, transition: 'width 0.5s ease' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: top reps by total flags (sorted) */}
          <div style={{ background: '#fff', border: '1px solid #E9E5E7', borderRadius: 12, padding: '12px 14px', maxHeight: 260, overflowY: 'auto' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#1B1F2A', marginBottom: 8, paddingBottom: 6, borderBottom: '1px solid #E9E5E7' }}>
              Top reps by training flags
            </div>
            {reps.length === 0 && (
              <div style={{ fontSize: 12, color: '#9CA3AF', padding: '16px 0', textAlign: 'center' }}>No data</div>
            )}
            {reps.slice(0, 20).map((rep, i) => {
              const name = repName(rep);
              const tf   = totalFlags(rep);
              const barW = pct(tf, maxRepFlags || 1);
              return (
                <div key={rep.rep_wwid || i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: '1px solid #F3F0F1' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#1B1F2A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
                    <div style={{ fontSize: 9, color: '#9CA3AF' }}>{rep.desig || rep.ta || '—'}</div>
                  </div>
                  <span style={{ fontSize: 10, color: '#9CA3AF', flexShrink: 0 }}>{fmt(rep.total_pins_fcrs)} FCRs</span>
                  <div style={{ width: 64, height: 5, background: '#F0EEEF', borderRadius: 3, overflow: 'hidden', flexShrink: 0 }}>
                    <div style={{ width: `${barW}%`, height: '100%', background: '#E11937', borderRadius: 3 }} />
                  </div>
                  <span style={{ fontSize: 10, fontWeight: 700, color: '#E11937', width: 18, textAlign: 'right', flexShrink: 0 }}>{tf}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ═══ AI INSIGHTS SIDE PANEL ═══ */}
      {aiOpen && (
        <>
          {/* Backdrop */}
          <div
            onClick={() => setAiOpen(false)}
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.18)', zIndex: 999 }}
          />
          {/* Panel */}
          <div style={{
            position: 'fixed', right: 0, top: 0, bottom: 0, width: 400,
            background: '#fff', zIndex: 1000,
            boxShadow: '-6px 0 32px rgba(0,0,0,0.14)',
            display: 'flex', flexDirection: 'column',
            animation: 'slideInRight 0.22s ease both',
          }}>
            {/* Panel header */}
            <div style={{
              padding: '16px 20px', borderBottom: '1px solid #E9E5E7',
              display: 'flex', alignItems: 'center', gap: 10,
              background: '#FDECEE',
            }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: '#E11937', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Sparkles size={15} color="#fff" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#1B1F2A' }}>AI PINS Insights</div>
                <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>Powered by Azure OpenAI · Last 90 days</div>
              </div>
              <button
                onClick={() => setAiOpen(false)}
                style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#6B7280', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 6 }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Panel body */}
            <div style={{ flex: 1, overflowY: 'auto', padding: 20 }}>
              {aiLoading ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, paddingTop: 60 }}>
                  <div style={{
                    width: 36, height: 36, border: '3px solid #E11937',
                    borderTopColor: 'transparent', borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite',
                  }} />
                  <div style={{ fontSize: 13, color: '#6B7280', textAlign: 'center' }}>Analyzing training patterns…</div>
                  <div style={{ fontSize: 11, color: '#C9CDD4', textAlign: 'center' }}>This may take a moment</div>
                </div>
              ) : (
                <AiInsightText text={aiText} />
              )}
            </div>

            {/* Panel footer */}
            {!aiLoading && aiText && (
              <div style={{ padding: '12px 20px', borderTop: '1px solid #E9E5E7', background: '#FAFAFA', display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  onClick={() => { setAiText(''); handleAiInsight(); }}
                  style={{ fontSize: 11, fontWeight: 600, color: '#E11937', border: '1px solid #E11937', borderRadius: 8, padding: '5px 14px', background: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}
                >
                  <Sparkles size={11} color="#E11937" /> Regenerate
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
