/**
 * Frontend Telemetry Service
 * 
 * Handles client-side event collection, batching, and submission.
 * Features:
 * - Session ID generation and persistence (sessionStorage)
 * - Event batching (by size or time interval)
 * - Offline queue (localStorage fallback)
 * - Auto-flush on page unload
 * - No-op when disabled
 */

class TelemetryService {
  constructor() {
    this.enabled = import.meta.env.VITE_TELEMETRY_ENABLED === 'true';
    this.sessionId = this._getOrCreateSessionId();
    this.userId = null;
    this.userName = null;
    this.userEmail = null;
    this.eventQueue = [];
    this.flushTimer = null;

    // Config from environment
    this.batchSize = parseInt(import.meta.env.VITE_TELEMETRY_BATCH_SIZE || '10');
    this.flushIntervalMs = parseInt(import.meta.env.VITE_TELEMETRY_FLUSH_INTERVAL_MS || '30000');
    this.apiEndpoint = '/api/telemetry';

    // Debug logging
    console.log('[Telemetry] Enabled:', this.enabled);
    console.log('[Telemetry] VITE_TELEMETRY_ENABLED env:', import.meta.env.VITE_TELEMETRY_ENABLED);
    console.log('[Telemetry] Session ID:', this.sessionId);
    console.log('[Telemetry] Batch Size:', this.batchSize);
    console.log('[Telemetry] Flush Interval:', this.flushIntervalMs);

    if (this.enabled) {
      console.log('[Telemetry] Service initialized - telemetry ENABLED');
      this._startFlushTimer();
      window.addEventListener('beforeunload', () => this.trackBrowserClose());
      this._flushOfflineQueue();
    } else {
      console.warn('[Telemetry] Service disabled - telemetry DISABLED');
    }
  }

  /**
   * Initialize telemetry with user info (call after auth)
   */
  init(userId, userName, userEmail) {
    this.userId = userId;
    this.userName = userName;
    this.userEmail = userEmail;
    this.trackSessionStart(userId, userName, userEmail);
  }

  /**
   * Track page view
   */
  trackPageView(pageName, url = window.location.href) {
    this.trackEvent('page_view', {
      page_name: pageName,
      url,
      referrer: document.referrer
    });
  }

  /**
   * Track page exit
   */
  trackPageExit(pageName, timeOnPageMs = 0) {
    this.trackEvent('page_exit', {
      page_name: pageName,
      time_on_page_ms: timeOnPageMs
    });
  }

  /**
   * Track button click
   */
  trackButtonClick(buttonName, pageName = null) {
    this.trackEvent('button_click', {
      button_name: buttonName,
      page_name: pageName
    });
  }

  /**
   * Track search
   */
  trackSearch(query, resultCount = null) {
    this.trackEvent('search', {
      query,
      result_count: resultCount
    });
  }

  /**
   * Track data export
   */
  trackDataExport(exportFormat, recordCount = null) {
    this.trackEvent('data_export', {
      format: exportFormat,
      record_count: recordCount
    });
  }

  /**
   * Track API call
   */
  trackApiCall(endpoint, method = 'GET', statusCode = 200, responseTimeMs = 0) {
    this.trackEvent('api_call', {
      endpoint,
      method,
      status_code: statusCode,
      response_time_ms: responseTimeMs
    });
  }

  /**
   * Track error
   */
  trackError(errorMessage, errorCode = null, additionalData = {}) {
    this.trackEvent('error', {
      message: errorMessage,
      code: errorCode,
      ...additionalData
    });
  }

  /**
   * Track session start
   */
  trackSessionStart(userId = null, userName = null, userEmail = null) {
    this.userId = userId;
    this.userName = userName;
    this.userEmail = userEmail;

    this.trackEvent('session_start', {
      user_id: userId,
      user_name: userName,
      user_email: userEmail
    });
  }

  /**
   * Track session end
   */
  trackSessionEnd() {
    this.trackEvent('session_end', {
      session_duration_ms: this._getSessionDurationMs()
    });
    this.flush();
  }

  /**
   * Track user login
   */
  trackUserLogin(userId, userName, userEmail) {
    this.userId = userId;
    this.userName = userName;
    this.userEmail = userEmail;

    this.trackEvent('user_login', {
      user_id: userId,
      user_name: userName,
      user_email: userEmail
    });
  }

  /**
   * Track user logout
   */
  trackUserLogout() {
    this.trackEvent('user_logout', {});
    this.flush();
  }

  /**
   * Track browser close
   */
  trackBrowserClose() {
    this.trackEvent('browser_closed', {});
    this.flush();
  }

  /**
   * Track custom event
   */
  trackEvent(eventType, data = {}) {
    if (!this.enabled) {
      console.log('[TelemetryService] Telemetry disabled, ignoring event:', eventType);
      return;
    }

    console.log('[TelemetryService] trackEvent():', eventType, data);

    const event = {
      event_type: eventType,
      event_data: data,
      session_id: this.sessionId,
      user_id: this.userId,
      user_name: this.userName,
      user_email: this.userEmail,
      event_timestamp: new Date().toISOString()
    };

    this._enqueue(event);
  }

  /**
   * Manually flush event queue
   */
  async flush() {
    if (!this.enabled) {
      console.log('[TelemetryService] flush() - telemetry disabled');
      return;
    }
    
    if (this.eventQueue.length === 0) {
      console.log('[TelemetryService] flush() - queue empty, nothing to flush');
      return;
    }

    const batch = [...this.eventQueue];
    console.log('[TelemetryService] flush() - flushing', batch.length, 'events');
    this.eventQueue = [];

    try {
      console.log('[TelemetryService] POST to', this.apiEndpoint);
      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events: batch }),
        keepalive: true
      });

      console.log('[TelemetryService] Response status:', response.status);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      console.log('[TelemetryService] flush() succeeded');
    } catch (err) {
      console.error('[TelemetryService] flush() failed:', err.message);
      this._saveToOfflineQueue(batch);
    }
  }

  /**
   * Private: Enqueue event and auto-flush if needed
   */
  _enqueue(event) {
    console.log('[TelemetryService] _enqueue() - queue size before:', this.eventQueue.length);
    this.eventQueue.push(event);
    console.log('[TelemetryService] _enqueue() - queue size after:', this.eventQueue.length, '| batchSize:', this.batchSize);
    if (this.eventQueue.length >= this.batchSize) {
      console.log('[TelemetryService] Batch size reached, calling flush()');
      this.flush();
    }
  }

  /**
   * Private: Start periodic flush timer
   */
  _startFlushTimer() {
    this.flushTimer = setInterval(() => {
      if (this.eventQueue.length > 0) {
        this.flush();
      }
    }, this.flushIntervalMs);
  }

  /**
   * Private: Get or create session ID from sessionStorage
   */
  _getOrCreateSessionId() {
    let sessionId = sessionStorage.getItem('telemetrySessionId');
    if (!sessionId) {
      sessionId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('telemetrySessionId', sessionId);
    }
    return sessionId;
  }

  /**
   * Private: Save events to localStorage for offline retry
   */
  _saveToOfflineQueue(events) {
    const key = 'telemetry_offline_queue';
    try {
      const existing = JSON.parse(localStorage.getItem(key) || '[]');
      const updated = [...existing, ...events];
      
      const maxQueueSize = 1000;
      if (updated.length > maxQueueSize) {
        updated.splice(0, updated.length - maxQueueSize);
      }
      
      localStorage.setItem(key, JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save offline queue:', err.message);
    }
  }

  /**
   * Private: Attempt to flush offline queue on startup
   */
  async _flushOfflineQueue() {
    const key = 'telemetry_offline_queue';
    try {
      const queued = JSON.parse(localStorage.getItem(key) || '[]');
      if (queued.length === 0) return;

      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ events: queued })
      });

      if (response.ok) {
        localStorage.removeItem(key);
      }
    } catch (err) {
      console.warn('Offline queue flush failed:', err.message);
    }
  }

  /**
   * Private: Get session duration in milliseconds
   */
  _getSessionDurationMs() {
    const stored = sessionStorage.getItem('telemetrySessionStart');
    if (!stored) return 0;
    return Date.now() - parseInt(stored);
  }

  /**
   * Cleanup: Stop flush timer
   */
  destroy() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
    }
  }
}

// Export singleton instance
export const telemetryService = new TelemetryService();

export default TelemetryService;

