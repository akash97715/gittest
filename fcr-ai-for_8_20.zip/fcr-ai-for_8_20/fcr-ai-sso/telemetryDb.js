import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

/**
 * Telemetry Database Connection Pool (Azure PostgreSQL)
 * Separate from main Redshift pool to isolate telemetry operations
 */
const telemetryPool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
  max: 10,
  min: 2,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

telemetryPool.on('error', (err) => {
  console.error('Telemetry pool error:', err.message);
});

export default telemetryPool;
