#!/usr/bin/env node
/**
 * Test: Browser Close Telemetry Event
 * 
 * This script tests the complete flow:
 * 1. Validates browser_closed event type is accepted
 * 2. Sends a browser_closed event to the API
 * 3. Queries the database to verify it was stored
 * 4. Reports success/failure
 */

import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

// Test configuration
const TEST_SESSION_ID = 'test-session-' + Date.now();
const TEST_USER_ID = 'test-user-123';
const TEST_USER_EMAIL = 'test@example.com';
const API_BASE = 'http://localhost:8080';
const API_ENDPOINT = `${API_BASE}/api/telemetry`;

// Database connection pool
const telemetryPool = new Pool({
  host: process.env.TELEMETRY_DB_HOST,
  port: parseInt(process.env.TELEMETRY_DB_PORT || '5432'),
  database: process.env.TELEMETRY_DB_NAME,
  user: process.env.TELEMETRY_DB_USER,
  password: process.env.TELEMETRY_DB_PASSWORD,
  ssl: process.env.TELEMETRY_DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

console.log('\n' + '='.repeat(80));
console.log('BROWSER CLOSE TELEMETRY - END-TO-END TEST');
console.log('='.repeat(80));

// Test 1: Verify environment
console.log('\n✓ Test 1: Environment Configuration');
console.log('  TELEMETRY_ENABLED:', process.env.TELEMETRY_ENABLED);
console.log('  TELEMETRY_TRANSPORT:', process.env.TELEMETRY_TRANSPORT);
console.log('  TELEMETRY_DB_HOST:', process.env.TELEMETRY_DB_HOST);
console.log('  API Endpoint:', API_ENDPOINT);

// Test 2: Create test event
console.log('\n✓ Test 2: Creating browser_closed Event');
const testEvent = {
  event_type: 'browser_closed',
  event_data: {},
  session_id: TEST_SESSION_ID,
  user_id: TEST_USER_ID,
  user_email: TEST_USER_EMAIL,
  event_timestamp: new Date().toISOString()
};
console.log('  Event payload:', JSON.stringify(testEvent, null, 2));

// Test 3: Send to API
console.log('\n✓ Test 3: Sending browser_closed Event to API');
try {
  console.log(`  POST ${API_ENDPOINT}`);
  const response = await fetch(API_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ events: [testEvent] })
  });

  console.log('  Response Status:', response.status);
  const responseBody = await response.json();
  console.log('  Response Body:', JSON.stringify(responseBody, null, 2));

  if (!response.ok) {
    console.error('  ❌ API returned error!');
    process.exit(1);
  }

  console.log('  ✅ API accepted the event');
} catch (err) {
  console.error('  ❌ API request failed:', err.message);
  console.error('  Make sure the server is running on port 3000');
  process.exit(1);
}

// Test 4: Wait a bit for async processing
console.log('\n✓ Test 4: Waiting for async processing (2 seconds)...');
await new Promise(resolve => setTimeout(resolve, 2000));

// Test 5: Query database
console.log('\n✓ Test 5: Querying Database for Stored Event');
try {
  const client = await telemetryPool.connect();
  
  // Query for the event we just sent
  const query = `
    SELECT 
      event_id,
      session_id,
      user_id,
      user_email,
      event_type,
      event_data,
      event_timestamp
    FROM telemetry.user_events
    WHERE session_id = $1 AND event_type = $2
    ORDER BY event_timestamp DESC
    LIMIT 1
  `;

  console.log('  SQL Query:', query);
  console.log('  Parameters:', [TEST_SESSION_ID, 'browser_closed']);

  const result = await client.query(query, [TEST_SESSION_ID, 'browser_closed']);
  
  client.release();

  if (result.rows.length === 0) {
    console.error('  ❌ Event NOT found in database!');
    console.error('  The event was accepted by the API but not stored in the database.');
    console.error('  Possible issues:');
    console.error('    - Publisher not sending to database');
    console.error('    - Event writer failing silently');
    console.error('    - Database connection issue');
    process.exit(1);
  }

  const storedEvent = result.rows[0];
  console.log('  ✅ Event FOUND in database!');
  console.log('\n  Stored Event Details:');
  console.log('    Event ID:', storedEvent.event_id);
  console.log('    Session ID:', storedEvent.session_id);
  console.log('    User ID:', storedEvent.user_id);
  console.log('    User Email:', storedEvent.user_email);
  console.log('    Event Type:', storedEvent.event_type);
  console.log('    Event Data:', storedEvent.event_data);
  console.log('    Event Timestamp:', storedEvent.event_timestamp);

} catch (err) {
  console.error('  ❌ Database query failed:', err.message);
  console.error('  Details:', err);
  process.exit(1);
}

// Test 6: Verify database schema
console.log('\n✓ Test 6: Verifying Database Schema');
try {
  const client = await telemetryPool.connect();
  
  const tableQuery = `
    SELECT column_name, data_type 
    FROM information_schema.columns
    WHERE table_schema = 'telemetry' AND table_name = 'user_events'
    ORDER BY ordinal_position
  `;

  const result = await client.query(tableQuery);
  
  client.release();

  console.log('  telemetry.user_events table columns:');
  result.rows.forEach(col => {
    console.log(`    - ${col.column_name}: ${col.data_type}`);
  });

} catch (err) {
  console.error('  ⚠️  Could not verify schema:', err.message);
}

console.log('\n' + '='.repeat(80));
console.log('✅ ALL TESTS PASSED! Browser close events are being logged to the database.');
console.log('='.repeat(80) + '\n');

process.exit(0);
