#!/usr/bin/env python3
"""
Redshift Permissions Test - Simplified Diagnostic
"""

import psycopg2

config = {
    'host': 'itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com',
    'port': 5439,
    'database': 'awprdrsdb',
    'user': 'dmp_fcr_ai_development_prod_read',
    'password': 'fPmzkv-12rfF',
    'sslmode': 'require'
}

print("\n" + "=" * 100)
print("REDSHIFT CONNECTIVITY TEST - SIMPLIFIED DIAGNOSTIC")
print("=" * 100)

try:
    conn = psycopg2.connect(**config)
    cursor = conn.cursor()
    
    print("\n✓ CONNECTION: SUCCESS")
    print(f"  Service Account: dmp_fcr_ai_development_prod_read")
    print(f"  Database: awprdrsdb")
    print(f"  Status: Connected and authenticated")
    
    # Test schema visibility
    print("\n" + "-" * 100)
    print("TESTING ODP SCHEMA & TABLE ACCESS")
    print("-" * 100)
    
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata
        WHERE schema_name = 'odp'
    """)
    result = cursor.fetchone()
    
    if result:
        print("\n✓ ODP schema IS visible to this user")
    else:
        print("\n✗ ODP schema is NOT visible to this user")
    
    # Test direct table access
    print("\nTesting direct table access: odp.dp_cust_pers_engagement_dly")
    
    try:
        cursor.execute("SELECT 1 FROM odp.dp_cust_pers_engagement_dly LIMIT 1")
        cursor.fetchone()
        print("✓ TABLE ACCESS: SUCCESS - Table is readable")
        
        # Get table stats
        cursor.execute("SELECT COUNT(*) FROM odp.dp_cust_pers_engagement_dly")
        row_count = cursor.fetchone()[0]
        print(f"✓ Table contains {row_count:,} rows")
        
        # Run sample queries
        print("\n" + "-" * 100)
        print("RUNNING SAMPLE QUERIES")
        print("-" * 100)
        
        # Query 1: Basic stats
        print("\n[Query 1] Basic FCR Statistics:")
        cursor.execute("""
            SELECT
                COUNT(DISTINCT survey_target_id) as total_fcrs,
                COUNT(DISTINCT rep_wwid) as total_msls
            FROM odp.dp_cust_pers_engagement_dly
            WHERE chnl = 'SURVEY'
                AND (LOWER(engagement_title) LIKE '%coaching%' 
                     OR LOWER(engagement_title) LIKE '%fcr%')
                AND survey_target_id IS NOT NULL
                AND (LOWER(engagement_title) LIKE '%msl%' 
                     OR LOWER(engagement_title) LIKE '%vese%')
        """)
        fcrs, msls = cursor.fetchone()
        print(f"  ✓ Total FCRs: {fcrs:,}")
        print(f"  ✓ Total MSLs: {msls:,}")
        
        # Query 2: TA breakdown
        print("\n[Query 2] Top Therapeutic Areas:")
        cursor.execute("""
            SELECT ta, COUNT(DISTINCT survey_target_id) as fcr_count
            FROM odp.dp_cust_pers_engagement_dly
            WHERE chnl = 'SURVEY'
                AND survey_target_id IS NOT NULL
                AND (LOWER(engagement_title) LIKE '%msl%' 
                     OR LOWER(engagement_title) LIKE '%vese%')
            GROUP BY ta
            ORDER BY fcr_count DESC
            LIMIT 5
        """)
        results = cursor.fetchall()
        for ta, count in results:
            print(f"  ✓ {ta:^20} : {count:>6,} FCRs")
        
        # Query 3: Status breakdown
        print("\n[Query 3] FCR Status Distribution:")
        cursor.execute("""
            SELECT
                CASE
                    WHEN LOWER(survey_target_status) LIKE '%submitted%' THEN 'Submitted'
                    WHEN LOWER(survey_target_status) LIKE '%saved%' OR LOWER(survey_target_status) LIKE '%draft%' THEN 'Draft'
                    ELSE 'Other'
                END as status,
                COUNT(DISTINCT survey_target_id) as count
            FROM odp.dp_cust_pers_engagement_dly
            WHERE chnl = 'SURVEY'
                AND survey_target_id IS NOT NULL
                AND (LOWER(engagement_title) LIKE '%msl%' 
                     OR LOWER(engagement_title) LIKE '%vese%')
            GROUP BY status
            ORDER BY count DESC
        """)
        results = cursor.fetchall()
        for status, count in results:
            print(f"  ✓ {status:^20} : {count:>6,} FCRs")
        
        # Query 4: Recent FCRs
        print("\n[Query 4] Sample of Recent FCRs:")
        cursor.execute("""
            SELECT
                survey_target_id,
                rep_first_nm,
                rep_last_nm,
                ta,
                MIN(acty_dt) as coaching_date
            FROM odp.dp_cust_pers_engagement_dly
            WHERE chnl = 'SURVEY'
                AND survey_target_id IS NOT NULL
                AND (LOWER(engagement_title) LIKE '%msl%' 
                     OR LOWER(engagement_title) LIKE '%vese%')
            GROUP BY survey_target_id, rep_first_nm, rep_last_nm, ta
            ORDER BY coaching_date DESC
            LIMIT 3
        """)
        results = cursor.fetchall()
        for i, (fcr_id, first, last, ta, date) in enumerate(results, 1):
            print(f"  {i}. {first} {last} | TA: {ta:^5} | Date: {date}")
        
        # Query 5: PINS data check
        print("\n[Query 5] PINS Training Flags Summary:")
        cursor.execute("""
            SELECT
                COUNT(DISTINCT survey_target_id) as pins_fcrs,
                SUM(CASE WHEN survey_question_response = 'Yes' THEN 1 ELSE 0 END) as training_flags
            FROM odp.dp_cust_pers_engagement_dly
            WHERE chnl = 'SURVEY'
                AND survey_target_id IS NOT NULL
                AND (LOWER(engagement_title) LIKE '%msl%' 
                     OR LOWER(engagement_title) LIKE '%vese%')
                AND survey_question_response IN ('Yes', 'No')
                AND (TRIM(survey_question_text) ILIKE 'plan%'
                     OR TRIM(survey_question_text) ILIKE 'invest%'
                     OR TRIM(survey_question_text) ILIKE 'navigat%'
                     OR TRIM(survey_question_text) ILIKE 'negot%'
                     OR TRIM(survey_question_text) ILIKE 'secure%')
        """)
        pins_fcrs, training_flags = cursor.fetchone()
        print(f"  ✓ FCRs with PINS data: {pins_fcrs:,}")
        print(f"  ✓ Training flags: {training_flags:,}")
        
        cursor.close()
        conn.close()
        
        print("\n" + "=" * 100)
        print("✓ ALL TESTS PASSED - REDSHIFT ACCESS VERIFIED")
        print("=" * 100)
        print("\nSUMMARY:")
        print("  ✓ Service account can connect to Redshift")
        print("  ✓ ODP schema is accessible")
        print("  ✓ dp_cust_pers_engagement_dly table is readable")
        print("  ✓ MSL/VESE coaching data is available")
        print("  ✓ PINS data is available for analysis")
        print("\n✓ You are ready to run the FCR AI dashboard!\n")
        
    except psycopg2.Error as e:
        print(f"\n✗ TABLE ACCESS: FAILED")
        print(f"\nError: {e}")
        
        print("\n" + "=" * 100)
        print("PERMISSION ISSUE DETECTED")
        print("=" * 100)
        print("""
The service account 'dmp_fcr_ai_development_prod_read' CAN connect to Redshift,
but CANNOT read the ODP table 'dp_cust_pers_engagement_dly'.

POSSIBLE CAUSES:
  1. User lacks SELECT permissions on the table
  2. User lacks USAGE permission on the 'odp' schema
  3. Table or schema ownership issues

SOLUTION - Ask Redshift Admin to execute:

  GRANT USAGE ON SCHEMA odp TO dmp_fcr_ai_development_prod_read;
  GRANT SELECT ON ALL TABLES IN SCHEMA odp TO dmp_fcr_ai_development_prod_read;
  ALTER DEFAULT PRIVILEGES IN SCHEMA odp 
    GRANT SELECT ON TABLES TO dmp_fcr_ai_development_prod_read;

After permissions are granted, re-run this test.
""")
        
        cursor.close()
        conn.close()

except psycopg2.OperationalError as e:
    print(f"\n✗ CONNECTION FAILED: {e}")
    print("""
Cannot connect to Redshift. Possible reasons:
  • Incorrect hostname or port
  • Network connectivity issue
  • Credentials are wrong
  • Service account is locked/expired
  • Security group rules need update

Check:
  1. Redshift endpoint is reachable
  2. .env file has correct credentials
  3. AWS security groups allow port 5439
""")

except Exception as e:
    print(f"\n✗ ERROR: {e}")

