import pkg from 'pg';
const { Client } = pkg;
import dotenv from 'dotenv';

dotenv.config();

const client = new Client({
  host: process.env.REDSHIFT_HOST,
  port: process.env.REDSHIFT_PORT,
  database: process.env.REDSHIFT_DB,
  user: process.env.REDSHIFT_USER,
  password: process.env.REDSHIFT_PASSWORD,
  ssl: true,
});

console.log('🔗 Attempting Redshift connection...');
console.log(`Host: ${process.env.REDSHIFT_HOST}`);
console.log(`User: ${process.env.REDSHIFT_USER}`);
console.log(`DB: ${process.env.REDSHIFT_DB}\n`);

client.connect((err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    process.exit(1);
  }
  
  console.log('✅ Connected successfully!\n');
  
  // Test query 1: Simple connectivity test
  client.query('SELECT CURRENT_USER, CURRENT_DATABASE, VERSION()', (err, res) => {
    if (err) {
      console.error('❌ Query failed:', err.message);
    } else {
      console.log('✅ Query successful!');
      console.log(`Current User: ${res.rows[0].current_user}`);
      console.log(`Database: ${res.rows[0].current_database}`);
    }
    
    // Test query 2: Schema access
    client.query('SELECT COUNT(*) as row_count FROM odp.dp_cust_pers_engagement_dly LIMIT 1', (err2, res2) => {
      if (err2) {
        console.warn('\n⚠️  Schema access issue:', err2.message);
        console.log('ℹ️  You may need to GRANT permissions on the odp schema to this user');
      } else {
        console.log(`Table row count: ${res2.rows[0].row_count}`);
      }
      
      client.end();
      process.exit(err || err2 ? 1 : 0);
    });
  });
});
