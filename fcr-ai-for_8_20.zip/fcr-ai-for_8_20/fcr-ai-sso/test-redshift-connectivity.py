#!/usr/bin/env python3
"""
Test Redshift connectivity with service account credentials
Tests ODP table access and runs sample queries
"""

import psycopg2
from psycopg2 import sql
import sys
from datetime import datetime

# Redshift connection parameters
config = {
    'host': 'itx-ags-aw-rs-cl-01.cku868xglwj7.us-east-1.redshift.amazonaws.com',
    'port': 5439,
    'database': 'awprdrsdb',
    'user': 'dmp_fcr_ai_development_prod_read',
    'password': 'fPmzkv-12rfF',
    'sslmode': 'require'
}

print("=" * 80)
print("REDSHIFT CONNECTIVITY TEST")
print("=" * 80)
print(f"\nTest Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Host: {config['host']}")
print(f"Database: {config['database']}")
print(f"User: {config['user']}")
print(f"Port: {config['port']}")

# Test 1: Connection
print("\n" + "=" * 80)
print("TEST 1: Database Connection")
print("=" * 80)

try:
    conn = psycopg2.connect(**config)
    cursor = conn.cursor()
    print("✓ Connected to Redshift successfully!")
    
    # Get connection info
    cursor.execute("SELECT current_database(), current_user, version()")
    result = cursor.fetchone()
    print(f"✓ Database: {result[0]}")
    print(f"✓ User: {result[1]}")
    print(f"✓ Version: {result[2][:60]}...")
    
except Exception as e:
    print(f"✗ Connection failed: {e}")
    sys.exit(1)

# Test 2: Schema and Table Access
print("\n" + "=" * 80)
print("TEST 2: ODP Schema & Table Access")
print("=" * 80)

try:
    # Check if odp schema exists
    cursor.execute("""
        SELECT schema_name 
        FROM information_schema.schemata 
        WHERE schema_name = 'odp'
    """)
    result = cursor.fetchone()
    if result:
        print("✓ ODP schema found!")
    else:
        print("✗ ODP schema NOT found!")
        
    # Check if table exists
    cursor.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'odp' 
        AND table_name = 'dp_cust_pers_engagement_dly'
    """)
    result = cursor.fetchone()
    if result:
        print("✓ Table 'dp_cust_pers_engagement_dly' found in ODP schema!")
    else:
        print("✗ Table NOT found!")
        
except Exception as e:
    print(f"✗ Schema check failed: {e}")

# Test 3: Table Structure
print("\n" + "=" * 80)
print("TEST 3: Table Structure & Columns")
print("=" * 80)

try:
    cursor.execute("""
        SELECT column_name, data_type, ordinal_position
        FROM information_schema.columns
        WHERE table_schema = 'odp'
        AND table_name = 'dp_cust_pers_engagement_dly'
        ORDER BY ordinal_position
        LIMIT 15
    """)
    
    columns = cursor.fetchall()
    if columns:
        print(f"✓ Found {len(columns)} columns (showing first 15):\n")
        for col in columns:
            print(f"  {col[2]:2d}. {col[0]:40s} | {col[1]}")
    else:
        print("✗ No columns found!")
        
except Exception as e:
    print(f"✗ Column check failed: {e}")

# Test 4: Row Count
print("\n" + "=" * 80)
print("TEST 4: Data Access - Row Count")
print("=" * 80)

try:
    cursor.execute("""
        SELECT COUNT(*) as total_rows
        FROM odp.dp_cust_pers_engagement_dly
    """)
    result = cursor.fetchone()
    print(f"✓ Total rows in table: {result[0]:,}")
    
except Exception as e:
    print(f"✗ Row count query failed: {e}")

# Test 5: Sample Data Query
print("\n" + "=" * 80)
print("TEST 5: Sample Data - First 5 FCRs")
print("=" * 80)

try:
    cursor.execute("""
        SELECT 
            survey_target_id,
            rep_first_nm,
            rep_last_nm,
            ta,
            COUNT(*) as question_count,
            MIN(acty_dt) as coaching_date
        FROM odp.dp_cust_pers_engagement_dly
        WHERE chnl = 'SURVEY'
            AND (LOWER(engagement_title) LIKE '%coaching%' 
                 OR LOWER(engagement_title) LIKE '%fcr%')
            AND survey_target_id IS NOT NULL
            AND (LOWER(engagement_title) LIKE '%msl%' 
                 OR LOWER(engagement_title) LIKE '%vese%')
        GROUP BY survey_target_id, rep_first_nm, rep_last_nm, ta
        ORDER BY coaching_date DESC
        LIMIT 5
    """)
    
    rows = cursor.fetchall()
    if rows:
        print(f"✓ Retrieved {len(rows)} sample FCRs:\n")
        for i, row in enumerate(rows, 1):
            print(f"  {i}. FCR ID: {row[0]}")
            print(f"     Coachee: {row[1]} {row[2]}")
            print(f"     TA: {row[3]}")
            print(f"     Questions: {row[4]}")
            print(f"     Coaching Date: {row[5]}")
            print()
    else:
        print("✗ No data returned!")
        
except Exception as e:
    print(f"✗ Sample data query failed: {e}")

# Test 6: Filter & Analytics Query
print("=" * 80)
print("TEST 6: Analytics Query - MSL Summary Stats")
print("=" * 80)

try:
    cursor.execute("""
        SELECT
            COUNT(DISTINCT survey_target_id) as total_fcrs,
            COUNT(DISTINCT rep_wwid) as total_msls,
            COUNT(DISTINCT ta) as therapeutic_areas,
            COUNT(DISTINCT reg_nm) as regions,
            COUNT(DISTINCT CASE 
                WHEN LOWER(survey_target_status) LIKE '%submitted%' 
                THEN survey_target_id END) as submitted_fcrs,
            COUNT(DISTINCT CASE 
                WHEN LOWER(survey_target_status) LIKE '%saved%' 
                OR LOWER(survey_target_status) LIKE '%draft%'
                THEN survey_target_id END) as draft_fcrs
        FROM odp.dp_cust_pers_engagement_dly
        WHERE chnl = 'SURVEY'
            AND (LOWER(engagement_title) LIKE '%coaching%' 
                 OR LOWER(engagement_title) LIKE '%fcr%')
            AND survey_target_id IS NOT NULL
            AND (LOWER(engagement_title) LIKE '%msl%' 
                 OR LOWER(engagement_title) LIKE '%vese%')
    """)
    
    result = cursor.fetchone()
    if result:
        print("✓ Analytics query successful!\n")
        print(f"  Total FCRs:           {result[0]:>5,}")
        print(f"  Total MSLs:           {result[1]:>5,}")
        print(f"  Therapeutic Areas:    {result[2]:>5,}")
        print(f"  Regions:              {result[3]:>5,}")
        print(f"  Submitted FCRs:       {result[4]:>5,}")
        print(f"  Draft FCRs:           {result[5]:>5,}")
    else:
        print("✗ No data returned!")
        
except Exception as e:
    print(f"✗ Analytics query failed: {e}")

# Test 7: PINS Data Query
print("\n" + "=" * 80)
print("TEST 7: PINS Data Access - Training Flags")
print("=" * 80)

try:
    cursor.execute("""
        SELECT
            COUNT(DISTINCT survey_target_id) as fcrs_with_pins,
            SUM(CASE WHEN survey_question_response = 'Yes' THEN 1 ELSE 0 END) as training_needed_count,
            SUM(CASE WHEN survey_question_response = 'No' THEN 1 ELSE 0 END) as training_not_needed
        FROM odp.dp_cust_pers_engagement_dly
        WHERE chnl = 'SURVEY'
            AND (LOWER(engagement_title) LIKE '%coaching%' 
                 OR LOWER(engagement_title) LIKE '%fcr%')
            AND survey_target_id IS NOT NULL
            AND (LOWER(engagement_title) LIKE '%msl%' 
                 OR LOWER(engagement_title) LIKE '%vese%')
            AND survey_question_response IN ('Yes', 'No')
            AND (TRIM(survey_question_text) ILIKE 'plan%'
                 OR TRIM(survey_question_text) ILIKE 'invest%'
                 OR TRIM(survey_question_text) ILIKE 'navigat%'
                 OR TRIM(survey_question_text) ILIKE 'negot%'
                 OR TRIM(survey_question_text) ILIKE 'secure%')
    """)
    
    result = cursor.fetchone()
    if result:
        print("✓ PINS data query successful!\n")
        print(f"  FCRs with PINS data:        {result[0]:>5,}")
        print(f"  Training needed flags:      {result[1]:>5,}")
        print(f"  Training not needed flags:  {result[2]:>5,}")
    else:
        print("✗ No PINS data found!")
        
except Exception as e:
    print(f"✗ PINS query failed: {e}")

# Test 8: TA Breakdown
print("\n" + "=" * 80)
print("TEST 8: Therapeutic Area Breakdown")
print("=" * 80)

try:
    cursor.execute("""
        SELECT
            ta,
            COUNT(DISTINCT survey_target_id) as fcr_count,
            COUNT(DISTINCT rep_wwid) as msl_count
        FROM odp.dp_cust_pers_engagement_dly
        WHERE chnl = 'SURVEY'
            AND (LOWER(engagement_title) LIKE '%coaching%' 
                 OR LOWER(engagement_title) LIKE '%fcr%')
            AND survey_target_id IS NOT NULL
            AND (LOWER(engagement_title) LIKE '%msl%' 
                 OR LOWER(engagement_title) LIKE '%vese%')
        GROUP BY ta
        ORDER BY fcr_count DESC
        LIMIT 10
    """)
    
    rows = cursor.fetchall()
    if rows:
        print(f"✓ TA Breakdown (top 10):\n")
        print(f"  {'TA':^20} | {'FCRs':>8} | {'MSLs':>8}")
        print(f"  {'-'*20}-+-{'-'*8}-+-{'-'*8}")
        for row in rows:
            print(f"  {row[0]:^20} | {row[1]:>8,} | {row[2]:>8,}")
    else:
        print("✗ No TA data found!")
        
except Exception as e:
    print(f"✗ TA query failed: {e}")

# Close connection
cursor.close()
conn.close()

# Final Summary
print("\n" + "=" * 80)
print("CONNECTIVITY TEST COMPLETED SUCCESSFULLY!")
print("=" * 80)
print("\n✓ All tests passed!")
print("✓ Redshift connection is working")
print("✓ ODP table is accessible")
print("✓ Service account has read permissions")
print("✓ MSL/VESE data is available")
print("\nYou are ready to run the FCR AI dashboard!\n")
