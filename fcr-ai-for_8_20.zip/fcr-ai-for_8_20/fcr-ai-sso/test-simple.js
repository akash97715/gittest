import pkg from 'pg';
const { Client } = pkg;
import dotenv from 'dotenv';

dotenv.config();

const client = new Client({
  host: process.env.REDSHIFT_HOST,
  port: process.env.REDSHIFT_PORT,
  database: process.env.REDSHIFT_DB,
  user: process.env.REDSHIFT_USER,
  password: process.env.REDSHIFT_PASSWORD,
  ssl: true,
});

client.connect(async (err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    process.exit(1);
  }
  
  console.log('✅ Connected successfully!');
  console.log(`User: ${process.env.REDSHIFT_USER}`);
  console.log(`Database: ${process.env.REDSHIFT_DB}\n`);
  
  try {
    // Try to list available schemas
    const res = await client.query(`
      SELECT schema_name FROM information_schema.schemata 
      WHERE schema_name NOT IN ('information_schema', 'pg_internal', 'pg_catalog')
      ORDER BY schema_name
    `);
    console.log('📊 Available schemas:');
    res.rows.forEach(row => console.log(`  - ${row.schema_name}`));
  } catch (e) {
    console.error('Error listing schemas:', e.message);
  }
  
  client.end();
});
